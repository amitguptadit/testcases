package com.iag.application.error;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.iag.application.exception.ApplicationServiceException;
import com.iag.application.exception.ServiceException;
import com.iag.application.exception.ValidationServiceException;
import com.google.common.base.Optional;

/**
 * Factory of error. Constructs error corresponding to supplied exception. This factory returns error either of type
 * validation error derived from validation exception({@link ValidationServiceException} ) or its child class and
 * application error derived from application exception({@link ApplicationServiceException} ). Candidate of singleton
 * bean.
 * @author n438106
 */
public final class ErrorFactory {
  private Map<Class<? extends ServiceException>, AbstractErrorFactory> errorTransformerLocator = new HashMap<>();
  private AbstractErrorFactory applicationErrorTransformer = new ApplicationErrorFactory();
  private AbstractErrorFactory validationErrorTransformer = new ValidationErrorFactory();
  private static final String STATUS_CODE_POSTFIX = ".status.code";
  private static final String ERROR_KEY_INITIALS = "err-code-";

  /**
   * Constructs ServiceErrorFactory to create error.
   */
  public ErrorFactory() {
    errorTransformerLocator.put(ApplicationServiceException.class, applicationErrorTransformer);
    errorTransformerLocator.put(ValidationServiceException.class, validationErrorTransformer);
  }

  /**
   * Constructs error object with respect to supplied exception.
   * @param exception {@link ValidationError} for {@link ValidationServiceException} and {@link ApplicationError} for
   *          {@link ApplicationServiceException}. Must not be null.
   * @param contentProvider hook interface. Implementation to be provided by SDU {@link ContentProvider}
   * @return ServiceError.
   */
  public ServiceError createError(final ServiceException exception, final ContentProvider contentProvider) {
    Optional<AbstractErrorFactory> transformer =
        Optional.fromNullable(errorTransformerLocator.get(Optional.fromNullable(exception).get().getClass()));
    return transformer.get().createError(exception, contentProvider,
        StringUtils.trimToEmpty(exception.getOptionalNamespace()));
  }

  /**
   * Get status code with respect to supplied error code.
   * @param exception {@link ValidationError} for {@link ValidationServiceException} and {@link ApplicationError} for
   *          {@link ApplicationServiceException}. Must not be null.
   * @param contentProvider hook interface. Implementation to be provided by SDU {@link ContentProvider}
   * @return
   */
  public String getStatusCode(final ServiceException exception, final ContentProvider contentProvider) {
    String errorStatusCode =
        new StringBuilder().append(ERROR_KEY_INITIALS)
            .append(StringUtils.trimToEmpty(Optional.fromNullable(exception).get().getOptionalNamespace()))
            .append(Optional.fromNullable(exception).get().getCode())
            .append(STATUS_CODE_POSTFIX).toString();
    return contentProvider.getContent(errorStatusCode);
  }
}
