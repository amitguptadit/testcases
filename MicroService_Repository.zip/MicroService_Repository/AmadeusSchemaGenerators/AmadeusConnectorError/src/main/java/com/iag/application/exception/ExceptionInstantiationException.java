package com.iag.application.exception;

/**
 * Exception class to be used when there is an exception while creating ServiceException.
 */
public final class ExceptionInstantiationException extends RuntimeException {

  /**
   * Constructor method.
   * @param e : Throwable object to be passed to parent's constructor.
   */
  public ExceptionInstantiationException(final Throwable e) {
    super(e);
  }

  /**
   * constructor method.
   * @param message : message to be passed to parent's constructor.
   */
  public ExceptionInstantiationException(final String message) {
    super(message);
  }

}
