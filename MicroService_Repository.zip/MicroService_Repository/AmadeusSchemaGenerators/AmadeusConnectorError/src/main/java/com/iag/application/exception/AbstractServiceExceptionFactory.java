package com.iag.application.exception;

interface AbstractServiceExceptionFactory {
  
  /**
   * This method is implemented by concrete classes to create service exception.
   * @param errorCode
   * @param exceptionProvider
   * @return
   */
  ServiceException createServiceException(final String errorCode,
      final ExceptionProvider exceptionProvider);
}
