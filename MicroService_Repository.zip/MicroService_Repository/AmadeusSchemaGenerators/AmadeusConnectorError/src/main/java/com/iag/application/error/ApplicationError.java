package com.iag.application.error;

/**
 * Class to wrap application related error. When an ApplicationServiceException is thrown, this class will be used
 * convert it to application error and will be committed to client as JSON response. Committing the response is the
 * responsibility of the user of the class.
 * @see ServiceError
 */
public final class ApplicationError extends ServiceError {
  /**
   * Constructs ApplicationError with the supplied error code.
   * @param code
   */
  public ApplicationError(final String code) {
    super(code);
  }
}
