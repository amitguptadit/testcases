package com.iag.application.exception;

/**
 * Application exception factory to create application exception.This class is purposefully made package private as
 * its scope is within the package. Client using the error framework should not be aware of this low level
 * implementation.
 * @author n438106
 */
final class ApplicationServiceExceptionFactory implements AbstractServiceExceptionFactory {
  private static final String ERROR_CODE_POSTFIX = ".code";

  @Override
  public ServiceException createServiceException(final String errorCode, final ExceptionProvider exceptionProvider) {
    ApplicationServiceException applicationServiceException =
        new ApplicationServiceException(exceptionProvider.getCode(errorCode + ERROR_CODE_POSTFIX));
    return applicationServiceException;
  }

}
