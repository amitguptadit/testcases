package com.iag.application.exception;


/**
 * Application exception class to encapsulate the cause of application failure. This includes unavailability of down
 * stream services or unavailability of database and application failure because of business constraint too.
 * @see ServiceException
 */
public final class ApplicationServiceException extends ServiceException {
 /**
  * Constructor to instantiate ApplicationServiceException with suppled error code.
  * @param code
  */
  public ApplicationServiceException(final String code) {
    super(code);
  }
  /**
   * Constructor to instantiate ApplicationServiceException with supplied error code and cause.  
   * @param code
   * @param cause
   */
  public ApplicationServiceException(final String code, final Throwable cause) {
    super(code, cause);
  }

}
