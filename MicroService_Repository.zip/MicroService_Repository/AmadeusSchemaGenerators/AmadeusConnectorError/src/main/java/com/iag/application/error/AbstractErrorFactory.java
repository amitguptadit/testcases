package com.iag.application.error;

import com.iag.application.exception.ServiceException;

/**
 * Contract defining prototype of error transformer to be applied on exception.
 * @author n438106
 */
interface AbstractErrorFactory {
  /**
   * Creates the error instance from supplied exception.
   * @param exception
   * @param contentProvider
   * @param namespace
   * @return
   */
  ServiceError createError(final ServiceException exception, final ContentProvider contentProvider,
      final String namespace);

}
