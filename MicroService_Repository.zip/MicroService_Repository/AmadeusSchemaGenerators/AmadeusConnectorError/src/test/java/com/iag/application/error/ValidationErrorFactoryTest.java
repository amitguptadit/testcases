package com.iag.application.error;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.iag.application.exception.ValidationServiceException;

public class ValidationErrorFactoryTest {
  
  private ValidationErrorFactory validationErrorTransformer;
  
  private static final String DEVELOPER_LINK_KEY = "msg-message-business-developer_link";
  private static final String BUSINESS_MESSAGE_KEY_PREFIX = "msg-message-business-";
  private static final String NAMESPACE = "";
  private static final String ERROR_CODE = "REQUEST_INVALID";
  private static final String DEVELOPER_MESSAGE = "www.iag.com";
  private static final String BUSINESS_MESSAGE = "REQUEST_INVALID";
  private static final String PATH = "path";

  @Before
  public void setUp(){
    validationErrorTransformer = new ValidationErrorFactory();
  }
  
  @Test
  public void shouldCreateError(){
    ValidationServiceException validationServiceException = createValidationServiceException();
    ContentProvider contentProvider = createContentProvider();
    ValidationError validationError = (ValidationError)validationErrorTransformer.createError(validationServiceException, contentProvider, NAMESPACE);
    Assert.assertEquals(BUSINESS_MESSAGE, validationError.getBusinessMessage());
    Assert.assertEquals(ERROR_CODE, validationError.getCode());    
    Assert.assertEquals(DEVELOPER_MESSAGE, validationError.getDeveloperMessage());
    Assert.assertNull(validationError.getServiceErrors());
  }
  
  @Test
  public void shouldCreateErrorWithChildError(){
    ValidationServiceException validationServiceException = createValidationServiceException();    
    validationServiceException.addValidationException(new ValidationServiceException(ERROR_CODE));
    ContentProvider contentProvider = createContentProvider();
    ValidationError validationError = (ValidationError)validationErrorTransformer.createError(validationServiceException, 
                    contentProvider, NAMESPACE);
    Assert.assertEquals(BUSINESS_MESSAGE, validationError.getBusinessMessage());
    Assert.assertEquals(ERROR_CODE, validationError.getCode());    
    Assert.assertEquals(DEVELOPER_MESSAGE, validationError.getDeveloperMessage());
    Assert.assertNotNull(validationError.getServiceErrors());
  }
  
  private ValidationServiceException createValidationServiceException() {
    ValidationServiceException validationServiceException = new ValidationServiceException(ERROR_CODE);
    validationServiceException.setDeveloperMessage(DEVELOPER_MESSAGE);
    validationServiceException.setPath(PATH);
    return validationServiceException;
  }
  
  private ContentProvider createContentProvider() {
    ContentProvider contentProvider = new ContentProvider() {      
      @Override
      public String getContent(final String error) {
        if(error.equals(BUSINESS_MESSAGE_KEY_PREFIX+NAMESPACE+ERROR_CODE)){
          return BUSINESS_MESSAGE;
        }
        else  if(error.equals(DEVELOPER_LINK_KEY)){
          return DEVELOPER_MESSAGE;
        }
        return "No_Content";        
      }
    };
    return contentProvider;
  }
}
