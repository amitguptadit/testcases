package com.iag.application.error;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.application.exception.ServiceException;
import com.iag.application.exception.ValidationServiceException;

public class ErrorFactoryTest {
  
  private static final String ERROR_KEY_INITIALS = "err-code-";
  private static final String STATUS_CODE_POSTFIX = ".status.code";
  private static final String DEVELOPER_LINK_KEY = "msg-message-business-developer_link";

  ErrorFactory errorFactory = new ErrorFactory();
  
  @Mock
  ContentProvider contentProvider;
  @Mock
  ServiceException exception;

  @Before
  public void setUp() throws Exception {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void shouldCreateValidationErrorObjectForValidationExceptionHavingNoChild() {
    ValidationServiceException exception = new ValidationServiceException("REQUEST_INVLID");    
    exception.setDeveloperMessage("Request validation failed");
    exception.setPath("/domain/service");        
    Mockito.when(contentProvider.getContent("msg-message-business-"+""+"REQUEST_INVLID")).thenReturn("REQUEST_INVALID");
    Mockito.when(contentProvider.getContent("msg-message-business-developer_link")).thenReturn("www.iag.com");

    ValidationError error = (ValidationError) errorFactory.createError(exception, contentProvider);
    Assert.assertEquals(exception.getCode(), error.getCode());
    Assert.assertEquals(exception.getDeveloperMessage(), error.getDeveloperMessage());
    Assert.assertEquals("REQUEST_INVALID", error.getBusinessMessage());
    Assert.assertEquals("www.iag.com", error.getDeveloperLink());
    Assert.assertNull(error.getServiceErrors());
    Assert.assertEquals("/domain/service", error.getPath());
  }
  
  @Test
  public void shouldThrowExceptionForUnSupportedServiceExceptions() {
    
    class UnSupportedServiceException extends ServiceException{
      
      UnSupportedServiceException(){
        super("REQUEST_INVALID");
      }
    }
    
    UnSupportedServiceException unSupportedServiceException = new  UnSupportedServiceException();
    unSupportedServiceException.setDeveloperMessage("Request validation failed");

    try{
      errorFactory.createError(unSupportedServiceException, contentProvider);
      Assert.fail("This test case must fail against throwing Unrecognized Exception.");
    }catch(Exception e){
      Assert.assertTrue(e instanceof IllegalStateException);
    }
  }
  
  @Test
  public void shouldThrowExceptionForNull() {    
    try{
      errorFactory.createError(null, contentProvider);
      Assert.fail("This test case must fail against found null.");
    }catch(Exception e){
      Assert.assertTrue(e instanceof IllegalStateException);
    }
  }
  
  @Test
  public void shouldGetStatusCode() {
    String expectedOptionalNamespace = "optionalNamespace";
    String expectedExceptionCode = "REQUEST_INVALID";
    Mockito.when(exception.getOptionalNamespace()).thenReturn(expectedOptionalNamespace);
    Mockito.when(exception.getCode()).thenReturn(expectedExceptionCode);    
    String errorStatusCode =
        new StringBuffer().append(ERROR_KEY_INITIALS).append(expectedOptionalNamespace).append(expectedExceptionCode)
            .append(STATUS_CODE_POSTFIX).toString();    
    Mockito.when(contentProvider.getContent(errorStatusCode)).thenReturn(DEVELOPER_LINK_KEY);
    
    String statusCode = errorFactory.getStatusCode(exception, contentProvider);
    Assert.assertNotNull(statusCode);
    Assert.assertEquals(DEVELOPER_LINK_KEY, statusCode);
  }
  
  @Test
  public void shouldThrowExceptionWhenExceptionParameterIsNull() {
    try {
    errorFactory.getStatusCode(null, contentProvider);
    Assert.fail("This test case must fail against found null.");
    } catch (Exception e) {
      Assert.assertTrue(e instanceof IllegalStateException);
    }
    
  }
}
