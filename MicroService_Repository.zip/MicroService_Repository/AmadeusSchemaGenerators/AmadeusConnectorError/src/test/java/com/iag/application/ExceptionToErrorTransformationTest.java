package com.iag.application;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.application.error.ContentProvider;
import com.iag.application.error.ErrorFactory;
import com.iag.application.error.ServiceError;
import com.iag.application.exception.ExceptionFactory;
import com.iag.application.exception.ExceptionInstantiationException;
import com.iag.application.exception.ExceptionProvider;
import com.iag.application.exception.ServiceException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;

public class ExceptionToErrorTransformationTest {

  @Mock
  private ExceptionProvider exceptionProvider;
  @Mock
  private ContentProvider contentProvider;
  private ErrorFactory errorFactory = new ErrorFactory();
  private ExceptionFactory exceptionFactory = new ExceptionFactory();

  @Before
  public void setUp() throws Exception {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void shouldTransformExceptionToValidationError() throws JsonProcessingException {
    String errorCodeForExceptionType = "ncd.error.0025.exception";
    Mockito.when(exceptionProvider.getExceptionClass(errorCodeForExceptionType)).thenReturn(
        "com.iag.application.exception.ValidationServiceException");
    String parentErrorCode = "ncd.error.0025.parent.code";
    Mockito.when(exceptionProvider.getCode(parentErrorCode)).thenReturn(
        "REQUEST_INVALID");
    String thisErrorCode = "ncd.error.0025.code";
    Mockito.when(exceptionProvider.getCode(thisErrorCode)).thenReturn(
        "NAME_INVALID");
    String errorCodeSentFromSDU = "ncd.error.0025";
    ServiceException exception =
        exceptionFactory.createException(errorCodeSentFromSDU, exceptionProvider, Optional.<String>absent());

    System.out.println(exception);
    // Set the path and child error

    Mockito.when(contentProvider.getContent("msg-message-business-" +
        "REQUEST_INVALID")).thenReturn("REQUEST_INVALID");
    Mockito.when(contentProvider.getContent("msg-message-business-developer_link")).thenReturn("www.iag.com");
    Mockito.when(contentProvider.getContent("msg-message-business-NAME_INVALID")).thenReturn("NAME_INVALID");

    ServiceError serviceError = errorFactory.createError(exception, contentProvider);
    ObjectMapper mapper = new ObjectMapper();
    String str = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(serviceError);
    System.out.println(str);
  }

  @Test
  public void shouldTransformApplicationExceptionToApplicationError() throws ExceptionInstantiationException,
      JsonProcessingException {
    String errorCodeFromSDU = "code.ncd.4327";
    String exceptionTypeFinderCode = errorCodeFromSDU + ".exception";
    String errorCode = errorCodeFromSDU + ".code";
    Mockito.when(exceptionProvider.getExceptionClass(exceptionTypeFinderCode)).thenReturn(
        "com.iag.application.exception.ApplicationServiceException");
    Mockito.when(exceptionProvider.getCode(errorCode)).thenReturn(
        "RESOURCE_NOT_FOUND");

    ServiceException exception =
        exceptionFactory.createException(errorCodeFromSDU, exceptionProvider, Optional.<String>absent());
    System.out.println(exception);

    Mockito.when(contentProvider.getContent("msg-message-business-" + "RESOURCE_NOT_FOUND")).thenReturn(
        "RESOURCE_NOT_FOUND");
    Mockito.when(contentProvider.getContent("msg-message-business-developer_link")).thenReturn("www.iag.com");

    ServiceError serviceError = errorFactory.createError(exception, contentProvider);

    ObjectMapper mapper = new ObjectMapper();
    String str = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(serviceError);
    System.out.println(str);

  }

}
