package com.iag.application.error;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.application.exception.ApplicationServiceException;

public class ApplicationErrorFactoryTest {
  
  ApplicationErrorFactory applicationErrorTransformer;
  
  @Mock
  ContentProvider contentProvider;
  
  private static final String DEVELOPER_LINK_KEY = "msg-message-business-developer_link";
  private static final String DEVELOPER_LINK_VALUE = "developer.iag.com";
  private static final String BUSINESS_MESSAGE_KEY_PREFIX = "msg-message-business-";
  private static final String NAMESPACE = "service-namespace";
  private static final String ERROR_CODE = "code.ncd.4327";
  private static final String DEVELOPER_MESSAGE = "www.iag.com";
  private static final String BUSINESS_MESSAGE = "Request Invalid";
  
  @Before
  public void setUp(){
    MockitoAnnotations.initMocks(this);
    applicationErrorTransformer = new ApplicationErrorFactory();    
  }
  
  @Test
  public void shouldCreateError(){
    ApplicationServiceException exception = createApplicationServiceException();
    Mockito.when(contentProvider.getContent(BUSINESS_MESSAGE_KEY_PREFIX
        + StringUtils.trimToEmpty(NAMESPACE) + exception.getCode())).thenReturn(NAMESPACE+BUSINESS_MESSAGE);
    Mockito.when(contentProvider.getContent(DEVELOPER_LINK_KEY)).thenReturn(DEVELOPER_LINK_VALUE);
    
    ServiceError serviceError = applicationErrorTransformer.createError(exception, contentProvider, NAMESPACE);
    Assert.assertNotNull(serviceError);
    Assert.assertEquals(NAMESPACE+BUSINESS_MESSAGE, serviceError.getBusinessMessage());
    Assert.assertEquals(DEVELOPER_LINK_VALUE, serviceError.getDeveloperLink());
    Assert.assertEquals(ERROR_CODE, serviceError.getCode());    
    Assert.assertEquals(DEVELOPER_MESSAGE, serviceError.getDeveloperMessage());
  }  

  private ApplicationServiceException createApplicationServiceException() {
    ApplicationServiceException applicationServiceException = new ApplicationServiceException(ERROR_CODE);
    applicationServiceException.setDeveloperMessage(DEVELOPER_MESSAGE);
    return applicationServiceException;
  }
}
