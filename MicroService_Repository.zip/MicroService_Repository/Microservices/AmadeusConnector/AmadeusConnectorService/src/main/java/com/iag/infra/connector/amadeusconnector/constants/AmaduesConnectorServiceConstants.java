package com.iag.infra.connector.amadeusconnector.constants;

/**
 * AmaduesConnectorServiceConstants class is used for constants declaration.
 */
public class AmaduesConnectorServiceConstants {

    public static final String ERROR_CODE = "err-code-";
    public static final String COUNTRY_CODE_PARAM = "location";
    public static final String CHANNEL_PARAM = "channel";
    public static final String SCOPE_PARAM = "scope";
    public static final String SECURITY_TOKEN_PARAM = "tokenNumber";

    public static final String STATUS_PARAM = "status";
    public static final String SESSION_ID_PARAM = "sessionIdentifier";
    public static final String SESSION_POOL_PARAM = "session-pool";
    public static final String DEVELOPER_MSG_ERROR_CODE_KEY = "developer_msg_error_code.";
    public static final String DOT_SYMBOL = ".";
    public static final String AMADEUS_GATEWAY_WEBURL = "amedeus.gateway.webUrl";
    public static final String AMADEUS_SIGNIN_MARSHALLER = "amedeus.gateway.signIn.marshaller";
    public static final String AMADEUS_SIGNIN_UNMARSHALLER = "amedeus.gateway.signIn.unMarshaller";
    public static final String AMADEUS_SIGNOUT_MARSHALLER = "amedeus.gateway.signOut.marshaller";
    public static final String AMADEUS_SIGNOUT_UNMARSHALLER = "amedeus.gateway.signOut.unMarshaller";


    public static final String VALID_RESPONSE_CODE = "VALID";
    public static final String DEVICE_REGEX = "^[a-zA-Z0-9-()/ ]*$";
    public static final String TOKEN_NUMBER_REGEX = "^[a-zA-Z0-9]*$";
    public static final String SESSION_IDENTIFIER_REGEX = "^[a-zA-Z0-9]*$";
    public static final String SCOPE_REGEX = "^[a-zA-Z]{1,20}+$";
    public static final String COUNTRY_CODE_REGEX = "^[a-zA-Z]{2,3}$";
    public static final String CHANNEL_REGEX = "^[a-zA-Z]{1,20}+$";
    public static final String DATA_INVALID = "Data Invalid";
    public static final String MANDATORY_DATA_MISSING = "Mandatory Data Missing";
    public static final String WAIT_TIMEOUT = "Timeout waiting for idle object";
    public static final String CONFIG_ERROR_JSON_LOCATION = "classpath:config/error.json";
    public static final String SESSION_NODE_KEY = "Session";
    public static final String SESSION_ID_NODE_KEY = "SessionId";
    public static final String SEQUENCE_NUMBER_NODE_KEY = "SequenceNumber";
    public static final String SECURITY_TOKEN_NODE_KEY = "SecurityToken";
    public static final String MESSAGE_CONFIGURATION_KEYWORD = "msg-";
    public static final String KEY_SEPARATOR_DOT = ".";
    public static final String KEY_SEPARATOR = "-";

    public static final int HTTP_SENDER_READ_TIME_OUT = 1000;
    public static final int HTTP_SENDER_CONNECTOR_TIME_OUT = 10000;

    public static final String HTTP_SENDER_MAX_HOSTS = "5";

    public static final String HTTP_SENDER_WILDCARD_HOSTS = "*";

    public static final String MISSING_CONFIG_DATA = "Missing Config Data";

    public static final String REQUEST_INVALID = "Request Invalid";

    public static final String LOCATION_PARAM = "location";
	public static final String DEVICE_PARAM = "device";
	public static final String DEFAULT_DEVICE="DEFAULT";
    
    

}