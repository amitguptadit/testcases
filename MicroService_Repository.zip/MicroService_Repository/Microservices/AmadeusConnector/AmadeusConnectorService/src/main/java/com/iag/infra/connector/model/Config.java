package com.iag.infra.connector.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Config {

	@JsonProperty("resource")
	private String resource;
	@JsonProperty("identifier")
	private String identifier;
	@JsonProperty("version")
	private String version;
	@JsonProperty("configurationNamespaces")
	private List<ConfigurationNamespaces> configurationNamespaces;


	@JsonProperty("resource")
	public String getResource() {
		return resource;
	}

	@JsonProperty("resource")
	public void setResource(String resource) {
		this.resource = resource;
	}

	@JsonProperty("identifier")
	public String getIdentifier() {
		return identifier;
	}

	@JsonProperty("identifier")
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	@JsonProperty("version")
	public String getVersion() {
		return version;
	}

	@JsonProperty("version")
	public void setVersion(String version) {
		this.version = version;
	}

	@JsonProperty("configurationNamespaces")
	public List<ConfigurationNamespaces> getConfigurationNamespaces() {
		return configurationNamespaces;
	}


	@JsonProperty("configurationNamespaces")
	public void setConfigurationNamespaces(List<ConfigurationNamespaces> configurationNamespaces) {
		this.configurationNamespaces = configurationNamespaces;
	}

//	@Override
//	public String toString() {
//		return "Configuration [resource=" + resource + ", identifier=" + identifier + ", version=" + version
//				+ ", configurationNamespaces=" + configurationNamespaces + ", links=" + _links + "]";
//	}

}