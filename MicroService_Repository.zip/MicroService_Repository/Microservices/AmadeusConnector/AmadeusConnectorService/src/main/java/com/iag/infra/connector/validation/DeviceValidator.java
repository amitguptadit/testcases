package com.iag.infra.connector.validation;

import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;

@Component
public class DeviceValidator {
private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

@Autowired
public DeviceValidator(final ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
	this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;

}

/**
 * 
 * @param validationServiceExceptionList
 * @param countryCode
 * @return
 */

	public ValidationServiceException validate(final String device, String path) {
		ValidationServiceException validationServiceException = null;
		if (!StringUtils.isEmpty(device)) {
			Pattern countryCodeMatcher = Pattern.compile(AmaduesConnectorServiceConstants.DEVICE_REGEX);
			if (!countryCodeMatcher.matcher(device).matches()) {
				validationServiceException = validationServiceExceptionGenerator.createValidationError(AmadeusSeviceErrorCode.DATA_INVALID.name(),path,AmaduesConnectorServiceConstants.DATA_INVALID);
			}
		}
		return validationServiceException;
	}
}
