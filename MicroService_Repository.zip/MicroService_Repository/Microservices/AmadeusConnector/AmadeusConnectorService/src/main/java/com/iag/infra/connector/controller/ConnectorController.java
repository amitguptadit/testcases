package com.iag.infra.connector.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.service.ConnectorService;
import com.iag.infra.connector.service.pool.SessionPoolFactory;
import com.iag.infra.connector.validation.AmadeusConnectorGetRequestValidator;
import com.iag.infra.connector.validation.AmadeusConnectorPatchRequestValidator;

/**
 * This controller class is used to connect Amadeus connector service.
 */
@RestController
public class ConnectorController {
	@Autowired
	private ConnectorService connectorService;
	private static final Logger LOG = LoggerFactory.getLogger(SessionPoolFactory.class); 
	
	@Autowired
	private AmadeusConnectorGetRequestValidator amadeusConnectorGetRequestValidator;
	
	@Autowired
	private AmadeusConnectorPatchRequestValidator amadeusConnectorPatchRequestValidator;
	
	/**
	 * Rest GET operation that take channel,country-code and scope in
	 * Query parameter.
	 * 
	 * @param countrycode
	 * @param channel
	 * @param scope
	 * @return Session.
	 * @throws Exception
	 */
	@GetMapping(value = "/sessions", produces = "application/json; charset=utf-8")
	public ResponseEntity<Session> getSession(@RequestParam() Map<String, String> reqParams,
			@RequestHeader final Map<String, String> headerValueMap)  {
		LOG.info("getSession  start -----------------");
		amadeusConnectorGetRequestValidator.validateGetSessionRequest(reqParams);
		Session session = connectorService.getSession(reqParams);
		LOG.info("getSession end -----------------");
		return new ResponseEntity<Session>(session, HttpStatus.OK);
	}

	/**
	 * Rest PATCH operation that take session in requestBody.
	 * 
	 * @param session
	 * @throws Exception
	 */
	@PatchMapping(value = "/sessions", headers = "Accept=application/json", consumes = {
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity releaseSession(@RequestBody Session session) {
		amadeusConnectorPatchRequestValidator.validateReleaseSessionRequest(session);
		connectorService.releaseSession(session);
		LOG.info("release session working successfully");
		return new ResponseEntity(HttpStatus.NO_CONTENT);

	}
}
