package com.iag.infra.connector.service.pool;
import javax.xml.soap.SOAPException;

import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.model.AmadeusConnectionDetails;
import com.iag.infra.connector.repository.SessionProviderRepository;

/**
 * Purpose of this class is to manage creation and destroy the session in pool.
 */
public class SessionFactory extends BasePooledObjectFactory<Session> {
	private static final Logger LOG = LoggerFactory.getLogger(SessionFactory.class);

	private  SessionProviderRepository sessionProviderRepository;
	private  AmadeusConnectionDetails amadeusConnectionDetails;
	private  SessionPoolIdentifier sessionPoolIdentifier;
	public SessionFactory() {
	}
	
    /**
     * Constructor to initialize class attributes.
     * 
     * @param sessionProviderRepository
     * @param amadeusConnectionDetails
     */
	public SessionFactory(final SessionProviderRepository sessionProviderRepository,
			final AmadeusConnectionDetails amadeusConnectionDetails, SessionPoolIdentifier sessionPoolIdentifier) {
		this.sessionProviderRepository = sessionProviderRepository;
		this.amadeusConnectionDetails = amadeusConnectionDetails;
		this.sessionPoolIdentifier = sessionPoolIdentifier;
	}

	@Override
	public Session create() {
        LOG.info("create method is calling");
		return null;
	}

	@Override
	public PooledObject<Session> wrap(Session paramT) {
		return null;
	}
    
	@Override
    public void activateObject(final PooledObject<Session> session) {		
			LOG.info("activateObject method is calling"); 
    }

	@Override
    public void destroyObject(final PooledObject<Session> session) {		

			LOG.info("destroyObject method is calling");
        LOG.info("Going to destroy Object of session- > SessionIdentifier {} ", session.getObject()
                .getSessionIdentifier());
			sessionProviderRepository.signOut(session.getObject(),amadeusConnectionDetails);

    }
	@Override
	public PooledObject<Session> makeObject() throws SOAPException {
		LOG.info("amadeusConnectionDetails in makeObject in AmadeusSessionFactory. {}", amadeusConnectionDetails);
		return sessionProviderRepository.signIn(amadeusConnectionDetails, sessionPoolIdentifier);
	}

}
