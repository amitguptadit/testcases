package com.iag.infra.connector.repository.impl;

import java.io.IOException;

import javax.xml.soap.SOAPException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.support.MarshallingUtils;

import com.amadeus.xml.vlsslr_06_1_1a.SecurityAuthenticateReply;
import com.amadeus.xml.vlsslr_06_1_1a.SecurityAuthenticateReply.ErrorSection;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ApplicationServiceExceptionGenerator;
import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.model.AmedeusResponseDetails;
import com.iag.infra.connector.repository.impl.mapper.request.AmedeusSignInRequestHeaderMapper;
import com.iag.infra.connector.repository.impl.mapper.request.AmedeusSignOutRequestHeaderMapper;
import com.iag.infra.connector.repository.impl.mapper.response.AmedeusSignInResponseHeaderMapper;

/**
 * The class AmadeusWebServiceGateway.
 */
@Component
public class AmadeusWebServiceGateway {
	@Autowired
	private ApplicationServiceExceptionGenerator applicationServiceExceptionGenerator;

	@Autowired
	Jaxb2Marshaller amadeusMarshaller;
	@Autowired
	Jaxb2Marshaller amadeusUnMarshaller;

	@Autowired
	private AmedeusSignOutRequestHeaderMapper amedeusSignOutRequestHeaderMapper;
	@Autowired
	private AmedeusSignInResponseHeaderMapper amedeusSignInResponseHeaderMapper;
	@Autowired
	private AmedeusSignInRequestHeaderMapper amedeusSignInRequestHeaderMapper;
	private static final Logger LOG = LoggerFactory.getLogger(AmadeusWebServiceGateway.class);

    @Autowired
    private WebServiceTemplate amadeusWebServiceTemplate;



	/**
	 * getWebServiceResponse.
	 * 
	 * @param requestObject
	 * @param soapActionUri
	 * @return response
	 */
	public AmedeusResponseDetails getWebServiceResponseForSignIn(final Object requestObject,final String soapActionUri, final String messageId,final String deviceId) {
		AmedeusResponseDetails response = null;
		try {
			response = getAmadeusWebServiceResponse(requestObject, soapActionUri,messageId,deviceId);
		} catch (Exception exception) {                           
			LOG.info("exception occured while calling Amadeus SignIn-> " + exception.getMessage());
			throwWebServiceException(exception);
		}
		if (hasError(response)) {
			throw applicationServiceExceptionGenerator.createAplicationExceptionWithDeveloperMessage(
					AmadeusSeviceErrorCode.REQUEST_UNAUTHORIZED.name(),
					AmaduesConnectorServiceConstants.DEVELOPER_MSG_ERROR_CODE_KEY + getResponseErrorCode(response));
		}
		return response;
	}

	public Object getWebServiceResponseForSignOut(final Object requestObject, final String soapActionUri,
			final Session session) {
		Object response = null;
		try {
			response = amadeusWebServiceTemplate.marshalSendAndReceive(requestObject, new WebServiceMessageCallback() { 
				/**
				 * This method is used to set the SOAP URI at runtime.
				 * 
				 * @param message
				 */
				public void doWithMessage(final WebServiceMessage message) {
					SoapMessage soapMessage = (SoapMessage) message;
					amedeusSignOutRequestHeaderMapper.mapHeaders(soapMessage, soapActionUri, session);
					soapMessage.setSoapAction(soapActionUri);
				}
			});
		} catch (Exception exception) {
            LOG.info("exception occured while calling Amadeus SignOut ->{} ", exception.getMessage());
			throwWebServiceException(exception);
		}
		return response;
	}

	private AmedeusResponseDetails getAmadeusWebServiceResponse(final Object requestObject,final String soapActionUri, final String messageId,final String deviceId) {

		final AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
		LOG.info("calling Amadeus Service with Request " + requestObject);
		return amadeusWebServiceTemplate.sendAndReceive(new WebServiceMessageCallback() {
			public void doWithMessage(WebServiceMessage message) throws IOException {
				SaajSoapMessage soapMessage = (SaajSoapMessage) message;
				amedeusSignInRequestHeaderMapper.mapHeaders(soapMessage, soapActionUri,amadeusWebServiceTemplate.getDestinationProvider().getDestination().toString(),deviceId, messageId);
				soapMessage.setSoapAction(soapActionUri);
				MarshallingUtils.marshal(amadeusMarshaller, requestObject, message);
			}
		}, new WebServiceMessageExtractor<AmedeusResponseDetails>() {
			public AmedeusResponseDetails extractData(WebServiceMessage message) throws IOException {
				SecurityAuthenticateReply responseBody =(SecurityAuthenticateReply) MarshallingUtils.unmarshal(amadeusUnMarshaller, message);
				amedeusResponseDetails.setSoapResponse(responseBody);
				 AmedeusResponseDetails response=null;
				try {
					    response = amedeusSignInResponseHeaderMapper.map(message, amedeusResponseDetails);
				} catch (SOAPException e) {
					throwWebServiceException(e);
				}
				return response;

			}
		});
		

	}

	/**
	 * This private method is responsible to handle the webServiceException if
	 * any in response from AmadeusWebSerfvice. It should throw the exception
	 * based on the nature.
	 * 
	 * @param exception
	 *            WebServiceIOException
	 */
	private void throwWebServiceException(final Exception exception) {
        throw applicationServiceExceptionGenerator.createApplicationExceptionWithErrorMessage(
                AmadeusSeviceErrorCode.SYSTEM_UNAVAILABLE.name(), exception.getMessage());

	}

	private boolean hasError(final AmedeusResponseDetails amedeusResponseDetails) {
		boolean hasError = false;
		final SecurityAuthenticateReply soapResponse = (SecurityAuthenticateReply) amedeusResponseDetails.getSoapResponse();
        if (soapResponse.getProcessStatus() == null && soapResponse.getErrorSection() != null) {
			hasError = true;
		}
		return hasError;
	}

    private String getResponseErrorCode(final AmedeusResponseDetails amedeusResponseDetails) {
        String errorCode = StringUtils.EMPTY;
        final ErrorSection errorSection = ((SecurityAuthenticateReply) amedeusResponseDetails.getSoapResponse()).getErrorSection();
        if (errorSection != null) {
            errorCode = errorSection.getApplicationError().getErrorDetails().getErrorCode();
        }
        return errorCode;
    }


}
