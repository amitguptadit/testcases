package com.iag.infra.connector.amadeusconnector.error;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.exception.ApplicationServiceException;
import com.iag.infra.connector.utility.AmadeusConnectorServiceUtility;

@Component
public class ApplicationServiceExceptionGenerator {

	 private final AmadeusConnectorServiceUtility amadeusConnectorServiceUtility;
	 
	 @Autowired
		public ApplicationServiceExceptionGenerator(final AmadeusConnectorServiceUtility amadeusConnectorServiceUtility ){
			this.amadeusConnectorServiceUtility=amadeusConnectorServiceUtility;
			
		}
		
	
	
	public ApplicationServiceException createAplicationExceptionWithDeveloperMessage(final String code, final String developerMsg){
		ApplicationServiceException exception=new  ApplicationServiceException(code);
		exception.setDeveloperMessage(amadeusConnectorServiceUtility.getMessageConfigurationValue(developerMsg));
		return exception;
	}

    public ApplicationServiceException createApplicationExceptionWithErrorMessage(final String code,
            final String errorMsg) {
        ApplicationServiceException ex = new ApplicationServiceException(code);
        ex.setDeveloperMessage(errorMsg);
        return ex;
    }
}
