package com.iag.infra.connector.repository;



import javax.xml.soap.SOAPException;

import org.apache.commons.pool2.PooledObject;

import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.model.AmadeusConnectionDetails;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

/**
 * This class defines various operations wrt Authentication for getting Amadeus
 * session.
 */

public interface SessionProviderRepository {

	/**
	 * Member function to perform Authentication to get the AmadeuSession
	 * Information after signIn. This session information is use to perform any
	 * other Amadeus transactions.
	 * 
	 * @param amadeusConnectionDetails
	 * @return session Session
	 * @throws SOAPException 
	 */
	public PooledObject<Session> signIn(AmadeusConnectionDetails amadeusConnectionDetails,SessionPoolIdentifier sessionPoolIdentifier) throws SOAPException;

	/**
	 * Member function used to sign-out for a particular session which is already
	 * created by the signIn().
	 * 
	 * @return boolean
	 */
	public void signOut(Session session,AmadeusConnectionDetails amadeusConnectionDetails);

}
