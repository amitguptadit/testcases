package com.iag.infra.connector.service.pool;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;

public class SessionPoolIdentifier {

	private String countrycode;
	private String channel;
	private String scope;
	private String device;

	public SessionPoolIdentifier(String countrycode, String channel, String scope) {
		this.countrycode = countrycode;
		this.channel = channel;
		this.scope = scope;
	}

    public String getSessionPoolIdentifierKey() {
        return (this.getCountrycode() + AmaduesConnectorServiceConstants.DOT_SYMBOL + this.getScope()
                + AmaduesConnectorServiceConstants.DOT_SYMBOL + this.getChannel()+AmaduesConnectorServiceConstants.DOT_SYMBOL+(device==null?AmaduesConnectorServiceConstants.DEFAULT_DEVICE:device));
    }

    public String getDevice() {
		return device;
	}
    
    public void setDevice(String device) {
		this.device = device;
	}
    
	public String getCountrycode() {
		return countrycode;
	}

	public void setCountrycode(String countrycode) {
		this.countrycode = countrycode;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public SessionPoolIdentifier() {
		super();

	}

	@Override
	public boolean equals(final Object other) {
		return EqualsBuilder.reflectionEquals(this, other);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}
}
