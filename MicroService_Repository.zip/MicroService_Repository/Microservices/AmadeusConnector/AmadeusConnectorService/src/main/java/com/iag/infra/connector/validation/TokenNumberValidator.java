package com.iag.infra.connector.validation;

import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;

@Component
public class TokenNumberValidator  {
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	@Autowired
	public TokenNumberValidator(ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * 
	 * @param validationServiceExceptionList
	 * @param channel
	 * @return
	 */
    public ValidationServiceException validate(final String tokenNumber) {
        ValidationServiceException validationServiceException = null;
        if (StringUtils.isEmpty(tokenNumber)) {
            validationServiceException = validationServiceExceptionGenerator.createValidationError(
                    AmadeusSeviceErrorCode.MANDATORY_DATA_MISSING.name(),
                    AmaduesConnectorServiceConstants.SECURITY_TOKEN_PARAM,
                    AmaduesConnectorServiceConstants.MANDATORY_DATA_MISSING);

        } else {
            Pattern tokenNumberMatcher = Pattern.compile(AmaduesConnectorServiceConstants.TOKEN_NUMBER_REGEX);

            if (!tokenNumberMatcher.matcher(tokenNumber).matches()) {
                validationServiceException = validationServiceExceptionGenerator.createValidationError(
                        AmadeusSeviceErrorCode.DATA_INVALID.name(),
                        AmaduesConnectorServiceConstants.SECURITY_TOKEN_PARAM,
                        AmaduesConnectorServiceConstants.DATA_INVALID);
            }
        }
        return validationServiceException;
    }
}
