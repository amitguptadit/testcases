package com.iag.infra.connector.model;


import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.springframework.stereotype.Component;


/**
 * The Class AmadeusSessionPoolConfiguration.
 */
@SuppressWarnings("serial")
@Component
public class AmadeusSessionPoolConfiguration implements Serializable {

	private AmadeusConnectionDetails amadeusConnectionDetails;
	private int maxPoolSize;
	private int minPoolSize;
	private int defaultPoolSize;
	private long inactivityTimeOut;
	private long waitingTimeOut;
	private long poolCleanFrequency;
	private String supplierId;
	private boolean isAgencyOfficeId;

	public int getPoolSize() {
		return maxPoolSize;
	}

	public void setPoolSize(final int poolSize) {
		this.maxPoolSize = poolSize;
	}

	public void setMinimumPoolSize(final int poolSize) {
		this.minPoolSize = poolSize;
	}

	public int getMinimumPoolSize() {
		return minPoolSize;
	}

	public int getDefaultPoolSize() {
		return defaultPoolSize;
	}

	public void setDefaultPoolSize(final int defaultPoolSize) {
		this.defaultPoolSize = defaultPoolSize;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(final String supplierId) {
		this.supplierId = supplierId;
	}

	public AmadeusConnectionDetails getAmadeusConnectionDetails() {
		return amadeusConnectionDetails;
	}

	public void setAmadeusConnectionDetails(final AmadeusConnectionDetails amadeusConnectionDetails) {
		this.amadeusConnectionDetails = amadeusConnectionDetails;
	}

	public int getMaxPoolSize() {
		return maxPoolSize;
	}

	public void setMaxPoolSize(final int maxPoolSize) {
		this.maxPoolSize = maxPoolSize;
	}

	public long getInactivityTimeOut() {
		return inactivityTimeOut;
	}

	public void setInactivityTimeOut(final long inactivityTimeOut) {
		this.inactivityTimeOut = inactivityTimeOut;
	}

	public long getWaitingTimeOut() {
		return waitingTimeOut;
	}

	public void setWaitingTimeOut(final long waitingTimeOut) {
		this.waitingTimeOut = waitingTimeOut;
	}

	public long getPoolCleanFrequency() {
		return poolCleanFrequency;
	}

	public void setPoolCleanFrequency(final long poolCleanFrequency) {
		this.poolCleanFrequency = poolCleanFrequency;
	}

	public boolean isAgencyOfficeId() {
		return isAgencyOfficeId;
	}

	public void setAgencyOfficeId(final boolean officeId) {
		this.isAgencyOfficeId = officeId;
	}

	@Override
	public boolean equals(final Object other) {
		return EqualsBuilder.reflectionEquals(this, other);
	}

	public int getMinPoolSize() {
		return minPoolSize;
	}

	public void setMinPoolSize(int minPoolSize) {
		this.minPoolSize = minPoolSize;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

}
