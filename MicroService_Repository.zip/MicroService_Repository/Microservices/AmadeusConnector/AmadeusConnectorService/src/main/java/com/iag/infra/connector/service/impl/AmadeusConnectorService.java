package com.iag.infra.connector.service.impl;

import java.util.Map;
import java.util.NoSuchElementException;

import org.apache.commons.lang.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.annotations.VisibleForTesting;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusErrorCode;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;
import com.iag.infra.connector.amadeusconnector.proxy.ServiceProxy;
import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.model.ConfigurationPoolData;
import com.iag.infra.connector.service.ConnectorService;
import com.iag.infra.connector.service.pool.SessionPool;
import com.iag.infra.connector.service.pool.SessionPoolFactory;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

@Service
public class AmadeusConnectorService implements ConnectorService {

	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(AmadeusConnectorService.class);
	private SessionPoolFactory amadeusSessionPoolFactory;

    private ServiceProxy serviceProxy;


    private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	/**
	 * Constructor to initiailse class attribute.
	 * 
	 * @param amadeusSessionPoolFactory
	 */
	@Autowired
    public AmadeusConnectorService(final SessionPoolFactory amadeusSessionPoolFactory,
            ValidationServiceExceptionGenerator validationServiceExceptionGenerator, ServiceProxy serviceProxy) {
		this.amadeusSessionPoolFactory = amadeusSessionPoolFactory;
        this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
        this.serviceProxy = serviceProxy;
	}

	/**
	 * This method is used to get session from pool.
	 * 
	 * 
	 * @param reqParams
	 * @return sessionPool.
	 * @throws Exception
	 */
	@Override
	public Session getSession(final Map<String, String> reqParams) {

		SessionPoolIdentifier sessionPoolIdentifier = createSessionPoolIdentifier(reqParams);
        if (!isConfigurationExistsInPoolConfiguration(sessionPoolIdentifier)) {
            LOG.info("getAmadeusSessionPoolConfiguration  method invoking when configurationData is null -------------");
            throwValidationServiceException(AmadeusSeviceErrorCode.MISSING_CONFIG_DATA.name(),  AmaduesConnectorServiceConstants.MISSING_CONFIG_DATA);
        }
		Session session = null;
		LOG.debug("sessionPoolIdentifier details : {} in getAmadeusSession", sessionPoolIdentifier);
        SessionPool<Session> amadeusSessionPool = amadeusSessionPoolFactory  .createAmadeusSessionPool(sessionPoolIdentifier);
		try {
            LOG.info("Total created session object in pool before borrowObject {}  ",
                    amadeusSessionPool.getCreatedCount());
            LOG.info("Total active session object in pool before borrowObject {}  ", amadeusSessionPool.getNumActive());
            LOG.info("Total Idle session object in pool before borrowObject {}  ", amadeusSessionPool.getNumIdle());
            session = amadeusSessionPool.borrowObject();
            LOG.info("Total created session object in pool after borrowObject {}  ",    amadeusSessionPool.getCreatedCount());
            LOG.info("Total active session object in pool after borrowObject {}  ", amadeusSessionPool.getNumActive());
            LOG.info("Total Idle session object in pool after borrowObject {}  ", amadeusSessionPool.getNumIdle());
        } catch (NoSuchElementException e) {
            LOG.error("The exception reported is " + AmaduesConnectorServiceConstants.WAIT_TIMEOUT);
            throw new ApplicationServiceException(AmadeusErrorCode.MAX_POOL_LIMIT_REACHED.name());
        } catch (Exception exception) {
            LOG.error("The exception reported is {}", exception.getMessage());
            throw ((ApplicationServiceException) exception);

        }
		LOG.debug("session in AmadeusConnectorService in getAmadeusSession after borrow object.  {}", session);
		return session;

	}



    /**
     * This method is used to release session to the pool.
     * 
     * @param session
     */
    @Override
    public void releaseSession(Session session) {
        LOG.info("releaseSession :  Entry");
        session.convertToUpperCase();
        SessionPoolIdentifier sessionPoolIdentifier = new SessionPoolIdentifier(session.getLocation(),
                session.getChannel(), session.getScope());
        if (!isConfigurationExistsInPoolConfiguration(sessionPoolIdentifier)) {
            LOG.info("releaseSession  method invoking when configurationData is null -------------");

            throwValidationServiceException(AmadeusSeviceErrorCode.DATA_INVALID.name(),
                    AmaduesConnectorServiceConstants.DATA_INVALID);
        }

        final SessionPool<Session> amadeusSessionPool = amadeusSessionPoolFactory
                .createAmadeusSessionPool(sessionPoolIdentifier);
        try {
            LOG.info("Total active session object in pool before returnObject {}  ", amadeusSessionPool.getNumActive());
            LOG.info("Total Idle session object in pool before returnObject {}  ", amadeusSessionPool.getNumIdle());
            LOG.info("Total session object returned to pool  before calling returnObject {}  ",
                    amadeusSessionPool.getReturnedCount());
            amadeusSessionPool.returnObject(session);

            LOG.info("Total session object returned to pool  after calling returnObject {}  ",
                    amadeusSessionPool.getReturnedCount());

            LOG.info("Total active session object in pool after returnObject {}  ", amadeusSessionPool.getNumActive());
            LOG.info("Total Idle session object in pool after returnObject {}  ", amadeusSessionPool.getNumIdle());
        } catch (IllegalStateException e) {
            throwValidationServiceException(AmadeusSeviceErrorCode.DATA_INVALID.name(), e.getMessage());
        }
        LOG.info("releaseSession :  Exit");
    }

    @VisibleForTesting
    protected SessionPoolIdentifier createSessionPoolIdentifier(Map<String, String> reqParams) {
        SessionPoolIdentifier sessionPoolIdentifier = new SessionPoolIdentifier();
        sessionPoolIdentifier.setChannel(reqParams.get(AmaduesConnectorServiceConstants.CHANNEL_PARAM).toUpperCase());
        sessionPoolIdentifier.setCountrycode(reqParams.get(AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM)
                .toUpperCase());
        sessionPoolIdentifier.setScope(reqParams.get(AmaduesConnectorServiceConstants.SCOPE_PARAM).toUpperCase());
        sessionPoolIdentifier.setDevice(reqParams.get(AmaduesConnectorServiceConstants.DEVICE_PARAM).toUpperCase());
        return sessionPoolIdentifier;

	}


    private Boolean isConfigurationExistsInPoolConfiguration(SessionPoolIdentifier sessionPoolIdentifier) {
        ConfigurationPoolData configurationData = serviceProxy.retrieveConfigurationForPool(sessionPoolIdentifier
                .getSessionPoolIdentifierKey());
        return !(configurationData == null);

    }

    private void throwValidationServiceException(String errorCode, String developerMessage) {
        ValidationServiceException validationServiceException = new ValidationServiceException(
                AmadeusErrorCode.REQUEST_INVALID.name());
        validationServiceException.setDeveloperMessage(AmaduesConnectorServiceConstants.REQUEST_INVALID);
        ValidationServiceException childValidationServiceException = validationServiceExceptionGenerator
                .createValidationError(errorCode, StringUtils.EMPTY, developerMessage);
        validationServiceException.addValidationException(childValidationServiceException);
        throw validationServiceException;
    }

}
