package com.iag.infra.connector.amadeusconnector.error;

import java.util.HashMap;
import java.util.Map;

public enum ProxyServiceSoapFaultErrors {
	MANDATORY_DATA_MISSING("MANDATORY_DATA_MISSING"), METHOD_NOT_SUPPORTED("METHOD_NOT_SUPPORTED"), DEFAULT("DEFAULT"),NO_CONTENT("NO_CONTENT"),DATA_INVALID("DATA_INVALID"),INTERNAL_SERVER_ERROR("INTERNAL_SERVER_ERROR");
	
	
	private final String errorMessage;
private	ProxyServiceSoapFaultErrors(String errorMessage){
		this.errorMessage=errorMessage;
	}


public String getValue() {
  return errorMessage;
}

private static final Map<String, ProxyServiceSoapFaultErrors> lookUp =new HashMap<>();

static {
  for (ProxyServiceSoapFaultErrors d : ProxyServiceSoapFaultErrors.values()) {
    lookUp.put(d.getValue(), d);
}
}

/**
 * This method gets error message from the enumeration on the basis of input.
 * @param abbreviation
 * @return AmadeusSoapFaultErrors
 */
public static ProxyServiceSoapFaultErrors getErrorCode(final String abbreviation) {
  return lookUp.get(abbreviation);
}
}
