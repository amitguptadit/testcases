package com.iag.infra.connector.amadeusconnector.error;

/**
 *AmadeusSeviceErrorCode class used for constant declaration.
 */
public enum AmadeusSeviceErrorCode {
    DATA_INVALID, REQUEST_INVALID, MANDATORY_DATA_MISSING, MISSING_CONFIG_DATA, SYSTEM_UNAVAILABLE, REPOSITORY_UNVAILABLE, NO_CONTENT, INTERNAL_SERVER_ERROR, NOT_SUPPORTED, METHOD_NOT_SUPPORTED, REQUEST_UNAUTHORIZED;
}