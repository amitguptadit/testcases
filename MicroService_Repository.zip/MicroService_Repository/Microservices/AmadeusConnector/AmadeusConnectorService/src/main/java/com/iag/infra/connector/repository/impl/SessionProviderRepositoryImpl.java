package com.iag.infra.connector.repository.impl;

import javax.xml.soap.SOAPException;

import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.amadeus.xml.vlsslq_06_1_1a.SecurityAuthenticate;
import com.amadeus.xml.vlssoq_04_1_1a.SecuritySignOut;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.model.AmadeusConnectionDetails;
import com.iag.infra.connector.model.AmedeusResponseDetails;
import com.iag.infra.connector.repository.SessionProviderRepository;
import com.iag.infra.connector.repository.impl.mapper.request.SecurityAuthenticateRequestMapper;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

/**
 * The Class provides various operations for Amadeus Session management.
 */
@Repository
public class SessionProviderRepositoryImpl extends AmadeusWebServiceGateway implements SessionProviderRepository {

	private static final Logger LOG = LoggerFactory.getLogger(SessionProviderRepositoryImpl.class);



	    /**
     * This method is used to get session from Amadeus.
     * 
     * @param amadeusConnectionDetails
     * @param sessionPoolIdentifier
     * @return AmadeusSession
     * @throws SOAPException
     */

	public PooledObject<Session> signIn(final AmadeusConnectionDetails amadeusConnectionDetails,
			final SessionPoolIdentifier sessionPoolIdentifier) throws SOAPException {

		SecurityAuthenticateRequestMapper securityAuthenticateRequestMapper = new SecurityAuthenticateRequestMapper();
		SecurityAuthenticate securityAuthenticate = securityAuthenticateRequestMapper.mapSecurityAuthenticateRequest(amadeusConnectionDetails,sessionPoolIdentifier);
		final AmedeusResponseDetails amedeusResponseDetails = getWebServiceResponseForSignIn(securityAuthenticate, amadeusConnectionDetails.getSecurityAuthenticate().trim(),amadeusConnectionDetails.getMesssageId(), sessionPoolIdentifier.getDevice());
        final Session session = createNewPooledSession(sessionPoolIdentifier, amedeusResponseDetails);
		LOG.debug("AmadeusSession in SessionProviderRepositoryImpl during signIn - {}", session);
        return new DefaultPooledObject<Session>(session);
	}

	/**
	 * This method is used to release the Amadeus session. This is never called
	 * explicitly during any transactions. Post ITO, signOut occurs which in
	 * turn releases the session.
	 * 
	 * @return boolean
	 */
    //	@Override
	public void signOut(Session session, final AmadeusConnectionDetails amadeusConnectionDetails) {
		getWebServiceResponseForSignOut(new SecuritySignOut(), amadeusConnectionDetails.getSecuritySignOut().trim(),
				session);
	}

    private Session createNewPooledSession(final SessionPoolIdentifier sessionPoolIdentifier,
            final AmedeusResponseDetails amedeusResponseDetails) {
        final Session session = new Session();
        session.setLocation(sessionPoolIdentifier.getCountrycode());
        session.setChannel(sessionPoolIdentifier.getChannel());
        session.setScope(sessionPoolIdentifier.getScope());
        session.setTokenNumber(amedeusResponseDetails.getSecurityToken());
        session.setSessionIdentifier(amedeusResponseDetails.getSessionId());
        session.setStatus(AmaduesConnectorServiceConstants.VALID_RESPONSE_CODE);
        return session;
    }

}
