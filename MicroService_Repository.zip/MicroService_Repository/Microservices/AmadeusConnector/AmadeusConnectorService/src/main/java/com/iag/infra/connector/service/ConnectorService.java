package com.iag.infra.connector.service;

import java.util.Map;

import com.iag.infra.connector.domain.Session;

public interface ConnectorService {

	/**
	 * This method get amadeus session.
	 * 
	 * @param amadeusSessionPoolIdentifier.
	 * @return Session;
	 * @throws Exception;
	 **/
	public Session getSession(Map<String,String>reqParams)  ;

	/**
	 * This method return session.
	 * 
	 * @param amadeusSessionPoolIdentifier.
	 * @param Session.
	 * @throws Exception;
	 **/

	public void releaseSession(Session session);


}
