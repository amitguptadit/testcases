package com.iag.infra.connector.repository;


import com.iag.infra.connector.model.AmadeusSessionPoolConfiguration;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

/**
 * AmadeusSessionPoolConfigurationRepository interface defines the behaviour for
 * getting amadeus session pool configuration.
 */
public interface AmadeusSessionPoolConfigurationRepository {

	/**
	 * This method is responsible for getting amadeus session pool configuration.
	 * 
	 * @param amadeusSessionIdentifier
	 * @return AmadeusSessionPoolConfiguration
	 */
	public AmadeusSessionPoolConfiguration getAmadeusSessionPoolConfiguration(final SessionPoolIdentifier sessionIdentifier);

}
