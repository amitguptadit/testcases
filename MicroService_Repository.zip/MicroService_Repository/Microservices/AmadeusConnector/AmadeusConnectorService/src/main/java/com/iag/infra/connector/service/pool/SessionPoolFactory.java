package com.iag.infra.connector.service.pool;

import org.apache.commons.pool2.impl.AbandonedConfig;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.iag.infra.connector.amadeusconnector.proxy.ServiceProxy;
import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.model.AmadeusConnectionDetails;
import com.iag.infra.connector.model.AmadeusSessionPoolConfiguration;
import com.iag.infra.connector.model.ConfigurationPoolData;
import com.iag.infra.connector.repository.AmadeusConnectionDetailConfigurationRepository;
import com.iag.infra.connector.repository.AmadeusSessionPoolConfigurationRepository;
import com.iag.infra.connector.repository.SessionProviderRepository;


/**
 * The Class AmadeusSessionPoolFactory. 1. The class is used to get
 * AmadeusSessionPool based on AmadeusSessionPoolIdentifier. 2. The class is
 * used to create AmadusSessionPool based on AmadeusSessionPooleIdentifier which
 * internally call the public method getAmadeusSessionPool. 3. Inside this class
 * all the properties are set in GenericObjectPool object. 4. Inside this
 * AmadeusSessionFactory object created. Which is further used to make and
 * destroy the amadeusSession object if not in pool.
 */
@Component
public class SessionPoolFactory {
	private static final Logger LOG = LoggerFactory.getLogger(SessionPoolFactory.class);
	private AmadeusSessionPoolConfigurationRepository amadeusSessionPoolConfigurationRepository;
	private SessionProviderRepository sessionProviderRepository;
	private AmadeusConnectionDetailConfigurationRepository amadeusConnectionDetailConfigurationRepository;

    private ServiceProxy configurationInfrastructureServiceProxy;
	/**
	 * Constructor to initialise class attribyes.
	 * 
	 * @param amadeusSessionPoolConfigurationRepository
	 * @param sessionProviderRepository
	 */
	@Autowired
    public SessionPoolFactory(final ServiceProxy configurationInfrastructureServiceProxy,
            final SessionProviderRepository sessionProviderRepository,
            final AmadeusSessionPoolConfigurationRepository amadeusSessionPoolConfigurationRepository,
            AmadeusConnectionDetailConfigurationRepository amadeusConnectionDetailConfigurationRepository) {
		this.sessionProviderRepository = sessionProviderRepository;
		this.amadeusSessionPoolConfigurationRepository=amadeusSessionPoolConfigurationRepository;
		this.amadeusConnectionDetailConfigurationRepository=amadeusConnectionDetailConfigurationRepository;
        this.configurationInfrastructureServiceProxy = configurationInfrastructureServiceProxy;
	}

	/**
	 * This method is used to create amadeus session pool.
	 * 
	 * @param amadeusSessionPoolIdentifier
	 * @return
	 */
	@Cacheable("sessionPoolIdentifiers")
    public SessionPool<Session> createAmadeusSessionPool(SessionPoolIdentifier amadeusSessionPoolIdentifier) {

		AmadeusSessionPoolConfiguration amadeusSessionPoolConfiguration = amadeusSessionPoolConfigurationRepository
				.getAmadeusSessionPoolConfiguration(amadeusSessionPoolIdentifier);

        ConfigurationPoolData configuration = configurationInfrastructureServiceProxy
                .retrieveConfigurationForPool(amadeusSessionPoolIdentifier.getSessionPoolIdentifierKey());
		AmadeusConnectionDetails amadeusConnectionDetails = amadeusConnectionDetailConfigurationRepository.getAmadeusConnectionDetails(amadeusSessionPoolIdentifier);
		SessionFactory amadeusSessionFactory = new SessionFactory(sessionProviderRepository, amadeusConnectionDetails,amadeusSessionPoolIdentifier);
		SessionPool<Session> genericObjectPool = new SessionPool<Session>(amadeusSessionFactory);

		GenericObjectPoolConfig config = new GenericObjectPoolConfig();
		config.setMaxIdle(amadeusSessionPoolConfiguration.getDefaultPoolSize());
		config.setMinIdle(amadeusSessionPoolConfiguration.getMinimumPoolSize());
		config.setMaxTotal(amadeusSessionPoolConfiguration.getMaxPoolSize());
		config.setBlockWhenExhausted(true);
        config.setMinEvictableIdleTimeMillis(configuration.getMinEvictableIdleTimeMillis());
		config.setMaxWaitMillis(amadeusSessionPoolConfiguration.getWaitingTimeOut());
        LOG.info("min pool size config {}", amadeusSessionPoolConfiguration.getMinimumPoolSize());
        LOG.info("max pool size config {}", amadeusSessionPoolConfiguration.getMaxPoolSize());
        LOG.info("waiting time out config {}", amadeusSessionPoolConfiguration.getWaitingTimeOut());
		genericObjectPool.setConfig(config);
		genericObjectPool.setLifo(false);
        genericObjectPool.setTimeBetweenEvictionRunsMillis(configuration.getTimeBetweenEvictionRunsMillis());

        final AbandonedConfig abandonedConfig = new AbandonedConfig();
        abandonedConfig.setUseUsageTracking(configuration.isUseUsageTracking());
        abandonedConfig.setRemoveAbandonedOnBorrow(configuration.isRemoveAbandonedOnBorrow()); //will be true
        abandonedConfig.setRemoveAbandonedTimeout(configuration.getRemoveAbandonedTimeout()); //60sec
        abandonedConfig.setRemoveAbandonedOnMaintenance(configuration.isRemoveAbandonedOnMaintenance());
        abandonedConfig.setLogAbandoned(configuration.isLogAbandoned());
        genericObjectPool.setAbandonedConfig(abandonedConfig);

        LOG.info("abandonedConfig.getLogAbandoned value {} ", abandonedConfig.getLogAbandoned());

		LOG.info("getAmadeusSessionPool invoked -----------------");
		return genericObjectPool;
	}

}
