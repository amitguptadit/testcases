package com.iag.infra.connector.repository.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;
import com.iag.infra.connector.amadeusconnector.proxy.ServiceProxy;
import com.iag.infra.connector.model.AmadeusSessionPoolConfiguration;
import com.iag.infra.connector.model.ConfigurationPoolData;
import com.iag.infra.connector.repository.AmadeusSessionPoolConfigurationRepository;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

/**
 * This class is responsible to construct the AmadeusSessionPoolConfiguration
 * which will be used to create session pools managed by commons pool framework
 */

@Repository
public class AmadeusSessionPoolConfigurationRepositoryImpl implements AmadeusSessionPoolConfigurationRepository {
    ServiceProxy serviceProxy;

    @Autowired
    AmadeusSessionPoolConfigurationRepositoryImpl(ServiceProxy serviceProxy) {
        this.serviceProxy = serviceProxy;
    }

    /**
     * Method is used to create the AmadeusSessionPoolConfiguration which will
     * be used to create session pools managed by commons pool framework
     * 
     * @param sessionIdentifier
     * @return AmadeusSessionPoolConfiguration
     */

    @Override
    public AmadeusSessionPoolConfiguration getAmadeusSessionPoolConfiguration(
            final SessionPoolIdentifier sessionIdentifier) {
        AmadeusSessionPoolConfiguration amadeusSessionPoolConfiguration = new AmadeusSessionPoolConfiguration();

        ConfigurationPoolData configurationData = serviceProxy.retrieveConfigurationForPool(sessionIdentifier
                .getSessionPoolIdentifierKey());
        amadeusSessionPoolConfiguration.setDefaultPoolSize(Integer.parseInt(configurationData.getDefaultPoolSize()));
        amadeusSessionPoolConfiguration.setMinPoolSize(Integer.parseInt(configurationData.getMinPoolSize()));
        amadeusSessionPoolConfiguration.setWaitingTimeOut(Long.parseLong(configurationData.getWaitingTimeOut()));
        amadeusSessionPoolConfiguration.setMaxPoolSize(Integer.parseInt(configurationData.getMaxPoolSize()));
        return amadeusSessionPoolConfiguration;
    }
}
