package com.iag.infra.connector.exception;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Parent class of all kind of service exception. Should not be inherited directly. SDU should inherit its child classes
 * ValidationServiceException or ApplicationServiceException depending upon the requirement.
 * @see RuntimeException
 */
public abstract class ServiceException extends RuntimeException {

  private final String code;
  private String developerMessage;
  private String optionalNamespace;

  /**
   * Default constructor. Required by exception factory to instantiate exception on fly.
   * @param code
   */
  public ServiceException(final String code) {
    super(code);
    this.code = code;
  }

  /**
   * Constructor accepting root cause to be wrapped in exception. Required when we need to convert any check exception.
   * @param code
   * @param cause
   */
  public ServiceException(final String code, final Throwable cause) {
    super(code, cause);
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public String getDeveloperMessage() {
    return developerMessage;
  }

  public void setDeveloperMessage(final String developerMessage) {
    this.developerMessage = developerMessage;
  }

  /**
   * 
   * @return
   */
  public String getOptionalNamespace() {
    return optionalNamespace;
  }
  /**
   * 
   * @param optionalNamespace
   */
  public void setOptionalNamespace(final String optionalNamespace) {
    this.optionalNamespace = optionalNamespace;
  }

  @Override
  public boolean equals(final Object obj) {
    return EqualsBuilder.reflectionEquals(this, obj);
  }

  @Override
  public final String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    return HashCodeBuilder.reflectionHashCode(this);
  }
}
