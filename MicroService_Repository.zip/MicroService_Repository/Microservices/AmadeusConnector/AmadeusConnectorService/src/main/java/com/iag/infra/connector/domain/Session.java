package com.iag.infra.connector.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The Class Session.
 */
public class Session {

	private String tokenNumber;
	private String sessionIdentifier;
	private String location;
	private String channel;
	private String scope;
	private String status;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String device;

	/*
	 * 
	 */
	public Session() {

	}

	/**
	 * Constructor to initialize class attributes.
	 * 
	 * @param sessionId
	 * @param sequenceNumber
	 * @param securityToken
	 */

	public Session(String tokenNumber, String sessionIdentifier, String location, String channel, String scope) {
		this.tokenNumber = tokenNumber;
		this.sessionIdentifier = sessionIdentifier;
		this.location = location;
		this.channel = channel;
		this.scope = scope;
	}

    /**
     * This method is used to convert the case to upper case.
     */
    public void convertToUpperCase() {
        this.location = location.toUpperCase();
        this.channel = channel.toUpperCase();
        this.scope = scope.toUpperCase();
    }

	/**
	 * 
	 * @param location
	 * @param channel
	 * @param scope
	 */
	public Session(String location, String channel, String scope) {

		this.location = location;
		this.channel = channel;
		this.scope = scope;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	@Override
	public boolean equals(final Object other) {
		return EqualsBuilder.reflectionEquals(this, other);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	public String getTokenNumber() {
		return tokenNumber;
	}

	public void setTokenNumber(String tokenNumber) {
		this.tokenNumber = tokenNumber;
	}

	public String getSessionIdentifier() {
		return sessionIdentifier;
	}

	public void setSessionIdentifier(String sessionIdentifier) {
		this.sessionIdentifier = sessionIdentifier;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDevice() {
		return device;
	}
	
public void setDevice(String device) {
	this.device = device;
}
}
