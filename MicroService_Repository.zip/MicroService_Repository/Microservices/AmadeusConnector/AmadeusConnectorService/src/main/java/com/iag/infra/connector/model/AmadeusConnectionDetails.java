package com.iag.infra.connector.model;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * AmadeusConnectionDetails class is POJO class for Amadeus connector.
 */
@SuppressWarnings("serial")

public class AmadeusConnectionDetails implements Serializable {
	@JsonProperty("officeId")
	private String officeId;
			
	@JsonProperty("originator")
	private String originator;
	
	@JsonProperty("password")
	private String password;
	
	@JsonProperty("referenceQualifier")
	private String referenceQualifier;
	
	@JsonProperty("referenceIdentifier")
	private String referenceIdentifier;
	
	@JsonProperty("organisationalId")
	private String organisationalId;
	
	@JsonProperty("originatorTypeCode")
	private String originatorTypeCode;
	
	@JsonProperty("passwordDataLength")
	private int passwordDataLength;

	@JsonProperty("passwordDataType")
	private String passwordDataType;
	private String originatorForIdentificationType;
	private String originatorForUserIdentificationType;
	private String originatorTypeCodeForUserIdentificationType;
	private String originatorTypeCodeForIdentificationType;
	private String securityAuthenticate;
	private String messsageId;
	
	
	
	public String getMesssageId() {
		return messsageId;
	}
	public void setMesssageId(String messsageId) {
		this.messsageId = messsageId;
	}
	
	public String getSecurityAuthenticate() {
		return securityAuthenticate;
	}
	
	public void setSecurityAuthenticate(String securityAuthenticate) {
		this.securityAuthenticate = securityAuthenticate;
	}
	@JsonProperty("officeId")
	public String getOfficeId() {
		return officeId;
	}

	@JsonProperty("officeId")
	public void setOfficeId(final String officeId) {
		this.officeId = officeId;
	}

	@JsonProperty("originator")
	public String getOriginator() {
		return originator;
	}

	@JsonProperty("originator")
	public void setOriginator(final String originator) {
		this.originator = originator;
	}

	@JsonProperty("password")
	public String getPassword() {
		return password;
	}

	@JsonProperty("password")
	public void setPassword(final String password) {
		this.password = password;
	}

	@JsonProperty("referenceQualifier")
	public String getReferenceQualifier() {
		return referenceQualifier;
	}

	@JsonProperty("referenceQualifier")
	public void setReferenceQualifier(final String referenceQualifier) {
		this.referenceQualifier = referenceQualifier;
	}

	@JsonProperty("referenceIdentifier")
	public String getReferenceIdentifier() {
		return referenceIdentifier;
	}

	@JsonProperty("referenceIdentifier")
	public void setReferenceIdentifier(final String referenceIdentifier) {
		this.referenceIdentifier = referenceIdentifier;
	}

	@JsonProperty("organisationalId")
	public String getOrganisationalId() {
		return organisationalId;
	}

	@JsonProperty("organisationalId")
	public void setOrganisationalId(final String organisationalId) {
		this.organisationalId = organisationalId;
	}

	@JsonProperty("originatorTypeCode")
	public String getOriginatorTypeCode() {
		return originatorTypeCode;
	}

	@JsonProperty("originatorTypeCode")
	public void setOriginatorTypeCode(final String originatorTypeCode) {
		this.originatorTypeCode = originatorTypeCode;
	}

	@JsonProperty("passwordDataLength")
	public int getPasswordDataLength() {
		return passwordDataLength;
	}

	@JsonProperty("passwordDataLength")
	public void setPasswordDataLength(final int passwordDataLength) {
		this.passwordDataLength = passwordDataLength;
	}

	@JsonProperty("passwordDataType")
	public String getPasswordDataType() {
		return passwordDataType;
	}

	@JsonProperty("passwordDataType")
	public void setPasswordDataType(final String passwordDataType) {
		this.passwordDataType = passwordDataType;
	}
 

	private String securitySignOut;
	public String getSecuritySignOut() {
		return securitySignOut;
	}
	public void setSecuritySignOut(String securitySignOut) {
		this.securitySignOut = securitySignOut;
	}
	public String getOriginatorTypeCodeForIdentificationType() {
		return originatorTypeCodeForIdentificationType;
	}
	public void setOriginatorTypeCodeForIdentificationType(String originatorTypeCodeForIdentificationType) {
		this.originatorTypeCodeForIdentificationType = originatorTypeCodeForIdentificationType;
	}
	public String getOriginatorForIdentificationType() {
		return originatorForIdentificationType;
	}
	public void setOriginatorForIdentificationType(String originatorForIdentificationType) {
		this.originatorForIdentificationType = originatorForIdentificationType;
	}
	public String getOriginatorForUserIdentificationType() {
		return originatorForUserIdentificationType;
	}
	public void setOriginatorForUserIdentificationType(String originatorForUserIdentificationType) {
		this.originatorForUserIdentificationType = originatorForUserIdentificationType;
	}
	public String getOriginatorTypeCodeForUserIdentificationType() {
		return originatorTypeCodeForUserIdentificationType;
	}
	public void setOriginatorTypeCodeForUserIdentificationType(String originatorTypeCodeForUserIdentificationType) {
		this.originatorTypeCodeForUserIdentificationType = originatorTypeCodeForUserIdentificationType;
	}
	public AmadeusConnectionDetails()
	{
	}
	@Override
	public boolean equals(final Object other) {
		return EqualsBuilder.reflectionEquals(this, other);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

}
