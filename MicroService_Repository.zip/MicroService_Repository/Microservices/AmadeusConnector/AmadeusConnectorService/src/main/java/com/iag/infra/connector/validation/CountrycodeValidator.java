package com.iag.infra.connector.validation;

import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;

/**
 * CountrycodeValidator is responsible for validating channel.
 */
@Component
public class CountrycodeValidator {
		private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	@Autowired
	public CountrycodeValidator(final ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;

	}

	/**
	 * 
	 * @param validationServiceExceptionList
	 * @param countryCode
	 * @return
	 */

    public ValidationServiceException validate(final String countrycode, String path) {
        ValidationServiceException validationServiceException = null;
        if (StringUtils.isEmpty(countrycode)) {
            validationServiceException = validationServiceExceptionGenerator.createValidationError(
                    AmadeusSeviceErrorCode.MANDATORY_DATA_MISSING.name(), path,
                    AmaduesConnectorServiceConstants.MANDATORY_DATA_MISSING);

        } else {

            Pattern countryCodeMatcher = Pattern.compile(AmaduesConnectorServiceConstants.COUNTRY_CODE_REGEX);
            if (!countryCodeMatcher.matcher(countrycode).matches()) {
                validationServiceException = validationServiceExceptionGenerator
                        .createValidationError(AmadeusSeviceErrorCode.DATA_INVALID.name(), path,
                                AmaduesConnectorServiceConstants.DATA_INVALID);
            }
        }
        return validationServiceException;
    }

}
