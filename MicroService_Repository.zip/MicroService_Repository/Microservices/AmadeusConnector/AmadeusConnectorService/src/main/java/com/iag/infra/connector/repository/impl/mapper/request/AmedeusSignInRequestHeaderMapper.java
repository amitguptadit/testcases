package com.iag.infra.connector.repository.impl.mapper.request;

import javax.xml.transform.dom.DOMResult;

import org.springframework.stereotype.Component;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

@Component
public class AmedeusSignInRequestHeaderMapper {
	private static final String WSA_NAME_SPACE = "http://www.w3.org/2005/08/addressing";
	private static final String WSA = "wsa";
	private static final String WSA_TO = "wsa:To";
	private static final String WSA_MESSAGE_ID = "wsa:MessageID";
	private static final String WSA_ACTION = "wsa:Action";
	private static final String LINK_TRANSACTION_FLOW_LINK = "awsl:TransactionFlowLink";
	private static final String LINK_TRANSACTION_FLOW_LINK_CONSUMER = "awsl:Consumer";
	private static final String LINK_TRANSACTION_FLOW_LINK_UNIQUE_ID = "awsl:UniqueID";
	
	
	private static final String LINK_SPACE_URI = "http://wsdl.amadeus.com/2010/06/ws/Link_v1";
	
	
	private static final String ACTION_SPACE_URI = WSA_NAME_SPACE;
	  
	public void mapHeaders(final SoapMessage message,final String soapAction, final String uri,final String deviceId,final String messageId) {
		message.getEnvelope().addNamespaceDeclaration(WSA, WSA_NAME_SPACE);
		SoapHeader soapHeader = message.getSoapHeader();
		DOMResult xmlHeader = (DOMResult) soapHeader.getResult();
		Node headerNode = xmlHeader.getNode();
		addSessionDetailsToSoapHeader(headerNode, soapAction, uri,messageId);
		addTransactionFlowLinkToSoapHeader(headerNode, deviceId);

	}

	/**
	 * This method is to set <wsse:Session> elements in the soap header.These
	 * elements presents session details which are required to authenticate the
	 * soap header.
	 */
	private void addSessionDetailsToSoapHeader(final Node headerNode, final String soapActionUri, final String uri,final String messageId) {
		 Element action = headerNode.getOwnerDocument().createElementNS(ACTION_SPACE_URI,WSA_ACTION);
		 action.appendChild(headerNode.getOwnerDocument().createTextNode(soapActionUri));
		 
		 Element messageIdNode = headerNode.getOwnerDocument().createElementNS(ACTION_SPACE_URI,WSA_MESSAGE_ID );
		 messageIdNode.appendChild(headerNode.getOwnerDocument().createTextNode(messageId));
		 
		 Element to = headerNode.getOwnerDocument().createElementNS(ACTION_SPACE_URI,WSA_TO);
		 to.appendChild(headerNode.getOwnerDocument().createTextNode(uri));
		 
		 headerNode.appendChild(action);
		 headerNode.appendChild(messageIdNode);
		 headerNode.appendChild(to);
	}
	
	private void addTransactionFlowLinkToSoapHeader(final Node headerNode,final String deviceId){
		   Element linkTransactionFlowLink = headerNode.getOwnerDocument().createElementNS(LINK_SPACE_URI, LINK_TRANSACTION_FLOW_LINK);	

		   Element Consumer = headerNode.getOwnerDocument().createElementNS(LINK_SPACE_URI, LINK_TRANSACTION_FLOW_LINK_CONSUMER);
		   
		   
		   Element UniqueID = headerNode.getOwnerDocument().createElementNS(LINK_SPACE_URI, LINK_TRANSACTION_FLOW_LINK_UNIQUE_ID);
		   UniqueID.appendChild(headerNode.getOwnerDocument().createTextNode(deviceId));
		   
		   Consumer.appendChild(UniqueID);
		   linkTransactionFlowLink.appendChild(Consumer);
		   headerNode.appendChild(linkTransactionFlowLink);
		   
		
		
	}

}
