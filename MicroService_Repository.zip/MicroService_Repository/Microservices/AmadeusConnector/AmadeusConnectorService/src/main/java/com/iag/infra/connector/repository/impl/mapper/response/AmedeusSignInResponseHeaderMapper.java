package com.iag.infra.connector.repository.impl.mapper.response;

import java.util.Iterator;

import javax.xml.soap.SOAPException;
import javax.xml.transform.dom.DOMResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.model.AmedeusResponseDetails;

@Component
public class AmedeusSignInResponseHeaderMapper {

	private static final Logger LOG = LoggerFactory.getLogger(AmedeusSignInResponseHeaderMapper.class);
	public AmedeusResponseDetails map(final WebServiceMessage message,
			AmedeusResponseDetails amedeusResponseDetails) throws SOAPException{
		SaajSoapMessage soapMessage = (SaajSoapMessage) message;
		SoapHeader soapHeader = soapMessage.getSoapHeader();
		String sessionId = null; 
		int sequenceNumber = 0;
		String securityToken = null;
		for (Iterator iterator = soapHeader.examineAllHeaderElements(); iterator.hasNext();) {  
			SoapHeaderElement headerElement = (SoapHeaderElement) iterator.next();
			if (headerElement.getName().getLocalPart().equalsIgnoreCase(AmaduesConnectorServiceConstants.SESSION_NODE_KEY)) {

				DOMResult r = (DOMResult) headerElement.getResult();
				Node sessionNode = r.getNode(); 

				NodeList childNodes = sessionNode.getChildNodes();
 
				for (int j = 0; j < childNodes.getLength(); j++) {
					Node childNode = childNodes.item(j);
					if (childNode.getNodeType() == Node.ELEMENT_NODE
							&& childNode.getLocalName().equalsIgnoreCase(AmaduesConnectorServiceConstants.SESSION_ID_NODE_KEY)) {
						sessionId = childNode.getTextContent();
						LOG.info(sessionId);
						amedeusResponseDetails.setSessionId(sessionId);
					}
					if (childNode.getNodeType() == Node.ELEMENT_NODE
							&& childNode.getLocalName().equalsIgnoreCase(AmaduesConnectorServiceConstants.SEQUENCE_NUMBER_NODE_KEY)) {
						sequenceNumber = Integer.parseInt(childNode.getTextContent());
						amedeusResponseDetails.setSequenceNumber(sequenceNumber);
						LOG.info(Integer.toString(sequenceNumber));
					}
					if (childNode.getNodeType() == Node.ELEMENT_NODE
							&& childNode.getLocalName().equalsIgnoreCase(AmaduesConnectorServiceConstants.SECURITY_TOKEN_NODE_KEY)) {
						securityToken = childNode.getTextContent();
						amedeusResponseDetails.setSecurityToken(securityToken);
						LOG.info(securityToken);
					}
				}
			}
		}
		return amedeusResponseDetails;
	}



	
}
