package com.iag.infra.connector.amadeusconnector.proxy;

import com.iag.infra.connector.model.ConfigurationAuthenticationData;
import com.iag.infra.connector.model.ConfigurationPoolData;

/**
 * Interface to define contract for service call over http.
 */
public interface ServiceProxy {
  /**
   * Retrieves configuration item corresponding to supplied key.
   * @param key
   * @return
   */
  public String retrieveConfigurationForError(final String key);
  public ConfigurationPoolData retrieveConfigurationForPool(final String key);
  public ConfigurationAuthenticationData retrieveConfigurationForAuthentication(final String key);
}
