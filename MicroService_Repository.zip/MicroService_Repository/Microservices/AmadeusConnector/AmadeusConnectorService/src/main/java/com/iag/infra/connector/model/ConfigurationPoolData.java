package com.iag.infra.connector.model;

public class ConfigurationPoolData {

	private String maxPoolSize;
	private String waitingTimeOut;
	private String defaultPoolSize;
	private String minPoolSize;

    private long minEvictableIdleTimeMillis;

    private long timeBetweenEvictionRunsMillis;

    private boolean useUsageTracking;

    private boolean removeAbandonedOnBorrow;

    private int removeAbandonedTimeout;

    private boolean removeAbandonedOnMaintenance;

    private boolean logAbandoned;

    public long getMinEvictableIdleTimeMillis() {
        return minEvictableIdleTimeMillis;
    }

    public void setMinEvictableIdleTimeMillis(long minEvictableIdleTimeMillis) {
        this.minEvictableIdleTimeMillis = minEvictableIdleTimeMillis;
    }

    public long getTimeBetweenEvictionRunsMillis() {
        return timeBetweenEvictionRunsMillis;
    }

    public void setTimeBetweenEvictionRunsMillis(long timeBetweenEvictionRunsMillis) {
        this.timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis;
    }

    public boolean isUseUsageTracking() {
        return useUsageTracking;
    }

    public void setUseUsageTracking(boolean useUsageTracking) {
        this.useUsageTracking = useUsageTracking;
    }

    public boolean isRemoveAbandonedOnBorrow() {
        return removeAbandonedOnBorrow;
    }

    public void setRemoveAbandonedOnBorrow(boolean removeAbandonedOnBorrow) {
        this.removeAbandonedOnBorrow = removeAbandonedOnBorrow;
    }

    public int getRemoveAbandonedTimeout() {
        return removeAbandonedTimeout;
    }

    public void setRemoveAbandonedTimeout(int removeAbandonedTimeout) {
        this.removeAbandonedTimeout = removeAbandonedTimeout;
    }

    public boolean isRemoveAbandonedOnMaintenance() {
        return removeAbandonedOnMaintenance;
    }

    public void setRemoveAbandonedOnMaintenance(boolean removeAbandonedOnMaintenance) {
        this.removeAbandonedOnMaintenance = removeAbandonedOnMaintenance;
    }

    public boolean isLogAbandoned() {
        return logAbandoned;
    }

    public void setLogAbandoned(boolean logAbandoned) {
        this.logAbandoned = logAbandoned;
    }

    public String getMaxPoolSize() {
		return maxPoolSize;
	}
	public void setMaxPoolSize(String maxPoolSize) {
		this.maxPoolSize = maxPoolSize;
	}
	
	
	public String getWaitingTimeOut() {
		return waitingTimeOut;
	}
	public void setWaitingTimeOut(String waitingTimeOut) {
		this.waitingTimeOut = waitingTimeOut;
	}
	public String getDefaultPoolSize() {
		return defaultPoolSize;
	}
	public void setDefaultPoolSize(String defaultPoolSize) {
		this.defaultPoolSize = defaultPoolSize;
	}
	public String getMinPoolSize() {
		return minPoolSize;
	}
	public void setMinPoolSize(String minPoolSize) {
		this.minPoolSize = minPoolSize;
	}



}
