package com.iag.infra.connector.validation;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;

@Component
public class StatusValidator {
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	@Autowired
	public StatusValidator(ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * 
	 * @param validationServiceExceptionList
	 * @param channel
	 * @return
	 */
	public ValidationServiceException validate(final String status) {
		ValidationServiceException validationServiceException = null;
        if (StringUtils.isEmpty(status)) {
			validationServiceException = validationServiceExceptionGenerator.createValidationError(
					AmadeusSeviceErrorCode.MANDATORY_DATA_MISSING.name(), AmaduesConnectorServiceConstants.STATUS_PARAM,
                    AmaduesConnectorServiceConstants.MANDATORY_DATA_MISSING);
		} else {
            if (!status.equalsIgnoreCase(AmaduesConnectorServiceConstants.VALID_RESPONSE_CODE)) {
				validationServiceException = validationServiceExceptionGenerator.createValidationError(
                        AmadeusSeviceErrorCode.DATA_INVALID.name(), AmaduesConnectorServiceConstants.STATUS_PARAM,
                        AmaduesConnectorServiceConstants.DATA_INVALID);

			}
		}
		return validationServiceException;

	}

}
