package com.iag.infra.connector.repository.impl.mapper.request;

import javax.xml.transform.dom.DOMResult;

import org.springframework.stereotype.Component;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.iag.infra.connector.domain.Session;

@Component
public class AmedeusSignOutRequestHeaderMapper {

	private static final String SESSION_SPACE_URI = "http://xml.amadeus.com/ws/2009/01/WBS_Session-2.0.xsd";

	public void mapHeaders(final SoapMessage message, String soapAction, Session session) {
		SoapHeader soapHeader = message.getSoapHeader();
		DOMResult xmlHeader = (DOMResult) soapHeader.getResult();
		Node headerNode = xmlHeader.getNode();
		addSessionDetailsToSoapHeader(headerNode, session);

	}

	/**
	 * This method is to set <wsse:Session> elements in the soap header.These
	 * elements presents session details which are required to authenticate the
	 * soap header.
	 */
	private void addSessionDetailsToSoapHeader(final Node headerNode, Session session) {
		Element wsseSession = headerNode.getOwnerDocument().createElementNS(SESSION_SPACE_URI, "wbs:Session");
		Element wsseSessionId = headerNode.getOwnerDocument().createElementNS(SESSION_SPACE_URI, "wbs:SessionId");
		wsseSessionId.appendChild(headerNode.getOwnerDocument().createTextNode(session.getSessionIdentifier()));
		wsseSession.appendChild(wsseSessionId);
		Element wsseSequenceNumber = headerNode.getOwnerDocument().createElementNS(SESSION_SPACE_URI,
				"wbs:SequenceNumber");
		wsseSequenceNumber.appendChild(headerNode.getOwnerDocument().createTextNode(""));
		wsseSession.appendChild(wsseSequenceNumber);
		Element wsseSecurityToken = headerNode.getOwnerDocument().createElementNS(SESSION_SPACE_URI,
				"wbs:SecurityToken");
		wsseSecurityToken.appendChild(headerNode.getOwnerDocument().createTextNode(session.getTokenNumber()));
		wsseSession.appendChild(wsseSecurityToken);
		headerNode.appendChild(wsseSession);
	}

}
