package com.iag.infra.connector.validation;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;
import com.iag.infra.connector.domain.Session;

/**
 * AmadeusConnectorRequestValidator is responsible for validating request.
 */
@Component
public class AmadeusConnectorPatchRequestValidator {

	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;
	private final ScopeValidator scopeValidator;
	private final ChannelValidator channelValidator;
	private final CountrycodeValidator countrycodeValidator;
	private final StatusValidator statusValidator;
	private final SessionIdentifierValidator sessionIdentifierValidator;
	private final TokenNumberValidator tokenNumberValidator;

    private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(AmadeusConnectorPatchRequestValidator.class);
	Map<String, String> reqParametersIgnoreCase = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);

	@Autowired
	public AmadeusConnectorPatchRequestValidator(final ScopeValidator scopeValidator,
			final ChannelValidator channelValidator, final CountrycodeValidator countrycodeValidator,
			final StatusValidator statusValidator, final SessionIdentifierValidator sessionIdentifierValidator,
			TokenNumberValidator tokenNumberValidator,
			ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
		this.scopeValidator = scopeValidator;
		this.countrycodeValidator = countrycodeValidator;
		this.channelValidator = channelValidator;
		this.statusValidator = statusValidator;
		this.sessionIdentifierValidator = sessionIdentifierValidator;
		this.tokenNumberValidator = tokenNumberValidator;
	}


	/**
	 * The following method verifies that request parameter key is of various
	 * allowable formats else it throws exception.:
	 * 
	 * @param resource
	 * @param identifier
	 * @param version
	 * @param apiKey
	 */
    public void validateReleaseSessionRequest(Session session) {
        List<ValidationServiceException> validationServiceExceptionlist = Lists.newArrayList();
        validationServiceExceptionlist.add(scopeValidator.validate(session.getScope()));
        validationServiceExceptionlist.add(channelValidator.validate(session.getChannel()));
        validationServiceExceptionlist.add(countrycodeValidator.validate(session.getLocation(),
                AmaduesConnectorServiceConstants.LOCATION_PARAM));
        validationServiceExceptionlist.add(statusValidator.validate(session.getStatus()));
        validationServiceExceptionlist.add(tokenNumberValidator.validate(session.getTokenNumber()));
        validationServiceExceptionlist.add(sessionIdentifierValidator.validate(session.getSessionIdentifier()));
        validationServiceExceptionlist.removeAll(Collections.singleton(null));

        if (!validationServiceExceptionlist.isEmpty()) {
            LOG.info("validateForPatch  method invoking when Exception is occure in request processing ");

            throw validationServiceExceptionGenerator
                    .createServiceExceptionWithChildError(validationServiceExceptionlist);
        }
    }
 
}