package com.iag.infra.connector.amadeusconnector.error.handlers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.iag.application.error.ServiceError;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.application.exception.ServiceException;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;

/**
 * Class to handle ServiceExceptions and standard spring mvc exceptions.
 */
@ControllerAdvice
public class ServiceExceptionHandler {
 
  private final ServiceErrorResponseGenerator serviceErrorResponseGenerator;

  /**
   * Construct ServiceExceptionHandler instance.
   * 
   * @param membershipServiceExceptionGenerator
   * @param serviceErrorResponseGenerator
   * @param serviceExceptionGenerator
   */
  @Autowired
  public ServiceExceptionHandler(
      final ServiceErrorResponseGenerator serviceErrorResponseGenerator) {
        this.serviceErrorResponseGenerator = serviceErrorResponseGenerator;
  }

  /**
   * Returns HttpEntity encapsulating the error message Service Error.
   * 
   * @param serviceException
   * @return error response
   */
  @ExceptionHandler(ServiceException.class)
  public ResponseEntity<ServiceError> handleServiceException(final ServiceException serviceException) {
        final ServiceError serviceError = serviceErrorResponseGenerator.createServiceError(serviceException);
        final String httpStatusCode = serviceErrorResponseGenerator.getStatusCode(serviceException);
   
   return new ResponseEntity<ServiceError>(serviceError, HttpStatus.valueOf(Integer.parseInt(httpStatusCode)));
 }

    /**
     * Returns HttpEntity encapsulating the error message Service Error.
     * 
     * @param serviceException
     * @return error response
     */
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ServiceError> handleRuntimeException() {
        return handleServiceException(new ApplicationServiceException(AmadeusSeviceErrorCode.SYSTEM_UNAVAILABLE.name()));
   
    }
}
