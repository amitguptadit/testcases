package com.iag.infra.connector.model;

import java.util.ArrayList;
import java.util.List;

public class ConfigurationNamespaces {

	private String name;
	private List<ConfigurationItems> configurationItems =new ArrayList<>();
	private List<ConfigurationNamespaces> configurationNamespaces = null;

	
	@Override
	public String toString() {
		return "ConfigurationNamespaces [name=" + name + ", configurationItems=" + configurationItems
				+ ", configurationNamespaces=" + configurationNamespaces + "]";
	}

	public ConfigurationNamespaces() {
		
	}

	public ConfigurationNamespaces(String name, List<ConfigurationItems> configurationItems) {
		this.name = name;
		this.configurationItems = configurationItems;
	}

	public String getName() {
		return name;
	}


	public List<ConfigurationNamespaces> getConfigurationNamespaces() {
		return configurationNamespaces;
	}

	public void setConfigurationNamespaces(List<ConfigurationNamespaces> configurationNamespaces) {
		this.configurationNamespaces = configurationNamespaces;
	}

	public void setConfigurationItems(List<ConfigurationItems> configurationItems) {
		this.configurationItems = configurationItems;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ConfigurationItems> getConfigurationItems() {
		return configurationItems;
	}

	public void setConfigurationItem(List<ConfigurationItems> configurationItems) {
		this.configurationItems = configurationItems;
	}

	

}
