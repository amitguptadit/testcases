package com.iag.infra.connector.repository.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.proxy.ServiceProxy;
import com.iag.infra.connector.model.AmadeusConnectionDetails;
import com.iag.infra.connector.model.ConfigurationAuthenticationData;
import com.iag.infra.connector.repository.AmadeusConnectionDetailConfigurationRepository;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

/**
 * This class is responsible to construct the AmadeusConnectionDetails which
 * will be used to call Amadeus service
 */
@Repository
public class AmadeusConnectionDetailConfigurationRepositoryImpl
		implements AmadeusConnectionDetailConfigurationRepository {

	final ServiceProxy serviceProxy;


	@Autowired
	AmadeusConnectionDetailConfigurationRepositoryImpl(final ServiceProxy serviceProxy) {
		this.serviceProxy = serviceProxy;
	}

    /**
     * Method is used to create the AmadeusConnectionDetails which will be used to
     * call Amadeus service
     * 
     * @param sessionIdentifier
     * @return AmadeusConnectionDetails
     */
	@Override
	public AmadeusConnectionDetails getAmadeusConnectionDetails(final SessionPoolIdentifier sessionIdentifier) {
		ConfigurationAuthenticationData configurationData = serviceProxy
				.retrieveConfigurationForAuthentication(sessionIdentifier.getSessionPoolIdentifierKey());
        AmadeusConnectionDetails amadeusConnectionDetails = new AmadeusConnectionDetails();
        amadeusConnectionDetails.setReferenceQualifier(configurationData.getReferenceQualifier().trim());
        amadeusConnectionDetails.setReferenceIdentifier(configurationData.getReferenceIdentifier().trim());
        amadeusConnectionDetails.setPasswordDataLength(Integer.parseInt(configurationData.getPasswordDataLength().trim()));
        amadeusConnectionDetails.setPasswordDataType(configurationData.getPasswordDataType().trim());
        amadeusConnectionDetails.setPassword(configurationData.getPassword());
        amadeusConnectionDetails.setOfficeId(configurationData.getOfficeId().trim());
        amadeusConnectionDetails.setOrganisationalId(configurationData.getOrganisationalId().trim());
        amadeusConnectionDetails.setOriginator(configurationData.getOriginator().trim());
        amadeusConnectionDetails.setOriginatorTypeCode(configurationData.getOriginatorTypeCode().trim());
        amadeusConnectionDetails.setOriginatorForIdentificationType(configurationData
                .getOriginatorForIdentificationType().trim());
        amadeusConnectionDetails.setOriginatorTypeCodeForUserIdentificationType(configurationData
                .getOriginatorTypeCodeForUserIdentificationType().trim());
        amadeusConnectionDetails.setOriginatorForUserIdentificationType(configurationData
                .getOriginatorForUserIdentificationType().trim());
        amadeusConnectionDetails.setOriginatorTypeCodeForIdentificationType(configurationData
                .getOriginatorTypeCodeForIdentificationType().trim());
        amadeusConnectionDetails.setSecurityAuthenticate(configurationData.getSecurityAuthenticate().trim());
        amadeusConnectionDetails.setSecuritySignOut(configurationData.getSecuritySignOut().trim());
        amadeusConnectionDetails.setMesssageId(configurationData.getMesssageId());
        return amadeusConnectionDetails;
	}
}
