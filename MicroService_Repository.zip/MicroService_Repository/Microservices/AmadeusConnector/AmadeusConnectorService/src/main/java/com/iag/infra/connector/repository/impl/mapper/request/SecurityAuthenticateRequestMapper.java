package com.iag.infra.connector.repository.impl.mapper.request;

import java.math.BigInteger;

import com.amadeus.xml.vlsslq_06_1_1a.BinaryDataType;
import com.amadeus.xml.vlsslq_06_1_1a.FacilityInformationType;
import com.amadeus.xml.vlsslq_06_1_1a.LocationIdentificationBatchTypeU;
import com.amadeus.xml.vlsslq_06_1_1a.OriginatorIdentificationDetailsTypeI;
import com.amadeus.xml.vlsslq_06_1_1a.PlaceLocationIdentificationTypeU;
import com.amadeus.xml.vlsslq_06_1_1a.ReferenceInformationTypeI;
import com.amadeus.xml.vlsslq_06_1_1a.ReferencingDetailsTypeI;
import com.amadeus.xml.vlsslq_06_1_1a.RelatedLocationOneIdentificationTypeU;
import com.amadeus.xml.vlsslq_06_1_1a.SecurityAuthenticate;
import com.amadeus.xml.vlsslq_06_1_1a.SecurityAuthenticate.FullLocation;
import com.amadeus.xml.vlsslq_06_1_1a.SystemDetailsInfoType;
import com.amadeus.xml.vlsslq_06_1_1a.SystemDetailsTypeI;
import com.amadeus.xml.vlsslq_06_1_1a.TerminalLocationType;
import com.amadeus.xml.vlsslq_06_1_1a.UserIdentificationType;
import com.iag.infra.connector.model.AmadeusConnectionDetails;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

public class SecurityAuthenticateRequestMapper {

	/**
	 * Method is used to create the SecurityAuthenticate request to get the security
	 * authentication session information.
	 * 
	 * @param securityAuthenticate  SecurityAuthenticate
	 */
	public SecurityAuthenticate mapSecurityAuthenticateRequest(	final AmadeusConnectionDetails amadeusConnectionDetails,final SessionPoolIdentifier sessionPoolIdentifie) {
		SecurityAuthenticate securityAuthenticate = new SecurityAuthenticate();
		UserIdentificationType userIdentificationType = new UserIdentificationType();
		userIdentificationType.setOriginator(amadeusConnectionDetails.getOriginator());
		userIdentificationType.setOriginatorTypeCode(amadeusConnectionDetails.getOriginatorTypeCode());
		OriginatorIdentificationDetailsTypeI originatorIdentificationDetailsTypeI = new OriginatorIdentificationDetailsTypeI();
		originatorIdentificationDetailsTypeI.setSourceOffice(amadeusConnectionDetails.getOfficeId());
		userIdentificationType.setOriginIdentification(originatorIdentificationDetailsTypeI);
		securityAuthenticate.getUserIdentifier().add(userIdentificationType);
		ReferenceInformationTypeI referenceInformationTypeI = new ReferenceInformationTypeI();
		ReferencingDetailsTypeI referencingDetailsTypeI = new ReferencingDetailsTypeI();
		referencingDetailsTypeI.setReferenceIdentifier(amadeusConnectionDetails.getReferenceIdentifier());
		referencingDetailsTypeI.setReferenceQualifier(amadeusConnectionDetails.getReferenceQualifier());
		referenceInformationTypeI.setDutyCodeDetails(referencingDetailsTypeI);
		securityAuthenticate.setDutyCode(referenceInformationTypeI);
		SystemDetailsInfoType systemDetailsInfoType = new SystemDetailsInfoType();
		SystemDetailsTypeI organizationDetails = new SystemDetailsTypeI();
		organizationDetails.setOrganizationId(amadeusConnectionDetails.getOrganisationalId());
		systemDetailsInfoType.setOrganizationDetails(organizationDetails);
		securityAuthenticate.setSystemDetails(systemDetailsInfoType);
		BinaryDataType binaryDataType = new BinaryDataType();
		binaryDataType.setBinaryData(amadeusConnectionDetails.getPassword());
		binaryDataType.setDataLength(new BigInteger(String.valueOf(amadeusConnectionDetails.getPasswordDataLength())));
		binaryDataType.setDataType(amadeusConnectionDetails.getPasswordDataType());
		securityAuthenticate.getPasswordInfo().add(binaryDataType);
		
		
		//details of location information
		FullLocation fullLocation= new FullLocation();
		fullLocation.setLocationInfo(new TerminalLocationType(new FacilityInformationType("SSK", "G")));
		PlaceLocationIdentificationTypeU placeLocationIdentificationTypeU= new PlaceLocationIdentificationTypeU();
		placeLocationIdentificationTypeU.setLocationType("ZZZ");
		placeLocationIdentificationTypeU.setLocationDescription(new LocationIdentificationBatchTypeU(sessionPoolIdentifie.getCountrycode(), "139"));
		placeLocationIdentificationTypeU.setFirstLocationDetails(new RelatedLocationOneIdentificationTypeU("5", "180"));
		fullLocation.setWorkstationPos(placeLocationIdentificationTypeU);
		securityAuthenticate.setFullLocation(fullLocation);
		
		
		return securityAuthenticate;
	}
	
	
}
