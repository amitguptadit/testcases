package com.iag.infra.connector.amadeusconnector.error;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusErrorCode;
import com.iag.infra.connector.amadeusconnector.proxy.ServiceProxy;

/**
 * Class to create ServiceException.
 */
@Component
public class ValidationServiceExceptionGenerator {
@Autowired
  private ServiceProxy configurationInfrastructureServiceProxy;
  public static final String MESSAGE_CONFIGURATION_KEYWORD = "msg-";
  public static final String KEY_SEPARATOR_DOT = ".";
  public static final String KEY_SEPARATOR = "-";
                                
  /**
   * constructor method.
   * 
   * @param configurationInfrastructureServiceProxy
   */
 
  /**
   * This method is used to create validationServiceExceptionList.
   * 
   * @param serviceErrorCode
   * @param path
   * @param developerMessage
   * @return
   */
  public ValidationServiceException createValidationError(final String serviceErrorCode, final String path,
      final String developerMessage) {
    ValidationServiceException validationServiceException = new ValidationServiceException(serviceErrorCode);
    validationServiceException.setPath(path);
    validationServiceException.setDeveloperMessage(developerMessage);
    return validationServiceException;
  }

  /**
   * Method to create ValidationServiceException with child errors.
   * 
   * @param validationServiceExceptionList
   * @return
   */
  public ValidationServiceException
      createServiceExceptionWithChildError(final List<ValidationServiceException> validationServiceExceptionList) {
    ValidationServiceException validationServiceException =
        new ValidationServiceException(AmadeusErrorCode.REQUEST_INVALID.name());
        validationServiceException.setDeveloperMessage(AmaduesConnectorServiceConstants.REQUEST_INVALID);
    for (ValidationServiceException childValidationServiceException : validationServiceExceptionList) {
      validationServiceException.addValidationException(childValidationServiceException);
    }
    return validationServiceException;
  }

}
