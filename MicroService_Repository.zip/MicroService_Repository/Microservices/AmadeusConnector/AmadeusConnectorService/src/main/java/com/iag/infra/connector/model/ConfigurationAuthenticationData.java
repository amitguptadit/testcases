package com.iag.infra.connector.model;

public class ConfigurationAuthenticationData {
	private String officeId;
	private String originator;
	private String originatorForIdentificationType;
	private String originatorForUserIdentificationType;
	private String originatorTypeCodeForUserIdentificationType;
	private String originatorTypeCodeForIdentificationType;
	private String securitySignOut;
	private String securityAuthenticate;
	private String referenceQualifier;
	private String referenceIdentifier;
	private String passwordDataLength;
	private String passwordDataType;
	private String organisationalId;
	private String originatorTypeCode;
	private String password;
	private String messsageId;
	
	
	
	public String getMesssageId() {
		return messsageId;
	}
	
	public void setMesssageId(String messsageId) {
		this.messsageId = messsageId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSecuritySignOut() {
		return securitySignOut;
	}
	public void setSecuritySignOut(String securitySignOut) {
		this.securitySignOut = securitySignOut;
	}
	public String getSecurityAuthenticate() {
		return securityAuthenticate;
	}
	public void setSecurityAuthenticate(String securityAuthenticate) {
		this.securityAuthenticate = securityAuthenticate;
	}
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	public String getOriginator() {
		return originator;
	}
	public void setOriginator(String originator) {
		this.originator = originator;
	}
	public String getOriginatorTypeCodeForIdentificationType() {
		return originatorTypeCodeForIdentificationType;
	}
	public void setOriginatorTypeCodeForIdentificationType(String originatorTypeCodeForIdentificationType) {
		this.originatorTypeCodeForIdentificationType = originatorTypeCodeForIdentificationType;
	}

	public String getOriginatorForIdentificationType() {
		return originatorForIdentificationType;
	}
	public void setOriginatorForIdentificationType(String originatorForIdentificationType) {
		this.originatorForIdentificationType = originatorForIdentificationType;
	}
	public String getOriginatorForUserIdentificationType() {
		return originatorForUserIdentificationType;
	}
	public void setOriginatorForUserIdentificationType(String originatorForUserIdentificationType) {
		this.originatorForUserIdentificationType = originatorForUserIdentificationType;
	}
	public String getOriginatorTypeCodeForUserIdentificationType() {
		return originatorTypeCodeForUserIdentificationType;
	}
	public void setOriginatorTypeCodeForUserIdentificationType(String originatorTypeCodeForUserIdentificationType) {
		this.originatorTypeCodeForUserIdentificationType = originatorTypeCodeForUserIdentificationType;
	}

	public String getReferenceQualifier() {
		return referenceQualifier;
	}
	public void setReferenceQualifier(String referenceQualifier) {
		this.referenceQualifier = referenceQualifier;
	}
	public String getReferenceIdentifier() {
		return referenceIdentifier;
	}
	public void setReferenceIdentifier(String referenceIdentifier) {
		this.referenceIdentifier = referenceIdentifier;
	}
	public String getPasswordDataLength() {
		return passwordDataLength;
	}
	public void setPasswordDataLength(String passwordDataLength) {
		this.passwordDataLength = passwordDataLength;
	}
	public String getPasswordDataType() {
		return passwordDataType;
	}
	public void setPasswordDataType(String passwordDataType) {
		this.passwordDataType = passwordDataType;
	}
	public String getOrganisationalId() {
		return organisationalId;
	}
	public void setOrganisationalId(String organisationalId) {
		this.organisationalId = organisationalId;
	}
	public String getOriginatorTypeCode() {
		return originatorTypeCode;
	}
	public void setOriginatorTypeCode(String originatorTypeCode) {
		this.originatorTypeCode = originatorTypeCode;
	}

}
