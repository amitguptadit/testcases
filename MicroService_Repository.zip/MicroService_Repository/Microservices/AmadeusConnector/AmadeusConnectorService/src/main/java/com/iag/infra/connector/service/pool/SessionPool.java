package com.iag.infra.connector.service.pool;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

@SuppressWarnings("hiding")
public class SessionPool<Session> extends GenericObjectPool<Session> implements Serializable {
	/**
	 * Constructor.
	 * 
	 * It uses the default configuration for pool provided by apache-commons-pool2.
	 * 
	 * @param factory
	 */
	public SessionPool(PooledObjectFactory<Session> factory) {
		super(factory);
	}

	/**
	 * Constructor.
	 * 
	 * This can be used to have full control over the pool using configuration
	 * object.
	 * 
	 * @param factory
	 * @param config
	 */
	public SessionPool(PooledObjectFactory<Session> factory, GenericObjectPoolConfig config) {
		super(factory, config);
	}
	
	@Override
	public boolean equals(final Object other) {
		return EqualsBuilder.reflectionEquals(this, other);
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}
}
