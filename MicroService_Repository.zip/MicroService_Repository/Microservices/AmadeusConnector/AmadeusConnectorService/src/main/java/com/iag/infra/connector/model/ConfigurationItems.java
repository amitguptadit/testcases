package com.iag.infra.connector.model;

import javax.xml.bind.annotation.XmlType;


@XmlType
public class ConfigurationItems {

	private String identifier;
	private String value;
	public ConfigurationItems() {}
	public ConfigurationItems(String identifier, String value) {
		this.identifier = identifier;
		this.value = value;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getValue() {
		return value;
	}

	

	public void setValue(String value) {
		this.value = value;
	}

	
	/*@Override
	  public String toString() {
	    return ToStringBuilder.generateToString(this);
	  }*/

	@Override
	public String toString() {
		return "ConfigurationItems [identifier=" + identifier + ", value=" + value + "]";
	}

	  /**
	   * Class for deserializing ConfigurationItems.
	   */
	 

}
