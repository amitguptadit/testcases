package com.iag.infra.connector.exception;


public enum ConnectorErrorCode {
	
	REQUEST_INVALID_DATA_INVALID, MAX_POOL_LIMIT_REACHED, SYSTEM_UNAVAILABLE

}
