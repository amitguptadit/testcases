package com.iag.infra.connector.amadeusconnector.error;

/**
 * Enumeration containing error codes used as key by Membership Business Service to
 * fetch error message from infrastructure data source.
 */
public enum AmadeusErrorCode {
  
	REQUEST_INVALID,MANDATORY_DATA_MISSING, MAX_POOL_LIMIT_REACHED, SYSTEM_UNAVAILABLE
}
