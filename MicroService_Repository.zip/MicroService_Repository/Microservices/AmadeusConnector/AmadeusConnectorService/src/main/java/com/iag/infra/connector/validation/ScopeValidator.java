package com.iag.infra.connector.validation;

import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;

/**
 * ScopeValidator is responsible for validating channel.
 */
@Component
public class ScopeValidator {
	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;
	
	@Autowired
	public ScopeValidator(final ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * 
	 * @param validationServiceExceptionList
	 * @param scope
	 * @return
	 */
	public ValidationServiceException validate(final String scope) {
		ValidationServiceException validationServiceException = null;
        if (StringUtils.isEmpty(scope)) {

			validationServiceException = validationServiceExceptionGenerator.createValidationError(
					AmadeusSeviceErrorCode.MANDATORY_DATA_MISSING.name(), AmaduesConnectorServiceConstants.SCOPE_PARAM,AmaduesConnectorServiceConstants.MANDATORY_DATA_MISSING);
		} else {
			Pattern scopeMatcher = Pattern.compile(AmaduesConnectorServiceConstants.SCOPE_REGEX);
			if (!scopeMatcher.matcher(scope).matches()) {
				validationServiceException = validationServiceExceptionGenerator.createValidationError(
						AmadeusSeviceErrorCode.DATA_INVALID.name(), AmaduesConnectorServiceConstants.SCOPE_PARAM,AmaduesConnectorServiceConstants.DATA_INVALID);
            }
		}
		return validationServiceException;
	}

}