package com.iag.infra.connector.model;
	public class ConfigurationData {

	public String getOfficeId() {

	return officeId;

	}

	public void setOfficeId(String officeId) {

	this.officeId = officeId;

	}

	public String getOriginator() {

	return originator;

	}

	public void setOriginator(String originator) {

	this.originator = originator;

	}

	public String getMaxPoolSize() {

	return maxPoolSize;

	}

	public void setMaxPoolSize(String maxPoolSize) {

	this.maxPoolSize = maxPoolSize;

	}

	public String getWto() {

	return wto;

	}

	public void setWto(String wto) {

	this.wto = wto;

	}

	public String getDefaultPoolSize() {

	return defaultPoolSize;

	}

	public void setDefaultPoolSize(String defaultPoolSize) {

	this.defaultPoolSize = defaultPoolSize;

	}

	public String getPassword() {

	return password;

	}

	public void setPassword(String password) {

	this.password = password;

	}

	String officeId;

	String originator;

	String maxPoolSize;

	String wto;

	String defaultPoolSize;

	String password;

	}

