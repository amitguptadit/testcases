package com.iag.infra.connector.amadeusconnector.proxy;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.handlers.ServiceProxyRestCallResponseErrorHandler;
import com.iag.infra.connector.model.Config;
import com.iag.infra.connector.model.ConfigurationAuthenticationData;
import com.iag.infra.connector.model.ConfigurationItems;
import com.iag.infra.connector.model.ConfigurationNamespaces;
import com.iag.infra.connector.model.ConfigurationPoolData;

/**
 * 
 * Proxy to invoke configuration infrastructure service.
 * 
 */

@Component
public class ConfigurationInfrastructureServiceProxy implements ServiceProxy {

	public static final String IDENTIFIER_KEY = "identifier";

	public static final String RESOURCE_KEY_IDENTIFIER = "resource";

	private final ServiceUrlGenerator serviceUrlGenerator;

	private final String configurationServiceName;

	private RestTemplate restTemplate;

	private final String configurationServiceUriMetadata;

	private final ServiceProxyRestCallResponseErrorHandler serviceProxyRestCallResponseErrorHandler;
	private Map<String, ConfigurationPoolData> configurationMapforPool = new TreeMap<String, ConfigurationPoolData>(String.CASE_INSENSITIVE_ORDER);
	private Map<String, ConfigurationAuthenticationData> configurationMapforAuthentication = new TreeMap<String, ConfigurationAuthenticationData>((String.CASE_INSENSITIVE_ORDER));
	private Map<String, String> configurationMapForError = new TreeMap<String, String>((String.CASE_INSENSITIVE_ORDER));

	private final static String CONFIGURATION_SERVICE_URL = "/configurations";

	private final String CONFIGURATION_RESOURCE_KEY_IDENTIFIER;

	private final String CONFIGURATION_IDENTIFIER_KEY;
	private final static String CONFIGURATION_AMADEUS_ERROR = "AMADEUS.ERROR.";
	private final static String CONFIGURATION_POOL = "POOL.";
	private final static String CONFIGURATION_AUTH = "AUTH.";

	/**
	 * 
	 * Constructs ConfigurationInfrastructureServiceProxy instance.
	 * 
	 * 
	 * 
	 * @param serviceName
	 * 
	 * @param restTemplate
	 * 
	 * @param serviceUrlGenerator
	 * 
	 * @param configurationServiceUriMetadata
	 * 
	 */

	@Autowired

	public ConfigurationInfrastructureServiceProxy(@Value("${configuration.service.name}") final String serviceName,

			final ServiceUrlGenerator serviceUrlGenerator, RestTemplateBuilder restTemplateBuilder, final ServiceProxyRestCallResponseErrorHandler serviceProxyRestCallResponseErrorHandler,
			@Value("${configuration.serviceURL.metadata}") final String configurationServiceUriMetadata, @Value("${amadeus.configuration.resource}") final String configurationResourceKeyIdentifier,
			@Value("${amadeus.configuration.identifier}") final String configurationIdentifierKey) {

		this.configurationServiceName = serviceName;
		this.restTemplate = restTemplateBuilder.build();
		this.serviceUrlGenerator = serviceUrlGenerator;
		this.serviceProxyRestCallResponseErrorHandler = serviceProxyRestCallResponseErrorHandler;
		this.configurationServiceUriMetadata = configurationServiceUriMetadata;
		this.restTemplate.setErrorHandler(serviceProxyRestCallResponseErrorHandler);
		this.CONFIGURATION_IDENTIFIER_KEY = configurationIdentifierKey;
		this.CONFIGURATION_RESOURCE_KEY_IDENTIFIER = configurationResourceKeyIdentifier;

	}

	/**
	 * 
	 * Retrieves Configuration for pool from remote service and stores it in a
	 * map
	 * 
	 * which will be queried via key
	 * 
	 * 
	 * 
	 * @param key
	 * 
	 * @return configurationPoolData
	 * 
	 */

	public ConfigurationPoolData retrieveConfigurationForPool(String key) {
		return (ConfigurationPoolData) configurationMapforPool.get(key);
	}

	/**
	 * 
	 * Gets Configuration for authentication from the map stored which will be
	 * 
	 * queried via key
	 * 
	 * 
	 * 
	 * @param key
	 * 
	 * @return configurationPoolData
	 * 
	 */

	public ConfigurationAuthenticationData retrieveConfigurationForAuthentication(String key) {
		return (ConfigurationAuthenticationData) configurationMapforAuthentication.get(key);
	}

	/**
	 * 
	 * Clears the pool map created in memory
	 * 
	 */

	public void clearAllConfigurationData() {
		configurationMapforAuthentication.clear();
		configurationMapForError.clear();
		configurationMapforPool.clear();

		
	}

	 

	/**
	 * 
	 * Retrieves Configuration for error from remote service and stores it in a
	 * map
	 * 
	 * which will be queried via key
	 * 
	 * 
	 * 
	 * @param key
	 * 
	 * @return configurationPoolData
	 * 
	 */

	@Override
	public String retrieveConfigurationForError(String key) {
		if (configurationMapForError.isEmpty()) {
			getConfigData();
		}
		return configurationMapForError.get(key);
	}

	/**
	 * 
	 * Maps the json data received from service to model class
	 * @param configurationNamespaces
	 * @param configurationNamespaceMapforAuthentication2
	 */

	private void mapAndCreateConfigDataForAuthentication(ConfigurationNamespaces configurationNamespaces, Map<String, ConfigurationAuthenticationData> configurationNamespaceMapforAuthentication2) {

		configurationNamespaces.setName(configurationNamespaces.getName().replace(CONFIGURATION_AUTH, ""));
		BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(new ConfigurationAuthenticationData());

		for (ConfigurationItems configurationItems : configurationNamespaces.getConfigurationItems()) {

			bw.setPropertyValue(configurationItems.getIdentifier(), configurationItems.getValue());

		}

		configurationMapforAuthentication.put(configurationNamespaces.getName(),

				(ConfigurationAuthenticationData) bw.getWrappedInstance());

	}

	/**
	 * Maps the json data recieved from service to model class
	 * 
	 * @param configurationNamespaces
	 * @param configurationNamespaceMapforPool2
	 */

	private void mapAndCreatePoolConfigData(ConfigurationNamespaces configurationNamespaces, Map<String, ConfigurationPoolData> configurationNamespaceMapforPool2) {

		configurationNamespaces.setName(configurationNamespaces.getName().replace(CONFIGURATION_POOL, ""));
		BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(new ConfigurationPoolData());

		for (ConfigurationItems configurationItems : configurationNamespaces.getConfigurationItems()) {

			bw.setPropertyValue(configurationItems.getIdentifier(), configurationItems.getValue());

		}

		configurationNamespaceMapforPool2.put(configurationNamespaces.getName(),

				(ConfigurationPoolData) bw.getWrappedInstance());

	}
	
	/**
	 * Maps the json data recieved from service to model class
	 * 
	 * @param configurationNamespaces
	 * @param configurationMapForError
	 */
	private void mapAndCreateConfigDataForError(ConfigurationNamespaces configurationNamespaces, Map<String, String> configurationMapForError) {
		configurationNamespaces.setName(configurationNamespaces.getName().replace(CONFIGURATION_AMADEUS_ERROR, ""));
		for (ConfigurationItems configurationItems : configurationNamespaces.getConfigurationItems()) {
			configurationMapForError.put(configurationItems.getIdentifier(), configurationItems.getValue());
		}
	}

	private String getServiceURL() {

		Optional<String> optionalServiceURL = Optional.fromNullable(serviceUrlGenerator.generateUrl(configurationServiceName, configurationServiceUriMetadata));

		if (!optionalServiceURL.isPresent()) {
			throw new ApplicationServiceException(AmadeusSeviceErrorCode.SYSTEM_UNAVAILABLE.name());
		}
		return optionalServiceURL.get();

	}

	/**
	 * 
	 * Makes the real call to remote service to fetch the configuration of pool
	 * and
	 * 
	 * store in map
	 * 
	 * 
	 * 
	 * @param key
	 * 
	 * @return configurationPoolData
	 * 
	 */

	private void getConfigData() {
		final String url = getServiceURL() + CONFIGURATION_SERVICE_URL;

		final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam(RESOURCE_KEY_IDENTIFIER, CONFIGURATION_RESOURCE_KEY_IDENTIFIER).queryParam(IDENTIFIER_KEY,
				CONFIGURATION_IDENTIFIER_KEY);
		ResponseEntity<Config> response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, null, Config.class);

		Config configurationList = response.getBody();
		List<ConfigurationNamespaces> configurationNamespacesList = configurationList.getConfigurationNamespaces();
		for (ConfigurationNamespaces configurationNamespaces : configurationNamespacesList) {

			if (configurationNamespaces.getName().startsWith(CONFIGURATION_AMADEUS_ERROR)) {
				mapAndCreateConfigDataForError(configurationNamespaces, configurationMapForError);
			} else if (configurationNamespaces.getName().startsWith(CONFIGURATION_POOL)) {
				mapAndCreatePoolConfigData(configurationNamespaces, configurationMapforPool);
			} else if (configurationNamespaces.getName().startsWith(CONFIGURATION_AUTH)) {
				mapAndCreateConfigDataForAuthentication(configurationNamespaces, configurationMapforAuthentication);
			}
		}

	}

}