package com.iag.infra.connector.validation;

import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;

/**
 * ChannelValidator is responsible for validating channel.
 */
@Component
public class ChannelValidator {
		private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	@Autowired
	public ChannelValidator(ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * 
	 * @param validationServiceExceptionList
	 * @param channel
	 * @return
	 */
	public ValidationServiceException validate(final String channel) {
		ValidationServiceException validationServiceException = null;
        if (StringUtils.isEmpty(channel)) {
			validationServiceException = validationServiceExceptionGenerator.createValidationError(
					AmadeusSeviceErrorCode.MANDATORY_DATA_MISSING.name(), AmaduesConnectorServiceConstants.CHANNEL_PARAM,AmaduesConnectorServiceConstants.MANDATORY_DATA_MISSING);
		} else {
			Pattern channelMatcher = Pattern.compile(AmaduesConnectorServiceConstants.CHANNEL_REGEX);
			if (!channelMatcher.matcher(channel).matches()) {
				validationServiceException = validationServiceExceptionGenerator.createValidationError(
						AmadeusSeviceErrorCode.DATA_INVALID.name(), AmaduesConnectorServiceConstants.CHANNEL_PARAM,AmaduesConnectorServiceConstants.DATA_INVALID);
			}
		}
		return validationServiceException;
	}

}
