package com.iag.infra.connector.amadeusconnector.error.handlers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.ResponseErrorHandler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ProxyServiceSoapFaultErrors;

@Component
public class ServiceProxyRestCallResponseErrorHandler implements ResponseErrorHandler {
	 private final ObjectMapper objectMapper = new ObjectMapper();
	  private static final String CODE = "code";

    private static final String ERROR = "childError";
	  private static final Logger LOG = LoggerFactory.getLogger(ServiceProxyRestCallResponseErrorHandler.class);

	@Override
	public void handleError(ClientHttpResponse response) throws IOException {

        final Map<String, ArrayList<LinkedHashMap<String, String>>> errors = objectMapper.readValue(response.getBody(),
                Map.class);

        ArrayList<LinkedHashMap<String, String>> Errors = errors.get(ERROR);
        LOG.info("Error caught from API : " + Errors);
        String childErrorCode = null;
        if (!CollectionUtils.isEmpty(Errors)) {
            childErrorCode = Errors.get(0).get(CODE);
	    }
      
        throw createError(childErrorCode);
	  
		
	}

	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {
	return	isError(response.getStatusCode());
	}

	
	private boolean isError(final HttpStatus status) {
	    HttpStatus.Series series = status.series();
	    return !(HttpStatus.Series.SUCCESSFUL.equals(series));
	  }
	
	private ApplicationServiceException createError(final String childErrorCode){
		
		ProxyServiceSoapFaultErrors errorCode =
				ProxyServiceSoapFaultErrors.getErrorCode(String.valueOf(childErrorCode));
		if(errorCode==null){
			errorCode=ProxyServiceSoapFaultErrors.DEFAULT;
		}
		 String applicationErrorCode=null;
		
		switch (errorCode) {
		case MANDATORY_DATA_MISSING:
			applicationErrorCode= AmadeusSeviceErrorCode.MISSING_CONFIG_DATA.name();
			break;
		case NO_CONTENT:
			applicationErrorCode= AmadeusSeviceErrorCode.MISSING_CONFIG_DATA.name();
			break;
		case DATA_INVALID:
			applicationErrorCode= AmadeusSeviceErrorCode.MISSING_CONFIG_DATA.name();
			break;
		case INTERNAL_SERVER_ERROR:
			applicationErrorCode= AmadeusSeviceErrorCode.SYSTEM_UNAVAILABLE.name();
		break;
		case METHOD_NOT_SUPPORTED:
			applicationErrorCode= AmadeusSeviceErrorCode.SYSTEM_UNAVAILABLE.name();
			break;
		default:
			applicationErrorCode= AmadeusSeviceErrorCode.SYSTEM_UNAVAILABLE.name();
			break;
		}
		
		return new ApplicationServiceException(applicationErrorCode);
	}
	
	 
}
