package com.iag.infra.connector.validation;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;

/**
 * AmadeusConnectorRequestValidator is responsible for validating request.
 */
@Component
public class AmadeusConnectorGetRequestValidator {

	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;
	private final ScopeValidator scopeValidator;
	private final ChannelValidator channelValidator;
	private final CountrycodeValidator countrycodeValidator;
private final DeviceValidator deviceValidator;

    private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(AmadeusConnectorGetRequestValidator.class);
	Map<String, String> reqParametersIgnoreCase = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);

	@Autowired
	public AmadeusConnectorGetRequestValidator(final ScopeValidator scopeValidator,
            final ChannelValidator channelValidator, final CountrycodeValidator countrycodeValidator,final ValidationServiceExceptionGenerator validationServiceExceptionGenerator,final DeviceValidator deviceValidator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
		this.scopeValidator = scopeValidator;
		this.countrycodeValidator = countrycodeValidator;
		this.channelValidator = channelValidator;
		this.deviceValidator=deviceValidator;

	}

	/**
	 * The following method verifies that request parameter key is of various
	 * allowable formats else it throws exception.:
	 * 
	 * @param resource
	 * @param identifier
	 * @param version
	 * @param apiKey
	 */
	public void validateGetSessionRequest(final Map<String, String> reqParameters) {
		List<ValidationServiceException> validationServiceExceptionlist = Lists.newArrayList();
		validationServiceExceptionlist.add(
				scopeValidator.validate(reqParameters.get(AmaduesConnectorServiceConstants.SCOPE_PARAM)));
		validationServiceExceptionlist.add(
				channelValidator.validate(reqParameters.get(AmaduesConnectorServiceConstants.CHANNEL_PARAM)));
		validationServiceExceptionlist.add(countrycodeValidator.validate(reqParameters.get(AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM),
                AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM));
		
		validationServiceExceptionlist.add(deviceValidator.validate(reqParameters.get(AmaduesConnectorServiceConstants.DEVICE_PARAM),
                AmaduesConnectorServiceConstants.DEVICE_PARAM));
		
		validationServiceExceptionlist.removeAll(Collections.singleton(null));
		if (!validationServiceExceptionlist.isEmpty()) {
			LOG.info("validateForGet  method invoking when Exception is occure in request processing ");
			throw validationServiceExceptionGenerator
					.createServiceExceptionWithChildError(validationServiceExceptionlist);
		}
	}
}