package com.iag.infra.connector.configuration;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.transport.http.CommonsHttpMessageSender;

import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.proxy.ConfigurationInfrastructureServiceProxy;

public class AmedeusConnectorConfigTest {


    AmedeusConnectorConfig amedeusConnectorConfig;

    @Mock
    WebServiceTemplate amadeusWebServiceTemplate;

    @Mock
    Jaxb2Marshaller amadeusMarshaller;

    @Mock
    Jaxb2Marshaller amadeusUnMarshaller;

    @Mock
    RestTemplateBuilder builder;

    @Mock
    CommonsHttpMessageSender httpSender;

    @Mock
    private ConfigurationInfrastructureServiceProxy configurationInfrastructureServiceProxy;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        amedeusConnectorConfig = new AmedeusConnectorConfig();
        ReflectionTestUtils.setField(amedeusConnectorConfig, "configurationInfrastructureServiceProxy",
                configurationInfrastructureServiceProxy);

    }

    @Test
    public void shouldGetHttpSender() throws Exception {
        CommonsHttpMessageSender commonsHttpMessageSender = amedeusConnectorConfig.httpSender();
        assertNotNull(commonsHttpMessageSender);
    }

    @Test
    public void shouldTestAmadeusWebServiceTemplate() {
        Mockito.when(
                configurationInfrastructureServiceProxy
                        .retrieveConfigurationForError(AmaduesConnectorServiceConstants.AMADEUS_GATEWAY_WEBURL))
                .thenReturn("https://BAaccess.test.webservices.1a.amadeus.com:52069");
        WebServiceTemplate webServiceTemplate = amedeusConnectorConfig.amadeusWebServiceTemplate(amadeusMarshaller,
                amadeusUnMarshaller, httpSender);
        assertNotNull(webServiceTemplate);
        Assert.assertEquals(webServiceTemplate.getDefaultUri(),
                "https://BAaccess.test.webservices.1a.amadeus.com:52069");
    }

    @Test
    public void shouldGetAmadeusMarshaller() throws Exception {
        Mockito.when(
                configurationInfrastructureServiceProxy
                        .retrieveConfigurationForError(AmaduesConnectorServiceConstants.AMADEUS_SIGNIN_MARSHALLER))
                .thenReturn("com.amadeus.xml.vlstlq_11_1_1a");
        Mockito.when(
                configurationInfrastructureServiceProxy
                        .retrieveConfigurationForError(AmaduesConnectorServiceConstants.AMADEUS_SIGNOUT_MARSHALLER))
                .thenReturn("com.amadeus.xml.vlssoq_04_1_1a");

        Jaxb2Marshaller amadeusMarshaller = amedeusConnectorConfig.amadeusMarshaller();
        assertNotNull(amadeusMarshaller);
        assertNotNull(amadeusMarshaller.getContextPath());
    }

    @Test
    public void shouldGetAmadeusUnMarshaller() throws Exception {
        Mockito.when(
                configurationInfrastructureServiceProxy
                        .retrieveConfigurationForError(AmaduesConnectorServiceConstants.AMADEUS_SIGNIN_UNMARSHALLER))
                .thenReturn("com.amadeus.xml.vlstlr_11_1_1a");
        Mockito.when(
                configurationInfrastructureServiceProxy
                        .retrieveConfigurationForError(AmaduesConnectorServiceConstants.AMADEUS_SIGNOUT_UNMARSHALLER))
                .thenReturn("com.amadeus.xml.vlssor_04_1_1a");
        Jaxb2Marshaller amadeusUnMarshaller = amedeusConnectorConfig.amadeusUnMarshaller();
        assertNotNull(amadeusUnMarshaller);
        assertNotNull(amadeusUnMarshaller.getContextPath());
    }


}
