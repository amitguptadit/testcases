
package com.iag.infra.connector.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.amadeus.xml.vlsslr_06_1_1a.ApplicationErrorDetailType;
import com.amadeus.xml.vlsslr_06_1_1a.ApplicationErrorInformationType;
import com.amadeus.xml.vlsslr_06_1_1a.InteractiveFreeTextTypeI;
import com.amadeus.xml.vlsslr_06_1_1a.ResponseAnalysisDetailsType;
import com.amadeus.xml.vlsslr_06_1_1a.SecurityAuthenticateReply;
import com.amadeus.xml.vlsslr_06_1_1a.SecurityAuthenticateReply.ErrorSection;
import com.google.common.collect.Lists;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusErrorCode;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ApplicationServiceExceptionGenerator;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;
import com.iag.infra.connector.amadeusconnector.proxy.ServiceProxy;
import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.model.AmadeusConnectionDetails;
import com.iag.infra.connector.model.AmedeusResponseDetails;
import com.iag.infra.connector.model.ConfigurationPoolData;
import com.iag.infra.connector.repository.impl.SessionProviderRepositoryImpl;
import com.iag.infra.connector.service.pool.SessionFactory;
import com.iag.infra.connector.service.pool.SessionPool;
import com.iag.infra.connector.service.pool.SessionPoolFactory;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;
import com.iag.infra.connector.utility.AmadeusConnectorServiceUtility;

public class AmadeusConnectorServiceTest {

    private static final String SOAP_ACTION_URI = "http://webservices.amadeus.com/1ASIWCP2BA/VLSTLQ_11_1_1A";

    private static final String SCOPE = "BOOKING";
    private static final String DEVICE_ID = "WEB";

    private static final String COUNTRY_CODE = "GB";

    private static final String CHANNEL = "KIOSK";

    private static final String SECURITY_TOKEN = "2Y4BVG37P16P42HTA1YFUH5ZBE";

    private static final int SEQUENCE_NUMBER = 1;

    private static final String SESSION_ID = "02WQO94SAI";

	private AmadeusConnectorService amadeusConnectorService;

    @Mock
	private SessionPoolFactory mockAmadeusSessionPoolFactory;

    @Mock
    private ServiceProxy serviceProxy;

    private ApplicationServiceExceptionGenerator applicationServiceExceptionGenerator;

    @Mock
    private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;


    @Mock
    private WebServiceTemplate amadeusWebServiceTemplate;

    @Mock
    private AmadeusConnectorServiceUtility amadeusConnectorServiceUtility;

    @Rule
	public ExpectedException expectedException = ExpectedException.none();

    private SessionProviderRepositoryImpl sessionProviderRepository;

	@Before
    public void setup() throws Exception {
        MockitoAnnotations.initMocks(this);

        applicationServiceExceptionGenerator = new ApplicationServiceExceptionGenerator(amadeusConnectorServiceUtility);

        sessionProviderRepository = new SessionProviderRepositoryImpl();
        amadeusConnectorService = new AmadeusConnectorService(mockAmadeusSessionPoolFactory,
                validationServiceExceptionGenerator, serviceProxy);

        ReflectionTestUtils.setField(sessionProviderRepository, "amadeusWebServiceTemplate", amadeusWebServiceTemplate);
        ReflectionTestUtils.setField(sessionProviderRepository, "applicationServiceExceptionGenerator",
                applicationServiceExceptionGenerator);
	}

    @SuppressWarnings("unchecked")
    @Test
    public void shouldBorrowObjectFromSessionPool() throws Exception {

        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithSuccess());

        Map<String, String> reqParams = createRequestMapFromSessionIdentifier();
        ConfigurationPoolData configurationData = getConfigurationPoolData();
        when(serviceProxy.retrieveConfigurationForPool("GB.BOOKING.KIOSK")).thenReturn(configurationData);
        SessionPool<Session> sessionPool = createSessionPool();
        when(mockAmadeusSessionPoolFactory.createAmadeusSessionPool(Mockito.any(SessionPoolIdentifier.class)))
                .thenReturn(sessionPool);

        assertEquals(0, sessionPool.getCreatedCount());
        assertEquals(0, sessionPool.getNumIdle());
        assertEquals(0, sessionPool.getNumActive());
        Session session = amadeusConnectorService.getSession(reqParams);
        assertEquals(1, sessionPool.getCreatedCount());
        assertEquals(0, sessionPool.getNumIdle());
        assertEquals(1, sessionPool.getNumActive());

        assertEquals(SESSION_ID, session.getSessionIdentifier());
        assertEquals(SECURITY_TOKEN, session.getTokenNumber());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldThrowExceptionWhileBorrowingObjectFromPoolWhenMaxPoolSizeReached() throws Exception {

        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithSuccess());

        Map<String, String> reqParams = createRequestMapFromSessionIdentifier();
        ConfigurationPoolData configurationData = getConfigurationPoolData();
        when(serviceProxy.retrieveConfigurationForPool("GB.BOOKING.KIOSK")).thenReturn(configurationData);
        SessionPool<Session> sessionPool = createSessionPool();
        when(mockAmadeusSessionPoolFactory.createAmadeusSessionPool(Mockito.any(SessionPoolIdentifier.class)))
                .thenReturn(sessionPool);

        assertEquals(0, sessionPool.getCreatedCount());
        assertEquals(0, sessionPool.getNumIdle());
        assertEquals(0, sessionPool.getNumActive());
        amadeusConnectorService.getSession(reqParams);
        assertEquals(1, sessionPool.getCreatedCount());
        assertEquals(0, sessionPool.getNumIdle());
        assertEquals(1, sessionPool.getNumActive());
        amadeusConnectorService.getSession(reqParams);
        assertEquals(2, sessionPool.getCreatedCount());
        assertEquals(0, sessionPool.getNumIdle());
        assertEquals(1, sessionPool.getNumActive());

        expectedException.expect(ApplicationServiceException.class);
        expectedException.expectMessage(AmadeusErrorCode.MAX_POOL_LIMIT_REACHED.name());

        //Now pool have maximum object(Max Object configured in pool is =2).
        amadeusConnectorService.getSession(reqParams);

    }


    @Test
    public void shouldThrowExceptionWhenPoolIsNotConfiguredForGetSession() throws Exception {
        SessionPoolIdentifier sessionPoolIdentifier = createnSessionPoolIdentifier();

        when(serviceProxy.retrieveConfigurationForPool(sessionPoolIdentifier.getSessionPoolIdentifierKey()))
                .thenReturn(null);

        expectedException.expect(ValidationServiceException.class);
        expectedException.expectMessage("REQUEST_INVALID");

        amadeusConnectorService.getSession(createRequestMapFromSessionIdentifier());

    }
    
    
    
    @SuppressWarnings("unchecked")
    @Test
    public void shouldThrowApplicationServiceExceptionWhileBorrowingObjectFromSessionPool() throws Exception {

        AmedeusResponseDetails soapResposneWithError = createSoapResposneWithError();
        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(soapResposneWithError);

        ConfigurationPoolData configurationData = getConfigurationPoolData();
        when(serviceProxy.retrieveConfigurationForPool("GB.BOOKING.KIOSK")).thenReturn(configurationData);
        SessionPool<Session> sessionPool = createSessionPool();
        when(mockAmadeusSessionPoolFactory.createAmadeusSessionPool(Mockito.any(SessionPoolIdentifier.class)))
                .thenReturn(sessionPool);


        expectedException.expect(ApplicationServiceException.class);
        expectedException.expectMessage(AmadeusSeviceErrorCode.REQUEST_UNAUTHORIZED.name());
        amadeusConnectorService.getSession(createRequestMapFromSessionIdentifier());

    }
   
    
    
    

    @SuppressWarnings("unchecked")
    @Test
    public void shouldReturnObjectToSessionPool() throws Exception {

        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithSuccess());

        Map<String, String> reqParams = createRequestMapFromSessionIdentifier();
        ConfigurationPoolData configurationData = getConfigurationPoolData();
        when(serviceProxy.retrieveConfigurationForPool("GB.BOOKING.KIOSK")).thenReturn(configurationData);
        SessionPool<Session> sessionPool = createSessionPool();
        when(mockAmadeusSessionPoolFactory.createAmadeusSessionPool(Mockito.any(SessionPoolIdentifier.class)))
                .thenReturn(sessionPool);

        assertEquals(0, sessionPool.getCreatedCount());
        assertEquals(0, sessionPool.getNumIdle());
        assertEquals(0, sessionPool.getNumActive());
        final Session session = amadeusConnectorService.getSession(reqParams);
        assertEquals(1, sessionPool.getCreatedCount());
        assertEquals(0, sessionPool.getNumIdle());
        assertEquals(1, sessionPool.getNumActive());

        assertEquals(0, sessionPool.getReturnedCount());
        amadeusConnectorService.releaseSession(session);
        assertEquals(1, sessionPool.getReturnedCount());

        assertEquals(SESSION_ID, session.getSessionIdentifier());
        assertEquals(SECURITY_TOKEN, session.getTokenNumber());

    }

    @Test
    public void shouldNotReturnObjectToPoolWhenObjectNotMatchedFromSessionPool() throws Exception {



        ConfigurationPoolData configurationData = getConfigurationPoolData();
        when(serviceProxy.retrieveConfigurationForPool("GB.BOOKING.KIOSK")).thenReturn(configurationData);
        SessionPool<Session> sessionPool = createSessionPool();
        when(mockAmadeusSessionPoolFactory.createAmadeusSessionPool(Mockito.any(SessionPoolIdentifier.class)))
                .thenReturn(sessionPool);
        final Session session = createSession();

        assertEquals(0, sessionPool.getCreatedCount());
        assertEquals(0, sessionPool.getNumIdle());
        assertEquals(0, sessionPool.getNumActive());
        assertEquals(0, sessionPool.getReturnedCount());
        expectedException.expect(ValidationServiceException.class);
        expectedException.expectMessage(AmadeusSeviceErrorCode.REQUEST_INVALID.name());
        amadeusConnectorService.releaseSession(session);


    }

    @Test
    public void shouldNotReturnObjectToSessionPoolWhenPoolIsNotConfigured() throws Exception {
        SessionPoolIdentifier sessionPoolIdentifier = createnSessionPoolIdentifier();


        when(serviceProxy.retrieveConfigurationForPool(sessionPoolIdentifier.getSessionPoolIdentifierKey()))
                .thenReturn(null);
        SessionPool<Session> sessionPool = createSessionPool();
        when(mockAmadeusSessionPoolFactory.createAmadeusSessionPool(Mockito.any(SessionPoolIdentifier.class)))
                .thenReturn(sessionPool);

        expectedException.expect(ValidationServiceException.class);
        expectedException.expectMessage(AmadeusSeviceErrorCode.REQUEST_INVALID.name());
        amadeusConnectorService.releaseSession(createSession());

    }
	private Map<String, String> createRequestMapFromSessionIdentifier() {
		Map<String, String> reqParams = new HashMap<>();

		reqParams.put(AmaduesConnectorServiceConstants.CHANNEL_PARAM, CHANNEL);
		reqParams.put(AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM, "gb");
        reqParams.put(AmaduesConnectorServiceConstants.SCOPE_PARAM, SCOPE);
        reqParams.put(AmaduesConnectorServiceConstants.DEVICE_PARAM, DEVICE_ID);
		return reqParams;

	}



    private ConfigurationPoolData getConfigurationPoolData() {
        ConfigurationPoolData configurationData = new ConfigurationPoolData();
        configurationData.setDefaultPoolSize("10");
        configurationData.setMaxPoolSize("50");
        configurationData.setMinPoolSize("5");
        configurationData.setWaitingTimeOut("70000");
        return configurationData;
    }



    

    


    private SessionPool<Session> createSessionPool() {

        SessionFactory amadeusSessionFactory = new SessionFactory(sessionProviderRepository,
                createAmadeusConnectionDetails(), createnSessionPoolIdentifier());
        SessionPool<Session> genericObjectPool = new SessionPool<Session>(amadeusSessionFactory);
        genericObjectPool.setMinIdle(1);
        genericObjectPool.setMaxIdle(2);
        genericObjectPool.setMaxWaitMillis(2000);
        genericObjectPool.setMaxTotal(2);
        return genericObjectPool;
    }

    private SessionPoolIdentifier createnSessionPoolIdentifier() {
        SessionPoolIdentifier sessionPoolIdentifier = new SessionPoolIdentifier();
        sessionPoolIdentifier.setChannel(CHANNEL);
        sessionPoolIdentifier.setCountrycode(COUNTRY_CODE);
        sessionPoolIdentifier.setScope(SCOPE);
        return sessionPoolIdentifier;

    }
    private AmadeusConnectionDetails createAmadeusConnectionDetails() {
        AmadeusConnectionDetails amadeusConnectionDetails = new AmadeusConnectionDetails();
        amadeusConnectionDetails.setOriginatorForIdentificationType("dummy");
        amadeusConnectionDetails.setOriginatorTypeCodeForIdentificationType("su");
        amadeusConnectionDetails.setOriginatorForUserIdentificationType("BA");
        amadeusConnectionDetails.setOriginatorTypeCodeForUserIdentificationType("SU");
        amadeusConnectionDetails.setSecurityAuthenticate(SOAP_ACTION_URI);
        return amadeusConnectionDetails;
    }

    private AmedeusResponseDetails createSoapResposneWithSuccess() {
        AmedeusResponseDetails response = new AmedeusResponseDetails();
        SecurityAuthenticateReply soapResponse = new SecurityAuthenticateReply();
        ResponseAnalysisDetailsType responseAnalysisDetailsType = new ResponseAnalysisDetailsType("P");
        soapResponse.setProcessStatus(responseAnalysisDetailsType);

        response.setSoapResponse(soapResponse);
        response.setSecurityToken(SECURITY_TOKEN);
        response.setSequenceNumber(SEQUENCE_NUMBER);
        response.setSessionId(SESSION_ID);
        return response;
    }
    
    private AmedeusResponseDetails createSoapResposneWithError() {
        AmedeusResponseDetails response = new AmedeusResponseDetails();
        SecurityAuthenticateReply soapResponse = new SecurityAuthenticateReply();

        ApplicationErrorDetailType errorDetails = new ApplicationErrorDetailType("26322", "EC", "LSS");
        ApplicationErrorInformationType errorOrWarningCodeDetails = new ApplicationErrorInformationType(errorDetails);

        List<String> freeText = Lists.newArrayList();
        freeText.add("Authentication failed. Please check your credentials and try again.");
        InteractiveFreeTextTypeI errorWarningDescription = new InteractiveFreeTextTypeI(null, freeText);
        ErrorSection errorGroupType = new ErrorSection(errorOrWarningCodeDetails, errorWarningDescription);
        soapResponse.setErrorSection(errorGroupType);

        response.setSoapResponse(soapResponse);
        response.setSecurityToken(SECURITY_TOKEN);
        response.setSequenceNumber(SEQUENCE_NUMBER);
        response.setSessionId(SESSION_ID);
        return response;
    }

    private Session createSession() {
        Session session = new Session();
        session.setChannel(CHANNEL);
        session.setLocation(COUNTRY_CODE);
        session.setScope(SCOPE);
        return session;
    }

}