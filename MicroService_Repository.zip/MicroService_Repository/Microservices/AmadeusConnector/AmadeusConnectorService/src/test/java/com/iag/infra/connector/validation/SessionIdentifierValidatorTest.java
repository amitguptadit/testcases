package com.iag.infra.connector.validation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;

public class SessionIdentifierValidatorTest {
	@Mock
	ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	SessionIdentifierValidator sessionIdentifierValidator;
	ValidationServiceException validationServiceException;

	@Before
	public void setUp() {
		validationServiceExceptionGenerator = mock(ValidationServiceExceptionGenerator.class);
		sessionIdentifierValidator = new SessionIdentifierValidator(validationServiceExceptionGenerator);

	}

	@Test
	public void shouldValidateWhenSessionIdentifierIsAnyValue() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

		validationServiceException = sessionIdentifierValidator.validate("$$$Data**");
		assertNotNull(validationServiceException);
		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());
		assertEquals(AmaduesConnectorServiceConstants.SESSION_ID_PARAM, validationServiceException.getPath());
		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}

	@Test

	public void shouldValidateWhenSessionIdentifierIsNull() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceException());
		validationServiceException = sessionIdentifierValidator.validate(null);
		assertNotNull(validationServiceException);
		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());
		assertEquals(AmaduesConnectorServiceConstants.SESSION_ID_PARAM, validationServiceException.getPath());
		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}

	@Test

	public void shouldValidateWhenSessionIdentifierIsValid() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

		validationServiceException = sessionIdentifierValidator.validate("Bookings");

		assertNull(validationServiceException);

	}

	private ValidationServiceException createValidationServiceException() {

		ValidationServiceException validationServiceException = new ValidationServiceException(
				AmadeusSeviceErrorCode.DATA_INVALID.name());
		validationServiceException.setDeveloperMessage(AmadeusSeviceErrorCode.DATA_INVALID.name());
		validationServiceException.setPath(AmaduesConnectorServiceConstants.SESSION_ID_PARAM);

		return validationServiceException;

	}
}
