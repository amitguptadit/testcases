package com.iag.infra.connector.amadeusconnector.error.handlers;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;

public class ServiceProxyRestCallResponseErrorHandlerTest {

    private ServiceProxyRestCallResponseErrorHandler serviceProxyRestCallResponseErrorHandler;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private ClientHttpResponse response;

    private static final String CODE = "code";

    private static final String ERROR = "childError";

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        serviceProxyRestCallResponseErrorHandler = new ServiceProxyRestCallResponseErrorHandler();
        ReflectionTestUtils.setField(serviceProxyRestCallResponseErrorHandler, "objectMapper", objectMapper);

    }

    @Test
    public void shouldReturnTrueWhenHttpStatusIsCientError() throws IOException {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        Mockito.when(response.getStatusCode()).thenReturn(httpStatus);
        boolean result = serviceProxyRestCallResponseErrorHandler.hasError(response);
        Assert.assertTrue(result);

    }

    @Test
    public void shouldReturnTrueWhenHttpStatusIsServerError() throws IOException {
        HttpStatus httpStatus = HttpStatus.SERVICE_UNAVAILABLE;
        Mockito.when(response.getStatusCode()).thenReturn(httpStatus);
        boolean result = serviceProxyRestCallResponseErrorHandler.hasError(response);
        Assert.assertTrue(result);
    }

    @Test
    public void shouldReturnFalseWhenHttpStatusIsNeitherServerErrorNorClientError() throws IOException {
        HttpStatus httpStatus = HttpStatus.OK;
        Mockito.when(response.getStatusCode()).thenReturn(httpStatus);
        boolean result = serviceProxyRestCallResponseErrorHandler.hasError(response);
        Assert.assertFalse(result);
    }

    @Test
    public void shouldThrowServiceExceptionForMandatoryDataMissing() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        InputStream inputStream = Mockito.mock(InputStream.class);
        Mockito.when(response.getBody()).thenReturn(inputStream);
        Mockito.when(response.getHeaders()).thenReturn(headers);
        Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.UNAUTHORIZED);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = createErrorMapForMandatoryDataMissing();
        Mockito.when(objectMapper.readValue(inputStream, Map.class)).thenReturn(errorMap);
        thrown.expect(ApplicationServiceException.class);
        serviceProxyRestCallResponseErrorHandler.handleError(response);
    }

    @Test
    public void shouldThrowServiceExceptionForNoContent() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        InputStream inputStream = Mockito.mock(InputStream.class);
        Mockito.when(response.getBody()).thenReturn(inputStream);
        Mockito.when(response.getHeaders()).thenReturn(headers);
        Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.UNAUTHORIZED);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = createErrorMapForNoContent();
        Mockito.when(objectMapper.readValue(inputStream, Map.class)).thenReturn(errorMap);
        thrown.expect(ApplicationServiceException.class);
        serviceProxyRestCallResponseErrorHandler.handleError(response);
    }

    @Test
    public void shouldThrowServiceExceptionForDataInvalid() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        InputStream inputStream = Mockito.mock(InputStream.class);
        Mockito.when(response.getBody()).thenReturn(inputStream);
        Mockito.when(response.getHeaders()).thenReturn(headers);
        Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.UNAUTHORIZED);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = createErrorMapForDataInvalid();
        Mockito.when(objectMapper.readValue(inputStream, Map.class)).thenReturn(errorMap);
        thrown.expect(ApplicationServiceException.class);
        serviceProxyRestCallResponseErrorHandler.handleError(response);
    }

    @Test
    public void shouldThrowServiceExceptionForInternalServerError() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        InputStream inputStream = Mockito.mock(InputStream.class);
        Mockito.when(response.getBody()).thenReturn(inputStream);
        Mockito.when(response.getHeaders()).thenReturn(headers);
        Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.UNAUTHORIZED);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = createErrorMapForInternalServerError();
        Mockito.when(objectMapper.readValue(inputStream, Map.class)).thenReturn(errorMap);
        thrown.expect(ApplicationServiceException.class);
        serviceProxyRestCallResponseErrorHandler.handleError(response);
    }

    @Test
    public void shouldThrowServiceExceptionForMethodNotSupported() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        InputStream inputStream = Mockito.mock(InputStream.class);
        Mockito.when(response.getBody()).thenReturn(inputStream);
        Mockito.when(response.getHeaders()).thenReturn(headers);
        Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.UNAUTHORIZED);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = createErrorMapForMethodNotSupported();
        Mockito.when(objectMapper.readValue(inputStream, Map.class)).thenReturn(errorMap);
        thrown.expect(ApplicationServiceException.class);
        serviceProxyRestCallResponseErrorHandler.handleError(response);
    }

    @Test
    public void shouldThrowServiceExceptionForWhenErrorIsNull() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        InputStream inputStream = Mockito.mock(InputStream.class);
        Mockito.when(response.getBody()).thenReturn(inputStream);
        Mockito.when(response.getHeaders()).thenReturn(headers);
        Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.UNAUTHORIZED);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = createErrorMapWhenErrorCodeIsInvalid();
        Mockito.when(objectMapper.readValue(inputStream, Map.class)).thenReturn(errorMap);
        thrown.expect(ApplicationServiceException.class);
        serviceProxyRestCallResponseErrorHandler.handleError(response);
    }

    @Test
    public void shouldThrowServiceExceptionForWhenErrorCodeIsNull() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        InputStream inputStream = Mockito.mock(InputStream.class);
        Mockito.when(response.getBody()).thenReturn(inputStream);
        Mockito.when(response.getHeaders()).thenReturn(headers);
        Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.UNAUTHORIZED);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = createErrorMapInWhenErrorIsNull();
        Mockito.when(objectMapper.readValue(inputStream, Map.class)).thenReturn(errorMap);
        thrown.expect(ApplicationServiceException.class);
        serviceProxyRestCallResponseErrorHandler.handleError(response);
    }

    private Map<String, ArrayList<LinkedHashMap<String, String>>> createErrorMapForMandatoryDataMissing() {

        LinkedHashMap<String, String> linkedErrorMap = new LinkedHashMap<String, String>();
        linkedErrorMap.put(CODE, AmadeusSeviceErrorCode.MANDATORY_DATA_MISSING.name());
        ArrayList<LinkedHashMap<String, String>> errors = new ArrayList<LinkedHashMap<String, String>>();
        errors.add(0, linkedErrorMap);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = Maps.newHashMap();
        errorMap.put(ERROR, errors);
        return errorMap;

    }

    private Map<String, ArrayList<LinkedHashMap<String, String>>> createErrorMapForNoContent() {

        LinkedHashMap<String, String> linkedErrorMap = new LinkedHashMap<String, String>();
        linkedErrorMap.put(CODE, AmadeusSeviceErrorCode.NO_CONTENT.name());
        ArrayList<LinkedHashMap<String, String>> errors = new ArrayList<LinkedHashMap<String, String>>();
        errors.add(0, linkedErrorMap);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = Maps.newHashMap();
        errorMap.put(ERROR, errors);
        return errorMap;

    }

    private Map<String, ArrayList<LinkedHashMap<String, String>>> createErrorMapForInternalServerError() {

        LinkedHashMap<String, String> linkedErrorMap = new LinkedHashMap<String, String>();
        linkedErrorMap.put(CODE, AmadeusSeviceErrorCode.INTERNAL_SERVER_ERROR.name());
        ArrayList<LinkedHashMap<String, String>> errors = new ArrayList<LinkedHashMap<String, String>>();
        errors.add(0, linkedErrorMap);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = Maps.newHashMap();
        errorMap.put(ERROR, errors);
        return errorMap;

    }

    private Map<String, ArrayList<LinkedHashMap<String, String>>> createErrorMapForDataInvalid() {
        LinkedHashMap<String, String> linkedErrorMap = new LinkedHashMap<String, String>();
        linkedErrorMap.put(CODE, AmadeusSeviceErrorCode.DATA_INVALID.name());
        ArrayList<LinkedHashMap<String, String>> errors = new ArrayList<LinkedHashMap<String, String>>();
        errors.add(0, linkedErrorMap);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = Maps.newHashMap();
        errorMap.put(ERROR, errors);
        return errorMap;

    }

    private Map<String, ArrayList<LinkedHashMap<String, String>>> createErrorMapForMethodNotSupported() {
        LinkedHashMap<String, String> linkedErrorMap = new LinkedHashMap<String, String>();
        linkedErrorMap.put(CODE, AmadeusSeviceErrorCode.METHOD_NOT_SUPPORTED.name());
        ArrayList<LinkedHashMap<String, String>> errors = new ArrayList<LinkedHashMap<String, String>>();
        errors.add(0, linkedErrorMap);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = Maps.newHashMap();
        errorMap.put(ERROR, errors);
        return errorMap;

    }

    private Map<String, ArrayList<LinkedHashMap<String, String>>> createErrorMapWhenErrorCodeIsInvalid() {
        LinkedHashMap<String, String> linkedErrorMap = new LinkedHashMap<String, String>();
        linkedErrorMap.put(CODE, AmadeusSeviceErrorCode.NOT_SUPPORTED.name());
        ArrayList<LinkedHashMap<String, String>> errors = new ArrayList<LinkedHashMap<String, String>>();
        errors.add(0, linkedErrorMap);
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = Maps.newHashMap();
        errorMap.put(ERROR, errors);
        return errorMap;

    }

    private Map<String, ArrayList<LinkedHashMap<String, String>>> createErrorMapInWhenErrorIsNull() {
        Map<String, ArrayList<LinkedHashMap<String, String>>> errorMap = Maps.newHashMap();
        errorMap.put(ERROR, null);
        return errorMap;

    }
}
