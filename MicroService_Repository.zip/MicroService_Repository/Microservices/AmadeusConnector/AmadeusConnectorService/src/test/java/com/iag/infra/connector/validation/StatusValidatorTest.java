package com.iag.infra.connector.validation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;

public class StatusValidatorTest {
	@Mock
	ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	StatusValidator statusValidator;
	ValidationServiceException validationServiceException;

	@Before
	public void setUp() {
		validationServiceExceptionGenerator = mock(ValidationServiceExceptionGenerator.class);
		statusValidator = new StatusValidator(validationServiceExceptionGenerator);

	}

	@Test

	public void shouldValidateWhenStatusCodeIsInvalid() {
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceException());
		validationServiceException = statusValidator.validate("invalid");

		assertNotNull(validationServiceException);

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());

		assertEquals(AmaduesConnectorServiceConstants.STATUS_PARAM, validationServiceException.getPath());

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}

	@Test

	public void shouldValidateWhenStatusIsEmpty() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

		validationServiceException = statusValidator.validate("");

		assertNotNull(validationServiceException);

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());

		assertEquals(AmaduesConnectorServiceConstants.STATUS_PARAM, validationServiceException.getPath());

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}
	
	
	@Test

	public void shouldValidateWhenStatusIsNull() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

		validationServiceException = statusValidator.validate(null);

		assertNotNull(validationServiceException);

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());

		assertEquals(AmaduesConnectorServiceConstants.STATUS_PARAM, validationServiceException.getPath());

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}
	
	
	

	@Test

	public void shouldValidateWhenStatusIsValid() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

		validationServiceException = statusValidator.validate("Valid");

		assertNull(validationServiceException);

	}

	private ValidationServiceException createValidationServiceException() {

		ValidationServiceException validationServiceException = new ValidationServiceException(

				AmadeusSeviceErrorCode.DATA_INVALID.name());

		validationServiceException.setDeveloperMessage(AmadeusSeviceErrorCode.DATA_INVALID.name());

		validationServiceException.setPath(AmaduesConnectorServiceConstants.STATUS_PARAM);

		return validationServiceException;

	}
}
