package com.iag.infra.connector.repository.impl;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.iag.infra.connector.amadeusconnector.proxy.ConfigurationInfrastructureServiceProxy;
import com.iag.infra.connector.model.AmadeusConnectionDetails;
import com.iag.infra.connector.model.ConfigurationAuthenticationData;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

public class AmadeusConnectionDetailConfigurationRepositoryImplTest {

    private AmadeusConnectionDetailConfigurationRepositoryImpl amadeusConnectionDetailConfigurationRepositoryImpl;

    private ConfigurationInfrastructureServiceProxy serviceProxy;

    @Before
    public void setUp() {
        serviceProxy = mock(ConfigurationInfrastructureServiceProxy.class);
        amadeusConnectionDetailConfigurationRepositoryImpl = new AmadeusConnectionDetailConfigurationRepositoryImpl(
                serviceProxy);

    }

    @Test
    public void shouldProduceValidConnectionDetails() {
        SessionPoolIdentifier sessionPoolIdentifier = new SessionPoolIdentifier("GB", "KIOSK", "BOOKING");
        ConfigurationAuthenticationData configurationAuthenticationData = getConfigurationAuthenticationData();

        when(serviceProxy.retrieveConfigurationForAuthentication("GB.BOOKING.KIOSK.DEFAULT")).thenReturn(
                configurationAuthenticationData);
        AmadeusConnectionDetails amadeusConnectionDetails = amadeusConnectionDetailConfigurationRepositoryImpl .getAmadeusConnectionDetails(sessionPoolIdentifier);
        Assert.assertNotNull(amadeusConnectionDetails);
        Assert.assertEquals(amadeusConnectionDetails.getOfficeId(), configurationAuthenticationData.getOfficeId());
        Assert.assertEquals(amadeusConnectionDetails.getPasswordDataType(),
                configurationAuthenticationData.getPasswordDataType());

    }

    @Test
    public void shouldProduceSimilarConnectionDetailsForLowerAndUpperCaseOfSessionPoolIdentifier() {
        SessionPoolIdentifier sessionPoolIdentifier = new SessionPoolIdentifier("GB", "KIOSK", "BOOKING");
        ConfigurationAuthenticationData configurationAuthenticationData = getConfigurationAuthenticationData();
        when(serviceProxy.retrieveConfigurationForAuthentication("GB.BOOKING.KIOSK")).thenReturn(
                configurationAuthenticationData);
        AmadeusConnectionDetails amadeusConnectionDetails = amadeusConnectionDetailConfigurationRepositoryImpl
                .getAmadeusConnectionDetails(sessionPoolIdentifier);

        SessionPoolIdentifier sessionPoolIdentifierWithLowerCase = new SessionPoolIdentifier("gb", "kiosk", "booking");
        ConfigurationAuthenticationData configurationAuthenticationDataWithLowerCase = getConfigurationAuthenticationData();
        when(serviceProxy.retrieveConfigurationForAuthentication("gb.booking.kiosk")).thenReturn(
                configurationAuthenticationDataWithLowerCase);
        AmadeusConnectionDetails amadeusConnectionDetailsWithLowerCase = amadeusConnectionDetailConfigurationRepositoryImpl
                .getAmadeusConnectionDetails(sessionPoolIdentifierWithLowerCase);

        Assert.assertEquals(amadeusConnectionDetails, amadeusConnectionDetailsWithLowerCase);
    }

    @Test
    public void shouldProduceDiffrentConnectionDetailsForDiffremtSetOfSessionPoolIdentifier() {
        SessionPoolIdentifier sessionPoolIdentifier = new SessionPoolIdentifier("GB", "KIOSK", "BOOKING");
        ConfigurationAuthenticationData configurationAuthenticationData = getConfigurationAuthenticationData();
        when(serviceProxy.retrieveConfigurationForAuthentication("http://35.176.179.36")).thenReturn(
                configurationAuthenticationData);
        AmadeusConnectionDetails amadeusConnectionDetails = amadeusConnectionDetailConfigurationRepositoryImpl
                .getAmadeusConnectionDetails(sessionPoolIdentifier);

        SessionPoolIdentifier sessionPoolIdentifierWithDiffrentSetOfValues = new SessionPoolIdentifier("US", "KIOSK",
                "BOOKING");
        ConfigurationAuthenticationData configurationAuthenticationDataWithDiffrentSetOfValues = getConfigurationAuthenticationDataWithDiffrentSetOfValues();
        when(serviceProxy.retrieveConfigurationForAuthentication("US.BOOKING.KIOSK")).thenReturn(
                configurationAuthenticationDataWithDiffrentSetOfValues);
        AmadeusConnectionDetails amadeusConnectionDetailsWithLowerCase = amadeusConnectionDetailConfigurationRepositoryImpl
                .getAmadeusConnectionDetails(sessionPoolIdentifierWithDiffrentSetOfValues);

        Assert.assertNotEquals(amadeusConnectionDetails, amadeusConnectionDetailsWithLowerCase);
    }

    private ConfigurationAuthenticationData getConfigurationAuthenticationDataWithDiffrentSetOfValues() {
        ConfigurationAuthenticationData configurationAuthenticationData = new ConfigurationAuthenticationData();
        configurationAuthenticationData.setOfficeId("JNBBA07Y1");
        configurationAuthenticationData.setOriginator("WSBAAVI");
        configurationAuthenticationData.setPasswordDataLength("8");
        configurationAuthenticationData.setPasswordDataType("E");
        configurationAuthenticationData.setOriginatorTypeCode("U");
        configurationAuthenticationData.setOrganisationalId("RS");
        configurationAuthenticationData.setReferenceIdentifier("SU");
        configurationAuthenticationData.setReferenceQualifier("DUT");
        configurationAuthenticationData
                .setSecurityAuthenticate("http://webservices.amadeus.com/1ASIWCP2BA/VLSTLQ_11_1_1A");
        configurationAuthenticationData.setSecuritySignOut("http://webservices.amadeus.com/1ASIWCP2BA/VLSSOQ_04_1_1A");
        configurationAuthenticationData.setOriginatorForIdentificationType("DUMMY");
        configurationAuthenticationData.setOriginatorTypeCodeForUserIdentificationType("P");
        configurationAuthenticationData.setOriginatorForUserIdentificationType("Z");
        configurationAuthenticationData.setOriginatorTypeCodeForIdentificationType("01234");
        return configurationAuthenticationData;
    }

    private ConfigurationAuthenticationData getConfigurationAuthenticationData() {
        ConfigurationAuthenticationData configurationAuthenticationData = new ConfigurationAuthenticationData();
        configurationAuthenticationData.setOfficeId("JNBBA07Y1");
        configurationAuthenticationData.setOriginator("WSBAAVI");
        configurationAuthenticationData.setPasswordDataLength("8");
        configurationAuthenticationData.setPasswordDataType("E");
        configurationAuthenticationData.setOriginatorTypeCode("U");
        configurationAuthenticationData.setOrganisationalId("BA");
        configurationAuthenticationData.setReferenceIdentifier("SU");
        configurationAuthenticationData.setReferenceQualifier("DUT");
        configurationAuthenticationData
                .setSecurityAuthenticate("http://webservices.amadeus.com/1ASIWCP2BA/VLSTLQ_11_1_1A");
        configurationAuthenticationData.setSecuritySignOut("http://webservices.amadeus.com/1ASIWCP2BA/VLSSOQ_04_1_1A");
        configurationAuthenticationData.setOriginatorForIdentificationType("DUMMY");
        configurationAuthenticationData.setOriginatorTypeCodeForUserIdentificationType("U");
        configurationAuthenticationData.setOriginatorForUserIdentificationType("Z");
        configurationAuthenticationData.setOriginatorTypeCodeForIdentificationType("01234");
        return configurationAuthenticationData;
    }
}
