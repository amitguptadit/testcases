package com.iag.infra.connector.repository.impl;

import javax.xml.soap.SOAPException;

import org.apache.commons.pool2.PooledObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.amadeus.xml.vlsslr_06_1_1a.ResponseAnalysisDetailsType;
import com.amadeus.xml.vlsslr_06_1_1a.SecurityAuthenticateReply;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.model.AmadeusConnectionDetails;
import com.iag.infra.connector.model.AmedeusResponseDetails;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

public class SessionProviderRepositoryImplTest {
    private static final String SOAP_ACTION_URI = "http://webservices.amadeus.com/1ASIWCP2BA/VLSTLQ_11_1_1A";

    private static final String SECURITY_TOKEN = "2Y4BVG37P16P42HTA1YFUH5ZBE";

    private static final int SEQUENCE_NUMBER = 1;

    private static final String SESSION_ID = "02WQO94SAI";

    private SessionProviderRepositoryImpl sessionProviderRepositoryImpl;

    @Mock
    private WebServiceTemplate amadeusWebServiceTemplate;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        sessionProviderRepositoryImpl = new SessionProviderRepositoryImpl();

        ReflectionTestUtils.setField(sessionProviderRepositoryImpl, "amadeusWebServiceTemplate", amadeusWebServiceTemplate);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldGetSignInSession() throws SOAPException {
        final SessionPoolIdentifier sessionPoolIdentifier = getSessionPoolIdentifier();
        
        
        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithSuccess());
        final PooledObject<Session> sessionPooledObject = sessionProviderRepositoryImpl.signIn(
                getAmadeusConnectionDetails(), sessionPoolIdentifier);
        final Session session = sessionPooledObject.getObject();
        Assert.assertEquals(SESSION_ID, session.getSessionIdentifier());
        Assert.assertEquals(SECURITY_TOKEN, session.getTokenNumber());
        Assert.assertEquals(sessionPoolIdentifier.getCountrycode(), session.getLocation());
        Assert.assertEquals(sessionPoolIdentifier.getChannel(), session.getChannel());
        Assert.assertEquals(sessionPoolIdentifier.getScope(), session.getScope());
        Assert.assertEquals(AmaduesConnectorServiceConstants.VALID_RESPONSE_CODE, session.getStatus());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldGetSignInSessionWhenSecurityTokenIsNull() throws SOAPException {
        final SessionPoolIdentifier sessionPoolIdentifier = getSessionPoolIdentifier();
        final AmedeusResponseDetails soapResposne = createSoapResposneWithSuccess();
        soapResposne.setSecurityToken(null);
        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(soapResposne);
        final PooledObject<Session> sessionPooledObject = sessionProviderRepositoryImpl.signIn(
                getAmadeusConnectionDetails(), sessionPoolIdentifier);
        final Session session = sessionPooledObject.getObject();

        Assert.assertEquals(null, session.getTokenNumber());
        Assert.assertEquals(SESSION_ID, session.getSessionIdentifier());
        Assert.assertEquals(sessionPoolIdentifier.getCountrycode(), session.getLocation());
        Assert.assertEquals(sessionPoolIdentifier.getChannel(), session.getChannel());
        Assert.assertEquals(sessionPoolIdentifier.getScope(), session.getScope());
        Assert.assertEquals(AmaduesConnectorServiceConstants.VALID_RESPONSE_CODE, session.getStatus());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldGetSignInSessionWhenSessionIdIsNull() throws SOAPException {
        final SessionPoolIdentifier sessionPoolIdentifier = getSessionPoolIdentifier();
        final AmedeusResponseDetails soapResposne = createSoapResposneWithSuccess();
        soapResposne.setSessionId(null);
        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(soapResposne);
        final PooledObject<Session> sessionPooledObject = sessionProviderRepositoryImpl.signIn(
                getAmadeusConnectionDetails(), sessionPoolIdentifier);
        final Session session = sessionPooledObject.getObject();

        Assert.assertEquals(SECURITY_TOKEN, session.getTokenNumber());
        Assert.assertEquals(null, session.getSessionIdentifier());
        Assert.assertEquals(sessionPoolIdentifier.getCountrycode(), session.getLocation());
        Assert.assertEquals(sessionPoolIdentifier.getChannel(), session.getChannel());
        Assert.assertEquals(sessionPoolIdentifier.getScope(), session.getScope());
        Assert.assertEquals(AmaduesConnectorServiceConstants.VALID_RESPONSE_CODE, session.getStatus());
    }

    @Test
    public void shouldGetSignOut() {
        sessionProviderRepositoryImpl.signOut(createSession(), getAmadeusConnectionDetails());
    }

    private AmadeusConnectionDetails getAmadeusConnectionDetails() {
        AmadeusConnectionDetails amadeusConnectionDetails = new AmadeusConnectionDetails();
        amadeusConnectionDetails.setOfficeId("MANBA0609");
        amadeusConnectionDetails.setOriginator("WSBAAVI");
        amadeusConnectionDetails.setPassword("QU1BREVVUw==");
        amadeusConnectionDetails.setPasswordDataType("md5");
        amadeusConnectionDetails.setReferenceQualifier("DUT");
        amadeusConnectionDetails.setReferenceIdentifier("SU");
        amadeusConnectionDetails.setOrganisationalId("BA");
        amadeusConnectionDetails.setOriginatorTypeCode("WSBAAVI");
        amadeusConnectionDetails.setOriginatorForIdentificationType("DUMMY");
        amadeusConnectionDetails.setOriginatorTypeCodeForIdentificationType("DUMMY");
        amadeusConnectionDetails.setOriginatorTypeCodeForUserIdentificationType("U");
        amadeusConnectionDetails.setOriginatorForUserIdentificationType("0001AA");
        amadeusConnectionDetails.setSecurityAuthenticate("WSBAAVI");
        amadeusConnectionDetails.setSecuritySignOut(SOAP_ACTION_URI);
        return amadeusConnectionDetails;
    }

    private SessionPoolIdentifier getSessionPoolIdentifier() {
        SessionPoolIdentifier sessionPoolIdentifier = new SessionPoolIdentifier();
        sessionPoolIdentifier.setChannel("KIOSK");
        sessionPoolIdentifier.setCountrycode("GB");
        sessionPoolIdentifier.setScope("BOOKING");
        return sessionPoolIdentifier;
    }



    private AmedeusResponseDetails createSoapResposneWithSuccess() {
        AmedeusResponseDetails response = new AmedeusResponseDetails();
        SecurityAuthenticateReply soapResponse = new SecurityAuthenticateReply();
        ResponseAnalysisDetailsType responseAnalysisDetailsType = new ResponseAnalysisDetailsType("P");
        soapResponse.setProcessStatus(responseAnalysisDetailsType);

        response.setSoapResponse(soapResponse);
        response.setSecurityToken(SECURITY_TOKEN);
        response.setSequenceNumber(SEQUENCE_NUMBER);
        response.setSessionId(SESSION_ID);
        return response;
    }

    private Session createSession() {
        Session sessionRequest = new Session();
        sessionRequest.setChannel("Kiosk");
        sessionRequest.setLocation("GB");
        sessionRequest.setScope("Booking");
        sessionRequest.setTokenNumber("123");
        sessionRequest.setSessionIdentifier("123");
        return sessionRequest;
    }
}