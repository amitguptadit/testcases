package com.iag.infra.connector.service.pool;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.infra.connector.amadeusconnector.proxy.ConfigurationInfrastructureServiceProxy;
import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.model.AmadeusConnectionDetails;
import com.iag.infra.connector.model.AmadeusSessionPoolConfiguration;
import com.iag.infra.connector.model.ConfigurationAuthenticationData;
import com.iag.infra.connector.model.ConfigurationPoolData;
import com.iag.infra.connector.repository.AmadeusConnectionDetailConfigurationRepository;
import com.iag.infra.connector.repository.impl.AmadeusSessionPoolConfigurationRepositoryImpl;
import com.iag.infra.connector.repository.impl.SessionProviderRepositoryImpl;
import com.iag.infra.connector.service.pool.SessionPool;
import com.iag.infra.connector.service.pool.SessionPoolFactory;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

public class SessionPoolFactoryTest {

    private SessionPoolFactory amadeusSessionPoolFactory;

    @Mock
    private AmadeusSessionPoolConfigurationRepositoryImpl amadeusSessionPoolConfigurationRepository;

    private SessionProviderRepositoryImpl sessionProviderRepository;


    @Mock
    private AmadeusSessionPoolConfiguration amadeusSessionPoolConfiguration;

    @Mock
    private SessionPoolIdentifier sessionIdentifier;

    @Mock
    private AmadeusConnectionDetails amadeusConnectionDetails;

    @Mock
    private ConfigurationInfrastructureServiceProxy configurationInfrastructureServiceProxy;

    @Mock
    private AmadeusConnectionDetailConfigurationRepository amadeusConnectionDetailConfigurationRepository;

    private ConfigurationPoolData configurationPoolData = new ConfigurationPoolData();

    @SuppressWarnings("unchecked")
    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        amadeusSessionPoolFactory = new SessionPoolFactory(configurationInfrastructureServiceProxy,
                sessionProviderRepository,
                amadeusSessionPoolConfigurationRepository, amadeusConnectionDetailConfigurationRepository);

        Mockito.when(configurationInfrastructureServiceProxy.retrieveConfigurationForPool("GB.BOOKINGS.KIOSK"))
                .thenReturn(configurationPoolData);

    }

    @Test
    public void shouldProduceAProperPoolFactoryWhenValidValuesOfSessionPoolIdentifierIsGiven() {
        AmadeusSessionPoolConfiguration amadeusSessionPoolConfiguration = getAmadeusSessionPoolConfiguration();
        Mockito.when(
                amadeusSessionPoolConfigurationRepository
                        .getAmadeusSessionPoolConfiguration(getAmadeusSessionPoolIdentifier("KIOSK", "GB", "BOOKINGS")))
                .thenReturn(getAmadeusSessionPoolConfiguration());
        Mockito.when(
                amadeusConnectionDetailConfigurationRepository
                        .getAmadeusConnectionDetails(getAmadeusSessionPoolIdentifier("KIOSK", "GB", "BOOKINGS")))
                .thenReturn(getAmadeusConnectionDetails());
        @SuppressWarnings("unchecked")
        SessionPool<Session> genericObjectPool = amadeusSessionPoolFactory
                .createAmadeusSessionPool(getAmadeusSessionPoolIdentifier("KIOSK", "GB", "BOOKINGS"));
        Assert.assertNotNull(genericObjectPool);
        Assert.assertEquals(genericObjectPool.getMinIdle(), amadeusSessionPoolConfiguration.getMinimumPoolSize());
        Assert.assertEquals(genericObjectPool.getMaxIdle(), amadeusSessionPoolConfiguration.getDefaultPoolSize());
        Assert.assertEquals(genericObjectPool.getBlockWhenExhausted(), Boolean.TRUE);
        Assert.assertEquals(genericObjectPool.getMaxWaitMillis(), amadeusSessionPoolConfiguration.getWaitingTimeOut());
        Assert.assertEquals(genericObjectPool.getMaxTotal(), amadeusSessionPoolConfiguration.getMaxPoolSize());

    }

    @Test
    public void shouldReturnDifferentSessionPoolForDifferentChannel() throws Exception {
        Mockito.when(
                amadeusSessionPoolConfigurationRepository
                        .getAmadeusSessionPoolConfiguration(getAmadeusSessionPoolIdentifier("KIOSK", "GB", "BOOKINGS")))
                .thenReturn(getAmadeusSessionPoolConfiguration());
        Mockito.when(
                amadeusConnectionDetailConfigurationRepository
                        .getAmadeusConnectionDetails(getAmadeusSessionPoolIdentifier("KIOSK", "GB", "BOOKINGS")))
                .thenReturn(getAmadeusConnectionDetails());
        SessionPool<Session> genericObjectPool = amadeusSessionPoolFactory
                .createAmadeusSessionPool(getAmadeusSessionPoolIdentifier("KIOSK", "GB", "BOOKINGS"));
        SessionPool<Session> genericObjectPoolWithDiffrentChannel = amadeusSessionPoolFactory
                .createAmadeusSessionPool(getAmadeusSessionPoolIdentifier("MOBILE", "GB", "BOOKINGS"));
        Assert.assertNotEquals(genericObjectPool, genericObjectPoolWithDiffrentChannel);
    }

    @Test
    public void shouldReturnDifferentSessionPoolForDifferentLocation() throws Exception {
        Mockito.when(
                amadeusSessionPoolConfigurationRepository
                        .getAmadeusSessionPoolConfiguration(getAmadeusSessionPoolIdentifier("KIOSK", "GB", "BOOKINGS")))
                .thenReturn(getAmadeusSessionPoolConfiguration());
        Mockito.when(
                amadeusConnectionDetailConfigurationRepository
                        .getAmadeusConnectionDetails(getAmadeusSessionPoolIdentifier("KIOSK", "gb", "BOOKINGS")))
                .thenReturn(getAmadeusConnectionDetails());
        SessionPool<Session> genericObjectPool = amadeusSessionPoolFactory
                .createAmadeusSessionPool(getAmadeusSessionPoolIdentifier("KIOSK", "GB", "BOOKINGS"));
        SessionPool<Session> genericObjectPoolWithDiffrentLocation = amadeusSessionPoolFactory
                .createAmadeusSessionPool(getAmadeusSessionPoolIdentifier("KIOSK", "US", "BOOKINGS"));
        Assert.assertNotEquals(genericObjectPool, genericObjectPoolWithDiffrentLocation);
    }

    @Test
    public void shouldReturnDifferentSessionPoolForDifferentScope() throws Exception {
        Mockito.when(
                amadeusSessionPoolConfigurationRepository
                        .getAmadeusSessionPoolConfiguration(getAmadeusSessionPoolIdentifier("KIOSK", "GB", "BOOKINGS")))
                .thenReturn(getAmadeusSessionPoolConfiguration());
        Mockito.when(
                amadeusConnectionDetailConfigurationRepository
                        .getAmadeusConnectionDetails(getAmadeusSessionPoolIdentifier("KIOSK", "GB", "BOOKINGS")))
                .thenReturn(getAmadeusConnectionDetails());
        SessionPool<Session> genericObjectPool = amadeusSessionPoolFactory
                .createAmadeusSessionPool(getAmadeusSessionPoolIdentifier("KIOSK", "GB", "BOOKINGS"));
        SessionPool<Session> genericObjectPoolWithDiffrentScope = amadeusSessionPoolFactory
                .createAmadeusSessionPool(getAmadeusSessionPoolIdentifier("KIOSK", "GB", "ALL"));
        Assert.assertNotEquals(genericObjectPool, genericObjectPoolWithDiffrentScope);
    }

    private SessionPoolIdentifier getAmadeusSessionPoolIdentifier(String channel, String countrycode, String scope) {
        SessionPoolIdentifier sessionPoolIdentifier = new SessionPoolIdentifier();
        sessionPoolIdentifier.setChannel("KIOSK");
        sessionPoolIdentifier.setCountrycode("GB");
        sessionPoolIdentifier.setScope("BOOKINGS");
        return sessionPoolIdentifier;
    }

    private static AmadeusConnectionDetails getAmadeusConnectionDetails() {
        AmadeusConnectionDetails amadeusConnectionDetails = new AmadeusConnectionDetails();
        amadeusConnectionDetails.setOfficeId("MANBA0609");
        amadeusConnectionDetails.setOriginator("WSBAAVI");
        amadeusConnectionDetails.setPassword("QU1BREVVUw==");
        amadeusConnectionDetails.setReferenceQualifier("DUT");
        amadeusConnectionDetails.setReferenceIdentifier("SU");
        amadeusConnectionDetails.setOrganisationalId("BA");
        amadeusConnectionDetails.setPasswordDataType("E");
        amadeusConnectionDetails.setOriginatorTypeCode("U");
        return amadeusConnectionDetails;
    }

    private AmadeusSessionPoolConfiguration getAmadeusSessionPoolConfiguration() {
        AmadeusSessionPoolConfiguration amadeusSessionPoolConfiguration = new AmadeusSessionPoolConfiguration();
        amadeusSessionPoolConfiguration.setDefaultPoolSize(5);
        amadeusSessionPoolConfiguration.setInactivityTimeOut(100);
        amadeusSessionPoolConfiguration.setMaxPoolSize(15);
        amadeusSessionPoolConfiguration.setPoolCleanFrequency(50);
        amadeusSessionPoolConfiguration.setPoolSize(10);
        amadeusSessionPoolConfiguration.setSupplierId("LONOVID");
        amadeusSessionPoolConfiguration.setWaitingTimeOut(200);
        return amadeusSessionPoolConfiguration;
    }
    /*private ConfigurationPoolData createConfigurationPoolData(){
        ConfigurationPoolData configurationPoolData= new ConfigurationPoolData();
        configurationPoolData.set
        return authenticationData;
    }*/
}
