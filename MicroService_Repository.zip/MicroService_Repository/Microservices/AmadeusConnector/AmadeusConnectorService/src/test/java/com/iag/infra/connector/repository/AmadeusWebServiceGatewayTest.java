package com.iag.infra.connector.repository;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.WebServiceIOException;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapFaultException;

import com.amadeus.xml.vlsslr_06_1_1a.ApplicationErrorDetailType;
import com.amadeus.xml.vlsslr_06_1_1a.ApplicationErrorInformationType;
import com.amadeus.xml.vlsslr_06_1_1a.InteractiveFreeTextTypeI;
import com.amadeus.xml.vlsslr_06_1_1a.ResponseAnalysisDetailsType;
import com.amadeus.xml.vlsslr_06_1_1a.SecurityAuthenticateReply;
import com.amadeus.xml.vlsslr_06_1_1a.SecurityAuthenticateReply.ErrorSection;
import com.google.common.collect.Lists;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.infra.connector.amadeusconnector.error.ApplicationServiceExceptionGenerator;
import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.model.AmedeusResponseDetails;
import com.iag.infra.connector.repository.impl.AmadeusWebServiceGateway;
import com.iag.infra.connector.repository.impl.mapper.request.AmedeusSignOutRequestHeaderMapper;
import com.iag.infra.connector.utility.AmadeusConnectorServiceUtility;



public class AmadeusWebServiceGatewayTest {

    private static final String DEVICE_ID = "web";

	private static final String MESSAGE_ID = "uuid:f728bb7a-f855-4cbf-9f8a-e272c3f30c34";

	private static final String SOAP_ACTION_URI = "http://webservices.amadeus.com/1ASIWCP2BA/VLSTLQ_11_1_1A";

    private AmadeusWebServiceGateway gateway;

    private static final String SECURITY_TOKEN = "2Y4BVG37P16P42HTA1YFUH5ZBE";

    private static final String PROCESSING_CODE_SUCCESS = "P";

    private static final int SEQUENCE_NUMBER = 1;

    private static final String SESSION_ID = "02WQO94SAI";
    @Mock
    private WebServiceTemplate amadeusWebServiceTemplate;


    private ApplicationServiceExceptionGenerator applicationServiceExceptionGenerator;

    @Mock
    Jaxb2Marshaller amadeusMarshaller;

    @Mock
    Jaxb2Marshaller amadeusUnMarshaller;

    @Mock
    AmedeusSignOutRequestHeaderMapper amedeusSignOutRequestHeaderMapper;

    @Mock
    private AmadeusConnectorServiceUtility amadeusConnectorServiceUtility;
    @Rule
    public final ExpectedException exception = ExpectedException.none();


    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        gateway = new AmadeusWebServiceGateway();

        applicationServiceExceptionGenerator = new ApplicationServiceExceptionGenerator(amadeusConnectorServiceUtility);

        ReflectionTestUtils.setField(gateway, "applicationServiceExceptionGenerator",
                applicationServiceExceptionGenerator);
        ReflectionTestUtils.setField(gateway, "amadeusMarshaller", amadeusMarshaller);
        ReflectionTestUtils.setField(gateway, "amadeusUnMarshaller", amadeusUnMarshaller);
        ReflectionTestUtils.setField(gateway, "amedeusSignOutRequestHeaderMapper", amedeusSignOutRequestHeaderMapper);
        ReflectionTestUtils.setField(gateway, "amadeusWebServiceTemplate", amadeusWebServiceTemplate);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldGetWebServiceResponseForSignIn() {

        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithSuccess());

        final AmedeusResponseDetails webServiceResponseForSignIn = gateway.getWebServiceResponseForSignIn(new Object(),
                SOAP_ACTION_URI,MESSAGE_ID,DEVICE_ID);
        final SecurityAuthenticateReply securityTrustedUserSignInReply = ((SecurityAuthenticateReply) webServiceResponseForSignIn .getSoapResponse());

        Assert.assertEquals(null, securityTrustedUserSignInReply.getErrorSection());
        Assert.assertEquals(PROCESSING_CODE_SUCCESS, securityTrustedUserSignInReply.getProcessStatus().getStatusCode());
        Assert.assertEquals(SECURITY_TOKEN, webServiceResponseForSignIn.getSecurityToken());
        Assert.assertEquals(SESSION_ID, webServiceResponseForSignIn.getSessionId());
        Assert.assertEquals(SEQUENCE_NUMBER, webServiceResponseForSignIn.getSequenceNumber());
    }

    @SuppressWarnings("unchecked")
    @Test(expected = ApplicationServiceException.class)
    public void shouldThowExceptionWhenSignInResponseHasErrorSection() {
        AmedeusResponseDetails soapResposneWithError = createSoapResposneWithError();
        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(soapResposneWithError);


        gateway.getWebServiceResponseForSignIn(new Object(), SOAP_ACTION_URI,MESSAGE_ID,DEVICE_ID);

    }
    
    
    @SuppressWarnings("unchecked")
    @Test(expected = ApplicationServiceException.class)
    public void shouldThowExceptionWhenAmadeusIsNotAvailableForSignIn() {
        WebServiceIOException serviceNotAvailable = new WebServiceIOException(
                "I/O error: BAaccess.test.webservices.1a.amadeus.com");
        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(serviceNotAvailable);


        gateway.getWebServiceResponseForSignIn(new Object(), SOAP_ACTION_URI,MESSAGE_ID,DEVICE_ID);

    }

    @SuppressWarnings("unchecked")
    @Test(expected = ApplicationServiceException.class)
    public void shouldThowExceptionWhenSocketTimeoutOccuredForSignIn() {
        WebServiceIOException serviceNotAvailable = new WebServiceIOException(
                "I/O error: Read timed out; nested exception is java.net.SocketTimeoutException");
        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(serviceNotAvailable);

        gateway.getWebServiceResponseForSignIn(new Object(), SOAP_ACTION_URI,MESSAGE_ID,DEVICE_ID);

    }


    @SuppressWarnings("unchecked")
    @Test
    public void shouldGetWebServiceResponseForSignInWhenResponseHaveBothProcessStatuAndErrorSection() {

        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(
                createSoapResposneWithSuccessAndErrorSection());

        final AmedeusResponseDetails webServiceResponseForSignIn = gateway.getWebServiceResponseForSignIn(new Object(),
                SOAP_ACTION_URI,MESSAGE_ID,DEVICE_ID);
        final SecurityAuthenticateReply securityTrustedUserSignInReply = ((SecurityAuthenticateReply) webServiceResponseForSignIn .getSoapResponse());

        Assert.assertEquals(PROCESSING_CODE_SUCCESS, securityTrustedUserSignInReply.getProcessStatus().getStatusCode());
        Assert.assertEquals(SECURITY_TOKEN, webServiceResponseForSignIn.getSecurityToken());
        Assert.assertEquals(SESSION_ID, webServiceResponseForSignIn.getSessionId());
        Assert.assertEquals(SEQUENCE_NUMBER, webServiceResponseForSignIn.getSequenceNumber());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldThowExceptionWhenSignInResponseNotHaveProcessStatus() {
        AmedeusResponseDetails soapResposneWithError = createBlankAmedeusResponseDetails();
        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenReturn(soapResposneWithError);

        gateway.getWebServiceResponseForSignIn(new Object(), SOAP_ACTION_URI,MESSAGE_ID,DEVICE_ID);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldThowExceptionWhenErrorOccuredWhileCallingAmadeusForSignIn() {
        AmedeusResponseDetails soapResposneWithError = createSoapResposneWithError();

        ApplicationServiceException applicationServiceException = new ApplicationServiceException(
                getResponseErrorCode(soapResposneWithError));

        Mockito.when(
                amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
                        Mockito.any(WebServiceMessageExtractor.class))).thenThrow(applicationServiceException);


        exception.expect(ApplicationServiceException.class);
        exception.expectMessage("SYSTEM_UNAVAILABLE");
        gateway.getWebServiceResponseForSignIn(new Object(), SOAP_ACTION_URI,MESSAGE_ID,DEVICE_ID);


    }

    @Test
    public void shouldGetWebServiceResponseForSignOut() {

        Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenReturn(new Object());
        gateway.getWebServiceResponseForSignOut(new Object(), SOAP_ACTION_URI, new Session());
    }


    @Test
    public void shouldThowExceptionWhenErrorOccuredWhileCallingAmadeusForSignOut() {

        SoapFaultException faultException = new SoapFaultException("Bad SecurityToken");
        Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenThrow(faultException);

        exception.expect(ApplicationServiceException.class);
        exception.expectMessage("SYSTEM_UNAVAILABLE");

        gateway.getWebServiceResponseForSignOut(new Object(), SOAP_ACTION_URI, new Session());
    }

    @Test
    public void shouldThowExceptionWhenAmadeusIsNotAvailableForSignOut() {

        WebServiceIOException serviceNotAvailable = new WebServiceIOException(
                "I/O error: BAaccess.test.webservices.1a.amadeus.com");
        Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenThrow(serviceNotAvailable);

        exception.expect(ApplicationServiceException.class);
        exception.expectMessage("SYSTEM_UNAVAILABLE");

        gateway.getWebServiceResponseForSignOut(new Object(), SOAP_ACTION_URI, new Session());
    }

    @Test
    public void shouldThowExceptionWhenSocketTimeoutOccuredForSignOut() {

        WebServiceIOException serviceNotAvailable = new WebServiceIOException(
                "I/O error: Read timed out; nested exception is java.net.SocketTimeoutException");
        Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenThrow(serviceNotAvailable);

        exception.expect(ApplicationServiceException.class);
        exception.expectMessage("SYSTEM_UNAVAILABLE");

        gateway.getWebServiceResponseForSignOut(new Object(), SOAP_ACTION_URI, new Session());
    }

    private AmedeusResponseDetails createSoapResposneWithSuccess() {
        AmedeusResponseDetails response = new AmedeusResponseDetails();
        SecurityAuthenticateReply soapResponse = new SecurityAuthenticateReply();
        ResponseAnalysisDetailsType responseAnalysisDetailsType = new ResponseAnalysisDetailsType("P");
        soapResponse.setProcessStatus(responseAnalysisDetailsType);

        response.setSoapResponse(soapResponse);
        response.setSecurityToken(SECURITY_TOKEN);
        response.setSequenceNumber(SEQUENCE_NUMBER);
        response.setSessionId(SESSION_ID);
        return response;
    }

    private AmedeusResponseDetails createSoapResposneWithSuccessAndErrorSection() {

        AmedeusResponseDetails response = new AmedeusResponseDetails();
        SecurityAuthenticateReply soapResponse = new SecurityAuthenticateReply();
        ResponseAnalysisDetailsType responseAnalysisDetailsType = new ResponseAnalysisDetailsType("P");
        soapResponse.setProcessStatus(responseAnalysisDetailsType);

        ApplicationErrorDetailType errorDetails = new ApplicationErrorDetailType("26322", "EC", "LSS");
        ApplicationErrorInformationType errorOrWarningCodeDetails = new ApplicationErrorInformationType(errorDetails);

        List<String> freeText = Lists.newArrayList();
        freeText.add("Authentication failed. Please check your credentials and try again.");
        InteractiveFreeTextTypeI errorWarningDescription = new InteractiveFreeTextTypeI(null, freeText);
        ErrorSection errorGroupType = new ErrorSection(errorOrWarningCodeDetails, errorWarningDescription);
        soapResponse.setErrorSection(errorGroupType);

        response.setSoapResponse(soapResponse);
        response.setSecurityToken(SECURITY_TOKEN);
        response.setSequenceNumber(SEQUENCE_NUMBER);
        response.setSessionId(SESSION_ID);
        return response;
    }

    private AmedeusResponseDetails createSoapResposneWithError() {
        AmedeusResponseDetails response = new AmedeusResponseDetails();
        SecurityAuthenticateReply soapResponse = new SecurityAuthenticateReply();

        ApplicationErrorInformationType applicationErrorInformationType = new ApplicationErrorInformationType(new ApplicationErrorDetailType("26322", "EC", "LSS"));

        List<String> freeText = Lists.newArrayList();
        freeText.add("Authentication failed. Please check your credentials and try again.");
        InteractiveFreeTextTypeI errorWarningDescription = new InteractiveFreeTextTypeI(null, freeText);
		ErrorSection errorSection = new ErrorSection(applicationErrorInformationType, errorWarningDescription);
        soapResponse.setErrorSection(errorSection);

        response.setSoapResponse(soapResponse);
        response.setSecurityToken(SECURITY_TOKEN);
        response.setSequenceNumber(SEQUENCE_NUMBER);
        response.setSessionId(SESSION_ID);
        return response;
    }

    private AmedeusResponseDetails createBlankAmedeusResponseDetails() {
        AmedeusResponseDetails response = new AmedeusResponseDetails();
        response.setSoapResponse(new SecurityAuthenticateReply());
        return response;
    }
    private String getResponseErrorCode(final AmedeusResponseDetails amedeusResponseDetails) {

        return ((SecurityAuthenticateReply) amedeusResponseDetails.getSoapResponse()).getErrorSection()
              .getApplicationError().getErrorDetails().getErrorCode();
    }

}