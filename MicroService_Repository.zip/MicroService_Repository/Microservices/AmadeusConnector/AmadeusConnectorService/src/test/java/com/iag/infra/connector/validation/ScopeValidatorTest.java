package com.iag.infra.connector.validation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;

public class ScopeValidatorTest {

	private ScopeValidator scopeValidator;
	@Mock
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;
	ValidationServiceException validationServiceException;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		scopeValidator = new ScopeValidator(validationServiceExceptionGenerator);
	}

	@Test
	public void shouldValidateWhenScopeIsAnyValue() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

		validationServiceException = scopeValidator.validate("$$$scopevalue**");

		assertNotNull(validationServiceException);

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());

		assertEquals(AmaduesConnectorServiceConstants.SCOPE_PARAM, validationServiceException.getPath());

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}

	@Test

	public void shouldValidateWhenScopeIsEmpty() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

		validationServiceException = scopeValidator.validate("");

		assertNotNull(validationServiceException);

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());

		assertEquals(AmaduesConnectorServiceConstants.SCOPE_PARAM, validationServiceException.getPath());

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}

	@Test

	public void shouldValidateWhenScopeIsNull() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

		validationServiceException = scopeValidator.validate(null);

		assertNotNull(validationServiceException);

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());

		assertEquals(AmaduesConnectorServiceConstants.SCOPE_PARAM, validationServiceException.getPath());

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}

	@Test

	public void shouldValidateWhenScopeLengthIsMoreThanTwenty() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

		validationServiceException = scopeValidator.validate("amadeusconfigdatatouchpoint");

		assertNotNull(validationServiceException);

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());

		assertEquals(AmaduesConnectorServiceConstants.SCOPE_PARAM, validationServiceException.getPath());

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}

	
	
	@Test

	public void shouldValidateWhenScopeIsValid() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

		validationServiceException = scopeValidator.validate("booking");

		assertNull(validationServiceException);

	}

	private ValidationServiceException createValidationServiceException() {

		ValidationServiceException validationServiceException = new ValidationServiceException(

				AmadeusSeviceErrorCode.DATA_INVALID.name());

		validationServiceException.setDeveloperMessage(AmadeusSeviceErrorCode.DATA_INVALID.name());

		validationServiceException.setPath(AmaduesConnectorServiceConstants.SCOPE_PARAM);

		return validationServiceException;

	}

}
