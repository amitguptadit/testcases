package com.iag.infra.connector.amadeusconnector.error;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.proxy.ServiceProxy;



public class ValidationServiceExceptionGeneratorTest {
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

  @Mock
  private ServiceProxy configurationInfrastructureServiceProxy;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    validationServiceExceptionGenerator =
        new ValidationServiceExceptionGenerator();
  }

  @Test
  public void shouldReturnServiceExceptionWithChildError() {
    ValidationServiceException childValidationServiceException1 =
        new ValidationServiceException(AmadeusErrorCode.REQUEST_INVALID.name());
    ValidationServiceException childValidationServiceException2 =
        new ValidationServiceException(AmadeusErrorCode.MANDATORY_DATA_MISSING.name());
    List<ValidationServiceException> validationServiceExceptionList = new ArrayList<ValidationServiceException>();
    validationServiceExceptionList.add(childValidationServiceException1);
    validationServiceExceptionList.add(childValidationServiceException2);
    ValidationServiceException outputValidationServiceException =
        validationServiceExceptionGenerator.createServiceExceptionWithChildError(validationServiceExceptionList);
    Assert.assertEquals(AmadeusErrorCode.REQUEST_INVALID.name(), outputValidationServiceException.getCode());
    Assert.assertEquals(2, outputValidationServiceException.getValidationExceptions().size());
    Iterator<ValidationServiceException> iterator =
        outputValidationServiceException.getValidationExceptions().iterator();
    Assert.assertEquals(AmadeusErrorCode.REQUEST_INVALID.name(), iterator.next().getCode());
    Assert.assertEquals(AmadeusErrorCode.MANDATORY_DATA_MISSING.name(), iterator.next().getCode());
  }
  @Test
  public void shouldCreateValidationErrorWithOutDeveloperMessageAndPath() {
    ValidationServiceException validationServiceException = validationServiceExceptionGenerator
        .createValidationError(AmadeusErrorCode.REQUEST_INVALID.name(), null, null);
    Assert.assertEquals(AmadeusErrorCode.REQUEST_INVALID.name(), validationServiceException.getCode());
    Assert.assertNull(validationServiceException.getPath());
    Assert.assertEquals(null, validationServiceException.getDeveloperMessage());
  }

  @Test
  public void shouldCreateServiceExceptionWithChildError() {
    List<ValidationServiceException> validationServiceExceptionList = new ArrayList<ValidationServiceException>();
    validationServiceExceptionList.add(new ValidationServiceException(AmadeusErrorCode.REQUEST_INVALID.name()));
    ValidationServiceException validationServiceException =
        validationServiceExceptionGenerator.createServiceExceptionWithChildError(validationServiceExceptionList);
    Assert.assertNotNull(validationServiceException);
    Assert.assertEquals(AmadeusErrorCode.REQUEST_INVALID.name(), validationServiceException.getCode());
  }
}
