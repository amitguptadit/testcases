/*package com.iag.infra.connector.amadeusconnector.proxy;

import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.handlers.ServiceProxyRestCallResponseErrorHandler;
import com.iag.infra.connector.model.Config;
import com.iag.infra.connector.model.ConfigurationAuthenticationData;
import com.iag.infra.connector.model.ConfigurationItems;
import com.iag.infra.connector.model.ConfigurationNamespaces;
import com.iag.infra.connector.model.ConfigurationPoolData;

 
public class ConfigurationInfrastructureServiceProxyTest {

	private static final String serviceName = "CONFIGURATIONISV1";

	private static final String configurationServiceUrlMetadata = "http://CONFIGURATIONISV1/configuration/{key}";

	private static final String configurationResourceIdentifierPool = "CONFIGURATIONPOOL";

	private static final String configurationResourceIdentifierAuth = "AMADEUSAUTH";

	private static final String configurationResourceIdentifierError = "Error";

	private ConfigurationInfrastructureServiceProxy configurationInfrastructureServiceProxy;

	@Mock
	RestTemplate restTemplate;

	@Mock
	private ServiceUrlGenerator serviceUrlGenerator;

	@Mock
	private RestTemplateBuilder restTemplateBuilder;

	@Mock
	private ServiceProxyRestCallResponseErrorHandler serviceProxyRestCallResponseErrorHandler;

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@Mock
	HashMap<String, ConfigurationPoolData> configurationMapforPoolMock;

	@Mock
	HashMap<String, ConfigurationPoolData> configurationMapforAuthenticationMock;

	@Mock
	HashMap<String, ConfigurationPoolData> configurationMapforErrorMock;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		when(restTemplateBuilder.build()).thenReturn(restTemplate);
		configurationInfrastructureServiceProxy = new ConfigurationInfrastructureServiceProxy(serviceName,
				serviceUrlGenerator, restTemplateBuilder, serviceProxyRestCallResponseErrorHandler,
				configurationServiceUrlMetadata, configurationResourceIdentifierPool,
				configurationResourceIdentifierAuth, configurationResourceIdentifierError);

	}

	@Test
	public void shouldNotProduceBlankConfigurationDataForPoolForValidKey()
			throws JsonParseException, JsonMappingException, IOException {
		Config config = setUpConfigDataForPool();
		ResponseEntity<Config> response = new ResponseEntity<>(config, HttpStatus.ACCEPTED);
		Mockito.when(serviceUrlGenerator.generateUrl(serviceName, configurationServiceUrlMetadata))
				.thenReturn(configurationServiceUrlMetadata);
		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class))).thenReturn(response);
		ConfigurationPoolData configurationDataForPool = configurationInfrastructureServiceProxy
				.retrieveConfigurationForPool("GB.BOOKING.KIOSK");
		Assert.assertNotNull(configurationDataForPool);
		Assert.assertEquals(configurationDataForPool.getDefaultPoolSize(), "10");

	}

	@Test
	public void shouldProduceABlankConfigurationDataForInValidKey()
			throws JsonParseException, JsonMappingException, IOException {
		Config config = setUpConfigDataForPool();
		ResponseEntity<Config> response = new ResponseEntity<>(config, HttpStatus.ACCEPTED);
		Mockito.when(serviceUrlGenerator.generateUrl(serviceName, configurationServiceUrlMetadata))
				.thenReturn(configurationServiceUrlMetadata);
		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class))).thenReturn(response);
		ConfigurationPoolData configurationData = configurationInfrastructureServiceProxy
				.retrieveConfigurationForPool("GB.GB.GB");

		Assert.assertEquals(configurationData, null);

	}

	@Test
	public void shouldProducASimilarDataForRetrieveConfigurationFromConfigurationServiceWhenPoolMapIsProvided() {
		HashMap<String, ConfigurationPoolData> configurationMapforPool = new HashMap<String, ConfigurationPoolData>();
		ConfigurationPoolData configurationData = new ConfigurationPoolData();
		configurationData.setDefaultPoolSize("10");
		configurationData.setMaxPoolSize("50");
		configurationData.setMinPoolSize("5");
		configurationData.setWaitingTimeOut("70000");
		configurationMapforPool.put("GB.BOOKING.KIOSK", configurationData);
		ReflectionTestUtils.setField(configurationInfrastructureServiceProxy, "configurationMapforPool",
				configurationMapforPool);
		ConfigurationPoolData configurationDataResult = configurationInfrastructureServiceProxy
				.retrieveConfigurationForPool("GB.BOOKING.KIOSK");

		Assert.assertEquals(configurationData.getMaxPoolSize(), configurationDataResult.getMaxPoolSize());
		Assert.assertEquals(configurationData.getMinPoolSize(), configurationDataResult.getMinPoolSize());
		Assert.assertEquals(configurationData.getDefaultPoolSize(), configurationDataResult.getDefaultPoolSize());
	}

	@Test
	public void shoulNotProduceABlankAuthenticationConfigurationDataForValidKey()
			throws JsonParseException, JsonMappingException, IOException {
		Config config = setUpConfigDataForAuthentication();
		ResponseEntity<Config> response = new ResponseEntity<>(config, HttpStatus.ACCEPTED);
		Mockito.when(serviceUrlGenerator.generateUrl(serviceName, configurationServiceUrlMetadata))
				.thenReturn(configurationServiceUrlMetadata);
		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class))).thenReturn(response);
		ConfigurationAuthenticationData configurationDataForAuthentication = configurationInfrastructureServiceProxy
				.retrieveConfigurationForAuthentication("GB.BOOKING.KIOSK");
		Assert.assertNotNull(configurationDataForAuthentication);
		Assert.assertEquals(configurationDataForAuthentication.getOfficeId(), "LONBA07QQ");

	}

	@Test
	public void shoulProduceABlankAuthenticationConfigurationDataForInValidKey()
			throws JsonParseException, JsonMappingException, IOException {
		Config config = setUpConfigDataForAuthentication();
		ResponseEntity<Config> response = new ResponseEntity<>(config, HttpStatus.ACCEPTED);
		Mockito.when(serviceUrlGenerator.generateUrl(serviceName, configurationServiceUrlMetadata))
				.thenReturn(configurationServiceUrlMetadata);
		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class))).thenReturn(response);
		ConfigurationAuthenticationData configurationData = configurationInfrastructureServiceProxy
				.retrieveConfigurationForAuthentication("GB.GB.GB");
		Assert.assertEquals(configurationData, null);

	}

	@Test
	public void shouldProducASimilarDataForRetrieveConfigurationFromConfigurationServiceWhenAuthenticationMapIsProvided()
			throws JsonParseException, JsonMappingException, IOException {
		HashMap<String, ConfigurationAuthenticationData> configurationMapforAuthentication = new HashMap<String, ConfigurationAuthenticationData>();
		ConfigurationAuthenticationData configurationData = new ConfigurationAuthenticationData();
		configurationData.setOfficeId("JNBBA07Y1");
		configurationData.setOriginator("WSBAAVI");
		configurationData.setSecurityAuthenticate("http://webservices.amadeus.com/1ASIWCP2BA/VLSTLQ_11_1_1A");
		configurationData.setSecuritySignOut("http://webservices.amadeus.com/1ASIWCP2BA/VLSSOQ_04_1_1A");
		configurationMapforAuthentication.put("GB.BOOKING.KIOSK", configurationData);
		ReflectionTestUtils.setField(configurationInfrastructureServiceProxy, "configurationMapforAuthentication",
				configurationMapforAuthentication);
		ConfigurationAuthenticationData configurationDataResult = configurationInfrastructureServiceProxy
				.retrieveConfigurationForAuthentication("GB.BOOKING.KIOSK");
		Assert.assertEquals(configurationData.getSecurityAuthenticate(),
				configurationDataResult.getSecurityAuthenticate());
		Assert.assertEquals(configurationData.getOriginator(), configurationDataResult.getOriginator());
		Assert.assertEquals(configurationData.getOfficeId(), configurationDataResult.getOfficeId());
	}

	@Test
	public void shoulNotProduceABlankConfigurationDataErrorForValidKey()
			throws JsonParseException, JsonMappingException, IOException {
		Config config = setUpConfigDataForError();
		ResponseEntity<Config> response = new ResponseEntity<>(config, HttpStatus.ACCEPTED);
		Mockito.when(serviceUrlGenerator.generateUrl(serviceName, configurationServiceUrlMetadata))
				.thenReturn(configurationServiceUrlMetadata);
		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class))).thenReturn(response);
		String errorKey = configurationInfrastructureServiceProxy
				.retrieveConfigurationForError("err-code-REQUEST_INVALID.status.code");

		Assert.assertNotNull(errorKey);
		Assert.assertEquals(errorKey, "400");

	}

	@Test
	public void shouldProduceABlankConfigurationDataErrorForInValidKey()
			throws JsonParseException, JsonMappingException, IOException {
		Config config = setUpConfigDataForError();
		ResponseEntity<Config> response = new ResponseEntity<>(config, HttpStatus.ACCEPTED);
		Mockito.when(serviceUrlGenerator.generateUrl(serviceName, configurationServiceUrlMetadata))
				.thenReturn(configurationServiceUrlMetadata);
		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class))).thenReturn(response);
		String errorKey = configurationInfrastructureServiceProxy.retrieveConfigurationForError("err-code");

		Assert.assertEquals(errorKey, null);

	}

	@Test
	public void shouldProducASimilarDataForRetrieveConfigurationFromConfigurationServiceWhenErrorMapIsProvided() {
		HashMap<String, String> configurationMapForError = new HashMap<String, String>();
		configurationMapForError.put("err-code-REQUEST_INVALID.status.code", "400");
		ReflectionTestUtils.setField(configurationInfrastructureServiceProxy, "configurationMapForError",
				configurationMapForError);
		String configurationDataResult = configurationInfrastructureServiceProxy
				.retrieveConfigurationForError("err-code-REQUEST_INVALID.status.code");
		Assert.assertEquals(configurationDataResult,
				configurationMapForError.get("err-code-REQUEST_INVALID.status.code"));
	}

	@Test
	public void shouldClearConfigurationDataWhenCleared() {
		HashMap<String, ConfigurationPoolData> configurationMapforPool = new HashMap<String, ConfigurationPoolData>();
		ConfigurationPoolData configurationData = new ConfigurationPoolData();
		configurationData.setDefaultPoolSize("10");
		configurationData.setMaxPoolSize("50");
		configurationData.setMinPoolSize("5");
		configurationData.setWaitingTimeOut("70000");
		configurationMapforPool.put("GB.BOOKING.KIOSK", configurationData);
		ReflectionTestUtils.setField(configurationInfrastructureServiceProxy, "configurationMapforPool",
				configurationMapforPool);
		configurationInfrastructureServiceProxy.clearAllConfigurationPoolData();
		Assert.assertEquals(configurationMapforPool.size(), 0);

	}

	@Test
	public void shouldClearAuthenticationConfigurationDataWhenCleared() {
		HashMap<String, ConfigurationAuthenticationData> configurationMapforAuthentication = new HashMap<String, ConfigurationAuthenticationData>();
		ConfigurationAuthenticationData configurationData = new ConfigurationAuthenticationData();
		configurationData.setOfficeId("JNBBA07Y1");
		configurationData.setOriginator("WSBAAVI");
		configurationData.setSecurityAuthenticate("http://webservices.amadeus.com/1ASIWCP2BA/VLSTLQ_11_1_1A");
		configurationData.setSecuritySignOut("http://webservices.amadeus.com/1ASIWCP2BA/VLSSOQ_04_1_1A");
		configurationMapforAuthentication.put("GB.BOOKING.KIOSK", configurationData);
		ReflectionTestUtils.setField(configurationInfrastructureServiceProxy, "configurationMapforAuthentication",
				configurationMapforAuthentication);
		configurationInfrastructureServiceProxy.clearAllConfigurationAuthenticationData();
		Assert.assertEquals(configurationMapforAuthentication.size(), 0);

	}

	@Test
	public void shouldClearConfigurationErrorDataWhenCleared() {
		HashMap<String, String> configurationMapForError = new HashMap<String, String>();
		configurationMapForError.put("err-code-REQUEST_INVALID.status.code", "400");
		ReflectionTestUtils.setField(configurationInfrastructureServiceProxy, "configurationMapForError",
				configurationMapForError);
		configurationInfrastructureServiceProxy.retrieveConfigurationForError("err-code-REQUEST_INVALID.status.code");
		configurationInfrastructureServiceProxy.clearAllConfigurationErrorData();
		Assert.assertEquals(configurationMapForError.size(), 0);

	}

	@Test
	public void shouldThrowSystemUnavailableExceptionWhenGeneratedUrlIsNullForPoolConfiguration() {
		Mockito.when(serviceUrlGenerator.generateUrl(serviceName, configurationServiceUrlMetadata)).thenReturn(null);
		ApplicationServiceException applicationServiceException = new ApplicationServiceException(
				AmadeusSeviceErrorCode.SYSTEM_UNAVAILABLE.name());
		thrown.expect(ApplicationServiceException.class);
		thrown.expectMessage(AmadeusSeviceErrorCode.SYSTEM_UNAVAILABLE.name());
		configurationInfrastructureServiceProxy.retrieveConfigurationForPool("test");

	}

	@Test
	public void shouldThrowSystemUnavailableExceptionWhenGeneratedUrlIsNullForAuthenticationConfiguration() {
		Mockito.when(serviceUrlGenerator.generateUrl(serviceName, configurationServiceUrlMetadata)).thenReturn(null);
		ApplicationServiceException applicationServiceException = new ApplicationServiceException(
				AmadeusSeviceErrorCode.SYSTEM_UNAVAILABLE.name());
		thrown.expect(ApplicationServiceException.class);
		thrown.expectMessage(AmadeusSeviceErrorCode.SYSTEM_UNAVAILABLE.name());
		configurationInfrastructureServiceProxy.retrieveConfigurationForAuthentication("test");

	}

	@Test
	public void shouldThrowSystemUnavailableExceptionWhenGeneratedUrlIsNullForErrorConfiguration() {
		Mockito.when(serviceUrlGenerator.generateUrl(serviceName, configurationServiceUrlMetadata)).thenReturn(null);
		ApplicationServiceException applicationServiceException = new ApplicationServiceException(
				AmadeusSeviceErrorCode.SYSTEM_UNAVAILABLE.name());
		thrown.expect(ApplicationServiceException.class);
		thrown.expectMessage(AmadeusSeviceErrorCode.SYSTEM_UNAVAILABLE.name());
		configurationInfrastructureServiceProxy.retrieveConfigurationForError("test");

	}

	@Test
	public void shouldTestCachingWithMultipleCallsForRetrieveConfigurationForPoolWithSameKey() {
		Config config = setUpConfigDataForPool();
		ResponseEntity<Config> response = new ResponseEntity<Config>(config, HttpStatus.ACCEPTED);
		Mockito.when(serviceUrlGenerator.generateUrl(serviceName, configurationServiceUrlMetadata))
				.thenReturn(configurationServiceUrlMetadata);
		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class))).thenReturn(response);
		// Invoking retrieveConfiguration with same key
		configurationInfrastructureServiceProxy.retrieveConfigurationForPool("GB.BOOKING.KIOSK");
		configurationInfrastructureServiceProxy.retrieveConfigurationForPool("GB.BOOKING.KIOSK");
		Mockito.verify(restTemplate, Mockito.times(1)).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class));

	}

	@Test
	public void shouldTestCachingWithMultipleCallsForRetrieveConfigurationForAuthenticationWithSameKey() {
		Config config = setUpConfigDataForAuthentication();
		ResponseEntity<Config> response = new ResponseEntity<Config>(config, HttpStatus.ACCEPTED);
		Mockito.when(serviceUrlGenerator.generateUrl(serviceName, configurationServiceUrlMetadata))
				.thenReturn(configurationServiceUrlMetadata);
		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class))).thenReturn(response);
		// Invoking retrieveConfiguration with same key
		configurationInfrastructureServiceProxy.retrieveConfigurationForAuthentication("GB.BOOKING.KIOSK");
		configurationInfrastructureServiceProxy.retrieveConfigurationForAuthentication("GB.BOOKING.KIOSK");
		Mockito.verify(restTemplate, Mockito.times(1)).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class));

	}

	@Test
	public void shouldTestCachingWithMultipleCallsForRetrieveConfigurationForErrorWithSameKey() {
		Config config = setUpConfigDataForError();
		ResponseEntity<Config> response = new ResponseEntity<Config>(config, HttpStatus.ACCEPTED);
		Mockito.when(serviceUrlGenerator.generateUrl(serviceName, configurationServiceUrlMetadata))
				.thenReturn(configurationServiceUrlMetadata);
		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class))).thenReturn(response);
		configurationInfrastructureServiceProxy.retrieveConfigurationForError("err-code-REQUEST_INVALID.status.code");
		configurationInfrastructureServiceProxy.retrieveConfigurationForError("err-code-REQUEST_INVALID.status.code");
		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class))).thenReturn(response);

	}

	private HashMap<String, ConfigurationPoolData> getConfigurationPoolData(String key) {
		HashMap<String, ConfigurationPoolData> configurationMapforPool = new HashMap<String, ConfigurationPoolData>();

		ConfigurationPoolData configurationData = new ConfigurationPoolData();
		configurationData.setDefaultPoolSize("10");
		configurationData.setMaxPoolSize("50");
		configurationData.setMinPoolSize("5");
		configurationData.setWaitingTimeOut("70000");
		configurationMapforPool.put(key, configurationData);
		return configurationMapforPool;
	}

	private Config setUpConfigDataForPool() {
		List<ConfigurationItems> configurationItemsList = new ArrayList<ConfigurationItems>();
		List<ConfigurationNamespaces> configurationNamespacesList = new ArrayList<ConfigurationNamespaces>();
		ConfigurationItems configurationItems = new ConfigurationItems();
		configurationItems.setIdentifier("defaultPoolSize");
		configurationItems.setValue("10");
		configurationItemsList.add(configurationItems);
		ConfigurationNamespaces configurationNamespacesKey = new ConfigurationNamespaces();
		configurationNamespacesKey.setName("GB.BOOKING.KIOSK");
		configurationNamespacesKey.setConfigurationItems(configurationItemsList);
		configurationNamespacesList.add(configurationNamespacesKey);
		Config config = new Config();
		config.setIdentifier("AMADEUS_CONNECTOR");
		config.setResource("CONFIGURATION.POOL");
		config.setVersion("v1");
		config.setConfigurationNamespaces(configurationNamespacesList);
		return config;
	}

	private Config setUpConfigDataForAuthentication() {
		List<ConfigurationItems> configurationItemsList = new ArrayList<ConfigurationItems>();
		List<ConfigurationNamespaces> configurationNamespacesList = new ArrayList<ConfigurationNamespaces>();
		ConfigurationItems configurationItems = new ConfigurationItems();
		configurationItems.setIdentifier("officeId");
		configurationItems.setValue("LONBA07QQ");
		configurationItemsList.add(configurationItems);
		ConfigurationNamespaces configurationNamespacesKey = new ConfigurationNamespaces();
		configurationNamespacesKey.setName("GB.BOOKING.KIOSK");
		configurationNamespacesKey.setConfigurationItems(configurationItemsList);
		configurationNamespacesList.add(configurationNamespacesKey);
		Config config = new Config();
		config.setIdentifier("AMADEUS_CONNECTOR");
		config.setResource("CONFIGURATION.AUTHENTICATION");
		config.setVersion("v1");
		config.setConfigurationNamespaces(configurationNamespacesList);
		return config;
	}

	private Config setUpConfigDataForError() {
		List<ConfigurationItems> configurationItemsList = new ArrayList<ConfigurationItems>();
		List<ConfigurationNamespaces> configurationNamespacesList = new ArrayList<ConfigurationNamespaces>();
		ConfigurationItems configurationItems = new ConfigurationItems();
		configurationItems.setIdentifier("err-code-REQUEST_INVALID.status.code");
		configurationItems.setValue("400");
		configurationItemsList.add(configurationItems);
		ConfigurationNamespaces configurationNamespacesKey = new ConfigurationNamespaces();
		configurationNamespacesKey.setName("KIOSKCONFIG.ERROR");
		configurationNamespacesKey.setConfigurationItems(configurationItemsList);
		configurationNamespacesList.add(configurationNamespacesKey);
		Config config = new Config();
		config.setIdentifier("ERROR");
		config.setResource("CONFIG");
		config.setVersion("v1");
		config.setConfigurationNamespaces(configurationNamespacesList);
		return config;
	}
}
*/