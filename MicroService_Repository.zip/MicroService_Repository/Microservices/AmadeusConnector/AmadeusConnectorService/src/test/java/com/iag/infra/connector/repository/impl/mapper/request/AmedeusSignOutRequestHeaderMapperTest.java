package com.iag.infra.connector.repository.impl.mapper.request;

import javax.xml.transform.dom.DOMResult;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.iag.infra.connector.domain.Session;

public class AmedeusSignOutRequestHeaderMapperTest {
	AmedeusSignOutRequestHeaderMapper amedeusSignOutRequestHeaderMapper;
    @Mock
	Element element;
    @Mock
    Document document;
	@Before
	public void setUp() {
		document = Mockito.mock(Document.class);
		element = Mockito.mock(Element.class);
		amedeusSignOutRequestHeaderMapper = new AmedeusSignOutRequestHeaderMapper();
	}
	@Test
	public void shouldAddSessionDetailsToSoapHeaderforAllValue() {
		SoapMessage message = Mockito.mock(SoapMessage.class);
	SoapHeader soapHeader =Mockito.mock(SoapHeader.class);
		Mockito.when(message.getSoapHeader()).thenReturn(soapHeader);
	DOMResult xmlHeader  = Mockito.mock(DOMResult.class);
		Mockito.when(soapHeader.getResult()).thenReturn(xmlHeader);
		Node headerNode =Mockito.mock(Node.class);
	Mockito.when(xmlHeader.getNode()).thenReturn(headerNode);
	Mockito.when(headerNode.getOwnerDocument()).thenReturn(document);
	Mockito.when(document.createElementNS(Mockito.anyString(), Mockito.anyString())).thenReturn(element);
	
	amedeusSignOutRequestHeaderMapper.mapHeaders(message, "soapAction", getSessionRequest());
	}
	
	@Test
	public void shouldReturnNotWhenSessionIdentifierValueIsNuLL() {
		SoapMessage message = Mockito.mock(SoapMessage.class);
	SoapHeader soapHeader =Mockito.mock(SoapHeader.class);
		Mockito.when(message.getSoapHeader()).thenReturn(soapHeader);
	DOMResult xmlHeader  = Mockito.mock(DOMResult.class);
		Mockito.when(soapHeader.getResult()).thenReturn(xmlHeader);
		Node headerNode =Mockito.mock(Node.class);
	Mockito.when(xmlHeader.getNode()).thenReturn(headerNode);
	Mockito.when(headerNode.getOwnerDocument()).thenReturn(document);
	Mockito.when(document.createElementNS(Mockito.anyString(), Mockito.anyString())).thenReturn(element);
	
	amedeusSignOutRequestHeaderMapper.mapHeaders(message, "soapAction", getSessionRequestForEmptyIdentifier());

	}
	
	@Test
	public void shouldReturnNotWhenTokenValueIsNuLL() {
		SoapMessage message = Mockito.mock(SoapMessage.class);
	SoapHeader soapHeader =Mockito.mock(SoapHeader.class);
		Mockito.when(message.getSoapHeader()).thenReturn(soapHeader);
	DOMResult xmlHeader  = Mockito.mock(DOMResult.class);
		Mockito.when(soapHeader.getResult()).thenReturn(xmlHeader);
		Node headerNode =Mockito.mock(Node.class);
	Mockito.when(xmlHeader.getNode()).thenReturn(headerNode);
	Mockito.when(headerNode.getOwnerDocument()).thenReturn(document);
	Mockito.when(document.createElementNS(Mockito.anyString(), Mockito.anyString())).thenReturn(element);
	
	amedeusSignOutRequestHeaderMapper.mapHeaders(message, "soapAction", getSessionRequestForEmptyToken());

	}
	
	public Session getSessionRequest() {
		Session sessionRequest = new Session();
		sessionRequest.setChannel("KISOK");
		sessionRequest.setLocation("GB");
		sessionRequest.setScope("BOOKINGS");
		sessionRequest.setTokenNumber("123");
		sessionRequest.setSessionIdentifier("123");
		return sessionRequest;
	}
	
	
	
	public Session getSessionRequestForEmptyIdentifier() {
		Session sessionRequest = new Session();
		sessionRequest.setChannel("KISOK");
		sessionRequest.setLocation("GB");
		sessionRequest.setScope("BOOKINGS");
		sessionRequest.setTokenNumber("123");
		sessionRequest.setSessionIdentifier("");
		return sessionRequest;
	}
	public Session getSessionRequestForEmptyToken() {
		Session sessionRequest = new Session();
		sessionRequest.setChannel("KISOK");
		sessionRequest.setLocation("GB");
		sessionRequest.setScope("BOOKINGS");
		sessionRequest.setTokenNumber("123");
		sessionRequest.setSessionIdentifier("");
		return sessionRequest;
	}
}
