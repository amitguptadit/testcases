package com.iag.infra.connector.repository.impl.mapper.response;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.model.AmedeusResponseDetails;

public class AmedeusSignInResponseHeaderMapperTest {

    private AmedeusSignInResponseHeaderMapper amedeusSignInResponseHeaderMapper;

    private static final String SECURITY_TOKEN = "2Y4BVG37P16P42HTA1YFUH5ZBE";

    private static final int SEQUENCE_NUMBER = 1;

    private static final String SESSION_ID = "02WQO94SAI";

    private static final String SESSION = " ";

    @Before
    public void setup() {
        amedeusSignInResponseHeaderMapper = new AmedeusSignInResponseHeaderMapper();
    }

    @Test
    public void shouldMapSignInResponseHeader() throws Exception {
        AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
        SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessage(true, true, true));
        amedeusSignInResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

        Assert.assertEquals(SECURITY_TOKEN, amedeusResponseDetails.getSecurityToken());
        Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
        Assert.assertEquals(SEQUENCE_NUMBER, amedeusResponseDetails.getSequenceNumber());
    }

    @Test
    public void shouldMapSignInResponseHeaderForWrongSessionParentNode() throws Exception {
        AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
        SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessageWhenHeaderElementIsDifferent(true, true,
                true, false));
        amedeusResponseDetails.setSecurityToken("2Y4BVG37P16P42HTA1YFUH5ZBE");
        amedeusResponseDetails.setSessionId("02WQO94SAI");
        amedeusResponseDetails.setSequenceNumber(1);
        amedeusSignInResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

        Assert.assertEquals(SECURITY_TOKEN, amedeusResponseDetails.getSecurityToken());
        Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
        Assert.assertEquals(SEQUENCE_NUMBER, amedeusResponseDetails.getSequenceNumber());
    }

    @Test
    public void shouldMapSignInResponseHeaderForWrongSessionIdNodeName() throws Exception {
        AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
        SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessageForWrongSessionIdNodeName(true, true,
                true));
        amedeusResponseDetails.setSecurityToken("2Y4BVG37P16P42HTA1YFUH5ZBE");
        amedeusResponseDetails.setSessionId("02WQO94SAI");
        amedeusResponseDetails.setSequenceNumber(1);
        amedeusSignInResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

        Assert.assertEquals(SECURITY_TOKEN, amedeusResponseDetails.getSecurityToken());
        Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
        Assert.assertEquals(SEQUENCE_NUMBER, amedeusResponseDetails.getSequenceNumber());
    }

    @Test
    public void shouldMapSignInResponseHeaderForWrongSessionIdNodeType() throws Exception {
        AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
        SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessageForWrongSessionIdNodeType(true, true,
                true));
        amedeusResponseDetails.setSecurityToken("2Y4BVG37P16P42HTA1YFUH5ZBE");
        amedeusResponseDetails.setSessionId("02WQO94SAI");
        amedeusResponseDetails.setSequenceNumber(1);
        amedeusSignInResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

        Assert.assertEquals(SECURITY_TOKEN, amedeusResponseDetails.getSecurityToken());
        Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
        Assert.assertEquals(SEQUENCE_NUMBER, amedeusResponseDetails.getSequenceNumber());
    }

    @Test
    public void shouldMapSignInResponseHeaderWhenSessionIdIsNotPresent() throws Exception {
        AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();

        SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessage(false, true, true));

        amedeusSignInResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

        Assert.assertEquals(SECURITY_TOKEN, amedeusResponseDetails.getSecurityToken());
        Assert.assertEquals(null, amedeusResponseDetails.getSessionId());
        Assert.assertEquals(SEQUENCE_NUMBER, amedeusResponseDetails.getSequenceNumber());
    }

    @Test
    public void shouldMapSignInResponseHeaderWhenSessionIdIsPresent() throws Exception {
        AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();

        SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessage(true, false, false));

        amedeusSignInResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

        Assert.assertEquals(null, amedeusResponseDetails.getSecurityToken());
        Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
        Assert.assertEquals(0, amedeusResponseDetails.getSequenceNumber());
    }

    @Test
    public void shouldMapSignInResponseHeaderWhenSequenceNumberIsNotPresent() throws Exception {
        AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
        SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessage(true, false, true));
        amedeusSignInResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

        Assert.assertEquals(SECURITY_TOKEN, amedeusResponseDetails.getSecurityToken());
        Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
        Assert.assertEquals(0, amedeusResponseDetails.getSequenceNumber());
    }

    @Test
    public void shouldMapSignInResponseHeaderWhenSecurityTokenIsNotPresent() throws Exception {
        AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
        SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessage(true, true, false));
        amedeusSignInResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

        Assert.assertEquals(null, amedeusResponseDetails.getSecurityToken());
        Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
        Assert.assertEquals(SEQUENCE_NUMBER, amedeusResponseDetails.getSequenceNumber());
    }

    @Test
    public void shouldMapSignInResponseHeaderWhenAllAttributesAreNotPresent() throws Exception {
        AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
        SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessage(false, false, false));
        amedeusSignInResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

        Assert.assertEquals(null, amedeusResponseDetails.getSecurityToken());
        Assert.assertEquals(null, amedeusResponseDetails.getSessionId());
        Assert.assertEquals(0, amedeusResponseDetails.getSequenceNumber());
    }

    private SOAPMessage createSoapMessage(final boolean isSessionIdRequired, final boolean isSequenceNumberRequired,
            final boolean isSecurityTokenRequired) throws Exception {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage soapMsg = factory.createMessage();
        SOAPPart part = soapMsg.getSOAPPart();
        SOAPEnvelope envelope = part.getEnvelope();
        SOAPHeader header = envelope.getHeader();
        SOAPHeaderElement sessionNode = header.addHeaderElement(envelope.createName(
                AmaduesConnectorServiceConstants.SESSION_NODE_KEY, "awss", "http://xml.amadeus.com/VLSTLR_07_2_1A"));

        if (isSessionIdRequired) {
            sessionNode.addChildElement(AmaduesConnectorServiceConstants.SESSION_ID_NODE_KEY).addTextNode(SESSION_ID);
        }
        if (isSequenceNumberRequired) {
            sessionNode.addChildElement(AmaduesConnectorServiceConstants.SEQUENCE_NUMBER_NODE_KEY).addTextNode(
                    String.valueOf(SEQUENCE_NUMBER));
        }
        if (isSecurityTokenRequired) {
            sessionNode.addChildElement(AmaduesConnectorServiceConstants.SECURITY_TOKEN_NODE_KEY).addTextNode(
                    String.valueOf(SECURITY_TOKEN));
        }

        return soapMsg;

    }

    private SOAPMessage createSoapMessageForWrongSessionIdNodeType(final boolean isSessionIdRequired,
            final boolean isSequenceNumberRequired, final boolean isSecurityTokenRequired) throws Exception {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage soapMsg = factory.createMessage();
        SOAPPart part = soapMsg.getSOAPPart();
        SOAPEnvelope envelope = part.getEnvelope();
        SOAPHeader header = envelope.getHeader();
        SOAPHeaderElement sessionNode = header.addHeaderElement(envelope.createName(
                AmaduesConnectorServiceConstants.SESSION_NODE_KEY, "awss", "http://xml.amadeus.com/VLSTLR_07_2_1A"));

        if (isSessionIdRequired) {
            sessionNode.addTextNode(SESSION_ID);
        }
        if (isSequenceNumberRequired) {
            sessionNode.addChildElement(AmaduesConnectorServiceConstants.SEQUENCE_NUMBER_NODE_KEY).addTextNode(
                    String.valueOf(SEQUENCE_NUMBER));
        }
        if (isSecurityTokenRequired) {
            sessionNode.addChildElement(AmaduesConnectorServiceConstants.SECURITY_TOKEN_NODE_KEY).addTextNode(
                    String.valueOf(SECURITY_TOKEN));
        }

        return soapMsg;

    }

    private SOAPMessage createSoapMessageForWrongSessionIdNodeName(final boolean isSessionIdRequired,
            final boolean isSequenceNumberRequired, final boolean isSecurityTokenRequired) throws Exception {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage soapMsg = factory.createMessage();
        SOAPPart part = soapMsg.getSOAPPart();
        SOAPEnvelope envelope = part.getEnvelope();
        SOAPHeader header = envelope.getHeader();
        SOAPHeaderElement sessionNode = header.addHeaderElement(envelope.createName(
                AmaduesConnectorServiceConstants.SESSION_NODE_KEY, "awss", "http://xml.amadeus.com/VLSTLR_07_2_1A"));

        if (isSessionIdRequired) {
            sessionNode.addChildElement("session--id").addTextNode("session--id");
        }
        if (isSequenceNumberRequired) {
            sessionNode.addChildElement(AmaduesConnectorServiceConstants.SEQUENCE_NUMBER_NODE_KEY).addTextNode(
                    String.valueOf(SEQUENCE_NUMBER));
        }
        if (isSecurityTokenRequired) {
            sessionNode.addChildElement(AmaduesConnectorServiceConstants.SECURITY_TOKEN_NODE_KEY).addTextNode(
                    String.valueOf(SECURITY_TOKEN));
        }

        return soapMsg;

    }

    private SOAPMessage createSoapMessageWhenHeaderElementIsDifferent(final boolean isSessionIdRequired,
            final boolean isSequenceNumberRequired, final boolean isSecurityTokenRequired,
            final boolean isSessionRequired) throws Exception {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage soapMsg = factory.createMessage();
        SOAPPart part = soapMsg.getSOAPPart();
        SOAPEnvelope envelope = part.getEnvelope();
        SOAPHeader header = envelope.getHeader();
        SOAPHeaderElement sessionNode = header.addHeaderElement(envelope.createName("SessionData", "awssss",
                "http://xml.amadeus.com/VLST_2_1A"));

        if (isSessionIdRequired) {
            QName authHeader = new QName(AmaduesConnectorServiceConstants.SESSION_ID_NODE_KEY,
                    AmaduesConnectorServiceConstants.SESSION_ID_NODE_KEY,
                    AmaduesConnectorServiceConstants.SESSION_ID_NODE_KEY);
            sessionNode.addChildElement(
                    envelope.createName(AmaduesConnectorServiceConstants.SESSION_ID_NODE_KEY, "awssss",
                            "http://xml.amadeus.com/VLST_2_1A")).addTextNode(SESSION_ID);
        }
        if (isSequenceNumberRequired) {
            sessionNode.addChildElement(AmaduesConnectorServiceConstants.SEQUENCE_NUMBER_NODE_KEY).addTextNode(
                    String.valueOf(SEQUENCE_NUMBER));
        }
        if (isSecurityTokenRequired) {
            sessionNode.addChildElement(AmaduesConnectorServiceConstants.SECURITY_TOKEN_NODE_KEY).addTextNode(
                    String.valueOf(SECURITY_TOKEN));
        }
        if (isSessionRequired) {
            sessionNode.addChildElement(AmaduesConnectorServiceConstants.SESSION_NODE_KEY).addTextNode(
                    String.valueOf(SESSION));
        }
        soapMsg.saveChanges();
        return soapMsg;

    }

}
