package com.iag.infra.connector.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.service.ConnectorService;
import com.iag.infra.connector.validation.AmadeusConnectorGetRequestValidator;
import com.iag.infra.connector.validation.AmadeusConnectorPatchRequestValidator;
import com.iag.infra.connector.validation.CustomValidationServiceExceptionMatcher;

public class ConnectorControllerTest {

	private ConnectorController connectorController;
	@Mock
	private ConnectorService connectorService;
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	private MockMvc mockMvc;
	@Mock
	MockHttpServletResponse response;
	ObjectMapper mapper;
	@Mock
	private Session session;
	@Mock
	private AmadeusConnectorGetRequestValidator amadeusConnectorGetRequestValidator;
	@Mock
	private AmadeusConnectorPatchRequestValidator amadeusConnectorPatchRequestValidator;

	@Mock
	private CustomValidationServiceExceptionMatcher customValidationServiceExceptionMatcher;

	Map<String, String> headerMapValue;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		connectorController = new ConnectorController();
		this.mockMvc = MockMvcBuilders.standaloneSetup(connectorController).setMessageConverters(
				new MappingJackson2HttpMessageConverter(), new Jaxb2RootElementHttpMessageConverter()).build();
		ReflectionTestUtils.setField(connectorController, "connectorService", connectorService);
		ReflectionTestUtils.setField(connectorController, "amadeusConnectorGetRequestValidator",
				amadeusConnectorGetRequestValidator);
		ReflectionTestUtils.setField(connectorController, "amadeusConnectorPatchRequestValidator",
				amadeusConnectorPatchRequestValidator);
		headerMapValue = new HashMap<String, String>();
	}

	/**
	 * 
	 * @throws Exception
	 *             when method type incorrect
	 */
	@Test
	public void shouldNotGetSessionWhenURLIsNotCorrect() throws Exception {
		Mockito.when(connectorService.getSession(getRequestHeaderMapWithAllValue())).thenReturn(shouldGetSessionData());
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders
				.post("http://localhost:8080/sessions?countrycode=gb&scope=all&channel=")
				.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON);
		ResultActions result = mockMvc.perform(request);
		result.andExpect(status().is4xxClientError()).andReturn();
		Assert.assertNotNull(result.andReturn().getRequest().getMethod());
		Assert.assertNotEquals("GET", result.andReturn().getRequest().getMethod());
		Assert.assertEquals(405, result.andReturn().getResponse().getStatus());
	}

	/**
	 * 
	 * @throws Exception
	 *             when method type incorrect
	 */
	@Test
	public void shouldGetReleaseSessionWhenSessionIsNotNull() throws Exception {
		Session session = shouldGetSessionData();
		connectorController.releaseSession(session);
		Assert.assertNotNull(session);
	}

	@Test
	public void shouldGetSessionWithAllValue() throws Exception {
		Session session = shouldGetSessionData();
		Mockito.when(connectorService.getSession(getRequestHeaderMapWithAllValue())).thenReturn(shouldGetSessionData());
		MvcResult result = mockMvc
				.perform(get("http://localhost:8080/sessions?countrycode=gb&scope=booking&channel=kiosk")
						.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().is2xxSuccessful()).andReturn();
		Assert.assertNotNull(result.getRequest());
		response = result.getResponse();
		assertEquals("kiosk", session.getChannel());
		assertEquals("GB", session.getLocation());
		assertEquals("All", session.getScope());
	}

	@Test
	public void shouldNotGetSessionWhenScopeIsNull() throws Exception {
		Session session = shouldGetSessionDataForNullScope();
		Mockito.when(connectorService.getSession(getRequestMapWithNullValue()))
				.thenReturn(shouldGetSessionDataForNullScope());
		MvcResult result = mockMvc.perform(get("/sessions?country-code=gb&channel=kiosk&scope=booking")
				.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().is2xxSuccessful()).andReturn();
		Assert.assertNotNull(result.getRequest());
		response = result.getResponse();
		assertEquals("kiosk", session.getChannel());
		assertEquals("GB", session.getLocation());
		assertEquals(null, session.getScope());
	}

	@Test
	public void shouldNotGetSessionWhenChannelIsNull() throws Exception {
		Session session = shouldGetSessionDataForNullChannel();
		Mockito.when(connectorService.getSession(getRequestMapWithChannelNullValue()))
				.thenReturn(shouldGetSessionDataForNullChannel());
		MvcResult result = mockMvc.perform(get("/sessions?country-code=abcd&channel=&scope=kiosk")
				.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().is2xxSuccessful()).andReturn();
		Assert.assertNotNull(result.getRequest());
		response = result.getResponse();
		assertEquals(null, session.getChannel());
		assertEquals("GB", session.getLocation());
		assertEquals("booking", session.getScope());
	}

	@Test
	public void shouldNotGetSessionWhenCountrycodeIsNull() throws Exception {
		Session session = shouldGetSessionDataForNullCountrycode();
		Mockito.when(connectorService.getSession(getRequestMapWithCountryCodeNullValue()))
				.thenReturn(shouldGetSessionDataForNullCountrycode());
		MvcResult result = mockMvc.perform(get("/sessions?country-code=abcd&channel=&scope=kiosk")
				.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().is2xxSuccessful()).andReturn();
		Assert.assertNotNull(result.getRequest());
		response = result.getResponse();
		assertEquals(null, session.getChannel());
		assertEquals("GB", session.getLocation());
		assertEquals("booking", session.getScope());
	}

    private Map<String, String> getRequestMapWithNullValue() {
		Map<String, String> requestHeaderMap = Maps.newHashMap();
		requestHeaderMap.put("channel", "Kiosk");
		requestHeaderMap.put("scope", null);
		requestHeaderMap.put("countrycode", "GB");
		return requestHeaderMap;
	}

    private Map<String, String> getRequestMapWithChannelNullValue() {
		Map<String, String> requestHeaderMap = Maps.newHashMap();
		requestHeaderMap.put("channel", null);
		requestHeaderMap.put("scope", "booking");
		requestHeaderMap.put("countrycode", "GB");
		return requestHeaderMap;
	}

    private Map<String, String> getRequestMapWithCountryCodeNullValue() {
		Map<String, String> requestHeaderMap = Maps.newHashMap();
		requestHeaderMap.put("channel", "kiosk");
		requestHeaderMap.put("scope", "booking");
		requestHeaderMap.put("countrycode", null);
		return requestHeaderMap;
	}

    private Map<String, String> getRequestHeaderMapWithAllValue() {
		Map<String, String> requestHeaderMap = Maps.newHashMap();
		requestHeaderMap.put("channel", "Kiosk");
		requestHeaderMap.put("scope", "All");
		requestHeaderMap.put("countrycode", "GB");
		return requestHeaderMap;
	}

	private Session shouldGetSessionData() {
		Session session = new Session();
		session.setChannel("kiosk");
		session.setLocation("GB");
		session.setScope("All");
		session.setChannel("kiosk");
		session.setStatus("valid");
		session.setTokenNumber("data");
		return session;
	}

	private Session shouldGetSessionDataForNullScope() {
		Session session = new Session();
		session.setChannel("kiosk");
		session.setLocation("GB");
		session.setScope(null);
		session.setChannel("kiosk");
		return session;
	}

	private Session shouldGetSessionDataForNullChannel() {
		Session session = new Session();
		session.setLocation("GB");
		session.setScope("booking");
		session.setChannel(null);
		return session;
	}

	private Session shouldGetSessionDataForNullCountrycode() {
		Session session = new Session();
		session.setLocation("GB");
		session.setScope("booking");
		session.setChannel(null);
		return session;
	}

}