package com.iag.infra.connector.amadeusconnector.proxy;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;

public class ServiceUrlGeneratorTest {
    private static final String SERVICE_NAME = "CONFIGURATIONISV1";

    private static final String SERVICE_METADATA = "serviceMetadata";

    private ServiceUrlGenerator serviceUrlGenerator;

    private static final String SERVICE_URL = "http://127.1.1.0:8080";

    @Mock
    private EurekaClient eurekaClient;

    @Mock
    private Application application;

    @Mock
    private InstanceInfo info;

    private List<InstanceInfo> instanceInfo;

    private Map<String, String> metaData;
    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        instanceInfo = new ArrayList<>();
        metaData = new HashMap<String, String>();
        metaData.put(SERVICE_METADATA, SERVICE_METADATA);
        instanceInfo.add(info);
        serviceUrlGenerator = new ServiceUrlGenerator(eurekaClient);
    }

    @Test
    public void shouldReturnServiceURL() {
        when(eurekaClient.getApplication(SERVICE_NAME)).thenReturn(application);
        when(application.getInstances()).thenReturn(instanceInfo);
        when(info.getMetadata()).thenReturn(metaData);
        when(info.getIPAddr()).thenReturn("127.1.1.0");
        when(info.getPort()).thenReturn(8080);
        final String serviceUrl = serviceUrlGenerator.generateUrl(SERVICE_NAME, SERVICE_METADATA);
        Assert.assertEquals(SERVICE_URL, serviceUrl);

    }

    @Test
    public void shouldReturnNullWhenApplicationIsNull() {
        when(eurekaClient.getApplication(SERVICE_NAME)).thenReturn(null);

        final String serviceUrl = serviceUrlGenerator.generateUrl(SERVICE_NAME, SERVICE_METADATA);
        Assert.assertEquals(null, serviceUrl);

    }

    @Test
    public void shouldReturnNullWhenServiceInstancesIsNull() {
        when(eurekaClient.getApplication(SERVICE_NAME)).thenReturn(application);
        when(application.getInstances()).thenReturn(null);
        final String serviceUrl = serviceUrlGenerator.generateUrl(SERVICE_NAME, SERVICE_METADATA);
        Assert.assertEquals(null, serviceUrl);

    }

    @Test
    public void shouldReturnNullWhenServiceUrlIsNull() {
        when(eurekaClient.getApplication(SERVICE_NAME)).thenReturn(application);
        when(application.getInstances()).thenReturn(instanceInfo);
        final String serviceUrl = serviceUrlGenerator.generateUrl(SERVICE_NAME, SERVICE_METADATA);
        Assert.assertEquals("http://null:0", serviceUrl);

    }
}

