package com.iag.infra.connector.amadeusconnector.error;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.infra.connector.amadeusconnector.proxy.ServiceProxy;

public class DefaultContentProviderTest {
	private DefaultContentProvider defaultContentProvider;

	@Mock
	private ServiceProxy configurationInfrastructureServiceProxy;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		defaultContentProvider = new DefaultContentProvider(configurationInfrastructureServiceProxy);
	}

	@Test
    public void sholdGetContentValueWhenKeyIsPresent() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfigurationForError("key")).thenReturn("value");
		Assert.assertEquals("value", defaultContentProvider.getContent("key"));
	}

    @Test
    public void sholdGetContentValueWhenKeyIsNotPresent() {
        Mockito.when(configurationInfrastructureServiceProxy.retrieveConfigurationForError("key")).thenReturn(null);
        Assert.assertEquals(null, defaultContentProvider.getContent("key"));
    }
}
