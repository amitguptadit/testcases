package com.iag.infra.connector.repository.impl;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.iag.infra.connector.amadeusconnector.proxy.ConfigurationInfrastructureServiceProxy;
import com.iag.infra.connector.model.AmadeusSessionPoolConfiguration;
import com.iag.infra.connector.model.ConfigurationPoolData;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

public class AmadeusSessionPoolConfigurationRepositoryImplTest {

    private AmadeusSessionPoolConfigurationRepositoryImpl amadeusSessionPoolConfigurationRepositoryImpl;

    private ConfigurationInfrastructureServiceProxy serviceProxy;

    @Before
    public void setUp() {
        serviceProxy = mock(ConfigurationInfrastructureServiceProxy.class);
        amadeusSessionPoolConfigurationRepositoryImpl = new AmadeusSessionPoolConfigurationRepositoryImpl(serviceProxy);

    }

    @Test
    public void shouldProduceValidSessionPoolConfiguration() {
        SessionPoolIdentifier sessionPoolIdentifier = new SessionPoolIdentifier("GB", "KIOSK", "BOOKING");
        ConfigurationPoolData configurationData = new ConfigurationPoolData();
        configurationData.setDefaultPoolSize("10");
        configurationData.setMaxPoolSize("50");
        configurationData.setMinPoolSize("5");
        configurationData.setWaitingTimeOut("70000");
        when(serviceProxy.retrieveConfigurationForPool("GB.BOOKING.KIOSK")).thenReturn(configurationData);
        AmadeusSessionPoolConfiguration amadeusSessionPoolConfiguration = amadeusSessionPoolConfigurationRepositoryImpl
                .getAmadeusSessionPoolConfiguration(sessionPoolIdentifier);
        Assert.assertNotNull(amadeusSessionPoolConfiguration);
        Assert.assertEquals(amadeusSessionPoolConfiguration.getMinimumPoolSize(),
                Integer.parseInt(configurationData.getMinPoolSize()));
        Assert.assertEquals(amadeusSessionPoolConfiguration.getMaxPoolSize(),
                Integer.parseInt(configurationData.getMaxPoolSize()));
    }

    @Test
    public void shouldProduceSimilarSessionPoolConfigurationForLowerAndUpperCaseOfSessionPoolIdentifier() {
        SessionPoolIdentifier sessionPoolIdentifier = new SessionPoolIdentifier("GB", "KIOSK", "BOOKING");
        ConfigurationPoolData configurationData = new ConfigurationPoolData();
        configurationData.setDefaultPoolSize("10");
        configurationData.setMaxPoolSize("50");
        configurationData.setMinPoolSize("5");
        configurationData.setWaitingTimeOut("70000");
        when(serviceProxy.retrieveConfigurationForPool("GB.BOOKING.KIOSK")).thenReturn(configurationData);
        AmadeusSessionPoolConfiguration amadeusSessionPoolConfiguration = amadeusSessionPoolConfigurationRepositoryImpl
                .getAmadeusSessionPoolConfiguration(sessionPoolIdentifier);
        SessionPoolIdentifier sessionPoolIdentifierWithLowerCase = new SessionPoolIdentifier("gb", "kiosk", "booking");
        ConfigurationPoolData configurationDataForLowerCase = new ConfigurationPoolData();
        configurationDataForLowerCase.setDefaultPoolSize("10");
        configurationDataForLowerCase.setMaxPoolSize("50");
        configurationDataForLowerCase.setMinPoolSize("5");
        configurationDataForLowerCase.setWaitingTimeOut("70000");
        when(serviceProxy.retrieveConfigurationForPool("gb.booking.kiosk")).thenReturn(configurationDataForLowerCase);

        AmadeusSessionPoolConfiguration amadeusSessionPoolConfigurationForLowerCase = amadeusSessionPoolConfigurationRepositoryImpl
                .getAmadeusSessionPoolConfiguration(sessionPoolIdentifierWithLowerCase);
        Assert.assertEquals(amadeusSessionPoolConfiguration, amadeusSessionPoolConfigurationForLowerCase);
    }



    @Test
    public void shouldProduceDiffrentSessionPoolConfigurationForDiffremtSetOfSessionPoolIdentifier() {
        SessionPoolIdentifier sessionPoolIdentifier = new SessionPoolIdentifier("GB", "KIOSK", "BOOKING");
        ConfigurationPoolData configurationData = new ConfigurationPoolData();
        configurationData.setDefaultPoolSize("10");
        configurationData.setMaxPoolSize("50");
        configurationData.setMinPoolSize("5");
        configurationData.setWaitingTimeOut("70000");
        when(serviceProxy.retrieveConfigurationForPool("GB.BOOKING.KIOSK")).thenReturn(configurationData);
        AmadeusSessionPoolConfiguration amadeusSessionPoolConfigurationWithFirstSet = amadeusSessionPoolConfigurationRepositoryImpl
                .getAmadeusSessionPoolConfiguration(sessionPoolIdentifier);
        SessionPoolIdentifier sessionPoolIdentifierForSecondSet = new SessionPoolIdentifier("US", "KIOSK", "BOOKING");
        ConfigurationPoolData configurationDataForForSecondSet = new ConfigurationPoolData();
        configurationDataForForSecondSet.setDefaultPoolSize("10");
        configurationDataForForSecondSet.setMaxPoolSize("50");
        configurationDataForForSecondSet.setMinPoolSize("15");
        configurationDataForForSecondSet.setWaitingTimeOut("70000");
        when(serviceProxy.retrieveConfigurationForPool("US.BOOKING.KIOSK"))
                .thenReturn(configurationDataForForSecondSet);

        AmadeusSessionPoolConfiguration amadeusSessionPoolConfigurationForSecondSet = amadeusSessionPoolConfigurationRepositoryImpl
                .getAmadeusSessionPoolConfiguration(sessionPoolIdentifierForSecondSet);
        Assert.assertNotEquals(amadeusSessionPoolConfigurationWithFirstSet, amadeusSessionPoolConfigurationForSecondSet);
    }
}
