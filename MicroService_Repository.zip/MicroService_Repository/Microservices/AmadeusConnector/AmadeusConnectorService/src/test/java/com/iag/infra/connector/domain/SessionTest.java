package com.iag.infra.connector.domain;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class SessionTest {

    private static final String SESSION_IDENTIFIER = "0386QE171R";

    private static final String TOKEN_NUMBER = "26ZBFKWEQKFU7DDW6B2TM3YYI";

    private static final String SCOPE = "BOOKING";

    private static final String CHANNEL = "KIOSK";

    private static final String COUNTRY_CODE = "GB";

    @Test
    public void shouldCreateSessionObject() {
        final Session session = new Session(COUNTRY_CODE, CHANNEL, SCOPE);
        assertEquals(SCOPE, session.getScope());
        assertEquals(CHANNEL, session.getChannel());
        assertEquals(COUNTRY_CODE, session.getLocation());

    }

    @Test
    public void shouldCreateSessionWithAmadeusResponseDetails() {
        final Session session = new Session(TOKEN_NUMBER, SESSION_IDENTIFIER, COUNTRY_CODE, CHANNEL, SCOPE);

        assertEquals(TOKEN_NUMBER, session.getTokenNumber());
        assertEquals(SESSION_IDENTIFIER, session.getSessionIdentifier());
        assertEquals(SCOPE, session.getScope());
        assertEquals(CHANNEL, session.getChannel());
        assertEquals(COUNTRY_CODE, session.getLocation());

    }

    @Test
    public void shouldCreateSessionObjectWithUpperCaseValue() {
        final Session session = new Session("gb", "kiosk", "booking");
        session.convertToUpperCase();
        assertEquals(SCOPE, session.getScope());
        assertEquals(CHANNEL, session.getChannel());
        assertEquals(COUNTRY_CODE, session.getLocation());

    }

}
