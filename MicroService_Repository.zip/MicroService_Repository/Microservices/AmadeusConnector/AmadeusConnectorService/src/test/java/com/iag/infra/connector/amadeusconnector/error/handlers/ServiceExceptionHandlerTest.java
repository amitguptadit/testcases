package com.iag.infra.connector.amadeusconnector.error.handlers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;

import com.iag.application.error.ErrorFactory;
import com.iag.application.error.ServiceError;
import com.iag.application.error.ValidationError;
import com.iag.application.exception.ServiceException;
import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.DefaultContentProvider;
public class ServiceExceptionHandlerTest {
	private ServiceExceptionHandler serviceExceptionHandler;
	private ServiceErrorResponseGenerator serviceErrorResponseGenerator;
	@Mock
	private DefaultContentProvider contentProvider;
	@Mock
	private ServiceError serviceError;
	private ErrorFactory errorFactory;
	private final static String HTTP_STATUS_CODE = "400";


private static final String PASSENGER_INGIDENTIFER_PATH = "scope";

private static final String errorKey ="msg-message-business-REQUEST_INVALID";

private static final String DEVELOPER_MSG = "Value of Amadeus connector Invalid";


private static final String BUSINESS_MSG="Request Invalid";

	@Mock
	ServiceException serviceException;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		serviceErrorResponseGenerator = new ServiceErrorResponseGenerator(contentProvider);
		serviceExceptionHandler = new ServiceExceptionHandler(serviceErrorResponseGenerator);
		errorFactory = new ErrorFactory();
	}

	@Test
	public void shouldHandleRequestInvalidData() {
		Mockito.when(contentProvider.getContent(errorKey)).thenReturn("Request Invalid");
		ValidationServiceException validationRequestInvalidDataException = createValidationServiceException(AmadeusSeviceErrorCode.REQUEST_INVALID.name(),AmadeusSeviceErrorCode.DATA_INVALID.name(),PASSENGER_INGIDENTIFER_PATH);
		Mockito.when(errorFactory.getStatusCode(validationRequestInvalidDataException, contentProvider))
				.thenReturn(HTTP_STATUS_CODE);
		HttpEntity<ServiceError> result = serviceExceptionHandler.handleServiceException(validationRequestInvalidDataException);
		Collection<ValidationError> validationErrorList = ((ValidationError) result.getBody()).getServiceErrors();

		assertNotNull(result.getBody());
		assertEquals(AmadeusSeviceErrorCode.REQUEST_INVALID.name(), result.getBody().getCode());
		assertEquals(BUSINESS_MSG, result.getBody().getBusinessMessage());	    
		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationErrorList.iterator().next().getCode());
		assertEquals(PASSENGER_INGIDENTIFER_PATH, validationErrorList.iterator().next().getPath());
		assertEquals(DEVELOPER_MSG, validationErrorList.iterator().next().getDeveloperMessage());

		}

		private ValidationServiceException createValidationServiceException(String errorCode, String path) {
			ValidationServiceException childValidationServiceException = new ValidationServiceException(errorCode);
			childValidationServiceException.setDeveloperMessage(DEVELOPER_MSG);
			childValidationServiceException.setPath(path);
			return childValidationServiceException;
		}
		
		private ValidationServiceException createValidationServiceException(String parentErrorCode, String childErrorCode,	String path) {
			ValidationServiceException validationServiceException = new ValidationServiceException(parentErrorCode);		
			validationServiceException.addValidationException(createValidationServiceException(childErrorCode, path));
			return validationServiceException;
		}
}