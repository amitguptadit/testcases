package com.iag.infra.connector.utility;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.proxy.ServiceProxy;

public class AmadeusConnectorServiceUtilityTest {
    private static final String BLANK_VALUE = StringUtils.EMPTY;
    private AmadeusConnectorServiceUtility amadeusConnectorServiceUtility;

    @Mock
    private ServiceProxy configurationInfrastructureServiceProxy;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        amadeusConnectorServiceUtility = new AmadeusConnectorServiceUtility(configurationInfrastructureServiceProxy);

    }

    @Test
    public void findingMessageConfigurationValueWithValidKey() {

        String validKey = "msg.message.business.REQUEST_UNAUTHORIZED";
        String validValue = "";
        Mockito.when(configurationInfrastructureServiceProxy.retrieveConfigurationForError(getUrlKey(validKey)))
                .thenReturn(validValue);
        String value = amadeusConnectorServiceUtility.getMessageConfigurationValue(validKey);
        Assert.assertEquals(validValue, value);

    }

    @Test
    public void findingMessageConfigurationValueWithBlankKey() {

        String validKey = BLANK_VALUE;
        String validValue = BLANK_VALUE;
        Mockito.when(configurationInfrastructureServiceProxy.retrieveConfigurationForError(getUrlKey(validKey)))
                .thenReturn(validValue);
        String value = amadeusConnectorServiceUtility.getMessageConfigurationValue(validKey);
        Assert.assertEquals(value, StringUtils.EMPTY);

    }

    @Test
    public void findingMessageConfigurationValueWithNullKey() {

        Mockito.when(configurationInfrastructureServiceProxy.retrieveConfigurationForError(getUrlKey(BLANK_VALUE)))
                .thenReturn(BLANK_VALUE);
        String value = amadeusConnectorServiceUtility.getMessageConfigurationValue(BLANK_VALUE);
        Assert.assertEquals(BLANK_VALUE, value);

    }

    @Test
    public void findingMessageConfigurationValueWithInValidKey() {

        String validKey = "msg.message.business.REQUEST_UNAUTHORIZED_ABC";
        String validValue = "";
        Mockito.when(configurationInfrastructureServiceProxy.retrieveConfigurationForError(getUrlKey(validKey)))
                .thenReturn(validValue);
        String value = amadeusConnectorServiceUtility.getMessageConfigurationValue(validKey);
        System.out.println(value);
        Assert.assertEquals(BLANK_VALUE, value);

    }

    String getUrlKey(String key) {
        return new StringBuilder()
                .append(AmaduesConnectorServiceConstants.MESSAGE_CONFIGURATION_KEYWORD)
                .append(key.replace(AmaduesConnectorServiceConstants.KEY_SEPARATOR_DOT,
                        AmaduesConnectorServiceConstants.KEY_SEPARATOR)).toString();

    }

}
