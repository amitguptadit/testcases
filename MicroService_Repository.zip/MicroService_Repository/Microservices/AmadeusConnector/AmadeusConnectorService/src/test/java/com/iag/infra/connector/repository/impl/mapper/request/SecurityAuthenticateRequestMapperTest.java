package com.iag.infra.connector.repository.impl.mapper.request;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

import com.amadeus.xml.vlsslq_06_1_1a.SecurityAuthenticate;
import com.iag.infra.connector.model.AmadeusConnectionDetails;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

public class SecurityAuthenticateRequestMapperTest {

	private SecurityAuthenticateRequestMapper securityAuthenticateRequestMapper;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		securityAuthenticateRequestMapper = new SecurityAuthenticateRequestMapper();

	}

	@Test
	public void shouldBeAbleToProduceValidSecurityAuthenticateForAmadeusConnectionDetails() {
		SecurityAuthenticate securityAuthenticate  = securityAuthenticateRequestMapper.mapSecurityAuthenticateRequest(getAmadeusConnectionDetails(),createSessionPoolIdentifier());
		Assert.assertNotNull(securityAuthenticate);
	}

	@Test
	public void shouldProduceNullDataTypeForNullAmadeusConnectionDetailsOriginator() {
		AmadeusConnectionDetails amadeusConnectionDetails = getAmadeusConnectionDetails();
		SecurityAuthenticate securityAuthenticate = securityAuthenticateRequestMapper.mapSecurityAuthenticateRequest(amadeusConnectionDetails,createSessionPoolIdentifier());

		Assert.assertEquals("WSBAAVI",securityAuthenticate.getUserIdentifier().get(0).getOriginator());
	}

	@Test
	public void shouldProduceNullDataTypeForNullAmadeusConnectionDetailsOriginatorTypeCodevALUE() {
		AmadeusConnectionDetails amadeusConnectionDetails = getAmadeusConnectionDetails();
		amadeusConnectionDetails.setOriginator(null);
		SecurityAuthenticate securityAuthenticate = securityAuthenticateRequestMapper.mapSecurityAuthenticateRequest(amadeusConnectionDetails,createSessionPoolIdentifier());
		Assert.assertNull(securityAuthenticate.getUserIdentifier().get(0).getOriginator());
	}

	@Test
	public void shouldProduceNullDataTypeForNullAmadeusConnectionDetailsOriginatorTypeCode() {
		AmadeusConnectionDetails amadeusConnectionDetails = getAmadeusConnectionDetails();
		amadeusConnectionDetails.setOriginatorTypeCode(null);
		SecurityAuthenticate securityAuthenticate = securityAuthenticateRequestMapper.mapSecurityAuthenticateRequest(amadeusConnectionDetails,createSessionPoolIdentifier());
		Assert.assertNull(securityAuthenticate.getUserIdentifier().get(0).getOriginatorTypeCode());
	}

	private  AmadeusConnectionDetails getAmadeusConnectionDetails() {
		AmadeusConnectionDetails amadeusConnectionDetails = new AmadeusConnectionDetails();
		amadeusConnectionDetails.setOfficeId("MANBA0609");
		amadeusConnectionDetails.setOriginator("WSBAAVI");
		amadeusConnectionDetails.setPassword("QU1BREVVUw==");
		amadeusConnectionDetails.setPasswordDataType("md5");
		amadeusConnectionDetails.setReferenceQualifier("DUT");
		amadeusConnectionDetails.setReferenceIdentifier("SU");
		amadeusConnectionDetails.setOrganisationalId("BA");
		amadeusConnectionDetails.setOriginatorTypeCode("WSBAAVI");
		amadeusConnectionDetails.setOriginatorForIdentificationType("DUMMY");
		amadeusConnectionDetails.setOriginatorTypeCodeForIdentificationType("DUMMY");
		amadeusConnectionDetails.setOriginatorTypeCodeForUserIdentificationType("U");
		amadeusConnectionDetails.setOriginatorForUserIdentificationType("0001AA");
		return amadeusConnectionDetails;
	}
	
	private SessionPoolIdentifier createSessionPoolIdentifier(){
		
		SessionPoolIdentifier identifier= new SessionPoolIdentifier();
		identifier.setDevice("web");
		return identifier;
		
	}

}