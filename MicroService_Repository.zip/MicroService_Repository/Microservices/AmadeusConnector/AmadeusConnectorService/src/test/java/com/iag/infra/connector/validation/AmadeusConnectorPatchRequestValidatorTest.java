
package com.iag.infra.connector.validation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.google.common.collect.Lists;
import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;
import com.iag.infra.connector.domain.Session;

public class AmadeusConnectorPatchRequestValidatorTest {
	AmadeusConnectorPatchRequestValidator amadeusConnectorPatchRequestValidator;
	@Rule
	public ExpectedException expectedException = ExpectedException.none();
	@Mock
	private ChannelValidator channelValidator;
	@Mock
	private CountrycodeValidator countrycodeValidator;
	@Mock
	private ScopeValidator scopeValidator;
	@Mock
	private StatusValidator statusValidator;
	@Mock
	private TokenNumberValidator tokenNumberValidator;
	@Mock
	private SessionIdentifierValidator sessionIdentifierValidator;
	@Mock
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	Session session;
	Map<String, String> reqParameters;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		reqParameters = new HashMap<String, String>();
        amadeusConnectorPatchRequestValidator = new AmadeusConnectorPatchRequestValidator(scopeValidator,
                channelValidator, countrycodeValidator, statusValidator, sessionIdentifierValidator,
                tokenNumberValidator, validationServiceExceptionGenerator);

	}


	@Test
    public void shouldNotValidateWhenTokenNumberValueIsEmptyForPatch() throws Exception {
		List<ValidationServiceException> validationServiceExceptionList = Lists.newArrayList();
		ValidationServiceException validationServiceException = createServiceExceptionWithChildError(
				validationServiceExceptionList);
		validationServiceExceptionList.add(validationServiceException);
		Mockito.when(validationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionList))
				.thenThrow(validationServiceException);
        Mockito.when(tokenNumberValidator.validate(null)).thenReturn(validationServiceException);
		expectedException.expect(ValidationServiceException.class);
		expectedException.expect(CustomValidationServiceExceptionMatcher.hasException(validationServiceException));
        amadeusConnectorPatchRequestValidator.validateReleaseSessionRequest(new Session());

	}



	@Test
    public void shouldNotValidateWhenSessionIdentifierValueIsEmptyForPatch() throws Exception {
		List<ValidationServiceException> validationServiceExceptionList = Lists.newArrayList();
		ValidationServiceException validationServiceException = createServiceExceptionWithChildError(
				validationServiceExceptionList);
		validationServiceExceptionList.add(validationServiceException);
		Mockito.when(validationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionList))
				.thenThrow(validationServiceException);
		Mockito.when(sessionIdentifierValidator.validate(null)).thenReturn(validationServiceException);
		expectedException.expect(ValidationServiceException.class);
		expectedException.expect(CustomValidationServiceExceptionMatcher.hasException(validationServiceException));
        amadeusConnectorPatchRequestValidator.validateReleaseSessionRequest(new Session());
	}


	@Test
    public void shouldNotThrowExceptionWhenAllParamaterValidForPatch() {
		List<ValidationServiceException> validationServiceExceptionList = Lists.newArrayList();
		Mockito.when(channelValidator.validate("channel")).thenReturn(null);
        Mockito.when(countrycodeValidator.validate("country-code", AmaduesConnectorServiceConstants.LOCATION_PARAM))
                .thenReturn(null);
		Mockito.when(scopeValidator.validate("scope")).thenReturn(null);
		Mockito.when(sessionIdentifierValidator.validate("sessionIdentifier")).thenReturn(null);
		Mockito.when(tokenNumberValidator.validate("tokenNumber")).thenReturn(null);
		Mockito.when(statusValidator.validate("status")).thenReturn(null);
        amadeusConnectorPatchRequestValidator.validateReleaseSessionRequest(new Session());
		Assert.assertTrue(validationServiceExceptionList.isEmpty());

	}

	public ValidationServiceException createServiceExceptionWithChildError(
			final List<ValidationServiceException> validationServiceExceptionList) {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				AmadeusSeviceErrorCode.REQUEST_INVALID.name());
		for (ValidationServiceException childValidationServiceException : validationServiceExceptionList) {
            validationServiceException.addValidationException(childValidationServiceException);
		}
		return validationServiceException;
	}

}
