package com.iag.infra.connector.service.pool;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;

import javax.xml.soap.SOAPException;

import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.iag.infra.connector.domain.Session;
import com.iag.infra.connector.model.AmadeusConnectionDetails;
import com.iag.infra.connector.repository.SessionProviderRepository;
import com.iag.infra.connector.service.pool.SessionFactory;
import com.iag.infra.connector.service.pool.SessionPoolIdentifier;

public class SessionFactoryTest {
	@Mock
	private SessionProviderRepository sessionProviderRepository;
	@Mock
	private AmadeusConnectionDetails amadeusConnectionDetails;
	@Mock
	private SessionPoolIdentifier sessionPoolIdentifier;
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	private SessionFactory sessionFactory;
	private PooledObject<Session> session;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		sessionFactory = new SessionFactory(sessionProviderRepository, amadeusConnectionDetails, sessionPoolIdentifier);
		session = new DefaultPooledObject(getSessionRequest("kisok", "GB", "all"));

	}

	@Test
	public void shoulActivateObject() {
		sessionFactory.activateObject(session);
		assertNotNull(session);	}

	

	@Test
	public void shouldDestroyObjectWhenSignOutReturnTrue() {
		sessionFactory.destroyObject(session);
		assertNotNull(session);	

	}
	@Test
	public void shouldMakeObjectWhenSignInReturnPoolObject() throws SOAPException {
		sessionFactory.makeObject();
		assertNotNull(session);	

	}

	@Test
	public void shouldCreateWhenNull() throws Exception {
		Session session = sessionFactory.create();
		assertThat(session).isEqualTo(sessionFactory.create());

	}

	@Test
	public void shouldWrapWhenNull() throws Exception {
		Session sessionValue = null;
		Session session = (Session) sessionFactory.wrap(sessionValue);
		assertThat(session).isEqualTo(sessionFactory.wrap(session));

	}

	public Session getSessionRequest(String channel, String countrycode, String scope) {
		Session sessionRequest = new Session();
		sessionRequest.setChannel("KISOK");
		sessionRequest.setLocation("GB");
		sessionRequest.setScope("BOOKINGS");
		sessionRequest.setTokenNumber("123");
		sessionRequest.setSessionIdentifier("123");

		return sessionRequest;
	}

}
