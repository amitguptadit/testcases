package com.iag.infra.connector.validation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.constants.AmaduesConnectorServiceConstants;
import com.iag.infra.connector.amadeusconnector.error.AmadeusSeviceErrorCode;
import com.iag.infra.connector.amadeusconnector.error.ValidationServiceExceptionGenerator;

public class CountrycodeValidatorTest {

	ValidationServiceExceptionGenerator validationServiceExceptionGenerator;
	CountrycodeValidator countrycodeValidator;
	
	ValidationServiceException validationServiceException;

	@Before
	public void setUp() {
		validationServiceExceptionGenerator = mock(ValidationServiceExceptionGenerator.class);
		countrycodeValidator = new CountrycodeValidator(validationServiceExceptionGenerator);

	}

	@Test

	public void shouldValidateWhenCountryCodeIsAnyValue() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

        validationServiceException = countrycodeValidator.validate("$$$Data**",
                AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM);

		assertNotNull(validationServiceException);

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());

		assertEquals(AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM, validationServiceException.getPath());

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}

	@Test

	public void shouldValidateWhenCountryCodeIsEmpty() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(), 

				Mockito.anyString())).thenReturn(createValidationServiceException());

        validationServiceException = countrycodeValidator.validate("",
                AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM);

		assertNotNull(validationServiceException);

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());

		assertEquals(AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM, validationServiceException.getPath());

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}
	@Test

	public void shouldValidateWhenCountryCodeIsNull() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(), 

				Mockito.anyString())).thenReturn(createValidationServiceException());

        validationServiceException = countrycodeValidator.validate(null,
                AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM);

		assertNotNull(validationServiceException);

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());

		assertEquals(AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM, validationServiceException.getPath());

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}

	@Test

	public void shouldValidateWhenCountryCodeLengthIsLessThanTwo() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

        validationServiceException = countrycodeValidator.validate("g",
                AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM);

		assertNotNull(validationServiceException);

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());

		assertEquals(AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM, validationServiceException.getPath());

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}
	@Test

	public void shouldValidateWhenCountryCodeLengthIsMoreThanTwo() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

        validationServiceException = countrycodeValidator.validate("GBUS",
                AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM);

		assertNotNull(validationServiceException);

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());

		assertEquals(AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM, validationServiceException.getPath());

		assertEquals(AmadeusSeviceErrorCode.DATA_INVALID.name(), validationServiceException.getDeveloperMessage());

	}

	@Test

	public void shouldValidateWhenCountryCodeIsValid() {

		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),

				Mockito.anyString())).thenReturn(createValidationServiceException());

        validationServiceException = countrycodeValidator.validate("GB",
                AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM);

		assertNull(validationServiceException);

	}

	private ValidationServiceException createValidationServiceException() {

		ValidationServiceException validationServiceException = new ValidationServiceException(

				AmadeusSeviceErrorCode.DATA_INVALID.name());

		validationServiceException.setDeveloperMessage(AmadeusSeviceErrorCode.DATA_INVALID.name());

		validationServiceException.setPath(AmaduesConnectorServiceConstants.COUNTRY_CODE_PARAM);

		return validationServiceException;

	}

}
