package com.iag.infra.connector.amadeusconnector.error.handlers;

import java.util.Collection;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.application.error.ContentProvider;
import com.iag.application.error.ErrorFactory;
import com.iag.application.error.ServiceError;
import com.iag.application.error.ValidationError;
import com.iag.application.exception.ValidationServiceException;
import com.iag.infra.connector.amadeusconnector.error.AmadeusErrorCode;



public class ServiceErrorResponseGeneratorTest {

  private ServiceErrorResponseGenerator serviceErrorResponseGenerator;
  @Mock
  private ContentProvider membershipDefaultContentProvider;
  private ErrorFactory errorFactory;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
    errorFactory = new ErrorFactory();
    serviceErrorResponseGenerator = new ServiceErrorResponseGenerator(membershipDefaultContentProvider);
  }

  @Test
  public void shouldGetHttpStatusCodeForException() {
    ValidationServiceException validationServiceException = new ValidationServiceException(AmadeusErrorCode.REQUEST_INVALID.name());
    ValidationServiceException childValidationServiceException = new ValidationServiceException(AmadeusErrorCode.MANDATORY_DATA_MISSING.name());
    validationServiceException.addValidationException(childValidationServiceException);
    Mockito.when(errorFactory.getStatusCode(validationServiceException, membershipDefaultContentProvider))
        .thenReturn("400");
    String httpStatusCode = serviceErrorResponseGenerator.getStatusCode(validationServiceException);
    Assert.assertEquals("400", httpStatusCode);
  }

  @Test
  public void shouldGetServiceError() {
    ValidationServiceException validationServiceException = new ValidationServiceException(AmadeusErrorCode.REQUEST_INVALID.name());
    ValidationServiceException childValidationServiceException = new ValidationServiceException(AmadeusErrorCode.MANDATORY_DATA_MISSING.name());
    validationServiceException.addValidationException(childValidationServiceException);
    ServiceError serviceError = serviceErrorResponseGenerator.createServiceError(validationServiceException);
    Collection<ValidationError> validationErrorList = ((ValidationError) serviceError).getServiceErrors();
    Assert.assertNotNull(serviceError);
    Assert.assertEquals(AmadeusErrorCode.REQUEST_INVALID.name(), serviceError.getCode());
    Assert.assertTrue(validationErrorList.iterator().hasNext());
    Assert.assertEquals(AmadeusErrorCode.MANDATORY_DATA_MISSING.name(), validationErrorList.iterator().next().getCode());
  }

    @Test
    public void shouldGetHttpStatusCodeForExceptionWhenStatusCodeNotEqual() {
        ValidationServiceException validationServiceException = new ValidationServiceException(
                AmadeusErrorCode.SYSTEM_UNAVAILABLE.name());
        ValidationServiceException childValidationServiceException = new ValidationServiceException(
                AmadeusErrorCode.MANDATORY_DATA_MISSING.name());
        validationServiceException.addValidationException(childValidationServiceException);
        Mockito.when(errorFactory.getStatusCode(validationServiceException, membershipDefaultContentProvider))
                .thenReturn("404");
        String httpStatusCode = serviceErrorResponseGenerator.getStatusCode(validationServiceException);
        Assert.assertNotEquals("404", httpStatusCode);
    }
 
}
