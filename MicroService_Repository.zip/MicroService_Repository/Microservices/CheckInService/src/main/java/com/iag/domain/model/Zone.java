package com.iag.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

public class Zone {
	@JsonProperty("identifier")
	@JsonPropertyDescription("kioskLocation identifier")
	private String identifier;

	@JsonProperty("identifier")
	public String getIdentifier() {
		return identifier;
	}
}
