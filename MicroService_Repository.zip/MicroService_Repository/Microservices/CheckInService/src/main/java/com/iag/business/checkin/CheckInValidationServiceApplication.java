package com.iag.business.checkin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
 * 
 * Starting point for launching Check-in Validation application
 *
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableCircuitBreaker
@EnableHystrixDashboard
public class CheckInValidationServiceApplication {

	/**
	 * 
	 * Main method to start spring application
	 *
	 */
	public static void main(String[] args) {
		SpringApplication.run(CheckInValidationServiceApplication.class, args);
	}

	/**
	 * 
	 * Create RestTemplate using RestTemplateBuilder
	 * @param builder
	 *
	 */
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
}
