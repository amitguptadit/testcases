package com.iag.business.checkin.domain.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.iag.domain.model.party.role.Passenger;

/**
 * Class to map Validation Outcome
 *
 */
public class ValidationOutcome {

	@JsonProperty("code")
	private String code;

	@JsonProperty("validation-type")
	private String validationType;

	@JsonProperty("description")
	private String description;

	@JsonProperty("passenger")
	@JsonInclude(Include.NON_NULL)
	private Passenger passenger;

	@JsonProperty("result")
	private String result;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValidationType() {
		return validationType;
	}

	public void setValidationType(String validationType) {
		this.validationType = validationType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Passenger getPassenger() {
		return passenger;
	}

	public void setPassenger(Passenger passenger) {
		this.passenger = passenger;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
