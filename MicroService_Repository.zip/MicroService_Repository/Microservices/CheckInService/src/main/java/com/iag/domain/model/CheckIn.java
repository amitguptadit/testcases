package com.iag.domain.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iag.domain.model.flight.FlightSegment;
import com.iag.domain.model.party.role.Passenger;

/**
 * 
 * Model class for check in object
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "passengers", "flightSegments" })
public class CheckIn {

	@JsonProperty("passengers")
	private List<Passenger> passengers = new ArrayList<>();
	@JsonProperty("flightSegments")
	private List<FlightSegment> flightSegments = new ArrayList<>();
	private KioskLocation kioskLocation;

	public List<Passenger> getPassengers() {
		return passengers;
	}

	public void setPassengers(List<Passenger> passengers) {
		this.passengers = passengers;
	}

	@JsonProperty("flightSegments")
	public List<FlightSegment> getFlightSegments() {
		return flightSegments;
	}

	@JsonProperty("flightSegments")
	public void setFlightSegments(List<FlightSegment> flightSegments) {
		this.flightSegments = flightSegments;
	}

	public KioskLocation getKioskLocation() {
		return kioskLocation;
	}

	public void setKioskLocation(KioskLocation kioskLocation) {
		this.kioskLocation = kioskLocation;
	}

}
