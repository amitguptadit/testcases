package com.iag.business.checkin.session;

import java.io.Serializable;

import org.springframework.stereotype.Component;

/**
 * The Class creates Amadeus Session.
 */
@Component
public class AmadeusSession implements Serializable {

	private static final long serialVersionUID = 1L;
	private String securityToken;
	private String sequenceNumber;
	private String sessionId;
	private String location;
	private String channel;
	private String scope;

	/**
	 * Constructor to initialize class attributes.
	 * 
	 * @param sessionId
	 * @param sequenceNumber
	 * @param securityToken
	 * @param location
	 * @param channel
	 * @param scope
	 */
	public AmadeusSession(String securityToken, String sequenceNumber, String sessionId, String location,
			String channel, String scope) {
		super();
		this.securityToken = securityToken;
		this.sequenceNumber = sequenceNumber;
		this.sessionId = sessionId;
		this.location = location;
		this.channel = channel;
		this.scope = scope;
	}

	/**
	 * Constructor without parameters	 
	 */
	public AmadeusSession() {
		super();
	}

	public AmadeusSession(String sessionId2, String sequenceNumber2, String securityToken2) {
		this.sessionId = sessionId2;
		this.sequenceNumber = sequenceNumber2;
		this.securityToken = securityToken2;
	}

	public String getSecurityToken() {
		return securityToken;
	}

	public void setSecurityToken(String securityToken) {
		this.securityToken = securityToken;
	}

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	/**
	 * This method used to increase the sequence number after sign in. it can be
	 * easily traced in case of any error/exception from amadeus web service.
	 */
	/**
		 * This method used to decrease the sequence number. it can be easily
		 * traced in case of any error/exception from amadeus web service.
		 */

	/**
		 * This function will reset the Sequence Number to One. So that in
		 * incrementSequenceNumber it can be increased again to one.
		 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("AmadeusSession [sessionId= ");
		sb.append(sessionId).append(", sequenceNumber= ").append(sequenceNumber);
		sb.append(", securityToken= ");
		return sb.toString();
	}
}