package com.iag.business.checkin.application.exception;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.iag.business.checkin.application.error.ValidationError;

/**
 * ValidationServiceException to be used when request validation fails.
 * 
 * @see ServiceException
 * @see ValidationError
 */
public final class ValidationServiceException extends ServiceException {

	private Collection<ValidationServiceException> validationExceptions;
	private String path;

	/**
	 * Constructs validation service exception with the supplied error code. The
	 * error code will be used as message while constructing the exception.
	 * 
	 * @param code
	 */
	public ValidationServiceException(final String code) {
		super(code);
	}

	/**
	 * Constructs validation service exception with the supplied error code and
	 * list of child exceptions. The error code will be used as message while
	 * constructing the exception.
	 * 
	 * @param code
	 * @param childExceptions
	 */
	public ValidationServiceException(final String code, final List<ValidationServiceException> childExceptions) {
		super(code);
		validationExceptions = childExceptions;
	}

	/**
	 * Constructs validation service exception with the supplied error code and
	 * cause. The error code will be used as message while constructing the
	 * exception.
	 * 
	 * @param code
	 * @param cause
	 */
	public ValidationServiceException(final String code, final Throwable cause) {
		super(code, cause);
	}

	/**
	 * Returns collection of ValidationServiceException.
	 * 
	 * @return
	 */
	public Collection<ValidationServiceException> getValidationExceptions() {
		return validationExceptions;
	}

	/**
	 * Adds ValidationServiceException to the collection. Used for wrapping
	 * child error.
	 * 
	 * @param validationException
	 */
	public void addValidationException(final ValidationServiceException validationException) {
		if (validationExceptions == null) {
			validationExceptions = new ArrayList<>();
		}
		validationExceptions.add(validationException);
	}

	public String getPath() {
		return path;
	}

	public void setPath(final String path) {
		this.path = path;
	}

}
