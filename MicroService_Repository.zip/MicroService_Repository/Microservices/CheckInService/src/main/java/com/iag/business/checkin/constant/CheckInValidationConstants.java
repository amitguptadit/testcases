package com.iag.business.checkin.constant;

import com.iag.business.checkin.application.error.MessageConstants;
import com.iag.business.checkin.error.CheckInErrorCode;

/**
 * 
 * Constants for check-in validation service
 *
 */
public final class CheckInValidationConstants {
	
	private CheckInValidationConstants(){}
	/**************************************  CheckInValidation Service Constants *******************************************************************/
	

	public static final String DEVELOPER_MESSAGE_PASSENGER_NOT_FOUND = "PASSENGER_NOT_FOUND";

	public static final String PASSENGER_PATH = "passenger";
	public static final String FLIGHT_SEGMENTS_PATH = "flightSegments";
	public static final String KIOSK_LOCATION_PATH = "kioskLocation";
	public static final String BOOKING_IDENTIFIER_PATH = "booking-identifier";

	public static final String DEVELOPER_MESSAGE_BOOKING_IDENTIFIER_PART = ".developer_message_bookingidentifier";
	public static final String DEVELOPER_MESSAGE_PASSENGER_IDENTIFIER_PART = ".developer_message";

	public static final String DEVELOPER_MESSAGE_BOOKING_IDENTIFIER = MessageConstants.CHECKINVALIDATION_ERROR
			+ CheckInErrorCode.DATA_INVALID.name() + DEVELOPER_MESSAGE_BOOKING_IDENTIFIER_PART;

	public static final String DEVELOPER_MESSAGE_PASSENGER_IDENTIFIER = MessageConstants.CHECKINVALIDATION_ERROR
			+ CheckInErrorCode.MANDATORY_DATA_MISSING.name() + DEVELOPER_MESSAGE_PASSENGER_IDENTIFIER_PART;
	
	public static final String DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING = MessageConstants.CHECKINVALIDATION_ERROR
			+ CheckInErrorCode.MANDATORY_DATA_MISSING.name() + DEVELOPER_MESSAGE_PASSENGER_IDENTIFIER_PART;

	public static final String CONFIG_SERVICE_URI = "config.service.uri";
	public static final String SCOPE = "scope";
	public static final String CHANNEL = "channel";
	public static final String LOCATION = "location";
	public static final String SESSIONIDENTIFIER = "sessionidentifier";
	public static final String TOKENNUMBER = "tokennumber";
	public static final String HEADERVALUE_PATH = "headervalue";
	public static final String DEVMSG_HEADERVALUE = ".developer_message_headervalue";
	public static final String MOCK_RESPONSE = "mock_response";
	public static final String SLASH = "/";
	public static final String JSON = ".json";

	public static final String REFERENCE_QUALIFIER = "UCI";
	public static final String REFERENCE_QUALIFIER_PRODUCT_LEVEL = "DID";
	public static final String CHECKIN_VALIDATION_MARSHALLER_KEY = "CHECKINVALIDATION_MARSHALLER";
	public static final String CHECKIN_VALIDATION_UNMARSHALLER_KEY = "CHECKINVALIDATION_UNMARSHALLER";
	
	public static final int HTTP_SENDER_READ_TIME_OUT = 10000;
	public static final int HTTP_SENDER_CONNECTOR_TIME_OUT = 100000;
	public static final String HTTP_SENDER_MAX_HOSTS = "5";
	public static final String HTTP_SENDER_WILDCARD_HOSTS = "*";
	public static final String SESSIONID = "sessionidentifier";
	public static final String SEQUENCENUMBER = "sequencenumber";
	public static final String SECURITY_TOKEN = "tokennumber";

	public static final String MESSAGE_CONFIGURATION_KEYWORD = "msg-";
	public static final String KEY_SEPARATOR_DOT = ".";
	public static final String KEY_SEPARATOR = "-";

	public static final String VALIDATION_TYPE_ELIGIBILITY = "ELIGIBILITY";
	public static final String VALIDATION_TYPE_OPERATIONAL = "OPERATIONAL";
	public static final String VALIDATION_OUTCOME_RESULT_FAILURE = "FAILURE";
	public static final String VALIDATION_OUTCOME_RESULT_SUCCESS = "SUCCESS";
		
	public static final String REQUEST_INVALID_KEY = "checkinvalidation.error.REQUEST_INVALID.developer_message";
	public static final String ERROR_NAMESPACE = "Errors";
	public static final String VALIDATION_OUTCOME_NAMESPACE = "ValidationOutcomeConstants";
	public static final String VALIDATION_OUTCOME_PREFIX = "validation-outcome.result.";
	public static final String VALIDATION_OUTCOME_SUCCESS_CODE_KEY = "success.code";
	public static final String VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_CODE_KEY = "operational.success.code";
	public static final String VALIDATION_OUTCOME_OPERATIONAL_FAILURE_CODE_KEY = "operational.failure.code";

	public static final String VALIDATION_OUTCOME_SUCCESS_DESCRIPTION_KEY = "success.description";
	public static final String VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_DESCRIPTION_KEY = "operational.success.description";
	public static final String VALIDATION_OUTCOME_OPERATIONAL_FAILURE_DESCRIPTION_KEY = "operational.failure.description";

	public static final String VALIDATION_OUTCOME_RESULT_WARNING = "WARNING";
	public static final String ERROR_CATEGORY_WARNING = "WEC";
	public static final String ERROR_CATEGORY_FAILURE = "EC";
	public static final String VAL = "VAL";

	public static final String AMADEUS_NAMESPACE = "AmadeusConnectivity";
	public static final String AMADEUS_URL = "http://webservices.amadeus.com/1ASIWIAGBA/CREGRQ_16_2_1A";

	public static final String AMADEUS_URL_KEY = "AMADEUS_URL";
	public static final String BOOKING_IDENTIFIER_PATTERN = "^[a-zA-Z0-9]{1,20}+$";
	public static final String DEFAULT_URL_KEY = "DEFAULT_URL";


	
	/**************************************  CheckIn Service Constants *******************************************************************/
	
	
	public static final String V_STRING_OUTCOME_RESULT_PARTIAL = "FAILURE";
	public static final String CHECKIN_SUCCESS_INDICATOR = "CAC";
	public static final String BOOKING_IDENTIFIER = "booking-identifier";
	public static final String VALIDATION_OUTCOME_RESULT_PARTIAL = "PARTIAL";
	public static final String AMADEUS_CHECKIN_URL = "http://webservices.amadeus.com/1ASIWIAGBA/CCKIUQ_16_4_1A";
	public static final String ADULT = "ADULT";
	public static final String CHILD = "CHILD";
	public static final String INFANT = "INFANT";
	public static final String ADULT_VALUE = "A";
	public static final String CHILD_VALUE = "C";
	public static final String INFANT_VALUE = "IN";
	public static final String GENDER_MALE_VALUE = "M";
	public static final String GENDER_FEMALE_VALUE = "F";
	public static final String AMADEUS_NAMESPACE_CHECKIN = "AmadeusConnectivity.CheckIn";
	public static final String AMADEUS_URL_CHECKIN_KEY = "AMADEUS_URL";
	public static final String AMADEUS_URL_CHECKIN="http://webservices.amadeus.com/1ASIWIAGBA/CCKIUQ_16_4_1A";
	public static final String CHECKIN_MARSHALLER_KEY = "MARSHALLER";
	public static final String CHECKIN_UNMARSHALLER_KEY = "UNMARSHALLER";
	public static final String CONFIGURATION_SERVICE_URL="/configurations";
	public static final String IDENTIFIER_KEY = "identifier";
	public static final String RESOURCE_KEY_IDENTIFIER = "resource";
	public static final String VERSION = "version";
	public static final String COLON = ":";
	public static final String URL_PATH_SEPARATOR = "://";
	public static final String SCHEME = "http";
	public static final String SESSION_SPACE_URI = "http://xml.amadeus.com/ws/2009/01/WBS_Session-2.0.xsd";
	public static final String ONE = "1";
	public static final String PAC_VALUE = "PAC";
	public static final String CHECKIN_ACTION ="1";
	public static final Object MALE = "MALE";
	public static final Object NOT_SPECIFIED = "NOT_SPECIFIED";
	public static final Object FEMALE = "FEMALE";
	public static final Object NOT_KNOWN = "NOT_KNOWN";

}
