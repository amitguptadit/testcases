package com.iag.business.checkin.mapper;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.amadeus.xml.cregrq_16_2_1a.DCSACCCheckRegulatoryRqts;
import com.amadeus.xml.cregrq_16_2_1a.DCSACCCheckRegulatoryRqts.CustomerLevel.ProductLevel;
import com.amadeus.xml.cregrq_16_2_1a.FlightDetailsResponseType;
import com.amadeus.xml.cregrq_16_2_1a.ItemReferencesAndVersionsType;
import com.amadeus.xml.cregrq_16_2_1a.ItemReferencesAndVersionsType181303S;
import com.amadeus.xml.cregrq_16_2_1a.OutboundCarrierDetailsTypeI;
import com.amadeus.xml.cregrq_16_2_1a.OutboundFlightNumberDetailstypeI;
import com.amadeus.xml.cregrq_16_2_1a.UniqueIdDescriptionType;
import com.amadeus.xml.cregrq_16_2_1a.UniqueIdDescriptionType254614C;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.domain.model.Carrier;
import com.iag.domain.model.CarrierType;
import com.iag.domain.model.CheckIn;
import com.iag.domain.model.ItineraryItem;

/**
 * 
 * Mapping class to map CheckIn object into Amadeus Object
 */
@Component
public class CheckInValidationRequestMapper {

	private static final Logger logger = LoggerFactory.getLogger(CheckInValidationRequestMapper.class);

	DateTimeFormatter fmt = DateTimeFormat.forPattern("YYYYMMdd");

	/**
	 * Method to create customerLevel object
	 * 
	 * @param checkIn
	 * 
	 * @return DCSACCCheckRegulatoryRqts
	 */
	public DCSACCCheckRegulatoryRqts map(CheckIn checkIn) {
		logger.info("method start: map()");
		DCSACCCheckRegulatoryRqts dcsaccCheckRegulatoryRqts = new DCSACCCheckRegulatoryRqts();
		List<DCSACCCheckRegulatoryRqts.CustomerLevel> customerLevelList = dcsaccCheckRegulatoryRqts.getCustomerLevel();
		int passengerListSize = checkIn.getPassengers().size();
		for (int passengerIndex = 0; passengerIndex < passengerListSize; passengerIndex++) {
			String primeId = checkIn.getPassengers().get(passengerIndex).getIdentifier();
			logger.info("Passanger primeId: {}", primeId);
			DCSACCCheckRegulatoryRqts.CustomerLevel customerLevelObject = new DCSACCCheckRegulatoryRqts.CustomerLevel();
			ItemReferencesAndVersionsType customerIdentifier = new ItemReferencesAndVersionsType();

			UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
			uniqueIdDescriptionType.setReferenceQualifier(CheckInValidationConstants.REFERENCE_QUALIFIER);
			uniqueIdDescriptionType.setPrimeId(primeId);
			customerIdentifier.setIdSection(uniqueIdDescriptionType);
			customerLevelObject.setCustomerIdentifier(customerIdentifier);

			customerLevelObject.setProductLevel(getProductLevelList(passengerIndex, checkIn));
			customerLevelList.add(customerLevelObject);
		}
		dcsaccCheckRegulatoryRqts.setCustomerLevel(customerLevelList);
		logger.info("method end: map()");
		return dcsaccCheckRegulatoryRqts;
	}

	/**
	 * Creates productLevel list to be set under customerLevel object
	 * 
	 * @param passengerIndex
	 * @param checkIn
	 * @return List<ProductLevel>
	 */
	private List<ProductLevel> getProductLevelList(int passengerIndex, CheckIn checkIn) {
		logger.info("method start: getProductLevelList()");
		List<ItineraryItem> itenaryItemList = checkIn.getPassengers().get(passengerIndex).getItinerary()
				.getItineraryItems();
		List<DCSACCCheckRegulatoryRqts.CustomerLevel.ProductLevel> productLevelList = new ArrayList<>();
		int itenaryItemListSize = itenaryItemList.size();

		for (int itenaryIndex = 0; itenaryIndex < itenaryItemListSize; itenaryIndex++) {
			ItineraryItem itenaryItem = itenaryItemList.get(itenaryIndex);
			DCSACCCheckRegulatoryRqts.CustomerLevel.ProductLevel productLevel = new DCSACCCheckRegulatoryRqts.CustomerLevel.ProductLevel();
			FlightDetailsResponseType flightDetailsResponseType = new FlightDetailsResponseType();
			OutboundCarrierDetailsTypeI carrierDetails = new OutboundCarrierDetailsTypeI();
			OutboundFlightNumberDetailstypeI flightDetails = new OutboundFlightNumberDetailstypeI();
			ItemReferencesAndVersionsType181303S productIdentifier = new ItemReferencesAndVersionsType181303S();
			UniqueIdDescriptionType254614C idSection = new UniqueIdDescriptionType254614C();

			String code = "";
			BigInteger flightNumber = null;

			for (Carrier carrier : itenaryItem.getCarriers()) {
				if (CarrierType.MARKETING.name().equalsIgnoreCase(carrier.getType().name())) {
					code = carrier.getCode();
					flightNumber = new BigInteger(carrier.getFlightNumber());
				}
			}
			carrierDetails.setMarketingCarrier(code);
			flightDetailsResponseType.setCarrierDetails(carrierDetails);
			flightDetails.setFlightNumber(flightNumber);
			flightDetailsResponseType.setFlightDetails(flightDetails);
			flightDetailsResponseType.setDepartureDate(itenaryItem.getScheduledDepartureLocalDatetime().toString(fmt));
			flightDetailsResponseType.setBoardPoint(itenaryItem.getOrigin().getIdentifier());
			flightDetailsResponseType.setOffPoint(itenaryItem.getDestination().getIdentifier());
			flightDetailsResponseType.setArrivalDate(itenaryItem.getScheduledArrivalLocalDatetime().toString(fmt));
			idSection.setReferenceQualifier(CheckInValidationConstants.REFERENCE_QUALIFIER_PRODUCT_LEVEL);
			idSection.setPrimeId(itenaryItem.getIdentifier());
			productIdentifier.setIdSection(idSection);
			productLevel.setProductIdentifier(productIdentifier);
			productLevel.setOperatingFlightDetails(flightDetailsResponseType);
			productLevelList.add(productLevel);
			logger.info(
					"ItineraryItem itenaryIndex: {} ,marketingCarrierCode: {},flightNumber: {},DepartureDate: {} ,BoardPoint: {} ,OffPoint: {},ArrivalDate: {} , ReferenceQualifier: {} , PrimeId: {} ",
					itenaryIndex, code, flightNumber, flightDetailsResponseType.getDepartureDate(),
					flightDetailsResponseType.getBoardPoint(), flightDetailsResponseType.getOffPoint(),
					flightDetailsResponseType.getArrivalDate(), idSection.getReferenceQualifier(),
					idSection.getPrimeId());
		}
		logger.info("method end: getProductLevelList()");
		return productLevelList;
	}

}
