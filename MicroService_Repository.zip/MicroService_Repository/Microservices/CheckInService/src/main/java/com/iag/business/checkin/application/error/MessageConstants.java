package com.iag.business.checkin.application.error;

/**
 * Declare message constant
 * 
 */

public class MessageConstants {

	private MessageConstants(){}
	public static final String CHECKINVALIDATION_ERROR = "checkinvalidation.error.";
	public static final String VALIDATION_OUTCOME_RESULT = "validation-outcome.result.";

}
