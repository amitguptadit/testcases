package com.iag.business.checkin.exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.iag.business.checkin.application.error.ServiceError;
import com.iag.business.checkin.application.exception.ServiceException;

/**
 * Class to handle ServiceExceptions and standard spring mvc exceptions.
 */
@ControllerAdvice
public class CheckInValidationExceptionHandler {

	private final ServiceErrorResponseGenerator serviceErrorResponseGenerator;

	/**
	 * Construct ServiceExceptionHandler instance.
	 * 
	 * @param membershipServiceExceptionGenerator
	 * @param serviceErrorResponseGenerator
	 * @param serviceExceptionGenerator
	 */
	@Autowired
	public CheckInValidationExceptionHandler(final ServiceErrorResponseGenerator serviceErrorResponseGenerator) {
		this.serviceErrorResponseGenerator = serviceErrorResponseGenerator;
	}

	/**
	 * Returns HttpEntity encapsulating the error message Service Error.
	 * 
	 * @param serviceException
	 * @return error response
	 */
	@ExceptionHandler(ServiceException.class)
	public ResponseEntity<ServiceError> handleServiceException(final ServiceException serviceException) {
		ServiceError serviceError = serviceErrorResponseGenerator.createServiceError(serviceException);
		String httpStatusCode = serviceErrorResponseGenerator.getStatusCode(serviceException);
		return new ResponseEntity<>(serviceError, HttpStatus.valueOf(Integer.parseInt(httpStatusCode)));
	}

}
