package com.iag.business.checkin.application.exception;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.google.common.base.Optional;

/**
 * Factory to instantiate ServiceException. Client can use it as a singleton entity as it is state less.
 */
public final class ExceptionFactory {
  private static final String EXCEPTION_TYPE_FINDER_POSTFIX = ".exception";
  private final ValidationServiceExceptionFactory validationServiceExceptionFactory =
      new ValidationServiceExceptionFactory();
  private final ApplicationServiceExceptionFactory applicationServiceExceptionFactory =
      new ApplicationServiceExceptionFactory();

  private Map<Class<? extends ServiceException>, AbstractServiceExceptionFactory> exceptionFactoryLocator = new HashMap<>();

  /**
   * Constructs ExceptionFactory.
   */
  public ExceptionFactory() {
    exceptionFactoryLocator.put(ValidationServiceException.class, validationServiceExceptionFactory);
    exceptionFactoryLocator.put(ApplicationServiceException.class, applicationServiceExceptionFactory);
  }

  /**
   * Instantiates ServiceException for the given error code.
   * @param errorCode
   * @param exceptionProvider
   * @param namespace Optional.
   * @return
   */
  public ServiceException createException(final String errorCode,
      final ExceptionProvider exceptionProvider, final Optional<String> namespace) {
    throwExceptionIfBlank(errorCode, "errorCode is blank. Exception instantation failed");
    String fullyQulaifiedExceptionName = exceptionProvider.getExceptionClass(errorCode + EXCEPTION_TYPE_FINDER_POSTFIX);
    throwExceptionIfBlank(fullyQulaifiedExceptionName, "Exception type is found blank. Exception instantation failed");
    @SuppressWarnings("rawtypes")
    Class exceptionType = null;
    try {
      exceptionType = Class.forName(fullyQulaifiedExceptionName);
    } catch (ClassNotFoundException e) {
      throw new ExceptionInstantiationException(e);
    }
    ServiceException serviceException =
        Optional.fromNullable(exceptionFactoryLocator.get(exceptionType)).get()
            .createServiceException(errorCode, exceptionProvider);
    if (namespace.isPresent()) {
      serviceException.setOptionalNamespace(namespace.get());
    }
    return serviceException;
  }

  private void throwExceptionIfBlank(final String arg, final String message) {
    if (StringUtils.isBlank(arg)) {
      throw new ExceptionInstantiationException(message);
    }
  }
}
