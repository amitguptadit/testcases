package com.iag.business.checkin.repository;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.support.MarshallingUtils;

import com.amadeus.xml.cregrq_16_2_1a.DCSACCCheckRegulatoryRqts;
import com.amadeus.xml.cregrr_16_2_1a.DCSACCCheckRegulatoryRqtsReply;
import com.amadeus.xml.cregrr_16_2_1a.ErrorGroupType;
import com.iag.business.checkin.application.exception.ApplicationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.mapper.CheckInValidationRequestHeaderMapper;
import com.iag.business.checkin.mapper.CheckInValidationResponseMapper;
import com.iag.business.checkin.proxy.config.ServiceProxy;
import com.iag.business.checkin.session.AmadeusSession;

/**
 * The class AmadeusWebServiceGateway.
 */
@Component
public class AmadeusWebServiceGateway {
	private static final Logger logger = LoggerFactory.getLogger(AmadeusWebServiceGateway.class);

	@Autowired
	Jaxb2Marshaller amadeusMarshaller;
	@Autowired
	Jaxb2Marshaller amadeusUnMarshaller;
	@Autowired
	private WebServiceTemplate amadeusWebServiceTemplate;
	@Autowired
	CheckInValidationResponseMapper checkInValidationResponseMapper;
	@Autowired
	private ServiceProxy configurationInfrastructureServiceProxy;

	/**
	 * getWebServiceResponse
	 * 
	 * @param requestObject
	 * @param soapActionUri
	 * @param session
	 * @return response
	 */

	public Object getWebServiceResponseForCheckInValidation(DCSACCCheckRegulatoryRqts requestObject,
			String soapActionUri, AmadeusSession session) {

		Object response = null;
		try {
			logger.info("getWebServiceResponseForPassengers session Object {}", session);
			response = getAmadeusWebServiceResponse(requestObject, soapActionUri, session);
			logger.info("Amadeus response:{}", response.getClass());
		} catch (Exception exception) {
			throwWebServiceException(exception);
		}
		hasError(response);
		return response;
	}

	/**
	 * gets AmadeusWebServiceResponse
	 * 
	 * @param requestObject
	 * @param soapActionUri
	 * @param session
	 * @return
	 */
	private Object getAmadeusWebServiceResponse(final Object requestObject, final String soapActionUri,
			AmadeusSession session) {
		return amadeusWebServiceTemplate.sendAndReceive(new WebServiceMessageCallback() {
			public void doWithMessage(WebServiceMessage message) throws IOException {
				prepareRequestBeforeSendReceive(message, soapActionUri, session, requestObject);
			}
		}, new WebServiceMessageExtractor<Object>() {
			public Object extractData(WebServiceMessage message) throws IOException {
				return MarshallingUtils.unmarshal(amadeusUnMarshaller, message);
			}
		});
	}

	/**
	 * Method to set header fields and marshal request
	 * 
	 * @param message
	 * @param soapActionUri
	 * @param session
	 * @param requestObject
	 * @throws IOException
	 */
	private void prepareRequestBeforeSendReceive(WebServiceMessage message, String soapActionUri,
			AmadeusSession session, Object requestObject) throws IOException {
		logger.info("method: prepareRequestBeforeSendReceive() with soapActionUri {}", soapActionUri);
		SaajSoapMessage soapMessage = (SaajSoapMessage) message;
		soapMessage.setSoapAction(soapActionUri);
		CheckInValidationRequestHeaderMapper ame = new CheckInValidationRequestHeaderMapper();
		ame.mapHeaders(soapMessage, session);
		MarshallingUtils.marshal(amadeusMarshaller, requestObject, message);
	}

	/**
	 * This private method is responsible to handle the webServiceException if
	 * any in response from AmadeusWebSerfvice. It should throw the exception
	 * based on the nature.
	 * 
	 * @param WebServiceIOException
	 */

	void throwWebServiceException(final Exception exception) {
		logger.error("AmadeusWebServiceGateway throwWebServiceException {} ", exception);
		throw new ApplicationServiceException(CheckInErrorCode.SYSTEM_UNAVAILABLE.name());
	}

	/**
	 * Checks if the response has any root level errors and handles response
	 * accordingly
	 * 
	 * @param response
	 */
	public void hasError(final Object response) {
		String errorCode;
		final List<ErrorGroupType> errorSection = ((DCSACCCheckRegulatoryRqtsReply) response).getErrors();

		if (errorSection != null) {
			String configerrorCategory = configurationInfrastructureServiceProxy.retrieveConfiguration(
					CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.ERROR_CATEGORY.name());

			for (ErrorGroupType error : errorSection) {
				if (CheckInValidationConstants.ERROR_CATEGORY_FAILURE
						.equals(error.getErrorOrWarningCodeDetails().getErrorDetails().getErrorCategory())) {

					logger.error(
							"AmadeusWebServiceGateway Response ErrorCode {} ,errorCategory {}, errorDescription: {}",
							error.getErrorOrWarningCodeDetails().getErrorDetails().getErrorCode(),
							error.getErrorOrWarningCodeDetails().getErrorDetails().getErrorCategory(),
							getFreeText(error));

				} else {
					logger.warn(
							"AmadeusWebServiceGateway Response ErrorCode {} ,errorCategory {}, errorDescription: {}",
							error.getErrorOrWarningCodeDetails().getErrorDetails().getErrorCode(),
							error.getErrorOrWarningCodeDetails().getErrorDetails().getErrorCategory(),
							getFreeText(error));
				}

			}

			for (ErrorGroupType error : errorSection) {
				errorCode = error.getErrorOrWarningCodeDetails().getErrorDetails().getErrorCode();
				String description = getFreeText(error);
				String errorCategory = error.getErrorOrWarningCodeDetails().getErrorDetails().getErrorCategory();
				logger.error("AmadeusWebServiceGateway Response ErrorCode {} ,errorCategory {} , errorDescription: {} ",
						errorCode, errorCategory, getFreeText(error));
				if (configerrorCategory.contains(errorCategory)) {
					getErrorType(errorCode, description);
				}
			}
		}
	}

	/**
	 * Throws exception according to error status list
	 * 
	 * @param errorCode
	 * @param errorCategory
	 */
	private void getErrorType(String errorCode, String description) {
		String configvalue = configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE,
				CheckInErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name());
		logger.info("configvalue :: {} ", configvalue);
		if (listContain(configvalue, errorCode)) {
			logger.error("AmadeusWebServiceGateway getErrorType {} ,SYSTEM_UNAVAILABLE ", configvalue);
			createAndThrowException(CheckInErrorCode.SYSTEM_UNAVAILABLE.name(), description);
		}
		configvalue = configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.BOARDING_CLOSED_CODE_STATUS.name());
		logger.info("configvalue BOARDING_CLOSED_CODE_STATUS:: {} ", configvalue);

		if (listContain(configvalue, errorCode)) {
			logger.error("AmadeusWebServiceGateway getErrorType {} ,BOARDING_CLOSED ", configvalue);
			createAndThrowException(CheckInErrorCode.BOARDING_CLOSED.name(), description);
		}

		configvalue = configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.FLIGHT_CANCELLED_CODE_STATUS.name());
		logger.info("configvalue FLIGHT_CANCELLED:: {} ", configvalue);

		if (listContain(configvalue, errorCode)) {
			logger.error("AmadeusWebServiceGateway getErrorType {} ,FLIGHT_CANCELLED ", configvalue);
			createAndThrowException(CheckInErrorCode.FLIGHT_CANCELLED.name(), description);
		}

		configvalue = configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.FLIGHT_LOCKED_CODE_STATUS.name());
		logger.info("configvalue FLIGHT_LOCKED:: {} ", configvalue);

		if (listContain(configvalue, errorCode)) {
			logger.error("AmadeusWebServiceGateway getErrorType {} ,FLIGHT_LOCKED ", configvalue);
			createAndThrowException(CheckInErrorCode.FLIGHT_LOCKED.name(), description);
		}

		configvalue = configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.FLIGHT_NOT_ACTIVE_CODE_STATUS.name());
		logger.info("configvalue FLIGHT_NOT_ACTIVE:: {} ", configvalue);

		if (listContain(configvalue, errorCode)) {
			logger.error("AmadeusWebServiceGateway getErrorType {} ,FLIGHT_NOT_ACTIVE ", configvalue);
			createAndThrowException(CheckInErrorCode.FLIGHT_NOT_ACTIVE.name(), description);
		}

		configvalue = configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE,
				CheckInErrorCode.FLIGHT_NOT_OPERATIONAL_CODE_STATUS.name());
		logger.info("configvalue FLIGHT_NOT_OPERATIONAL:: {} ", configvalue);

		if (listContain(configvalue, errorCode)) {
			logger.error("AmadeusWebServiceGateway getErrorType {} ,FLIGHT_NOT_OPERATIONAL ", configvalue);
			createAndThrowException(CheckInErrorCode.FLIGHT_NOT_OPERATIONAL.name(), description);
		}

		configvalue = configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.FLIGHT_SUSPENDED_CODE_STATUS.name());
		logger.info("configvalue FLIGHT_SUSPENDED:: {} ", configvalue);

		if (listContain(configvalue, errorCode)) {
			logger.error("AmadeusWebServiceGateway getErrorType {} ,FLIGHT_SUSPENDED ", configvalue);
			createAndThrowException(CheckInErrorCode.FLIGHT_SUSPENDED.name(), description);
		}

		String ignoredConfigCodes = configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.IGNORE_CODE_STATUS_LIST.name());
		if (!listContain(ignoredConfigCodes, errorCode)) {
			logger.error("AmadeusWebServiceGateway getErrorType {} ,WARNING_CODE_STATUS_LIST -2 ", configvalue);
			createAndThrowException(CheckInErrorCode.SYSTEM_UNAVAILABLE.name(), description);

		}

	}

	/**
	 * Checks root level error code in errorStausList
	 * 
	 * @param errorStausList
	 * @param errorCode
	 * @return boolean
	 */
	private boolean listContain(String errorStausList, String errorCode) {
		boolean hasContain = false;
		if (errorStausList != null) {
			List<String> stringList = Arrays.asList(errorStausList.split("\\s*,\\s*"));
			if (stringList.contains(errorCode)) {
				hasContain = true;
			}
		}

		return hasContain;
	}
	
	/**
	 * Create and throw exception 
	 * @param  code
	 * @param  description	 
	 */

	private void createAndThrowException(String code, String description) {
		ApplicationServiceException appException = new ApplicationServiceException(code);
		appException.setDeveloperMessage(description);
		throw appException;
	}
	
	/**
	 * Get error message  
	 * 
	 * @param ErrorGroupType
	 * @return String
	 */
	public String getFreeText(ErrorGroupType errorGroupType) {
		logger.info("method start: getFreeText()");

		StringBuilder description = new StringBuilder();
		for (String freeText : errorGroupType.getErrorWarningDescription().getFreeText()) {
			description.append(freeText).append(" ");
		}
		logger.info("method end: getFreeText()");
		return description.toString();
	}

}
