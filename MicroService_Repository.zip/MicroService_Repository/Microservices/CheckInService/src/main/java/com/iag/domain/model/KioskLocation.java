package com.iag.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

public class KioskLocation {

	@JsonProperty("identifier")
	@JsonPropertyDescription("kioskLocation identifier")
	private String identifier;

	@JsonProperty("terminal")
	@JsonPropertyDescription("kioskLocation terminal")
	private String terminal;

	private Zone zone;

	public Zone getZone() {
		return zone;
	}

	@JsonProperty("identifier")
	public String getIdentifier() {
		return identifier;
	}

	@JsonProperty("terminal")
	public String getTerminal() {
		return terminal;
	}

}
