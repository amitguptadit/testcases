package com.iag.business.checkin.mapper;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amadeus.xml.cregrr_16_2_1a.DCSACCCheckRegulatoryRqtsReply;
import com.amadeus.xml.cregrr_16_2_1a.DCSACCCheckRegulatoryRqtsReply.CustomerLevel;
import com.amadeus.xml.cregrr_16_2_1a.DCSACCCheckRegulatoryRqtsReply.CustomerLevel.ProductLevel;
import com.amadeus.xml.cregrr_16_2_1a.ErrorGroupType;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.domain.response.CheckInValidation;
import com.iag.business.checkin.domain.response.ValidationOutcome;
import com.iag.business.checkin.proxy.config.ServiceProxy;
import com.iag.domain.model.Itinerary;
import com.iag.domain.model.ItineraryItem;
import com.iag.domain.model.party.role.Passenger;
import com.iag.domain.model.party.role.Passenger.PassengerBuilder;

/**
 * 
 * Check-in validation response mapper class to map response from Amadeus
 * objects DCSACCCheckRegulatoryRqtsReply Response
 */
@Component
public class CheckInValidationResponseMapper {

	private static final Logger logger = LoggerFactory.getLogger(CheckInValidationResponseMapper.class);

	@Autowired
	private ServiceProxy configurationInfrastructureServiceProxy;

	/**
	 * 
	 * CheckInValidationResponseMapper constructor
	 *  @param ServiceProxy
	 *  
	 */
	@Autowired
	public CheckInValidationResponseMapper(final ServiceProxy configurationInfrastructureServiceProxy) {
		this.configurationInfrastructureServiceProxy = configurationInfrastructureServiceProxy;
	}

	/**
	 * This method maps Amadeus response to CheckInValidation Object
	 * 
	 * @param DCSACCCheckRegulatoryRqtsReply
	 *            -- Amadeus reply
	 * @return - CheckInValidation
	 */
	public CheckInValidation map(DCSACCCheckRegulatoryRqtsReply dCSACCCheckRegulatoryRqtsReply) {
		logger.info("method start: DCSACCCheckRegulatoryRqtsReply()");
		CheckInValidation checkInValidation = new CheckInValidation();

		List<ValidationOutcome> validationOutcomes = new ArrayList<>();
		List<CustomerLevel> customerLevelArray = dCSACCCheckRegulatoryRqtsReply.getCustomerLevel();

		for (CustomerLevel customerLevel : customerLevelArray) {
			List<ValidationOutcome> validationOutcomesList = setValidationOutcomes(customerLevel);	
				validationOutcomes.addAll(validationOutcomesList);
			
		}

		checkInValidation.setValidationOutcomes(validationOutcomes);
		checkInValidation.setTotalRecords(validationOutcomes.size());
		logger.info("method end: DCSACCCheckRegulatoryRqtsReply()");
		return checkInValidation;
	}

	/**
	 * Returns validationOutcome errors list
	 * 
	 * @param CustomerLevel
	 * 
	 * @return - List<ValidationOutcome>
	 */

	public List<ValidationOutcome> setValidationOutcomes(CustomerLevel customerLevel) {
		logger.info("method start: setValidationOutcomes()");
		List<ValidationOutcome> validationOutcomesList = new ArrayList<>();
		ValidationOutcome validationOutcome = null;
		Itinerary itinerary = null;
		ItineraryItem itineraryItem = null;
		List<ItineraryItem> itineraryItemList = null;

		String description = "";
		for (ProductLevel productLevel : customerLevel.getProductLevel()) {

			if (productLevel.getErrors().isEmpty()) {
				setValidationOucomeSuccess(customerLevel, productLevel, validationOutcomesList);
			} else {
				for (ErrorGroupType errorGroupType : productLevel.getErrors()) {
					itinerary = new Itinerary();
					itineraryItem = new ItineraryItem();
					itineraryItemList = new ArrayList<>();
					itineraryItemList.add(itineraryItem);
					itinerary.setItineraryItems(itineraryItemList);
					Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<>(null, null, itinerary);
					validationOutcome = new ValidationOutcome();
					itinerary.getItineraryItems().get(0)
							.setIdentifier(productLevel.getProductIdentifier().getIdSection().getPrimeId());

					passengerBuilder
							.setPassengerIdentifier(customerLevel.getCustomerIdentifier().getIdSection().getPrimeId());
					validationOutcome.setPassenger(passengerBuilder.build());
					description = getFreeText(errorGroupType);
					validationOutcome.setCode(CheckInValidationConstants.VAL
							+ errorGroupType.getErrorOrWarningCodeDetails().getErrorDetails().getErrorCode());
					validationOutcome.setDescription(description);

					validationOutcome.setValidationType(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY);
					if (CheckInValidationConstants.ERROR_CATEGORY_WARNING.equals(
							errorGroupType.getErrorOrWarningCodeDetails().getErrorDetails().getErrorCategory())) {
						validationOutcome.setResult(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_WARNING);
					} else if (CheckInValidationConstants.ERROR_CATEGORY_FAILURE.equals(
							errorGroupType.getErrorOrWarningCodeDetails().getErrorDetails().getErrorCategory())) {
						validationOutcome.setResult(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_FAILURE);
					}
					validationOutcomesList.add(validationOutcome);
				}
			}
			logger.info("method end: setValidationOutcomes()");
		}
		return validationOutcomesList;
	}

	/**
	 * Set validationOutcome for success
	 * 
	 * @param CustomerLevel
	 * @param ProductLevel
	 * 
	 */
	public void setValidationOucomeSuccess(CustomerLevel customerLevel, ProductLevel productLevel,
			List<ValidationOutcome> validationOutcomesList) {
		logger.info("method start: setValidationOucomeSuccess()");
		Itinerary itinerary = new Itinerary();
		ItineraryItem itineraryItem = new ItineraryItem();
		List<ItineraryItem> itineraryItemList = new ArrayList<>();
		itineraryItemList.add(itineraryItem);
		itinerary.setItineraryItems(itineraryItemList);
		ValidationOutcome validationOutcome = new ValidationOutcome();

		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<>(null, null, itinerary);

		itinerary.getItineraryItems().get(0)
				.setIdentifier(productLevel.getProductIdentifier().getIdSection().getPrimeId());

		passengerBuilder.setPassengerIdentifier(customerLevel.getCustomerIdentifier().getIdSection().getPrimeId());
		validationOutcome.setPassenger(passengerBuilder.build());
		validationOutcome.setCode(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_SUCCESS_CODE_KEY));
		validationOutcome.setDescription(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_SUCCESS_DESCRIPTION_KEY));
		validationOutcome.setValidationType(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY);
		validationOutcome.setResult(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_SUCCESS);
		validationOutcomesList.add(validationOutcome);
		logger.info("method end: setValidationOucomeSuccess()");

	}
	
	/**
	 * 
	 *  Get error description
	 *  @return String
	 * 
	 */
	public String getFreeText(ErrorGroupType errorGroupType) {
		logger.info("method start: getFreeText()");

		StringBuilder description = new StringBuilder();
		for (String freeText : errorGroupType.getErrorWarningDescription().getFreeText()) {
			description.append(freeText).append(" ");
		}
		logger.info("method end: getFreeText()");
		return description.toString();
	}

}
