package com.iag.business.checkin.application.error;

import org.apache.commons.lang3.StringUtils;

import com.iag.business.checkin.application.exception.ServiceException;

/**
 * Transformer to transform ApplicationException to Application error.This class
 * is purposefully made package private as its scope is within the package.
 * Client using the error framework should not be aware of this low level
 * implementation.
 * 
 * @author n438106
 */
class ApplicationErrorFactory implements AbstractErrorFactory {

	private static final String BUSINESS_MESSAGE_KEY = ".business_message";
	private static final String DEVELOPER_LINK_KEY = ".developer_link";

	@Override
	public ServiceError createError(final ServiceException exception, final ContentProvider contentProvider,
			final String namespace) {
		ApplicationError applicationError = new ApplicationError(exception.getCode());
		applicationError.setBusinessMessage(contentProvider.getContent(MessageConstants.CHECKINVALIDATION_ERROR
				+ StringUtils.trimToEmpty(namespace) + exception.getCode() + BUSINESS_MESSAGE_KEY));
		applicationError.setDeveloperLink(contentProvider
				.getContent(MessageConstants.CHECKINVALIDATION_ERROR + exception.getCode() + DEVELOPER_LINK_KEY));
		applicationError.setDeveloperMessage(exception.getDeveloperMessage());
		return applicationError;
	}

}
