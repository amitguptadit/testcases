package com.iag.business.checkin.application.exception;

/**
 * Contract to get Exception class name for a given error code. Individual SDUs will provide
 * the implementation of this contract.
 */
public interface ExceptionProvider {
  /**
   * Returns fully qualified exception class name for a given error code.
   * @param errorCodeForExceptionType
   * @return
   */
  String getExceptionClass(final String errorCodeForExceptionType);

  /**
   * @param errorCode
   * @return
   */
  String getCode(final String errorCode);
}
