package com.iag.business.checkin.validation;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.exception.ValidationServiceExceptionGenerator;
import com.iag.domain.model.CheckIn;
/**
 * Class to validate operational checks
 *
 */
@Component
public class OperationalCheckValidation {
	private static final Logger logger = LoggerFactory.getLogger(OperationalCheckValidation.class);
	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	/**
	 * @param validationServiceExceptionGenerator
	 */
	@Autowired
	public OperationalCheckValidation(final ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * Validate operational check
	 * 
	 * @param checkIn
	 * @return List<ValidationServiceException>
	 */
	public List<ValidationServiceException> validate(final CheckIn checkIn) {
		logger.info("method start: opertaionalCheckValidate()");
		ValidationServiceException opertaionalCheckValidationServiceException = null;
		List<ValidationServiceException> validationServiceExceptionlist = Lists.newArrayList();

		if (checkIn.getFlightSegments() != null && !checkIn.getFlightSegments().isEmpty()) {
			String terminal = checkIn.getFlightSegments().get(0).getFlightLegs().get(0).getOrigin().getTerminal();
			if (terminal == null || terminal.isEmpty()) {
				opertaionalCheckValidationServiceException = validationServiceExceptionGenerator.createValidationError(
						CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.FLIGHT_SEGMENTS_PATH,
						CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING);
				validationServiceExceptionlist.add(opertaionalCheckValidationServiceException);
			}

			if (checkIn.getKioskLocation() == null) {
				opertaionalCheckValidationServiceException = validationServiceExceptionGenerator.createValidationError(
						CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.KIOSK_LOCATION_PATH,
						CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING);
				validationServiceExceptionlist.add(opertaionalCheckValidationServiceException);

			}

		}
		logger.info("method end opertaionalCheckValidate()");
		return validationServiceExceptionlist;
	}
}
