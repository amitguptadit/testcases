package com.iag.business.checkin.proxy.config;

/**
 * Interface to define contract for service call over http.
 */
public interface ServiceProxy {
	/**
	 * Retrieves configuration item corresponding to supplied key.
	 * 
	 * @param configurationName
	 * @param key
	 *          
	 * @return ServiceErrorMap as String
	 */
	String retrieveConfiguration(String configurationName, String key);
}
