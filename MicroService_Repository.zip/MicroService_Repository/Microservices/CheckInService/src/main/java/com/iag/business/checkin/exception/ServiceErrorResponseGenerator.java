package com.iag.business.checkin.exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.business.checkin.application.error.ContentProvider;
import com.iag.business.checkin.application.error.ErrorFactory;
import com.iag.business.checkin.application.error.ServiceError;
import com.iag.business.checkin.application.exception.ServiceException;
import com.iag.business.checkin.error.CheckInErrorCode;

/**
 * Class to generate Response Error .
 * 
 */
@Component
public class ServiceErrorResponseGenerator {

	private final com.iag.business.checkin.application.error.ContentProvider defaultContentProvider;

	private final ErrorFactory errorFactory;
	private static final String NAMESPACE = "";

	/**
	 * ServiceErrorResponseGenerator constructor
	 *  @param ContentProvider
	 * 
	 */
	@Autowired
	public ServiceErrorResponseGenerator(final ContentProvider defaultContentProvider) {
		this.defaultContentProvider = defaultContentProvider;
		this.errorFactory = new ErrorFactory();

	}

	/**
	 * Method to generate ServiceError from serviceException.
	 * 
	 * @param serviceException
	 * @return
	 */
	public ServiceError createServiceError(final ServiceException serviceException) {
		return errorFactory.createError(serviceException, defaultContentProvider);
	}

	/**
	 * Method to retrieve http status code for an service exception.
	 * 
	 * @param serviceException
	 * @return
	 */
	public String getStatusCode(final ServiceException serviceException) {
		if (serviceException.getCode().equalsIgnoreCase(CheckInErrorCode.SYSTEM_UNAVAILABLE.name())) {
			serviceException.setOptionalNamespace(NAMESPACE);
		}
		return errorFactory.getStatusCode(serviceException, defaultContentProvider);
	}

}
