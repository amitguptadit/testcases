package com.iag.domain.model.flight;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FlightSegmentStatuses {
	
	public FlightSegmentStatuses(){
		
	}
	
	@JsonProperty("bookingStatus")
	private BookingStatus bookingStatus;

	@JsonProperty("acceptanceStatus")
	private AcceptanceAndBoardingStatus acceptanceStatus;
	
	@JsonProperty("boardingStatus")
	private AcceptanceAndBoardingStatus boardingStatus;

	public BookingStatus getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public AcceptanceAndBoardingStatus getAcceptanceStatus() {
		return acceptanceStatus;
	}

	public void setAcceptanceStatus(AcceptanceAndBoardingStatus acceptanceStatus) {
		this.acceptanceStatus = acceptanceStatus;
	}

	public AcceptanceAndBoardingStatus getBoardingStatus() {
		return boardingStatus;
	}

	public void setBoardingStatus(AcceptanceAndBoardingStatus boardingStatus) {
		this.boardingStatus = boardingStatus;
	}

	
}
