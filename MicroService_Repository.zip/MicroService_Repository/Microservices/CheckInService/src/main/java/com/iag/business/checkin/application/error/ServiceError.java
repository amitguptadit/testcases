package com.iag.business.checkin.application.error;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * This class represents any businessMessage, developerMessage, developrLink and code .
 */
//@JsonTypeInfo(use = JsonTypeInfo.Id.CLASS, include = JsonTypeInfo.As.PROPERTY, property = "@type")
@JsonInclude(Include.NON_EMPTY)
public abstract class ServiceError {
  private String businessMessage;
  private String developerMessage;
  private String developerLink;
  private String code;

  /**
   * Parameterised Constructor to initialise code with supplied error code.
   * @param code
   */
  public ServiceError(final String code) {
    this.code = code;
  }
  
  public String getBusinessMessage() {
    return businessMessage;
  }

  public void setBusinessMessage(final String businessMessage) {
    this.businessMessage = businessMessage;
  }

  public String getDeveloperMessage() {
    return developerMessage;
  }

  public void setDeveloperMessage(final String developerMessage) {
    this.developerMessage = developerMessage;
  }

  public String getDeveloperLink() {
    return developerLink;
  }

  public void setDeveloperLink(final String developerLink) {
    this.developerLink = developerLink;
  }

  public String getCode() {
    return code;
  }

  @Override
  public boolean equals(final Object obj) {
    return EqualsBuilder.reflectionEquals(this, obj);
  }

  @Override
  public final String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @Override
  public int hashCode() {
    return HashCodeBuilder.reflectionHashCode(this);
  }
}
