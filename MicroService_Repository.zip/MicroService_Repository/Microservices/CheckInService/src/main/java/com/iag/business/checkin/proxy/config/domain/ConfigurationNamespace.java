
package com.iag.business.checkin.proxy.config.domain;

import java.util.List;

/**
 * 
 * Create ConfigurationNamespace 
 *
 */

public class ConfigurationNamespace {

	private String name;

	private List<ConfigurationItems> configurationItems = null;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ConfigurationItems> getConfigurationItems() {
		return configurationItems;
	}

	public void setConfigurationItems(List<ConfigurationItems> configurationItems) {
		this.configurationItems = configurationItems;
	}

	@Override
	public String toString() {
		return "ConfigurationNamespace [name=" + name + ", configurationItems=" + configurationItems + "]";
	}
}
