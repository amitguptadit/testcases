package com.iag.business.checkin.utility;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.proxy.config.ServiceProxy;

/**
 * The Class provides utility for Amadeus Connector service.
 */
@Component
public class AmadeusConnectorServiceUtility {
	public static final String MESSAGE_CONFIGURATION_KEYWORD = "msg-";
	public static final String KEY_SEPARATOR_DOT = ".";
	public static final String KEY_SEPARATOR = "-";

	private static final Logger logger = LoggerFactory.getLogger(AmadeusConnectorServiceUtility.class);

	private final ServiceProxy configurationInfrastructureServiceProxy;
	
	
	/**
	 * Constructor to initialize class attributes.
	 * @param configurationInfrastructureServiceProxy
	 * 
	 */
	@Autowired
	public AmadeusConnectorServiceUtility(final ServiceProxy configurationInfrastructureServiceProxy) {
		this.configurationInfrastructureServiceProxy = configurationInfrastructureServiceProxy;

	}

	/**
	 * Method to get the message based on the message key.
	 * 
	 * @param key
	 * @return
	 */
	public String getMessageConfigurationValue(final String key) {
		String value = StringUtils.EMPTY;
		if (!StringUtils.EMPTY.equals(StringUtils.trimToEmpty(key))) {
			String urlKey = new StringBuilder().append(MESSAGE_CONFIGURATION_KEYWORD)
					.append(key.replace(KEY_SEPARATOR_DOT, KEY_SEPARATOR)).toString();
			logger.info("getMessageConfigurationValue method invoke .{}", urlKey);

			value = configurationInfrastructureServiceProxy
					.retrieveConfiguration(CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE, urlKey);
		}
		return value;
	}

}
