package com.iag.business.checkin.application.error;
/**
 * Interface defining the contract to provide content to error.
 * @author n438106
 *
 */
public interface ContentProvider {
  /**
   * 
   * @param error
   * @return
   */
  String getContent(final String error);
}
