package com.iag.business.checkin.validation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.exception.ValidationServiceExceptionGenerator;
import com.iag.domain.model.CheckIn;

/**
 * Class to validate Passengers list within checkIn object
 * 
 *
 */
@Component
public class PassengerValidation {

	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;
	private static final Logger logger = LoggerFactory.getLogger(PassengerValidation.class);

	/**
	 * Constructor to initialize class attributes.
	 * 
	 * @param validationServiceExceptionGenerator	
	 */
	@Autowired
	public PassengerValidation(final ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * Returns ValidationServiceException when Passenger list in checkIn object
	 * is null or empty
	 * 
	 * @param checkIn
	 * @return
	 */
	public ValidationServiceException validate(final CheckIn checkIn) {
		logger.info("method start: validate()");
		ValidationServiceException validationServiceException = null;
		if (checkIn == null || checkIn.getPassengers() == null || checkIn.getPassengers().isEmpty()) {
			validationServiceException = validationServiceExceptionGenerator.createValidationError(
					CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.PASSENGER_PATH,
					CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING);

		}
		logger.info("method end: validate()");
		return validationServiceException;
	}
}
