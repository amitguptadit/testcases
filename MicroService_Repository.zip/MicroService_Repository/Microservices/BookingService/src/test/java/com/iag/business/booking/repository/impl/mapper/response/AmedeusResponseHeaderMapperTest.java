package com.iag.business.booking.repository.impl.mapper.response;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import com.iag.business.booking.amadeus.model.AmedeusResponseDetails;
import com.iag.business.booking.constants.BookingServiceConstants;

public class AmedeusResponseHeaderMapperTest {

	private AmedeusResponseHeaderMapper amedeusResponseHeaderMapper;

	private static final String SECURITY_TOKEN = "3MD2XG84Y84O1NVHD7L0CCZWV";

	private static final int SEQUENCE_NUMBER = 1;

	private static final String SESSION_ID = "011MH5M2PH";

	private static final String SESSION = " ";

	@Before
	public void setup() {
		amedeusResponseHeaderMapper = new AmedeusResponseHeaderMapper();
	}

	@Test
	public void shouldMapResponseHeader() throws Exception {
		AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
		SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessage(true, true, true));
		amedeusResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

		Assert.assertEquals(SECURITY_TOKEN, amedeusResponseDetails.getSecurityToken());
		Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
		Assert.assertEquals(SEQUENCE_NUMBER, amedeusResponseDetails.getSequenceNumber());
	}

	@Test
	public void shouldMapResponseHeaderForWrongSessionParentNode() throws Exception {
		AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
		SaajSoapMessage saajSoapMessage = new SaajSoapMessage(
				createSoapMessageWhenHeaderElementIsDifferent(true, true, true, false));
		amedeusResponseDetails.setSecurityToken("3MD2XG84Y84O1NVHD7L0CCZWV");
		amedeusResponseDetails.setSessionId("011MH5M2PH");
		amedeusResponseDetails.setSequenceNumber(1);
		amedeusResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

		Assert.assertEquals(SECURITY_TOKEN, amedeusResponseDetails.getSecurityToken());
		Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
		Assert.assertEquals(SEQUENCE_NUMBER, amedeusResponseDetails.getSequenceNumber());
	}

	@Test
	public void shouldMapResponseHeaderForWrongSessionIdNodeName() throws Exception {
		AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
		SaajSoapMessage saajSoapMessage = new SaajSoapMessage(
				createSoapMessageForWrongSessionIdNodeName(true, true, true));
		amedeusResponseDetails.setSecurityToken("3MD2XG84Y84O1NVHD7L0CCZWV");
		amedeusResponseDetails.setSessionId("011MH5M2PH");
		amedeusResponseDetails.setSequenceNumber(1);
		amedeusResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

		Assert.assertEquals(SECURITY_TOKEN, amedeusResponseDetails.getSecurityToken());
		Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
		Assert.assertEquals(SEQUENCE_NUMBER, amedeusResponseDetails.getSequenceNumber());
	}

	@Test
	public void shouldMapResponseHeaderForWrongSessionIdNodeType() throws Exception {
		AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
		SaajSoapMessage saajSoapMessage = new SaajSoapMessage(
				createSoapMessageForWrongSessionIdNodeType(true, true, true));
		amedeusResponseDetails.setSecurityToken("3MD2XG84Y84O1NVHD7L0CCZWV");
		amedeusResponseDetails.setSessionId("011MH5M2PH");
		amedeusResponseDetails.setSequenceNumber(1);
		amedeusResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

		Assert.assertEquals(SECURITY_TOKEN, amedeusResponseDetails.getSecurityToken());
		Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
		Assert.assertEquals(SEQUENCE_NUMBER, amedeusResponseDetails.getSequenceNumber());
	}

	@Test
	public void shouldMapResponseHeaderWhenSessionIdIsNotPresent() throws Exception {
		AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();

		SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessage(false, true, true));

		amedeusResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

		Assert.assertEquals(SECURITY_TOKEN, amedeusResponseDetails.getSecurityToken());
		Assert.assertEquals(null, amedeusResponseDetails.getSessionId());
		Assert.assertEquals(SEQUENCE_NUMBER, amedeusResponseDetails.getSequenceNumber());
	}

	@Test
	public void shouldMapResponseHeaderWhenSessionIdIsPresent() throws Exception {
		AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();

		SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessage(true, false, false));

		amedeusResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

		Assert.assertEquals(null, amedeusResponseDetails.getSecurityToken());
		Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
		Assert.assertEquals(0, amedeusResponseDetails.getSequenceNumber());
	}

	@Test
	public void shouldMapResponseHeaderWhenSequenceNumberIsNotPresent() throws Exception {
		AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
		SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessage(true, false, true));
		amedeusResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

		Assert.assertEquals(SECURITY_TOKEN, amedeusResponseDetails.getSecurityToken());
		Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
		Assert.assertEquals(0, amedeusResponseDetails.getSequenceNumber());
	}

	@Test
	public void shouldMapResponseHeaderWhenSecurityTokenIsNotPresent() throws Exception {
		AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
		SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessage(true, true, false));
		amedeusResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

		Assert.assertEquals(null, amedeusResponseDetails.getSecurityToken());
		Assert.assertEquals(SESSION_ID, amedeusResponseDetails.getSessionId());
		Assert.assertEquals(SEQUENCE_NUMBER, amedeusResponseDetails.getSequenceNumber());
	}

	@Test
	public void shouldMapResponseHeaderWhenAllAttributesAreNotPresent() throws Exception {
		AmedeusResponseDetails amedeusResponseDetails = new AmedeusResponseDetails();
		SaajSoapMessage saajSoapMessage = new SaajSoapMessage(createSoapMessage(false, false, false));
		amedeusResponseHeaderMapper.map(saajSoapMessage, amedeusResponseDetails);

		Assert.assertEquals(null, amedeusResponseDetails.getSecurityToken());
		Assert.assertEquals(null, amedeusResponseDetails.getSessionId());
		Assert.assertEquals(0, amedeusResponseDetails.getSequenceNumber());
	}

	private SOAPMessage createSoapMessage(final boolean isSessionIdRequired, final boolean isSequenceNumberRequired,
			final boolean isSecurityTokenRequired) throws Exception {
		MessageFactory factory = MessageFactory.newInstance();
		SOAPMessage soapMsg = factory.createMessage();
		SOAPPart part = soapMsg.getSOAPPart();
		SOAPEnvelope envelope = part.getEnvelope();
		SOAPHeader header = envelope.getHeader();
		SOAPHeaderElement sessionNode = header.addHeaderElement(envelope
				.createName(BookingServiceConstants.SESSION_NODE_KEY, "awss", "http://xml.amadeus.com/CCPRRQ_17_1_1A"));

		if (isSessionIdRequired) {
			sessionNode.addChildElement(BookingServiceConstants.SESSION_ID_NODE_KEY).addTextNode(SESSION_ID);
		}
		if (isSequenceNumberRequired) {
			sessionNode.addChildElement(BookingServiceConstants.SEQUENCE_NUMBER_NODE_KEY)
					.addTextNode(String.valueOf(SEQUENCE_NUMBER));
		}
		if (isSecurityTokenRequired) {
			sessionNode.addChildElement(BookingServiceConstants.SECURITY_TOKEN_NODE_KEY)
					.addTextNode(String.valueOf(SECURITY_TOKEN));
		}

		return soapMsg;

	}

	private SOAPMessage createSoapMessageForWrongSessionIdNodeType(final boolean isSessionIdRequired,
			final boolean isSequenceNumberRequired, final boolean isSecurityTokenRequired) throws Exception {
		MessageFactory factory = MessageFactory.newInstance();
		SOAPMessage soapMsg = factory.createMessage();
		SOAPPart part = soapMsg.getSOAPPart();
		SOAPEnvelope envelope = part.getEnvelope();
		SOAPHeader header = envelope.getHeader();
		SOAPHeaderElement sessionNode = header.addHeaderElement(envelope
				.createName(BookingServiceConstants.SESSION_NODE_KEY, "awss", "http://xml.amadeus.com/CCPRRQ_17_1_1A"));

		if (isSessionIdRequired) {
			sessionNode.addTextNode(SESSION_ID);
		}
		if (isSequenceNumberRequired) {
			sessionNode.addChildElement(BookingServiceConstants.SEQUENCE_NUMBER_NODE_KEY)
					.addTextNode(String.valueOf(SEQUENCE_NUMBER));
		}
		if (isSecurityTokenRequired) {
			sessionNode.addChildElement(BookingServiceConstants.SECURITY_TOKEN_NODE_KEY)
					.addTextNode(String.valueOf(SECURITY_TOKEN));
		}

		return soapMsg;

	}

	private SOAPMessage createSoapMessageForWrongSessionIdNodeName(final boolean isSessionIdRequired,
			final boolean isSequenceNumberRequired, final boolean isSecurityTokenRequired) throws Exception {
		MessageFactory factory = MessageFactory.newInstance();
		SOAPMessage soapMsg = factory.createMessage();
		SOAPPart part = soapMsg.getSOAPPart();
		SOAPEnvelope envelope = part.getEnvelope();
		SOAPHeader header = envelope.getHeader();
		SOAPHeaderElement sessionNode = header.addHeaderElement(envelope
				.createName(BookingServiceConstants.SESSION_NODE_KEY, "awss", "http://xml.amadeus.com/CCPRRQ_17_1_1A"));

		if (isSessionIdRequired) {
			sessionNode.addChildElement("session--id").addTextNode("session--id");
		}
		if (isSequenceNumberRequired) {
			sessionNode.addChildElement(BookingServiceConstants.SEQUENCE_NUMBER_NODE_KEY)
					.addTextNode(String.valueOf(SEQUENCE_NUMBER));
		}
		if (isSecurityTokenRequired) {
			sessionNode.addChildElement(BookingServiceConstants.SECURITY_TOKEN_NODE_KEY)
					.addTextNode(String.valueOf(SECURITY_TOKEN));
		}

		return soapMsg;

	}

	private SOAPMessage createSoapMessageWhenHeaderElementIsDifferent(final boolean isSessionIdRequired,
			final boolean isSequenceNumberRequired, final boolean isSecurityTokenRequired,
			final boolean isSessionRequired) throws Exception {
		MessageFactory factory = MessageFactory.newInstance();
		SOAPMessage soapMsg = factory.createMessage();
		SOAPPart part = soapMsg.getSOAPPart();
		SOAPEnvelope envelope = part.getEnvelope();
		SOAPHeader header = envelope.getHeader();
		SOAPHeaderElement sessionNode = header.addHeaderElement(
				envelope.createName("SessionData", "awssss", "http://xml.amadeus.com/CCPRRQ_17_1_1A"));

		if (isSessionIdRequired) {
			QName authHeader = new QName(BookingServiceConstants.SESSION_ID_NODE_KEY,
					BookingServiceConstants.SESSION_ID_NODE_KEY, BookingServiceConstants.SESSION_ID_NODE_KEY);
			sessionNode.addChildElement(envelope.createName(BookingServiceConstants.SESSION_ID_NODE_KEY, "awssss",
					"http://xml.amadeus.com/CCPRRQ_17_1_1A")).addTextNode(SESSION_ID);
		}
		if (isSequenceNumberRequired) {
			sessionNode.addChildElement(BookingServiceConstants.SEQUENCE_NUMBER_NODE_KEY)
					.addTextNode(String.valueOf(SEQUENCE_NUMBER));
		}
		if (isSecurityTokenRequired) {
			sessionNode.addChildElement(BookingServiceConstants.SECURITY_TOKEN_NODE_KEY)
					.addTextNode(String.valueOf(SECURITY_TOKEN));
		}
		if (isSessionRequired) {
			sessionNode.addChildElement(BookingServiceConstants.SESSION_NODE_KEY).addTextNode(String.valueOf(SESSION));
		}
		soapMsg.saveChanges();
		return soapMsg;

	}

}
