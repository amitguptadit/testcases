package com.iag.business.booking.repository.amadeus.proxy;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.WebServiceIOException;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.amadeus.xml.ccprrr_17_1_1a.AdditionalProductDetailsTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.ApplicationErrorDetailType;
import com.amadeus.xml.ccprrr_17_1_1a.ApplicationErrorInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.CodedAttributeInformationType208434C;
import com.amadeus.xml.ccprrr_17_1_1a.CodedAttributeType214203S;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerAndProductLinks;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel.LegLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.SwipeResponse;
import com.amadeus.xml.ccprrr_17_1_1a.EdiIdentifiedBagType;
import com.amadeus.xml.ccprrr_17_1_1a.EdiIdentifiedBaggageGroupType;
import com.amadeus.xml.ccprrr_17_1_1a.ErrorGroupType;
import com.amadeus.xml.ccprrr_17_1_1a.FacilityInformationType171568C;
import com.amadeus.xml.ccprrr_17_1_1a.FlightDetailsResponseType;
import com.amadeus.xml.ccprrr_17_1_1a.FreeTextDetailsType150193C;
import com.amadeus.xml.ccprrr_17_1_1a.FreeTextInformationType167874S;
import com.amadeus.xml.ccprrr_17_1_1a.OriginAndDestinationDetailsTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.OutboundCarrierDetailsTypeI166697C;
import com.amadeus.xml.ccprrr_17_1_1a.OutboundFlightNumberDetailstypeI139968C;
import com.amadeus.xml.ccprrr_17_1_1a.ProductDateTimeTypeI166696C;
import com.amadeus.xml.ccprrr_17_1_1a.RelatedProductInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationDetailsType;
import com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.StationInformationTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.StatusDetailsTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.StatusType144223S;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeType18904C;
import com.amadeus.xml.ccprrr_17_1_1a.TerminalLocationType116626S;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.business.booking.amadeus.model.AmedeusResponseDetails;
import com.iag.business.booking.error.BookingErrorCode;
import com.iag.business.booking.repository.impl.mapper.request.AmedeusRequestHeaderMapper;
import com.iag.domain.model.session.Session;

public class AmadeusWebServiceProxyTest {

	private static final String SOAP_ACTION_URI = "http://webservices.amadeus.com/1ASIWIAGBA/CCPRRQ_17_1_1A";

	private AmadeusWebServiceProxy amadeusWebServiceProxy;

	private static final String SECURITY_TOKEN = "2Y4BVG37P16P42HTA1YFUH5ZBE";

	private static final int SEQUENCE_NUMBER = 1;

	private static final String SESSION_ID = "02WQO94SAI";

	private static final String BOOKING_IDENTIFIER = "SIYB5G";

	@Mock
	private WebServiceTemplate amadeusWebServiceTemplate;


	@Mock
	Jaxb2Marshaller amadeusMarshaller;

	@Mock
	Jaxb2Marshaller amadeusUnMarshaller;

	@Mock
	AmedeusRequestHeaderMapper amedeusRequestHeaderMapper;

	
	 
	@Rule
	public final ExpectedException exception = ExpectedException.none();

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		amadeusWebServiceProxy = new AmadeusWebServiceProxy();

		ReflectionTestUtils.setField(amadeusWebServiceProxy, "amadeusMarshaller", amadeusMarshaller);
		ReflectionTestUtils.setField(amadeusWebServiceProxy, "amadeusUnMarshaller", amadeusUnMarshaller);
		ReflectionTestUtils.setField(amadeusWebServiceProxy, "amedeusRequestHeaderMapper", amedeusRequestHeaderMapper);
		ReflectionTestUtils.setField(amadeusWebServiceProxy, "amadeusWebServiceTemplate", amadeusWebServiceTemplate);
		
	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldGetWebServiceResponse() {
		DCSIDCCPRIdentificationReply dcsidccprIdentificationReply = createAmadeusResponse();
		Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenReturn(dcsidccprIdentificationReply);
		DCSIDCCPRIdentificationReply amadeusResponse =(DCSIDCCPRIdentificationReply) amadeusWebServiceProxy.getBookingResponse(new Object(), SOAP_ACTION_URI,new Session());
		Assert.assertNotNull(amadeusResponse);
		Assert.assertNotNull(amadeusResponse.getErrors());
		Assert.assertTrue(amadeusResponse.getErrors().size() == 0);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThowExceptionWhenAmadeusCallingTimeOut() {
		WebServiceIOException serviceNotAvailable = new WebServiceIOException(
                "I/O error: Read timed out; nested exception is java.net.SocketTimeoutException");
        Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenThrow(serviceNotAvailable);

        exception.expect(ApplicationServiceException.class);
        exception.expectMessage(BookingErrorCode.SYSTEM_UNAVAILABLE.name());
		amadeusWebServiceProxy.getBookingResponse(new Object(), SOAP_ACTION_URI, new Session());

	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThowExceptionWhenAmadeusIsNotAvailable() {
		WebServiceIOException serviceNotAvailable = new WebServiceIOException(
				"I/O error: BAaccess.test.webservices.1a.amadeus.com");
		Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenThrow(serviceNotAvailable);

        exception.expect(ApplicationServiceException.class);
        exception.expectMessage(BookingErrorCode.SYSTEM_UNAVAILABLE.name());
		amadeusWebServiceProxy.getBookingResponse(new Object(), SOAP_ACTION_URI, new Session());

	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThowExceptionWhenErrorOccuredWhileCallingAmadeus() {
		DCSIDCCPRIdentificationReply dcsidccprIdentificationReply = createAmadeusResponsWithError();
		Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenReturn(dcsidccprIdentificationReply);
		DCSIDCCPRIdentificationReply amadeusResponse =(DCSIDCCPRIdentificationReply) amadeusWebServiceProxy.getBookingResponse(new Object(), SOAP_ACTION_URI,new Session());
		Assert.assertNotNull(amadeusResponse);
		Assert.assertNotNull(amadeusResponse.getErrors());
		Assert.assertTrue(amadeusResponse.getErrors().size() > 0);
	}


	private AmedeusResponseDetails createBlankAmedeusResponseDetails() {
		AmedeusResponseDetails response = new AmedeusResponseDetails();
		response.setSoapResponse(new DCSIDCCPRIdentificationReply());
		return response;
	}

	private String getResponseErrorCode(final DCSIDCCPRIdentificationReply amadeusResponse) {
		return amadeusResponse.getErrors().get(0).getErrorOrWarningCodeDetails().getErrorDetails().getErrorCode();

	}

	private DCSIDCCPRIdentificationReply createAmadeusResponse() {
		DCSIDCCPRIdentificationReply amadeusResponse = new DCSIDCCPRIdentificationReply();

		List<CustomerLevel> customerLevelList = new ArrayList<>();
		amadeusResponse.setCustomerLevel(customerLevelList);
		CustomerLevel customerLevel1 = new CustomerLevel();
		customerLevelList.add(customerLevel1);
		List<ProductLevel> productLevelList = new ArrayList<>();
		ProductLevel productLevel = new ProductLevel();
		productLevelList.add(productLevel);

		ReservationControlInformationType recordLocator2 = new ReservationControlInformationType();
		customerLevel1.setRecordLocator(recordLocator2);
		ReservationControlInformationDetailsType reservation2 = new ReservationControlInformationDetailsType();
		recordLocator2.setReservation(reservation2);
		reservation2.setControlNumber(BOOKING_IDENTIFIER);

		RelatedProductInformationType bookingStatusDetails = new RelatedProductInformationType();
		productLevel.setBookingStatusDetails(bookingStatusDetails);
		bookingStatusDetails.setStatusCode("HK");
		CodedAttributeType214203S productLevelIndicators = new CodedAttributeType214203S();
		productLevel.setProductLevelIndicators(productLevelIndicators);
		customerLevel1.setProductLevel(productLevelList);
		List<CodedAttributeInformationType208434C> attributeDetailsList = new ArrayList<>();
		CodedAttributeInformationType208434C codedAttributeInformationType208434C = new CodedAttributeInformationType208434C();
		codedAttributeInformationType208434C.setAttributeType("DUMMY");
		attributeDetailsList.add(codedAttributeInformationType208434C);
		productLevelIndicators.setAttributeDetails(attributeDetailsList);

		StatusType144223S flightStatuses = new StatusType144223S();
		List<StatusDetailsTypeI> statusInformationList = new ArrayList<>();
		StatusDetailsTypeI statusDetailsTypeI = new StatusDetailsTypeI();
		statusDetailsTypeI.setIndicator("FDS");
		statusDetailsTypeI.setAction("FDL2");
		statusInformationList.add(statusDetailsTypeI);
		flightStatuses.setStatusInformation(statusInformationList);
		productLevel.setFlightStatuses(flightStatuses);
		FlightDetailsResponseType operatingFlightDetails = new FlightDetailsResponseType();
		operatingFlightDetails.setBoardPoint("SHA");

		operatingFlightDetails.setDepartureDate("20181022");
		operatingFlightDetails.setArrivalDate("20181022");

		productLevel.setOperatingFlightDetails(operatingFlightDetails);

		List<LegLevel> legLevelList = new ArrayList<>();
		LegLevel legLevel = new LegLevel();

		List<StructuredDateTimeInformationType> legTimes = legLevel.getLegTimes();

		StructuredDateTimeInformationType structuredDateTimeInformationType = new StructuredDateTimeInformationType();
		legTimes.add(structuredDateTimeInformationType);
		structuredDateTimeInformationType.setBusinessSemantic("STD");
		StructuredDateTimeType18904C dateTime = new StructuredDateTimeType18904C();
		structuredDateTimeInformationType.setDateTime(dateTime);
		dateTime.setYear("2018");
		dateTime.setMonth("4");
		dateTime.setDay("16");
		dateTime.setHour("9");
		dateTime.setMinutes("52");
		dateTime.setSeconds(BigInteger.valueOf(50));

		StructuredDateTimeInformationType structuredDateTimeInformationType1 = new StructuredDateTimeInformationType();
		legTimes.add(structuredDateTimeInformationType1);
		structuredDateTimeInformationType1.setBusinessSemantic("STA");
		StructuredDateTimeType18904C dateTime1 = new StructuredDateTimeType18904C();
		structuredDateTimeInformationType1.setDateTime(dateTime1);
		dateTime1.setYear("2018");
		dateTime1.setMonth("4");
		dateTime1.setDay("16");
		dateTime1.setHour("9");
		dateTime1.setMinutes("52");
		dateTime1.setSeconds(BigInteger.valueOf(50));

		legLevelList.add(legLevel);
		AdditionalProductDetailsTypeI additionalProductDetails = new AdditionalProductDetailsTypeI();
		legLevel.setAdditionalProductDetails(additionalProductDetails);
		StationInformationTypeI departureStationInfo = new StationInformationTypeI();
		departureStationInfo.setTerminal("T1");
		additionalProductDetails.setDepartureStationInfo(departureStationInfo);
		productLevel.setLegLevel(legLevelList);

		List<TerminalLocationType116626S> departureGate = new ArrayList<>();
		TerminalLocationType116626S terminalLocationType116626S = new TerminalLocationType116626S();
		departureGate.add(terminalLocationType116626S);
		FacilityInformationType171568C facilityDetails = new FacilityInformationType171568C();
		facilityDetails.setIdentifier("1");
		terminalLocationType116626S.setFacilityDetails(facilityDetails);
		productLevel.setDepartureGate(departureGate);
		StationInformationTypeI arrivalStationInfo = new StationInformationTypeI();
		arrivalStationInfo.setTerminal("T2");
		additionalProductDetails.setArrivalStationInfo(arrivalStationInfo);

		List<ProductDateTimeTypeI166696C> dateAndTimeRange = new ArrayList<>();
		ProductDateTimeTypeI166696C productDateTimeTypeI166696C = new ProductDateTimeTypeI166696C();
		productDateTimeTypeI166696C.setDepartureDate("2018-04-08");
		productDateTimeTypeI166696C.setDepartureTime("1913");
		productDateTimeTypeI166696C.setArrivalDate("2018-04-08");
		productDateTimeTypeI166696C.setArrivalTime("2040");
		dateAndTimeRange.add(productDateTimeTypeI166696C);
		operatingFlightDetails.setDateAndTimeRange(dateAndTimeRange);

		OutboundCarrierDetailsTypeI166697C carrierDetails = new OutboundCarrierDetailsTypeI166697C();
		carrierDetails.setMarketingCarrier("AS");
		carrierDetails.setOtherCarrier("BA");
		operatingFlightDetails.setCarrierDetails(carrierDetails);
		OutboundFlightNumberDetailstypeI139968C flightDetails = new OutboundFlightNumberDetailstypeI139968C();
		flightDetails.setFlightNumber("203");
		flightDetails.setOperationalSuffix("111");
		operatingFlightDetails.setFlightDetails(flightDetails);
		OriginAndDestinationDetailsTypeI legRouting = new OriginAndDestinationDetailsTypeI();
		legRouting.setOrigin("WUX");
		legRouting.setDestination("PVG");
		legLevel.setLegRouting(legRouting);
		operatingFlightDetails.setOffPoint("NTG");
		SwipeResponse responseAnalysisDetailsType = new SwipeResponse();

		amadeusResponse.setSwipeResponse(responseAnalysisDetailsType);
		List<EdiIdentifiedBagType> value = new ArrayList<EdiIdentifiedBagType>();

		amadeusResponse.setBagDetails(value);
		List<EdiIdentifiedBaggageGroupType> value1=new ArrayList<EdiIdentifiedBaggageGroupType>();
		amadeusResponse.setBaggageInfo(value1);
		List<CustomerAndProductLinks> value33=new ArrayList<CustomerAndProductLinks>();

		amadeusResponse.setCustomerAndProductLinks(value33);
		List<CustomerLevel> valu333e= new ArrayList<CustomerLevel>();;
		amadeusResponse.setCustomerLevel(valu333e);

		return amadeusResponse;
	}

	private DCSIDCCPRIdentificationReply createAmadeusResponsWithError() {
		DCSIDCCPRIdentificationReply amadeusResponse = new DCSIDCCPRIdentificationReply();

		List<CustomerLevel> customerLevelList = new ArrayList<>();
		amadeusResponse.setCustomerLevel(customerLevelList);
		CustomerLevel customerLevel1 = new CustomerLevel();
		customerLevelList.add(customerLevel1);
		List<ProductLevel> productLevelList = new ArrayList<>();
		ProductLevel productLevel = new ProductLevel();
		productLevelList.add(productLevel);

		ReservationControlInformationType recordLocator2 = new ReservationControlInformationType();
		customerLevel1.setRecordLocator(recordLocator2);
		ReservationControlInformationDetailsType reservation2 = new ReservationControlInformationDetailsType();
		recordLocator2.setReservation(reservation2);
		reservation2.setControlNumber(BOOKING_IDENTIFIER);

		RelatedProductInformationType bookingStatusDetails = new RelatedProductInformationType();
		productLevel.setBookingStatusDetails(bookingStatusDetails);
		bookingStatusDetails.setStatusCode("HK");
		CodedAttributeType214203S productLevelIndicators = new CodedAttributeType214203S();
		productLevel.setProductLevelIndicators(productLevelIndicators);
		customerLevel1.setProductLevel(productLevelList);
		List<CodedAttributeInformationType208434C> attributeDetailsList = new ArrayList<>();
		CodedAttributeInformationType208434C codedAttributeInformationType208434C = new CodedAttributeInformationType208434C();
		codedAttributeInformationType208434C.setAttributeType("DUMMY");
		attributeDetailsList.add(codedAttributeInformationType208434C);
		productLevelIndicators.setAttributeDetails(attributeDetailsList);

		StatusType144223S flightStatuses = new StatusType144223S();
		List<StatusDetailsTypeI> statusInformationList = new ArrayList<>();
		StatusDetailsTypeI statusDetailsTypeI = new StatusDetailsTypeI();
		statusDetailsTypeI.setIndicator("FDS");
		statusDetailsTypeI.setAction("FDL2");
		statusInformationList.add(statusDetailsTypeI);
		flightStatuses.setStatusInformation(statusInformationList);
		productLevel.setFlightStatuses(flightStatuses);
		FlightDetailsResponseType operatingFlightDetails = new FlightDetailsResponseType();
		operatingFlightDetails.setBoardPoint("SHA");

		operatingFlightDetails.setDepartureDate("20181022");
		operatingFlightDetails.setArrivalDate("20181022");

		productLevel.setOperatingFlightDetails(operatingFlightDetails);

		List<LegLevel> legLevelList = new ArrayList<>();
		LegLevel legLevel = new LegLevel();

		List<StructuredDateTimeInformationType> legTimes = legLevel.getLegTimes();

		StructuredDateTimeInformationType structuredDateTimeInformationType = new StructuredDateTimeInformationType();
		legTimes.add(structuredDateTimeInformationType);
		structuredDateTimeInformationType.setBusinessSemantic("STD");
		StructuredDateTimeType18904C dateTime = new StructuredDateTimeType18904C();
		structuredDateTimeInformationType.setDateTime(dateTime);
		dateTime.setYear("2018");
		dateTime.setMonth("4");
		dateTime.setDay("16");
		dateTime.setHour("9");
		dateTime.setMinutes("52");
		dateTime.setSeconds(BigInteger.valueOf(50));

		StructuredDateTimeInformationType structuredDateTimeInformationType1 = new StructuredDateTimeInformationType();
		legTimes.add(structuredDateTimeInformationType1);
		structuredDateTimeInformationType1.setBusinessSemantic("STA");
		StructuredDateTimeType18904C dateTime1 = new StructuredDateTimeType18904C();
		structuredDateTimeInformationType1.setDateTime(dateTime1);
		dateTime1.setYear("2018");
		dateTime1.setMonth("4");
		dateTime1.setDay("16");
		dateTime1.setHour("9");
		dateTime1.setMinutes("52");
		dateTime1.setSeconds(BigInteger.valueOf(50));

		legLevelList.add(legLevel);
		AdditionalProductDetailsTypeI additionalProductDetails = new AdditionalProductDetailsTypeI();
		legLevel.setAdditionalProductDetails(additionalProductDetails);
		StationInformationTypeI departureStationInfo = new StationInformationTypeI();
		departureStationInfo.setTerminal("T1");
		additionalProductDetails.setDepartureStationInfo(departureStationInfo);
		productLevel.setLegLevel(legLevelList);

		List<TerminalLocationType116626S> departureGate = new ArrayList<>();
		TerminalLocationType116626S terminalLocationType116626S = new TerminalLocationType116626S();
		departureGate.add(terminalLocationType116626S);
		FacilityInformationType171568C facilityDetails = new FacilityInformationType171568C();
		facilityDetails.setIdentifier("1");
		terminalLocationType116626S.setFacilityDetails(facilityDetails);
		productLevel.setDepartureGate(departureGate);
		StationInformationTypeI arrivalStationInfo = new StationInformationTypeI();
		arrivalStationInfo.setTerminal("T2");
		additionalProductDetails.setArrivalStationInfo(arrivalStationInfo);

		List<ProductDateTimeTypeI166696C> dateAndTimeRange = new ArrayList<>();
		ProductDateTimeTypeI166696C productDateTimeTypeI166696C = new ProductDateTimeTypeI166696C();
		productDateTimeTypeI166696C.setDepartureDate("2018-04-08");
		productDateTimeTypeI166696C.setDepartureTime("1913");
		productDateTimeTypeI166696C.setArrivalDate("2018-04-08");
		productDateTimeTypeI166696C.setArrivalTime("2040");
		dateAndTimeRange.add(productDateTimeTypeI166696C);
		operatingFlightDetails.setDateAndTimeRange(dateAndTimeRange);

		OutboundCarrierDetailsTypeI166697C carrierDetails = new OutboundCarrierDetailsTypeI166697C();
		carrierDetails.setMarketingCarrier("AS");
		carrierDetails.setOtherCarrier("BA");
		operatingFlightDetails.setCarrierDetails(carrierDetails);
		OutboundFlightNumberDetailstypeI139968C flightDetails = new OutboundFlightNumberDetailstypeI139968C();
		flightDetails.setFlightNumber("203");
		flightDetails.setOperationalSuffix("111");
		operatingFlightDetails.setFlightDetails(flightDetails);
		OriginAndDestinationDetailsTypeI legRouting = new OriginAndDestinationDetailsTypeI();
		legRouting.setOrigin("WUX");
		legRouting.setDestination("PVG");
		legLevel.setLegRouting(legRouting);
		operatingFlightDetails.setOffPoint("NTG");

		List<ErrorGroupType> errors = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();
		errors.add(errorGroupType);

		ApplicationErrorInformationType errorOrWarningCodeDetails = new ApplicationErrorInformationType();
		FreeTextInformationType167874S errorWarningDescription = new FreeTextInformationType167874S();
		errorGroupType.setErrorOrWarningCodeDetails(errorOrWarningCodeDetails);
		errorGroupType.setErrorWarningDescription(errorWarningDescription);

		ApplicationErrorDetailType errorDetails = new ApplicationErrorDetailType();
		errorOrWarningCodeDetails.setErrorDetails(errorDetails);
		errorDetails.setErrorCode("17569");
		FreeTextDetailsType150193C freeTextDetails = new FreeTextDetailsType150193C();
		errorWarningDescription.setFreeTextDetails(freeTextDetails);
		freeTextDetails.setLanguage("EN");
		amadeusResponse.setErrors(errors);

		return amadeusResponse;
	}
}
