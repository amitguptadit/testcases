package com.iag.business.booking.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.joda.time.LocalDateTime;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.iag.business.booking.service.BookingService;
import com.iag.business.booking.validation.BookingServiceValidator;
import com.iag.domain.model.Carrier;
import com.iag.domain.model.CarrierType;
import com.iag.domain.model.Destination;
import com.iag.domain.model.Gate;
import com.iag.domain.model.Origin;
import com.iag.domain.model.booking.Booking;
import com.iag.domain.model.booking.BookingResource;
import com.iag.domain.model.booking.BookingSearchCriteria;
import com.iag.domain.model.booking.Bookings;
import com.iag.domain.model.flight.BookingStatus;
import com.iag.domain.model.flight.FlightLeg;
import com.iag.domain.model.flight.FlightSegment;
import com.iag.domain.model.flight.FlightSegmentStatuses;
import com.iag.domain.model.flight.FlightSegmentType;
import com.iag.domain.model.session.Session;

/**
 * @author n485240
 *
 */
public class BookingControllerTest {

	@InjectMocks
	private BookingController bookingController;
	@Mock
	private BookingService bookingService;
	@Mock
	private BookingServiceValidator boookingServiceValidator;
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	private MockMvc mockMvc;
	private static final String BOOKING_IDENTIFIER = "SIYB5G";
	private static final String CORRECT_URI = "/bookings/SIYB5G?api-key=CXPI";
	private static final String GET_METHOD = "GET";
	private static final String SELF = "_self";
	private static final String BOOKING = "allPassengers";
	private HttpHeaders httpHeaders;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		httpHeaders = new HttpHeaders();
		httpHeaders.setAll(getRequestHeaderMapWithAllValue());
		this.mockMvc = MockMvcBuilders.standaloneSetup(bookingController).setMessageConverters(
				new MappingJackson2HttpMessageConverter(), new Jaxb2RootElementHttpMessageConverter()).build();

		ReflectionTestUtils.setField(bookingController, "bookingService", bookingService);
		ReflectionTestUtils.setField(bookingController, "boookingServiceValidator", boookingServiceValidator);
		Mockito.when(bookingService.getBooking(BOOKING_IDENTIFIER, getSession(getRequestHeaderMapWithAllValue())))
				.thenReturn(createBooking());
		Mockito.when(
				bookingService.getBookings(getBookingSearchCriteria(), getSession(getRequestHeaderMapWithAllValue())))
				.thenReturn(createBookings());
		HttpServletRequest httpServletRequestMock = new MockHttpServletRequest();
		ServletRequestAttributes servletRequestAttributes = new ServletRequestAttributes(httpServletRequestMock);
		RequestContextHolder.setRequestAttributes(servletRequestAttributes);
	}

	private BookingSearchCriteria getBookingSearchCriteria() {
		BookingSearchCriteria bookingSearchCriteria = new BookingSearchCriteria();
		bookingSearchCriteria.setBookingIdentifier("BID");
		bookingSearchCriteria.setFirstName("Firstname");
		bookingSearchCriteria.setFamilyName("Familyname");
		bookingSearchCriteria.setIdentifierType("IdentifierType");
		bookingSearchCriteria.setToken("Token");
		bookingSearchCriteria.setFlightNumber("FlightNumber");
		bookingSearchCriteria.setDestination("Destination");
		return bookingSearchCriteria;
	}

	private List<Booking> createBookings() {
		Booking booking = new Booking.BookingBuilder("SIYB5G", LoadflightSegments()).build();
		List<Booking> bookingList = new ArrayList<Booking>();
		bookingList.add(booking);
		// Bookings bookings = new
		// Bookings.BookingsBuilder(bookingList,1).build();

		return bookingList;
	}

	@After
	public void teardown() {
		RequestContextHolder.resetRequestAttributes();
	}

	@Test
	public void shouldGetBookingWhenIdentifierIsNotNull() {
		BookingResource<Booking> bookingResource = bookingController
				.getBooking(BOOKING_IDENTIFIER, getRequestHeaderMapWithAllValue()).getBody();
		Booking booking = bookingResource.getContent();
		assertNotNull(booking);
		assertNotNull(booking.getIdentifier());

		booking.getFlightSegments().forEach((flightSegment) -> {
			assertNotNull(flightSegment.getType());
			assertNotNull(flightSegment.getStatus());

			assertNotNull(flightSegment.getOrigin().getIdentifier());
			assertNotNull(flightSegment.getOrigin().getGate().getNumber());

			assertNotNull(flightSegment.getDestination().getIdentifier());
			assertNotNull(flightSegment.getDestination().getGate().getNumber());

			assertNotNull(flightSegment.getScheduledDepartureLocalDatetime());
			assertNotNull(flightSegment.getScheduledArrivalLocalDatetime());

			flightSegment.getFlightLegs().forEach((flightLeg) -> {
				assertNotNull(flightLeg.getOrigin().getIdentifier());
				assertNotNull(flightLeg.getOrigin().getGate().getNumber());

				assertNotNull(flightLeg.getDestination().getIdentifier());
				assertNotNull(flightLeg.getDestination().getGate().getNumber());

				assertNotNull(flightLeg.getScheduledDepartureLocalDatetime());
				assertNotNull(flightLeg.getScheduledArrivalLocalDatetime());
			});
		});
		assertEquals(2, bookingResource.getLinks().size());
		assertEquals(SELF, bookingResource.getLinks().get(0).getRel());
		assertThat(
				bookingResource.getLinks().get(0).withSelfRel().getHref().endsWith("/bookings/" + BOOKING_IDENTIFIER));
		assertEquals(BOOKING, bookingResource.getLinks().get(1).getRel());
		assertThat(bookingResource.getLinks().get(1).getHref()
				.endsWith("/bookings/" + BOOKING_IDENTIFIER + "/passengers"));
	}

	@Test
	public void shouldNotGetBookingsWhenHeaderIsNull() {
		BookingResource<Bookings> bookingsResource = bookingController.getBookings("Firstname", "BID", "Familyname",
				"IdentifierType", "Token", "FlightNumber", "Destination", null).getBody();
		assertNotNull(bookingsResource);
		assertEquals(0, bookingsResource.getContent().getBookings().size());
	}

	@Test
	public void shouldGetBookingsWhenHeaderIsNotNull() {
		BookingResource<Bookings> bookingsResource = bookingController.getBookings("Firstname", "BID", "Familyname",
				"IdentifierType", "Token", "FlightNumber", "Destination", getRequestHeaderMapWithAllValue()).getBody();

		Bookings bookings = bookingsResource.getContent();
		assertNotNull(bookings);
		assertNotNull(bookings.getBookings().get(0).getIdentifier());

		bookings.getBookings().get(0).getFlightSegments().forEach((flightSegment) -> {
			assertNotNull(flightSegment.getType());
			assertNotNull(flightSegment.getStatus());

			assertNotNull(flightSegment.getOrigin().getIdentifier());
			assertNotNull(flightSegment.getOrigin().getGate().getNumber());

			assertNotNull(flightSegment.getDestination().getIdentifier());
			assertNotNull(flightSegment.getDestination().getGate().getNumber());

			assertNotNull(flightSegment.getScheduledDepartureLocalDatetime());
			assertNotNull(flightSegment.getScheduledArrivalLocalDatetime());

			flightSegment.getFlightLegs().forEach((flightLeg) -> {
				assertNotNull(flightLeg.getOrigin().getIdentifier());
				assertNotNull(flightLeg.getOrigin().getGate().getNumber());

				assertNotNull(flightLeg.getDestination().getIdentifier());
				assertNotNull(flightLeg.getDestination().getGate().getNumber());

				assertNotNull(flightLeg.getScheduledDepartureLocalDatetime());
				assertNotNull(flightLeg.getScheduledArrivalLocalDatetime());
			});
		});
		assertEquals(2, bookingsResource.getLinks().size());
		assertEquals(SELF, bookingsResource.getLinks().get(0).getRel());
		assertThat(
				bookingsResource.getLinks().get(0).withSelfRel().getHref().endsWith("/bookings/" + BOOKING_IDENTIFIER));
		assertEquals(BOOKING, bookingsResource.getLinks().get(1).getRel());
		assertThat(bookingsResource.getLinks().get(1).getHref()
				.endsWith("/bookings/" + BOOKING_IDENTIFIER + "/passengers"));
	}

	@Test
	public void shouldGetBookingWhenURLCorrect() throws Exception {
		MvcResult result = mockMvc.perform(get(CORRECT_URI).headers(httpHeaders).accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
		Assert.assertNotNull(result.getRequest());
		Assert.assertEquals(GET_METHOD, result.getRequest().getMethod());
		Assert.assertEquals(200, result.getResponse().getStatus());
	}

	@Test
	public void shouldGetBookingWhenQueryParameterPassedInURL() throws Exception {
		MvcResult result = mockMvc.perform(get(CORRECT_URI).headers(httpHeaders).accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
		Assert.assertNotNull(result.getRequest());
		Assert.assertEquals(GET_METHOD, result.getRequest().getMethod());
		Assert.assertEquals(200, result.getResponse().getStatus());
	}

	@Test
	public void shouldGetHateosLink() throws Exception {
		BookingResource<Booking> bookingResource = bookingController
				.getBooking(BOOKING_IDENTIFIER, getRequestHeaderMapWithAllValue()).getBody();
		assertNotNull(bookingResource);
		Booking booking = bookingResource.getContent();
		assertNotNull(booking);
		assertEquals(2, bookingResource.getLinks().size());
		assertEquals(SELF, bookingResource.getLinks().get(0).getRel());
		assertThat(
				bookingResource.getLinks().get(0).withSelfRel().getHref().endsWith("/bookings/" + BOOKING_IDENTIFIER));
		assertEquals(BOOKING, bookingResource.getLinks().get(1).getRel());
		assertThat(bookingResource.getLinks().get(1).getHref()
				.endsWith("/bookings/" + BOOKING_IDENTIFIER + "/passengers"));
	}

	public void tearDown() throws Exception {
		this.mockMvc = null;
		bookingService = null;
		boookingServiceValidator = null;
	}

	private Map<String, String> getRequestHeaderMapWithAllValue() {
		Map<String, String> headerValueMap = new HashMap<String, String>();
		headerValueMap.put("X-Forwarded-For", "203.0.113.195");
		headerValueMap.put("X-Trace-Identifier", "3a01b0e2bc5ebbed");
		headerValueMap.put("X-Agent-Identifier", "Mozilla/5.0 ");
		headerValueMap.put("tokennumber", "tokennumber");
		headerValueMap.put("sessionidentifier", "sessionidentifier");
		headerValueMap.put("location", "location");
		headerValueMap.put("channel", "channel");
		headerValueMap.put("scope", "scope");
		headerValueMap.put("status", "status");
		return headerValueMap;
	}

	private Session getSession(Map<String, String> headerValueMap) {
		Session session = new Session();
		if (headerValueMap != null) {
			session.setTokenNumber(headerValueMap.get("tokennumber"));
			session.setSessionIdentifier(headerValueMap.get("sessionidentifier"));
			session.setLocation(headerValueMap.get("location"));
			session.setChannel(headerValueMap.get("channel"));
			session.setScope(headerValueMap.get("scope"));
			session.setStatus(headerValueMap.get("status"));
		}
		return session;
	}

	private Booking createBooking() {
		Booking booking = new Booking.BookingBuilder("SIYB5G", LoadflightSegments()).build();
		return booking;
	}

	private List<FlightSegment> LoadflightSegments() {
		List<FlightSegment> flightSegments = new ArrayList<FlightSegment>();
		List<FlightLeg> flightLegs = loadFlightLegs();
		FlightSegmentStatuses flightSegmentStatuses = new FlightSegmentStatuses();
		flightSegmentStatuses.setBookingStatus(BookingStatus.CONFIRMED);

		List<Carrier> carriers = loadCarriers();
		FlightSegment flightSegment = new FlightSegment.FlightSegmentBuilder(FlightSegmentType.INBOUND,
				flightSegmentStatuses, getOriginFlightSegment(), getDestinationFlightSegment(),
				new LocalDateTime(2004, 8, 25, 11, 20, 12), new LocalDateTime(2004, 8, 25, 11, 20, 12), flightLegs)
						.setIdentifier("fsIdentifier").setCarriers(carriers).build();
		flightSegments.add(flightSegment);
		return flightSegments;
	}

	private List<FlightLeg> loadFlightLegs() {
		List<FlightLeg> flightLegList = new ArrayList<>();

		FlightLeg flightLeg = new FlightLeg.FlightLegBuilder(getOriginFlightLeg(), getDestinationFlightLeg(),
				new LocalDateTime(2018, 10, 12, 04, 12, 0), new LocalDateTime(2018, 11, 11, 04, 17, 0)).build();
		flightLegList.add(flightLeg);
		return flightLegList;
	}

	private Origin getOriginFlightLeg() {
		Origin origin = new Origin();
		origin.setIdentifier("LHR");
		Gate gate = new Gate();
		gate.setNumber("6");
		origin.setGate(gate);
		origin.setTerminal("5");
		return origin;
	}

	private Origin getOriginFlightSegment() {
		Origin origin = new Origin();

		origin.setIdentifier("LHR");
		Gate gate = new Gate();
		gate.setNumber("5");
		origin.setGate(gate);
		origin.setTerminal("1");
		return origin;
	}

	private Destination getDestinationFlightSegment() {
		Destination destination = new Destination();
		destination.setTerminal("9");
		Gate gate = new Gate();
		gate.setNumber("7");
		destination.setGate(gate);
		destination.setIdentifier("BAH");
		return destination;
	}

	private Destination getDestinationFlightLeg() {
		Destination destination = new Destination();
		destination.setTerminal("5");
		Gate gate = new Gate();
		gate.setNumber("3");
		destination.setGate(gate);
		destination.setIdentifier("BAL");
		return destination;
	}

	private List<Carrier> loadCarriers() {
		List<Carrier> carrierList = new ArrayList<>();
		Carrier carrier = new Carrier();
		carrier.setCode("BA");
		carrier.setFlightNumber("124");
		carrier.setOperationalSuffix("OS");
		carrier.setType(CarrierType.MARKETING);
		carrierList.add(carrier);
		return carrierList;
	}

}
