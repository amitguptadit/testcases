package com.iag.business.booking.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.LocalDateTime;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.business.booking.repository.BookingRepository;
import com.iag.domain.model.Carrier;
import com.iag.domain.model.CarrierType;
import com.iag.domain.model.Destination;
import com.iag.domain.model.Gate;
import com.iag.domain.model.Origin;
import com.iag.domain.model.booking.Booking;
import com.iag.domain.model.booking.BookingSearchCriteria;
import com.iag.domain.model.flight.BookingStatus;
import com.iag.domain.model.flight.FlightLeg;
import com.iag.domain.model.flight.FlightSegment;
import com.iag.domain.model.flight.FlightSegmentStatuses;
import com.iag.domain.model.flight.FlightSegmentType;
import com.iag.domain.model.session.Session;

public class BookingServiceImplTest {
	@InjectMocks
	private BookingServiceImpl bookingService;
	@Mock
	private BookingRepository bookingRepository;
	private static final String BOOKING_IDENTIFIER = "BALHR1";
	private static final String BOOKING_IDENTIFIER1 = "BALHR2";

	private Session session;
	private BookingSearchCriteria bookingSearchCriteria;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		session = getSessionJson();
	}

	@Test
	public void shouldGetBookingTest() {
		bookingSearchCriteria = createBookingSearchCriteria(BOOKING_IDENTIFIER);
		Booking mockBooking = createBooking();
		Mockito.when(bookingRepository.getBooking(bookingSearchCriteria, session)).thenReturn(mockBooking);
		Booking booking = bookingService.getBooking(BOOKING_IDENTIFIER, session);

		assertNotNull(booking);
		assertEquals(mockBooking, booking);

		assertNotNull(booking);
		assertNotNull(booking.getIdentifier());

		booking.getFlightSegments().forEach((flightSegment) -> {
			assertNotNull(flightSegment.getType());
			assertNotNull(flightSegment.getStatus());

			assertNotNull(flightSegment.getOrigin().getIdentifier());
			assertNotNull(flightSegment.getOrigin().getTerminal());
			assertNotNull(flightSegment.getOrigin().getGate().getNumber());

			assertNotNull(flightSegment.getDestination().getIdentifier());
			assertNotNull(flightSegment.getDestination().getTerminal());
			assertNotNull(flightSegment.getDestination().getGate().getNumber());

			assertNotNull(flightSegment.getScheduledDepartureLocalDatetime());
			assertNotNull(flightSegment.getScheduledArrivalLocalDatetime());

			flightSegment.getFlightLegs().forEach((flightLeg) -> {
				assertNotNull(flightLeg.getOrigin().getIdentifier());
				assertNotNull(flightLeg.getOrigin().getTerminal());
				assertNotNull(flightLeg.getOrigin().getGate().getNumber());

				assertNotNull(flightLeg.getDestination().getIdentifier());
				assertNotNull(flightLeg.getDestination().getTerminal());
				assertNotNull(flightLeg.getDestination().getGate().getNumber());

				assertNotNull(flightLeg.getScheduledDepartureLocalDatetime());
				assertNotNull(flightLeg.getScheduledArrivalLocalDatetime());
			});
		});
	}

	@Test
	public void shouldGetBookingsTest() {
		bookingSearchCriteria = createBookingSearchCriteria(BOOKING_IDENTIFIER);
		List<Booking> mockBookings = createBookings();
		Mockito.when(bookingRepository.getBookings(bookingSearchCriteria, session)).thenReturn(mockBookings);
		List<Booking> bookings = bookingService.getBookings(bookingSearchCriteria, session);

		assertNotNull(bookings);
		assertEquals(mockBookings, bookings);

		assertNotNull(bookings);
		assertNotNull(bookings.get(0).getIdentifier());

		bookings.get(0).getFlightSegments().forEach((flightSegment) -> {
			assertNotNull(flightSegment.getType());
			assertNotNull(flightSegment.getStatus());

			assertNotNull(flightSegment.getOrigin().getIdentifier());
			assertNotNull(flightSegment.getOrigin().getTerminal());
			assertNotNull(flightSegment.getOrigin().getGate().getNumber());

			assertNotNull(flightSegment.getDestination().getIdentifier());
			assertNotNull(flightSegment.getDestination().getTerminal());
			assertNotNull(flightSegment.getDestination().getGate().getNumber());

			assertNotNull(flightSegment.getScheduledDepartureLocalDatetime());
			assertNotNull(flightSegment.getScheduledArrivalLocalDatetime());

			flightSegment.getFlightLegs().forEach((flightLeg) -> {
				assertNotNull(flightLeg.getOrigin().getIdentifier());
				assertNotNull(flightLeg.getOrigin().getTerminal());
				assertNotNull(flightLeg.getOrigin().getGate().getNumber());

				assertNotNull(flightLeg.getDestination().getIdentifier());
				assertNotNull(flightLeg.getDestination().getTerminal());
				assertNotNull(flightLeg.getDestination().getGate().getNumber());

				assertNotNull(flightLeg.getScheduledDepartureLocalDatetime());
				assertNotNull(flightLeg.getScheduledArrivalLocalDatetime());
			});
		});
	}

	private List<Booking> createBookings() {

		Booking booking = new Booking.BookingBuilder("SIYB5G", LoadflightSegments()).build();
		List<Booking> bookings = new ArrayList<Booking>();
		bookings.add(booking);
		return bookings;

	}

	@Test
	public void getBookingFlightSegmentTest() throws Exception {
		bookingSearchCriteria = createBookingSearchCriteria(BOOKING_IDENTIFIER1);
		Mockito.when(bookingRepository.getBooking(bookingSearchCriteria, session)).thenReturn(createBooking());
		Booking booking = bookingRepository.getBooking(bookingSearchCriteria, session);

		booking.getFlightSegments().forEach((flightSegment) -> {
			assertNotNull(flightSegment);
			assertNotNull(flightSegment.getType());
			assertNotNull(flightSegment.getStatus());
			assertNotNull(flightSegment.getScheduledDepartureLocalDatetime());
			assertNotNull(flightSegment.getScheduledArrivalLocalDatetime());
			assertNotNull(flightSegment.getOrigin());
			assertNotNull(flightSegment.getIdentifer());
			assertNotNull(flightSegment.getCarriers());
			assertNotNull(flightSegment.getDestination());
			assertNotNull(flightSegment.getFlightLegs());
		});
	}

	@Test
	public void getBookingFlightLegTest() throws Exception {
		bookingSearchCriteria = createBookingSearchCriteria(BOOKING_IDENTIFIER1);
		Mockito.when(bookingRepository.getBooking(bookingSearchCriteria, session)).thenReturn(createBooking());
		Booking booking = bookingRepository.getBooking(bookingSearchCriteria, session);

		booking.getFlightSegments().forEach((flightSegment) -> {
			flightSegment.getFlightLegs().forEach((flightLeg) -> {
				assertNotNull(flightLeg);
				assertNotNull(flightLeg.getScheduledDepartureLocalDatetime());
				assertNotNull(flightLeg.getScheduledArrivalLocalDatetime());
				assertNotNull(flightLeg.getOrigin());
				assertNotNull(flightLeg.getDestination());
			});
		});
	}

	@Test
	public void getBookingflightSegmentOriginTest() throws Exception {
		bookingSearchCriteria = createBookingSearchCriteria(BOOKING_IDENTIFIER1);
		Mockito.when(bookingRepository.getBooking(bookingSearchCriteria, session)).thenReturn(createBooking());
		Booking booking = bookingRepository.getBooking(bookingSearchCriteria, session);

		booking.getFlightSegments().forEach((flightSegment) -> {
			assertNotNull(flightSegment.getOrigin().getIdentifier());
			assertNotNull(flightSegment.getOrigin().getGate().getNumber());
		});
	}

	@Test
	public void getBookingflighSegmentDestinationTest() throws Exception {
		bookingSearchCriteria = createBookingSearchCriteria(BOOKING_IDENTIFIER1);
		Mockito.when(bookingRepository.getBooking(bookingSearchCriteria, session)).thenReturn(createBooking());
		Booking booking = bookingRepository.getBooking(bookingSearchCriteria, session);

		booking.getFlightSegments().forEach((flightSegment) -> {
			assertNotNull(flightSegment.getDestination().getIdentifier());
			assertNotNull(flightSegment.getDestination().getGate().getNumber());
		});
	}

	@Test
	public void getBookingflightLegOriginTest() throws Exception {
		bookingSearchCriteria = createBookingSearchCriteria(BOOKING_IDENTIFIER1);
		Mockito.when(bookingRepository.getBooking(bookingSearchCriteria, session)).thenReturn(createBooking());
		Booking booking = bookingRepository.getBooking(bookingSearchCriteria, session);

		booking.getFlightSegments().forEach((flightSegment) -> {
			flightSegment.getFlightLegs().forEach((flightLeg) -> {
				assertNotNull(flightLeg.getOrigin().getIdentifier());
				assertNotNull(flightLeg.getOrigin().getGate().getNumber());
			});
		});
	}

	@Test
	public void getBookingflightLegDestinationTest() throws Exception {
		bookingSearchCriteria = createBookingSearchCriteria(BOOKING_IDENTIFIER1);
		Mockito.when(bookingRepository.getBooking(bookingSearchCriteria, session)).thenReturn(createBooking());
		Booking booking = bookingRepository.getBooking(bookingSearchCriteria, session);

		booking.getFlightSegments().forEach((flightSegment) -> {
			flightSegment.getFlightLegs().forEach((flightLeg) -> {
				assertNotNull(flightLeg.getDestination().getIdentifier());
				assertNotNull(flightLeg.getDestination().getGate().getNumber());
			});
		});
	}

	@Test
	public void getBookingCarrierTest() throws Exception {
		bookingSearchCriteria = createBookingSearchCriteria(BOOKING_IDENTIFIER1);
		Mockito.when(bookingRepository.getBooking(bookingSearchCriteria, session)).thenReturn(createBooking());
		Booking booking = bookingRepository.getBooking(bookingSearchCriteria, session);

		booking.getFlightSegments().forEach((flightSegment) -> {
			flightSegment.getCarriers().forEach((carriers) -> {
				assertNotNull(carriers.getCode());
				assertNotNull(carriers.getFlightNumber());
				assertNotNull(carriers.getOperationalSuffix());
				assertNotNull(carriers.getType());
			});
		});
	}

	@After
	public void tearDown() throws Exception {
		bookingService = null;
		bookingRepository = null;
		session = null;
		bookingSearchCriteria = null;
	}

	private Session getSessionJson() {
		Session session = new Session();
		session.setChannel("channel");
		session.setLocation("location");
		session.setScope("scope");
		session.setSessionIdentifier("sessionIdentifier");
		session.setStatus("status");
		session.setTokenNumber("tokenNumber");
		return session;
	}

	private BookingSearchCriteria createBookingSearchCriteria(String bookingIdentifier) {
		BookingSearchCriteria bookingSearchCriteria = new BookingSearchCriteria();
		bookingSearchCriteria.setBookingIdentifier(bookingIdentifier);
		return bookingSearchCriteria;
	}

	private Booking createBooking() {
		Booking booking = new Booking.BookingBuilder("SIYB5G", LoadflightSegments()).build();
		return booking;
	}

	private List<FlightSegment> LoadflightSegments() {
		List<FlightSegment> flightSegments = new ArrayList<FlightSegment>();
		List<FlightLeg> flightLegs = loadFlightLegs();
		FlightSegmentStatuses flightSegmentStatuses = new FlightSegmentStatuses();
		flightSegmentStatuses.setBookingStatus(BookingStatus.CONFIRMED);

		List<Carrier> carriers = loadCarriers();
		FlightSegment flightSegment = new FlightSegment.FlightSegmentBuilder(FlightSegmentType.INBOUND,
				flightSegmentStatuses, getOriginFlightSegment(), getDestinationFlightSegment(),
				new LocalDateTime(2004, 8, 25, 11, 20, 12), new LocalDateTime(2004, 8, 25, 11, 20, 12), flightLegs)
						.setIdentifier("fsIdentifier").setCarriers(carriers).build();
		flightSegments.add(flightSegment);
		return flightSegments;
	}

	private List<FlightLeg> loadFlightLegs() {
		List<FlightLeg> flightLegList = new ArrayList<>();

		FlightLeg flightLeg = new FlightLeg.FlightLegBuilder(getOriginFlightLeg(), getDestinationFlightLeg(),
				new LocalDateTime(2018, 10, 12, 04, 12, 0), new LocalDateTime(2018, 11, 11, 04, 17, 0)).build();
		flightLegList.add(flightLeg);
		return flightLegList;
	}

	private Origin getOriginFlightLeg() {
		Origin origin = new Origin();
		origin.setIdentifier("LHR");
		Gate gate = new Gate();
		gate.setNumber("6");
		origin.setGate(gate);
		origin.setTerminal("5");
		return origin;
	}

	private Origin getOriginFlightSegment() {
		Origin origin = new Origin();

		origin.setIdentifier("LHR");
		Gate gate = new Gate();
		gate.setNumber("5");
		origin.setGate(gate);
		origin.setTerminal("1");
		return origin;
	}

	private Destination getDestinationFlightSegment() {
		Destination destination = new Destination();
		destination.setTerminal("9");
		Gate gate = new Gate();
		gate.setNumber("7");
		destination.setGate(gate);
		destination.setIdentifier("BAH");
		return destination;
	}

	private Destination getDestinationFlightLeg() {
		Destination destination = new Destination();
		destination.setTerminal("5");
		Gate gate = new Gate();
		gate.setNumber("3");
		destination.setGate(gate);
		destination.setIdentifier("BAL");
		return destination;
	}

	private List<Carrier> loadCarriers() {
		List<Carrier> carrierList = new ArrayList<>();
		Carrier carrier = new Carrier();
		carrier.setCode("BA");
		carrier.setFlightNumber("124");
		carrier.setOperationalSuffix("OS");
		carrier.setType(CarrierType.MARKETING);
		carrierList.add(carrier);
		return carrierList;
	}

}
