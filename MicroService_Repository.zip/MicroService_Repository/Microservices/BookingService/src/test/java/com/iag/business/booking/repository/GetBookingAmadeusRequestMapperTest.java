package com.iag.business.booking.repository;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

import com.amadeus.xml.ccprrq_17_1_1a.DCSIDCCPRIdentification;
import com.iag.domain.model.booking.BookingSearchCriteria;



public class GetBookingAmadeusRequestMapperTest {
	
	private GetBookingAmadeusRequestMapper getBookingAmadeusRequestMapper = null;
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		getBookingAmadeusRequestMapper = new  GetBookingAmadeusRequestMapper();
	}

	
	@Test 
	public void shouldGetAmadeusRequestMapperObject (){
		BookingSearchCriteria bookingSearchCriteria = new BookingSearchCriteria();
		bookingSearchCriteria.setBookingIdentifier("Abc123");
		DCSIDCCPRIdentification dCSIDCCPRIdentification = getBookingAmadeusRequestMapper.mapGetbookingRequest(bookingSearchCriteria);
		assertNotNull(dCSIDCCPRIdentification);
		assertEquals("Abc123", dCSIDCCPRIdentification.getSetOfCriteria().get(0).getRecordLocator().getReservation().getControlNumber());
	}
	
}
