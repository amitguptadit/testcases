package com.iag.business.booking.repository.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.amadeus.xml.ccprrr_17_1_1a.AdditionalProductDetailsTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.CodedAttributeInformationType208434C;
import com.amadeus.xml.ccprrr_17_1_1a.CodedAttributeType214203S;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel.LegLevel;
import com.amadeus.xml.ccprrr_17_1_1a.FacilityInformationType171568C;
import com.amadeus.xml.ccprrr_17_1_1a.FlightDetailsResponseType;
import com.amadeus.xml.ccprrr_17_1_1a.OriginAndDestinationDetailsTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.OutboundCarrierDetailsTypeI166697C;
import com.amadeus.xml.ccprrr_17_1_1a.OutboundFlightNumberDetailstypeI139968C;
import com.amadeus.xml.ccprrr_17_1_1a.ProductDateTimeTypeI166696C;
import com.amadeus.xml.ccprrr_17_1_1a.RelatedProductInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationDetailsType;
import com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.StationInformationTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.StatusDetailsTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.StatusType144223S;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeType18904C;
import com.amadeus.xml.ccprrr_17_1_1a.TerminalLocationType116626S;
import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.proxy.ConfigurationInfrastructureServiceProxy;
import com.iag.domain.model.Carrier;
import com.iag.domain.model.booking.Booking;
import com.iag.domain.model.flight.FlightLeg;
import com.iag.domain.model.flight.FlightSegment;
import com.iag.domain.model.flight.FlightSegmentStatuses;
import com.iag.domain.model.flight.FlightSegmentType;

public class BookingResponseMapperTest {
	@InjectMocks
	private BookingResponseMapper mapper;
	@Mock
	private ConfigurationInfrastructureServiceProxy serviceProxy;

	private static final String BOOKING_IDENTIFIER = "SIYB5G";
	private static final String ATTRIBUTE_TYPE_RFI = "RFI";
	private static final String ATTRIBUTE_TYPE_INB = "INB";
	private static final String ATTRIBUTE_TYPE_ONW = "ONW";
	private static final String ATTRIBUTE_TYPE_DUMMY = "DUMMY";
	private static final String STATUS_INFORMATION_INDOCATOR_DUMMY = "DUMMY";
	private static final String FLIGHT_SEGMENT_TYPE_RETURN = "RETURN";
	private static final String FLIGHT_SEGMENT_TYPE_INBOUND = "INBOUND";
	private static final String FLIGHT_SEGMENT_TYPE_ONWARD = "ONWARD";
	private static final String FLIGHT_SEGMENT_TYPE_OUTBOUND = "OUTBOUND";
	private static final String FLIGHT_SEGMENT_STATUS_CONFIRMED = "CONFIRMED";
	private static final String FLIGHT_SEGMENT_STATUS_UNCONFIRMED = "UNCONFIRMED";
	private static final String GATE_NO_NA = "NA";
	private static final String MARKETING = "MARKETING";
	private static final String OPERATING = "OPERATING";
	private static final String STATUS_CODE_CONFIRM_CONSTANTS = "HK,TK,HL,SA,KK,KL,TL";
	private static final String HK = "HK";
	private static final String TK = "TK";
	private static final String HL = "HL";
	private static final String SA = "SA";
	private static final String KK = "KK";
	private static final String KL = "KL";
	private static final String TL = "TL";
	private static final String FLIGHT_SEGMENT_ORIGIN_TERMNINAL = "5";
	private static final String FLIGHT_SEGMENT_ORIGIN_IDENTIFIER = "WUX";
	private static final String FLIGHT_SEGMENT_DESTINATION_TERMNINAL = "9";
	private static final String FLIGHT_SEGMENT_DESTINATION_IDENTIFIER = "NTG";

	private static final String FLIGHT_LEG_ORIGIN_TERMNINAL = "5";
	private static final String FLIGHT_LEG_ORIGIN_IDENTIFIER = "WUX";
	private static final String FLIGHT_LEG_ORIGIN_GATE_NO = "1";
	private static final String FLIGHT_LEG_DESTINATION_TERMNINAL = "9";
	private static final String FLIGHT_LEG_DESTINATION_IDENTIFIER = "NTG";
	private static final String CARRIER_CODE = "AS";
	private static final String FLIGHT_NO = "203";
	private static final String OPERATIONAL_SUFFIX = "111";

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mapper = new BookingResponseMapper();
		ReflectionTestUtils.setField(mapper, "serviceProxy", serviceProxy);
		Mockito.when(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE, BookingServiceConstants.ATTRIBUTE_TYPE_RETURN))
				.thenReturn(ATTRIBUTE_TYPE_RFI);
		Mockito.when(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE,BookingServiceConstants.ATTRIBUTE_TYPE_INBOUND))
				.thenReturn(ATTRIBUTE_TYPE_INB);
		Mockito.when(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE,BookingServiceConstants.ATTRIBUTE_TYPE_ONWARD))
				.thenReturn(ATTRIBUTE_TYPE_ONW);
		Mockito.when(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE,BookingServiceConstants.FLIGHT_SEGMENT_STATUS_CONFIRM))
				.thenReturn(STATUS_CODE_CONFIRM_CONSTANTS);
		Mockito.when(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE,BookingServiceConstants.FLIGHT_LEG_ARRIVAL_STA))
				.thenReturn("STA");
		Mockito.when(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE,BookingServiceConstants.FLIGHT_LEG_DEPARTURE_STD))
				.thenReturn("STD");
		Mockito.when(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE,BookingServiceConstants.GATE_NO_NA)).thenReturn("NA");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@Test
	public void shouldMapMandatoryFieldsTest() {
		Booking booking = mapper.map(amadeusResponse());
		assertNotNull(booking);
		assertNotNull(booking.getIdentifier());

		for (FlightSegment flightSegment : booking.getFlightSegments()) {
			
			
			assertNotNull(flightSegment.getType());
			assertEquals(FLIGHT_SEGMENT_TYPE_OUTBOUND, flightSegment.getType().name());
			assertNotNull(flightSegment.getStatus());
			assertEquals(FLIGHT_SEGMENT_STATUS_CONFIRMED, flightSegment.getStatus().getBookingStatus().toString());

			assertNotNull(flightSegment.getOrigin().getIdentifier());
			assertEquals(FLIGHT_SEGMENT_ORIGIN_IDENTIFIER, flightSegment.getOrigin().getIdentifier());

			assertNotNull(flightSegment.getOrigin().getTerminal());
			assertEquals(FLIGHT_SEGMENT_ORIGIN_TERMNINAL, flightSegment.getOrigin().getTerminal());
			assertNotNull(flightSegment.getOrigin().getGate().getNumber());

			assertNotNull(flightSegment.getDestination().getIdentifier());
			assertEquals(FLIGHT_SEGMENT_DESTINATION_IDENTIFIER, flightSegment.getDestination().getIdentifier());
			assertNotNull(flightSegment.getDestination().getTerminal());
			assertEquals(FLIGHT_SEGMENT_DESTINATION_TERMNINAL, flightSegment.getDestination().getTerminal());

			assertNotNull(flightSegment.getScheduledDepartureLocalDatetime());
			assertNotNull(flightSegment.getScheduledArrivalLocalDatetime());

			for (Carrier carrier : flightSegment.getCarriers()) {
			
				assertNotNull(carrier.getCode());
				assertEquals(CARRIER_CODE, carrier.getCode());
				assertNotNull(carrier.getFlightNumber());
				assertEquals(FLIGHT_NO, carrier.getFlightNumber());
				assertNotNull(carrier.getOperationalSuffix());
				assertEquals(OPERATIONAL_SUFFIX, carrier.getOperationalSuffix());
			}
			
			for (FlightLeg flightLeg : flightSegment.getFlightLegs()) {

				assertNotNull(flightLeg.getOrigin().getIdentifier());
				assertEquals(FLIGHT_LEG_ORIGIN_IDENTIFIER, flightLeg.getOrigin().getIdentifier());
				assertNotNull(flightLeg.getOrigin().getTerminal());
				assertEquals(FLIGHT_LEG_ORIGIN_TERMNINAL, flightLeg.getOrigin().getTerminal());
				assertNotNull(flightLeg.getOrigin().getGate().getNumber());
				assertEquals(FLIGHT_LEG_ORIGIN_GATE_NO, flightLeg.getOrigin().getGate().getNumber());

				assertNotNull(flightLeg.getDestination().getIdentifier());
				assertEquals(FLIGHT_LEG_DESTINATION_IDENTIFIER, flightLeg.getDestination().getIdentifier());
				assertNotNull(flightLeg.getDestination().getTerminal());
				assertEquals(FLIGHT_LEG_DESTINATION_TERMNINAL, flightLeg.getDestination().getTerminal());
				

				assertNotNull(flightLeg.getScheduledDepartureLocalDatetime());
				assertNotNull(flightLeg.getScheduledArrivalLocalDatetime());
			}
		}

		assertEquals(1, booking.getFlightSegments().size());
		assertEquals(1, booking.getFlightSegments().get(0).getFlightLegs().size());
		assertNotNull(booking.getFlightSegments().size());
		assertNotNull(booking.getFlightSegments().get(0).getFlightLegs().size());
	}
	
	
	@Test
	public void shouldMapsMandatoryFieldsTest() {
		List<Booking> bookings = mapper.maps(amadeusResponse());
		assertNotNull(bookings);
		assertNotNull(bookings.get(0).getIdentifier());

		for (FlightSegment flightSegment : bookings.get(0).getFlightSegments()) {
		
		
			assertNotNull(flightSegment.getType());
			assertEquals(FLIGHT_SEGMENT_TYPE_OUTBOUND, flightSegment.getType().name());
			assertNotNull(flightSegment.getStatus());
			assertEquals(FLIGHT_SEGMENT_STATUS_CONFIRMED, flightSegment.getStatus().getBookingStatus().toString());

			assertNotNull(flightSegment.getOrigin().getIdentifier());
			assertEquals(FLIGHT_SEGMENT_ORIGIN_IDENTIFIER, flightSegment.getOrigin().getIdentifier());

			assertNotNull(flightSegment.getOrigin().getTerminal());
			assertEquals(FLIGHT_SEGMENT_ORIGIN_TERMNINAL, flightSegment.getOrigin().getTerminal());
			assertNotNull(flightSegment.getOrigin().getGate().getNumber());

			assertNotNull(flightSegment.getDestination().getIdentifier());
			assertEquals(FLIGHT_SEGMENT_DESTINATION_IDENTIFIER, flightSegment.getDestination().getIdentifier());
			assertNotNull(flightSegment.getDestination().getTerminal());
			assertEquals(FLIGHT_SEGMENT_DESTINATION_TERMNINAL, flightSegment.getDestination().getTerminal());

			assertNotNull(flightSegment.getScheduledDepartureLocalDatetime());
			assertNotNull(flightSegment.getScheduledArrivalLocalDatetime());

			for (Carrier carrier : flightSegment.getCarriers()) {
			
				assertNotNull(carrier.getCode());
				assertEquals(CARRIER_CODE, carrier.getCode());
				assertNotNull(carrier.getFlightNumber());
				assertEquals(FLIGHT_NO, carrier.getFlightNumber());
				assertNotNull(carrier.getOperationalSuffix());
				assertEquals(OPERATIONAL_SUFFIX, carrier.getOperationalSuffix());
			}
			
			for (FlightLeg flightLeg : flightSegment.getFlightLegs()) {

				assertNotNull(flightLeg.getOrigin().getIdentifier());
				assertEquals(FLIGHT_LEG_ORIGIN_IDENTIFIER, flightLeg.getOrigin().getIdentifier());
				assertNotNull(flightLeg.getOrigin().getTerminal());
				assertEquals(FLIGHT_LEG_ORIGIN_TERMNINAL, flightLeg.getOrigin().getTerminal());
				assertNotNull(flightLeg.getOrigin().getGate().getNumber());
				assertEquals(FLIGHT_LEG_ORIGIN_GATE_NO, flightLeg.getOrigin().getGate().getNumber());

				assertNotNull(flightLeg.getDestination().getIdentifier());
				assertEquals(FLIGHT_LEG_DESTINATION_IDENTIFIER, flightLeg.getDestination().getIdentifier());
				assertNotNull(flightLeg.getDestination().getTerminal());
				assertEquals(FLIGHT_LEG_DESTINATION_TERMNINAL, flightLeg.getDestination().getTerminal());
				

				assertNotNull(flightLeg.getScheduledDepartureLocalDatetime());
				assertNotNull(flightLeg.getScheduledArrivalLocalDatetime());
			}
		}

		assertEquals(1, bookings.get(0).getFlightSegments().size());
		assertEquals(1, bookings.get(0).getFlightSegments().get(0).getFlightLegs().size());
		assertNotNull(bookings.get(0).getFlightSegments().size());
		assertNotNull(bookings.get(0).getFlightSegments().get(0).getFlightLegs().size());
	}

	@Test
	public void shouldMapWhenCustomeLevelisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.setCustomerLevel(null);
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenProductLevelisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.setProductLevel(null);
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenRecordLocatorisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.setRecordLocator(null);
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenReservationisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getRecordLocator().setReservation(null);
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenControlNumberisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getRecordLocator().getReservation().setControlNumber(null);
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenProductLevelIndicatorsisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.setProductLevelIndicators(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenAttributeDetailsisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getProductLevelIndicators().setAttributeDetails(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenAttributeTypeisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getProductLevelIndicators().getAttributeDetails().forEach((attributeDetails) -> {
					attributeDetails.setAttributeType(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldmapRETURNinFlightSegmentTypeWhenAttributeTypeisRFI() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getProductLevelIndicators().getAttributeDetails().forEach((attributeDetails) -> {
					attributeDetails.setAttributeType(ATTRIBUTE_TYPE_RFI);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		booking.getFlightSegments().forEach((flightSegment) -> {
			FlightSegmentType flightSegmentType = flightSegment.getType();
			assertNotNull(flightSegmentType);
			assertEquals(FLIGHT_SEGMENT_TYPE_RETURN, flightSegmentType.name());
		});
	}

	@Test
	public void shouldmapRETURNinFlightSegmentTypeWhenAttributeTypeisINB() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getProductLevelIndicators().getAttributeDetails().forEach((attributeDetails) -> {
					attributeDetails.setAttributeType(ATTRIBUTE_TYPE_INB);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		booking.getFlightSegments().forEach((flightSegment) -> {
			FlightSegmentType flightSegmentType = flightSegment.getType();
			assertNotNull(flightSegmentType);
			assertEquals(FLIGHT_SEGMENT_TYPE_INBOUND, flightSegmentType.name());
		});
	}

	@Test
	public void shouldmapRETURNinFlightSegmentTypeWhenAttributeTypeisONW() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getProductLevelIndicators().getAttributeDetails().forEach((attributeDetails) -> {
					attributeDetails.setAttributeType(ATTRIBUTE_TYPE_ONW);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		booking.getFlightSegments().forEach((flightSegment) -> {
			FlightSegmentType flightSegmentType = flightSegment.getType();
			assertNotNull(flightSegmentType);
			assertEquals(FLIGHT_SEGMENT_TYPE_ONWARD, flightSegmentType.name());
		});
	}

	@Test
	public void shouldmapRETURNinFlightSegmentTypeWhenAttributeTypeisDUMMY() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getProductLevelIndicators().getAttributeDetails().forEach((attributeDetails) -> {
					attributeDetails.setAttributeType(ATTRIBUTE_TYPE_DUMMY);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		booking.getFlightSegments().forEach((flightSegment) -> {
			FlightSegmentType flightSegmentType = flightSegment.getType();
			assertNotNull(flightSegmentType);
			assertEquals(FLIGHT_SEGMENT_TYPE_OUTBOUND, flightSegmentType.name());
		});
	}

	/*@Test
	public void shouldMapWhenFlightStatusesisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.setFlightStatuses(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}*/

	@Test
	public void shouldMapWhenStatusInformationisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getFlightStatuses().setStatusInformation(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	/*@Test
	public void shouldMapWhenIndicatorisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getFlightStatuses().getStatusInformation().forEach((statusInformation) -> {
					statusInformation.setIndicator(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}*/

	@Test
	public void shouldMapWhenActionisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getFlightStatuses().getStatusInformation().forEach((statusInformation) -> {
					statusInformation.setAction(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	/*@Test
	public void shouldMapWhenBookingStatusDetailsisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.setBookingStatusDetails(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}*/

	/*@Test
	public void shouldMapWhenStatusCodeisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getBookingStatusDetails().setStatusCode(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}*/

	@Test
	public void shouldMapFlightSegmentStatusCONFIRMwhenStatusCodeIsHK() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getBookingStatusDetails().setStatusCode(HK);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		booking.getFlightSegments().forEach((flightSegments) -> {
			FlightSegmentStatuses flightSegmentStatus = flightSegments.getStatus();
			assertNotNull(flightSegmentStatus);
			assertEquals(FLIGHT_SEGMENT_STATUS_CONFIRMED, flightSegmentStatus.getBookingStatus().toString());
		});
	}

	@Test
	public void shouldMapFlightSegmentStatusCONFIRMwhenStatusCodeIsTK() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getBookingStatusDetails().setStatusCode(TK);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		booking.getFlightSegments().forEach((flightSegments) -> {
			FlightSegmentStatuses flightSegmentStatus = flightSegments.getStatus();
			assertNotNull(flightSegmentStatus);
			assertEquals(FLIGHT_SEGMENT_STATUS_CONFIRMED, flightSegmentStatus.getBookingStatus().toString());
		});
	}

	@Test
	public void shouldMapFlightSegmentStatusCONFIRMwhenStatusCodeIsHL() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getBookingStatusDetails().setStatusCode(HL);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		booking.getFlightSegments().forEach((flightSegments) -> {
			FlightSegmentStatuses flightSegmentStatus = flightSegments.getStatus();
			assertNotNull(flightSegmentStatus);
			assertEquals(FLIGHT_SEGMENT_STATUS_CONFIRMED, flightSegmentStatus.getBookingStatus().toString());
		});

	}

	@Test
	public void shouldMapFlightSegmentStatusCONFIRMwhenStatusCodeIsSA() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getBookingStatusDetails().setStatusCode(SA);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		booking.getFlightSegments().forEach((flightSegments) -> {
			FlightSegmentStatuses flightSegmentStatus = flightSegments.getStatus();
			assertNotNull(flightSegmentStatus);
			assertEquals(FLIGHT_SEGMENT_STATUS_CONFIRMED, flightSegmentStatus.getBookingStatus().toString());
		});

	}

	@Test
	public void shouldMapFlightSegmentStatusCONFIRMwhenStatusCodeIsKK() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getBookingStatusDetails().setStatusCode(KK);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		booking.getFlightSegments().forEach((flightSegments) -> {
			FlightSegmentStatuses flightSegmentStatus = flightSegments.getStatus();
			assertNotNull(flightSegmentStatus);
			assertEquals(FLIGHT_SEGMENT_STATUS_CONFIRMED, flightSegmentStatus.getBookingStatus().toString());
		});

	}

	@Test
	public void shouldMapFlightSegmentStatusCONFIRMwhenStatusCodeIsKL() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getBookingStatusDetails().setStatusCode(KL);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		booking.getFlightSegments().forEach((flightSegments) -> {
			FlightSegmentStatuses flightSegmentStatus = flightSegments.getStatus();
			assertNotNull(flightSegmentStatus);
			assertEquals(FLIGHT_SEGMENT_STATUS_CONFIRMED, flightSegmentStatus.getBookingStatus().toString());
		});

	}

	@Test
	public void shouldMapFlightSegmentStatusCONFIRMwhenStatusCodeIsTL() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getBookingStatusDetails().setStatusCode(TL);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		booking.getFlightSegments().forEach((flightSegments) -> {
			FlightSegmentStatuses flightSegmentStatus = flightSegments.getStatus();
			assertNotNull(flightSegmentStatus);
			assertEquals(FLIGHT_SEGMENT_STATUS_CONFIRMED, flightSegmentStatus.getBookingStatus().toString());
		});

	}

	@Test
	public void shouldMapFlightSegmentStatusUNCONFIRMED() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getBookingStatusDetails().setStatusCode(STATUS_INFORMATION_INDOCATOR_DUMMY);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		booking.getFlightSegments().forEach((flightSegments) -> {
			FlightSegmentStatuses flightSegmentStatus = flightSegments.getStatus();
			assertNotNull(flightSegmentStatus);
			assertEquals(FLIGHT_SEGMENT_STATUS_UNCONFIRMED, flightSegmentStatus.getBookingStatus().toString());
		});

	}

	@Test
	public void shouldMapWhenOperatingFlightDetailsisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.setOperatingFlightDetails(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	/*
	 * @Test public void shouldMapWhenBoardPointisNull() throws Exception {
	 * DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
	 * amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
	 * customerLevel.getProductLevel().forEach((productLevel) -> {
	 * productLevel.getOperatingFlightDetails().setBoardPoint(null); }); });
	 * Booking booking = mapper.map(amadeusResponse); assertNotNull(booking); }
	 */

	@Test
	public void shouldMapWhenLegLevelisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.setLegLevel(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenAdditionalProductDetailsisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.setAdditionalProductDetails(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenDepartureStationInfoisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getAdditionalProductDetails().setDepartureStationInfo(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenDepartureStationInfoTerminalisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getAdditionalProductDetails().getDepartureStationInfo().setTerminal(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenDepartureGateisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.setDepartureGate(null);

			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenFacilitiyDetailsisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getDepartureGate().forEach((departureGate) -> {
					departureGate.setFacilityDetails(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenDeparturGateIdentifierisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getDepartureGate().forEach((departureGate) -> {
					departureGate.getFacilityDetails().setIdentifier(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenOffPointisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().setOffPoint(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenArrivalStationInfoisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getAdditionalProductDetails().setArrivalStationInfo(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenArrivalStationInfoTerminalisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getAdditionalProductDetails().getArrivalStationInfo().setTerminal(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	

	@Test
	public void shouldMapWhenDateAndTimeRangeisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().setDateAndTimeRange(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenDepartureDateisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().getDateAndTimeRange().forEach((dateAndTimeRange) -> {
					dateAndTimeRange.setDepartureDate(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenDepartureTimeisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().getDateAndTimeRange().forEach((dateAndTimeRange) -> {
					dateAndTimeRange.setDepartureTime(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenArrivalDateisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().getDateAndTimeRange().forEach((dateAndTimeRange) -> {
					dateAndTimeRange.setArrivalDate(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenArrivalTimeisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().getDateAndTimeRange().forEach((dateAndTimeRange) -> {
					dateAndTimeRange.setArrivalTime(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenOperationalFlightDetailsDepartureDateisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().setDepartureDate(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenOperationalFlightDetailsArrivalDateisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().setArrivalDate(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenCarrierDetailsisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().setCarrierDetails(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenMarketingCarrierisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().getCarrierDetails().setMarketingCarrier(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenOtherCarrierisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().getCarrierDetails().setOtherCarrier(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldSetMARKETINGinCArrierTypewhenmarketingCarrierIsNotNull() {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		Booking booking = mapper.map(amadeusResponse);

		booking.getFlightSegments().forEach((flightSegment) -> {
			flightSegment.getCarriers().forEach((carriers) -> {
				assertNotNull(carriers.getType());
				assertEquals(MARKETING, carriers.getType().name());
			});
		});

	}

	@Test
	public void shouldSetOPERATINGinCArrierTypewhenmarketingCarrierIsNull() {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().getCarrierDetails().setMarketingCarrier(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);

		booking.getFlightSegments().forEach((flightSegment) -> {
			flightSegment.getCarriers().forEach((carriers) -> {
				assertNotNull(carriers.getType());
				assertEquals(OPERATING, carriers.getType().name());
			});
		});

	}

	@Test
	public void shouldMapWhenFlightDetailsisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().setFlightDetails(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenFlightNumberisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().getFlightDetails().setFlightNumber(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenOperationalSuffixisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getOperatingFlightDetails().getFlightDetails().setOperationalSuffix(null);
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	/*@Test
	public void shouldMapWhenLegRoutingisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.setLegRouting(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}*/

	/*@Test
	public void shouldMapWhenLegRoutingOriginisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getLegRouting().setOrigin(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}*/

	/*@Test
	public void shouldMapWhenLegRoutingDestinationisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getLegRouting().setDestination(null);
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}*/

	

	@Test
	public void shouldMapWhenLegTimesisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.setLegTimes(null);
				});
			});
		});
		mapper.map(amadeusResponse);
	}

	@Test
	public void shouldMapWhenDateTimeisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getLegTimes().forEach((legTimes) -> {
						legTimes.setDateTime(null);
					});
				});
			});
		});
		mapper.map(amadeusResponse);
	}

	@Test
	public void shouldMapWhenYearisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getLegTimes().forEach((legTimes) -> {
						legTimes.getDateTime().setYear(null);
					});
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenMonthisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getLegTimes().forEach((legTimes) -> {
						legTimes.getDateTime().setMonth(null);
					});
				});
			});
		});
		mapper.map(amadeusResponse);
	}

	@Test
	public void shouldMapWhenDayisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getLegTimes().forEach((legTimes) -> {
						legTimes.getDateTime().setDay(null);
					});
				});
			});
		});
		mapper.map(amadeusResponse);
	}

	@Test
	public void shouldMapWhenHourisNull() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getLegTimes().forEach((legTimes) -> {
						legTimes.getDateTime().setHour(null);
					});
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenMinutsisNull() throws Exception {

		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getLegTimes().forEach((legTimes) -> {
						legTimes.getDateTime().setMinutes(null);
					});
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	@Test
	public void shouldMapWhenSecondisNotZero() throws Exception {
		DCSIDCCPRIdentificationReply amadeusResponse = amadeusResponse();
		amadeusResponse.getCustomerLevel().forEach((customerLevel) -> {
			customerLevel.getProductLevel().forEach((productLevel) -> {
				productLevel.getLegLevel().forEach((legLevel) -> {
					legLevel.getLegTimes().forEach((legTimes) -> {
						legTimes.getDateTime().setSeconds(BigInteger.ZERO);
					});
				});
			});
		});
		Booking booking = mapper.map(amadeusResponse);
		assertNotNull(booking);
	}

	private DCSIDCCPRIdentificationReply amadeusResponse() {
		DCSIDCCPRIdentificationReply amadeusResponse = new DCSIDCCPRIdentificationReply();

		List<CustomerLevel> customerLevelList = new ArrayList<>();
		amadeusResponse.setCustomerLevel(customerLevelList);
		
			CustomerLevel customerLevel1 = new CustomerLevel();
			customerLevelList.add(customerLevel1);
			List<ProductLevel> productLevelList = new ArrayList<>();
			ProductLevel productLevel = new ProductLevel();
			productLevelList.add(productLevel);

			ReservationControlInformationType recordLocator2 = new ReservationControlInformationType();
			customerLevel1.setRecordLocator(recordLocator2);
			ReservationControlInformationDetailsType reservation2 = new ReservationControlInformationDetailsType();
			recordLocator2.setReservation(reservation2);
			reservation2.setControlNumber(BOOKING_IDENTIFIER);
			
			RelatedProductInformationType bookingStatusDetails = new RelatedProductInformationType();
			productLevel.setBookingStatusDetails(bookingStatusDetails);
			bookingStatusDetails.setStatusCode("HK");
			CodedAttributeType214203S productLevelIndicators = new CodedAttributeType214203S();
			productLevel.setProductLevelIndicators(productLevelIndicators);
			customerLevel1.setProductLevel(productLevelList);
			List<CodedAttributeInformationType208434C> attributeDetailsList = new ArrayList<>();
			CodedAttributeInformationType208434C codedAttributeInformationType208434C = new CodedAttributeInformationType208434C();
			codedAttributeInformationType208434C.setAttributeType("DUMMY");
			attributeDetailsList.add(codedAttributeInformationType208434C);
			productLevelIndicators.setAttributeDetails(attributeDetailsList);

			StatusType144223S flightStatuses = new StatusType144223S();
			List<StatusDetailsTypeI> statusInformationList = new ArrayList<>();
			StatusDetailsTypeI statusDetailsTypeI = new StatusDetailsTypeI();
			statusDetailsTypeI.setIndicator("FDS");
			statusDetailsTypeI.setAction("FDL2");
			statusInformationList.add(statusDetailsTypeI);
			flightStatuses.setStatusInformation(statusInformationList);
			productLevel.setFlightStatuses(flightStatuses);
			FlightDetailsResponseType operatingFlightDetails = new FlightDetailsResponseType();

			operatingFlightDetails.setBoardPoint("WUX");

			operatingFlightDetails.setDepartureDate("20181022");
			operatingFlightDetails.setArrivalDate("20181022");

			operatingFlightDetails.setBoardPoint("WUX");

			operatingFlightDetails.setDepartureDate("20181022");
			operatingFlightDetails.setArrivalDate("20181022");

			productLevel.setOperatingFlightDetails(operatingFlightDetails);

			List<LegLevel> legLevelList = new ArrayList<>();
			LegLevel legLevel = new LegLevel();

			List<StructuredDateTimeInformationType> legTimes = legLevel.getLegTimes();

			StructuredDateTimeInformationType structuredDateTimeInformationType = new StructuredDateTimeInformationType();
			legTimes.add(structuredDateTimeInformationType);
			structuredDateTimeInformationType.setBusinessSemantic("STD");
			StructuredDateTimeType18904C dateTime = new StructuredDateTimeType18904C();
			structuredDateTimeInformationType.setDateTime(dateTime);
			dateTime.setYear("2018");
			dateTime.setMonth("4");
			dateTime.setDay("16");
			dateTime.setHour("9");
			dateTime.setMinutes("52");
			dateTime.setSeconds(BigInteger.valueOf(50));

			StructuredDateTimeInformationType structuredDateTimeInformationType1 = new StructuredDateTimeInformationType();
			legTimes.add(structuredDateTimeInformationType1);
			structuredDateTimeInformationType1.setBusinessSemantic("STA");
			StructuredDateTimeType18904C dateTime1 = new StructuredDateTimeType18904C();
			structuredDateTimeInformationType1.setDateTime(dateTime1);
			dateTime1.setYear("2018");
			dateTime1.setMonth("4");
			dateTime1.setDay("16");
			dateTime1.setHour("9");
			dateTime1.setMinutes("52");
			dateTime1.setSeconds(BigInteger.valueOf(50));

			legLevelList.add(legLevel);
			AdditionalProductDetailsTypeI additionalProductDetails = new AdditionalProductDetailsTypeI();
			legLevel.setAdditionalProductDetails(additionalProductDetails);
			StationInformationTypeI departureStationInfo = new StationInformationTypeI();
			departureStationInfo.setTerminal("5");
			additionalProductDetails.setDepartureStationInfo(departureStationInfo);
			productLevel.setLegLevel(legLevelList);

			List<TerminalLocationType116626S> departureGate = new ArrayList<>();
			TerminalLocationType116626S terminalLocationType116626S = new TerminalLocationType116626S();
			departureGate.add(terminalLocationType116626S);
			FacilityInformationType171568C facilityDetails = new FacilityInformationType171568C();
			facilityDetails.setIdentifier("1");
			terminalLocationType116626S.setFacilityDetails(facilityDetails);
			productLevel.setDepartureGate(departureGate);
			StationInformationTypeI arrivalStationInfo = new StationInformationTypeI();
			arrivalStationInfo.setTerminal("9");
			additionalProductDetails.setArrivalStationInfo(arrivalStationInfo);

			List<ProductDateTimeTypeI166696C> dateAndTimeRange = new ArrayList<>();
			ProductDateTimeTypeI166696C productDateTimeTypeI166696C = new ProductDateTimeTypeI166696C();
			productDateTimeTypeI166696C.setDepartureDate("2018-04-08");
			productDateTimeTypeI166696C.setDepartureTime("1913");
			productDateTimeTypeI166696C.setArrivalDate("2018-04-08");
			productDateTimeTypeI166696C.setArrivalTime("2040");
			dateAndTimeRange.add(productDateTimeTypeI166696C);
			operatingFlightDetails.setDateAndTimeRange(dateAndTimeRange);

			OutboundCarrierDetailsTypeI166697C carrierDetails = new OutboundCarrierDetailsTypeI166697C();
			carrierDetails.setMarketingCarrier("AS");
			carrierDetails.setOtherCarrier("BA");
			operatingFlightDetails.setCarrierDetails(carrierDetails);

			OutboundFlightNumberDetailstypeI139968C flightDetails = new OutboundFlightNumberDetailstypeI139968C();
			flightDetails.setFlightNumber("203");
			flightDetails.setOperationalSuffix("111");
			operatingFlightDetails.setFlightDetails(flightDetails);

			OriginAndDestinationDetailsTypeI legRouting = new OriginAndDestinationDetailsTypeI();
			legRouting.setOrigin("WUX");
			legRouting.setDestination("NTG");
			legLevel.setLegRouting(legRouting);
			operatingFlightDetails.setOffPoint("NTG");

		
		return amadeusResponse;
	}

}
