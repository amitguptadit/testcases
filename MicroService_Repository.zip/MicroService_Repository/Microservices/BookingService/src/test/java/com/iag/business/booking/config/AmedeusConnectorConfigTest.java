package com.iag.business.booking.config;

import static org.junit.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.proxy.ConfigurationInfrastructureServiceProxy;

public class AmedeusConnectorConfigTest {

	AmedeusConnectorConfig amedeusConnectorConfig;

	@Mock
	WebServiceTemplate amadeusWebServiceTemplate;

	@Mock
	Jaxb2Marshaller amadeusMarshaller;

	@Mock
	Jaxb2Marshaller amadeusUnMarshaller;

	@Mock
	ConfigurationInfrastructureServiceProxy serviceProxy;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);

		amedeusConnectorConfig = new AmedeusConnectorConfig();
		ReflectionTestUtils.setField(amedeusConnectorConfig, "serviceProxy", serviceProxy);
	}

	@Test
	public void shouldTestAmadeusWebServiceTemplate() throws Exception {
		
		
		Mockito.when(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUS_NAMESPACE, BookingServiceConstants.AMADEUS_GATEWAY_WEBURL))
		.thenReturn("http://BAaccess.test.webservices.1a.amadeus.com");
		WebServiceTemplate webServiceTemplate = amedeusConnectorConfig.amadeusWebServiceTemplate(amadeusMarshaller,
				amadeusUnMarshaller);
		assertNotNull(webServiceTemplate);
		Assert.assertEquals(webServiceTemplate.getDefaultUri(), "http://BAaccess.test.webservices.1a.amadeus.com");
	}

	@Test
	public void shouldGetAmadeusMarshaller() throws Exception {
		Mockito.when(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUS_NAMESPACE, BookingServiceConstants.AMADEUS_RESPONSE_MARSHALLER))
				.thenReturn("com.amadeus.xml.ccprrq_17_1_1a");

		Jaxb2Marshaller amadeusMarshaller = amedeusConnectorConfig.amadeusMarshaller();
		assertNotNull(amadeusMarshaller);
		assertNotNull(amadeusMarshaller.getContextPath());
	}

	@Test
	public void shouldGetAmadeusUnMarshaller() throws Exception {
		Mockito.when(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUS_NAMESPACE, BookingServiceConstants.AMADEUS_RESPONSE_UNMARSHALLER))
				.thenReturn("com.amadeus.xml.ccprrr_17_1_1a");
		Jaxb2Marshaller amadeusUnMarshaller = amedeusConnectorConfig.amadeusUnMarshaller();
		assertNotNull(amadeusUnMarshaller);
		assertNotNull(amadeusUnMarshaller.getContextPath());
	}

}
