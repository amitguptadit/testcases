package com.iag.business.booking.validation;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.google.common.collect.Lists;
import com.iag.application.exception.ValidationServiceException;
import com.iag.business.booking.error.BookingErrorCode;
import com.iag.business.booking.error.matcher.CustomValidationServiceExceptionMatcher;
import com.iag.business.booking.exception.ValidationServiceExceptionGenerator;

public class BookingServiceValidatorTest {

	@InjectMocks
	private BookingServiceValidator bookingServiceValidator;

	@Mock
	private BookingIdentifierValidation mockBookingIdentifierValidation;
	@Mock
	private ValidationServiceExceptionGenerator mockValidationServiceExceptionGenerator;
	@Rule
	public ExpectedException thrown = ExpectedException.none();

	private static final String DEV_MSG_DATA_INVALID = "Data Invalid";
	private static final String BOOKINGIDENTIFER_PATH = "booking-identifier";
	private static final String BOOKING_IDENTIFIER = "BALHR1";

	List<ValidationServiceException> validationServiceExceptionlist;
	List<ValidationServiceException> serviceExceptionlist;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		bookingServiceValidator = new BookingServiceValidator(mockBookingIdentifierValidation,
				mockValidationServiceExceptionGenerator);
		validationServiceExceptionlist = Lists.newArrayList();
	}

	@Test
	public void shouldThrowValidationServiceException() {
		String booking_identifier = "TKT0123456@@78";
		ValidationServiceException validationServiceException = createValidationServiceException(
				BookingErrorCode.REQUEST_INVALID.name(), BookingErrorCode.DATA_INVALID.name(), BOOKINGIDENTIFER_PATH);
		validationServiceExceptionlist.add(validationServiceException);
		thrown.expect(ValidationServiceException.class);
		thrown.expect(CustomValidationServiceExceptionMatcher.hasException(validationServiceException));
		when(mockBookingIdentifierValidation.validate(Mockito.anyString())).thenReturn(validationServiceException);
		when(mockValidationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionlist))
						.thenThrow(validationServiceException);
		bookingServiceValidator.validate(booking_identifier);
	}

	
	@Test
	public void shouldValidateWhenValidatorServiceExceptinIsNullTest() {
		ValidationServiceException validate = mockBookingIdentifierValidation.validate(BOOKING_IDENTIFIER);
		assertEquals(null, validate);
	}

	@Test
	public void shouldPassValidation() {
		String booking_identifier = "TKT012345678";
		List<ValidationServiceException> validationServiceExceptionlist = Lists.newArrayList();
		when(mockBookingIdentifierValidation.validate(Mockito.anyString())).thenReturn(null);
		bookingServiceValidator.validate(booking_identifier);
		assertEquals(0, validationServiceExceptionlist.size());
	}

	private ValidationServiceException createValidationServiceException(String parentErrorCode, String childErrorCode,
			String path) {
		ValidationServiceException validationServiceException = new ValidationServiceException(parentErrorCode);
		validationServiceException.addValidationException(createValidationServiceException(childErrorCode, path));
		return validationServiceException;
	}

	private ValidationServiceException createValidationServiceException(String errorCode, String path) {
		ValidationServiceException childValidationServiceException = new ValidationServiceException(errorCode);
		childValidationServiceException.setPath(path);
		childValidationServiceException.setDeveloperMessage(DEV_MSG_DATA_INVALID);
		return childValidationServiceException;
	}
}
