package com.iag.business.booking.repository;

import static org.junit.Assert.assertNotNull;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.amadeus.xml.ccprrr_17_1_1a.AdditionalProductDetailsTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.ApplicationErrorDetailType;
import com.amadeus.xml.ccprrr_17_1_1a.ApplicationErrorInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.CodedAttributeInformationType208434C;
import com.amadeus.xml.ccprrr_17_1_1a.CodedAttributeType214203S;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerAndProductLinks;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel.LegLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.SwipeResponse;
import com.amadeus.xml.ccprrr_17_1_1a.EdiIdentifiedBagType;
import com.amadeus.xml.ccprrr_17_1_1a.EdiIdentifiedBaggageGroupType;
import com.amadeus.xml.ccprrr_17_1_1a.ErrorGroupType;
import com.amadeus.xml.ccprrr_17_1_1a.FacilityInformationType171568C;
import com.amadeus.xml.ccprrr_17_1_1a.FlightDetailsResponseType;
import com.amadeus.xml.ccprrr_17_1_1a.FreeTextDetailsType150193C;
import com.amadeus.xml.ccprrr_17_1_1a.FreeTextInformationType167874S;
import com.amadeus.xml.ccprrr_17_1_1a.OriginAndDestinationDetailsTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.OutboundCarrierDetailsTypeI166697C;
import com.amadeus.xml.ccprrr_17_1_1a.OutboundFlightNumberDetailstypeI139968C;
import com.amadeus.xml.ccprrr_17_1_1a.ProductDateTimeTypeI166696C;
import com.amadeus.xml.ccprrr_17_1_1a.RelatedProductInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationDetailsType;
import com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.StationInformationTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.StatusDetailsTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.StatusType144223S;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeType18904C;
import com.amadeus.xml.ccprrr_17_1_1a.TerminalLocationType116626S;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.business.booking.amadeus.error.AmadeusErrorCode;
import com.iag.business.booking.amadeus.error.ApplicationServiceExceptionGenerator;
import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.error.BookingErrorCode;
import com.iag.business.booking.proxy.ConfigurationInfrastructureServiceProxy;
import com.iag.business.booking.repository.mapper.BookingResponseMapper;
import com.iag.domain.model.Carrier;
import com.iag.domain.model.CarrierType;
import com.iag.domain.model.Destination;
import com.iag.domain.model.Gate;
import com.iag.domain.model.Origin;
import com.iag.domain.model.booking.Booking;
import com.iag.domain.model.booking.BookingSearchCriteria;
import com.iag.domain.model.flight.BookingStatus;
import com.iag.domain.model.flight.FlightLeg;
import com.iag.domain.model.flight.FlightSegment;
import com.iag.domain.model.flight.FlightSegmentStatuses;
import com.iag.domain.model.flight.FlightSegmentType;
import com.iag.domain.model.session.Session;

public class BookingRepositoryImplTest {
	@InjectMocks
	private BookingRepositoryImpl bookingRepository;
	private GetBookingAmadeusRequestMapper amadeusRequestMapper;
	private BookingSearchCriteria bookingSearchCriteria;
	private Session session;
	@Mock
	private BookingResponseMapper bookingResponseMapper;
	@Mock
	private ConfigurationInfrastructureServiceProxy serviceProxy;
	
	@Mock
	private WebServiceTemplate amadeusWebServiceTemplate;
	
	@Rule
	public final ExpectedException exception = ExpectedException.none();
	
	private static final String RESMSG_BOOKINGIDENTIFER = ".response_message_bookingidentifier";
	@Mock
	ApplicationServiceExceptionGenerator applicationServiceExceptionGenerator;
	
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		amadeusRequestMapper = new GetBookingAmadeusRequestMapper();
		bookingSearchCriteria = new BookingSearchCriteria();
		bookingSearchCriteria.setBookingIdentifier("SIYB5G");
		session = getSession();
		ReflectionTestUtils.setField(bookingRepository, "bookingResponseMapper", bookingResponseMapper);
		ReflectionTestUtils.setField(bookingRepository, "serviceProxy", serviceProxy);
		ReflectionTestUtils.setField(bookingRepository, "amadeusWebServiceTemplate", amadeusWebServiceTemplate);
		Mockito.when(bookingResponseMapper.map(Mockito.any(DCSIDCCPRIdentificationReply.class))).thenReturn(createBooking());
		Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenReturn(createAmadeusResponse());
		Mockito.when(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUS_NAMESPACE, BookingServiceConstants.AMADEUS_SOAP_ACTION_URL)).thenReturn("http://webservices.amadeus.com/1ASIWIAGBA/CCPRRQ_17_1_1A");
		ApplicationServiceException applicationServiceException = new ApplicationServiceException(BookingErrorCode.SYSTEM_UNAVAILABLE.name());
		Mockito.when(applicationServiceExceptionGenerator.createAplicationExceptionWithDeveloperMessage(
				AmadeusErrorCode.SYSTEM_UNAVAILABLE.name(),
				AmadeusErrorCode.SYSTEM_UNAVAILABLE.name() + RESMSG_BOOKINGIDENTIFER)).thenThrow(applicationServiceException);

	
		Mockito.when(applicationServiceExceptionGenerator.createAplicationExceptionWithDeveloperMessage(
				AmadeusErrorCode.BOOKING_NOT_FOUND.name(),
				AmadeusErrorCode.BOOKING_NOT_FOUND.name() + RESMSG_BOOKINGIDENTIFER)).thenThrow(applicationServiceException);
}
	
	@Test 
	public void shouldReturnBookingRepositryResponseTest(){
		Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenReturn(createAmadeusResponse());
		Booking booking = bookingRepository.getBooking(bookingSearchCriteria, session);
		assertNotNull(booking);
	}
	
	@Test 
	public void shouldReturnBookingsRepositryResponseTest(){
		Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenReturn(createAmadeusResponse());
		List<Booking> bookings = bookingRepository.getBookings(bookingSearchCriteria, session);
		assertNotNull(bookings);
	}
	
	@Test 
	public void shouldNotReturnBookingRepositryResponseForAmadeusErrorTest(){
		Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenReturn(createAmadeusResponsWithError());
		exception.expect(ApplicationServiceException.class);
		bookingRepository.getBooking(bookingSearchCriteria, session);
	}
	
	@Test 
	public void shouldNotReturnBookingRepositryResponseForAmadeusBookingNotFoundErrorTest(){
		Mockito.when(
                amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
                        Mockito.any(WebServiceMessageCallback.class))).thenReturn(createAmadeusResponsWithBookingnotFoundError());
		exception.expect(ApplicationServiceException.class);
		bookingRepository.getBooking(bookingSearchCriteria, session);
	}
	
	
	private Object createAmadeusResponsWithBookingnotFoundError() {
		DCSIDCCPRIdentificationReply amadeusResponse = new DCSIDCCPRIdentificationReply();

		

		List<ErrorGroupType> errors = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();
		errors.add(errorGroupType);

		ApplicationErrorInformationType errorOrWarningCodeDetails = new ApplicationErrorInformationType();
		FreeTextInformationType167874S errorWarningDescription = new FreeTextInformationType167874S();
		errorGroupType.setErrorOrWarningCodeDetails(errorOrWarningCodeDetails);
		errorGroupType.setErrorWarningDescription(errorWarningDescription);

		ApplicationErrorDetailType errorDetails = new ApplicationErrorDetailType();
		errorOrWarningCodeDetails.setErrorDetails(errorDetails);
		errorDetails.setErrorCode("17569");
		FreeTextDetailsType150193C freeTextDetails = new FreeTextDetailsType150193C();
		errorWarningDescription.setFreeTextDetails(freeTextDetails);
		freeTextDetails.setLanguage("EN");
		amadeusResponse.setErrors(errors);

		return amadeusResponse;
	}

	private DCSIDCCPRIdentificationReply createAmadeusResponsWithError() {
		DCSIDCCPRIdentificationReply amadeusResponse = new DCSIDCCPRIdentificationReply();

		

		List<ErrorGroupType> errors = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();
		errors.add(errorGroupType);

		ApplicationErrorInformationType errorOrWarningCodeDetails = new ApplicationErrorInformationType();
		FreeTextInformationType167874S errorWarningDescription = new FreeTextInformationType167874S();
		errorGroupType.setErrorOrWarningCodeDetails(errorOrWarningCodeDetails);
		errorGroupType.setErrorWarningDescription(errorWarningDescription);

		ApplicationErrorDetailType errorDetails = new ApplicationErrorDetailType();
		errorOrWarningCodeDetails.setErrorDetails(errorDetails);
		errorDetails.setErrorCode(BookingErrorCode.SYSTEM_UNAVAILABLE.name());
		FreeTextDetailsType150193C freeTextDetails = new FreeTextDetailsType150193C();
		errorWarningDescription.setFreeTextDetails(freeTextDetails);
		freeTextDetails.setLanguage("EN");
		amadeusResponse.setErrors(errors);

		return amadeusResponse;
	}

	
	private DCSIDCCPRIdentificationReply createAmadeusResponse() {
		DCSIDCCPRIdentificationReply amadeusResponse = new DCSIDCCPRIdentificationReply();
		
		List<CustomerLevel> customerLevelList = new ArrayList<>();
		amadeusResponse.setCustomerLevel(customerLevelList);
		CustomerLevel customerLevel1 = new CustomerLevel();
		customerLevelList.add(customerLevel1);
		List<ProductLevel> productLevelList = new ArrayList<>();
		ProductLevel productLevel = new ProductLevel();
		productLevelList.add(productLevel);

		ReservationControlInformationType recordLocator2 = new ReservationControlInformationType();
		customerLevel1.setRecordLocator(recordLocator2);
		ReservationControlInformationDetailsType reservation2 = new ReservationControlInformationDetailsType();
		recordLocator2.setReservation(reservation2);
		reservation2.setControlNumber("BL001");

		RelatedProductInformationType bookingStatusDetails = new RelatedProductInformationType();
		productLevel.setBookingStatusDetails(bookingStatusDetails);
		bookingStatusDetails.setStatusCode("HK");
		CodedAttributeType214203S productLevelIndicators = new CodedAttributeType214203S();
		productLevel.setProductLevelIndicators(productLevelIndicators);
		customerLevel1.setProductLevel(productLevelList);
		List<CodedAttributeInformationType208434C> attributeDetailsList = new ArrayList<>();
		CodedAttributeInformationType208434C codedAttributeInformationType208434C = new CodedAttributeInformationType208434C();
		codedAttributeInformationType208434C.setAttributeType("DUMMY");
		attributeDetailsList.add(codedAttributeInformationType208434C);
		productLevelIndicators.setAttributeDetails(attributeDetailsList);

		StatusType144223S flightStatuses = new StatusType144223S();
		List<StatusDetailsTypeI> statusInformationList = new ArrayList<>();
		StatusDetailsTypeI statusDetailsTypeI = new StatusDetailsTypeI();
		statusDetailsTypeI.setIndicator("FDS");
		statusDetailsTypeI.setAction("FDL2");
		statusInformationList.add(statusDetailsTypeI);
		flightStatuses.setStatusInformation(statusInformationList);
		productLevel.setFlightStatuses(flightStatuses);
		FlightDetailsResponseType operatingFlightDetails = new FlightDetailsResponseType();
		operatingFlightDetails.setBoardPoint("SHA");

		operatingFlightDetails.setDepartureDate("20181022");
		operatingFlightDetails.setArrivalDate("20181022");

		productLevel.setOperatingFlightDetails(operatingFlightDetails);

		List<LegLevel> legLevelList = new ArrayList<>();
		LegLevel legLevel = new LegLevel();

		List<StructuredDateTimeInformationType> legTimes = legLevel.getLegTimes();

		StructuredDateTimeInformationType structuredDateTimeInformationType = new StructuredDateTimeInformationType();
		legTimes.add(structuredDateTimeInformationType);
		structuredDateTimeInformationType.setBusinessSemantic("STD");
		StructuredDateTimeType18904C dateTime = new StructuredDateTimeType18904C();
		structuredDateTimeInformationType.setDateTime(dateTime);
		dateTime.setYear("2018");
		dateTime.setMonth("4");
		dateTime.setDay("16");
		dateTime.setHour("9");
		dateTime.setMinutes("52");
		dateTime.setSeconds(BigInteger.valueOf(50));

		StructuredDateTimeInformationType structuredDateTimeInformationType1 = new StructuredDateTimeInformationType();
		legTimes.add(structuredDateTimeInformationType1);
		structuredDateTimeInformationType1.setBusinessSemantic("STA");
		StructuredDateTimeType18904C dateTime1 = new StructuredDateTimeType18904C();
		structuredDateTimeInformationType1.setDateTime(dateTime1);
		dateTime1.setYear("2018");
		dateTime1.setMonth("4");
		dateTime1.setDay("16");
		dateTime1.setHour("9");
		dateTime1.setMinutes("52");
		dateTime1.setSeconds(BigInteger.valueOf(50));

		legLevelList.add(legLevel);
		AdditionalProductDetailsTypeI additionalProductDetails = new AdditionalProductDetailsTypeI();
		legLevel.setAdditionalProductDetails(additionalProductDetails);
		StationInformationTypeI departureStationInfo = new StationInformationTypeI();
		departureStationInfo.setTerminal("T1");
		additionalProductDetails.setDepartureStationInfo(departureStationInfo);
		productLevel.setLegLevel(legLevelList);

		List<TerminalLocationType116626S> departureGate = new ArrayList<>();
		TerminalLocationType116626S terminalLocationType116626S = new TerminalLocationType116626S();
		departureGate.add(terminalLocationType116626S);
		FacilityInformationType171568C facilityDetails = new FacilityInformationType171568C();
		facilityDetails.setIdentifier("1");
		terminalLocationType116626S.setFacilityDetails(facilityDetails);
		productLevel.setDepartureGate(departureGate);
		StationInformationTypeI arrivalStationInfo = new StationInformationTypeI();
		arrivalStationInfo.setTerminal("T2");
		additionalProductDetails.setArrivalStationInfo(arrivalStationInfo);

		List<ProductDateTimeTypeI166696C> dateAndTimeRange = new ArrayList<>();
		ProductDateTimeTypeI166696C productDateTimeTypeI166696C = new ProductDateTimeTypeI166696C();
		productDateTimeTypeI166696C.setDepartureDate("2018-04-08");
		productDateTimeTypeI166696C.setDepartureTime("1913");
		productDateTimeTypeI166696C.setArrivalDate("2018-04-08");
		productDateTimeTypeI166696C.setArrivalTime("2040");
		dateAndTimeRange.add(productDateTimeTypeI166696C);
		operatingFlightDetails.setDateAndTimeRange(dateAndTimeRange);

		OutboundCarrierDetailsTypeI166697C carrierDetails = new OutboundCarrierDetailsTypeI166697C();
		carrierDetails.setMarketingCarrier("AS");
		carrierDetails.setOtherCarrier("BA");
		operatingFlightDetails.setCarrierDetails(carrierDetails);
		OutboundFlightNumberDetailstypeI139968C flightDetails = new OutboundFlightNumberDetailstypeI139968C();
		flightDetails.setFlightNumber("203");
		flightDetails.setOperationalSuffix("111");
		operatingFlightDetails.setFlightDetails(flightDetails);
		OriginAndDestinationDetailsTypeI legRouting = new OriginAndDestinationDetailsTypeI();
		legRouting.setOrigin("WUX");
		legRouting.setDestination("PVG");
		legLevel.setLegRouting(legRouting);
		operatingFlightDetails.setOffPoint("NTG");
		SwipeResponse responseAnalysisDetailsType = new SwipeResponse();

		amadeusResponse.setSwipeResponse(responseAnalysisDetailsType);
		List<EdiIdentifiedBagType> value = new ArrayList<EdiIdentifiedBagType>();

		amadeusResponse.setBagDetails(value);
		List<EdiIdentifiedBaggageGroupType> value1=new ArrayList<EdiIdentifiedBaggageGroupType>();
		amadeusResponse.setBaggageInfo(value1);
		List<CustomerAndProductLinks> value33=new ArrayList<CustomerAndProductLinks>();

		amadeusResponse.setCustomerAndProductLinks(value33);
		List<CustomerLevel> valu333e= new ArrayList<CustomerLevel>();;
		amadeusResponse.setCustomerLevel(valu333e);

		return amadeusResponse;
	}

	
	private Booking createBooking() {
		Booking booking = new Booking.BookingBuilder("SIYB5G", LoadflightSegments()).build();
		return booking;
	}
	
	private List<FlightSegment> LoadflightSegments() {
		List<FlightSegment> flightSegments = new ArrayList<FlightSegment>();
		List<FlightLeg> flightLegs = loadFlightLegs();
		FlightSegmentStatuses flightSegmentStatuses = new FlightSegmentStatuses();
		flightSegmentStatuses.setBookingStatus(BookingStatus.CONFIRMED);

		List<Carrier> carriers = loadCarriers();
		FlightSegment flightSegment  = new FlightSegment.FlightSegmentBuilder(FlightSegmentType.INBOUND, 
		flightSegmentStatuses, getOriginFlightSegment(), getDestinationFlightSegment(), new LocalDateTime(2004, 8, 25, 11, 20, 12), 
		new LocalDateTime(2004, 8, 25, 11, 20, 12), flightLegs).setIdentifier("fsIdentifier").setCarriers(carriers)
		.build();
		flightSegments.add(flightSegment);
		return flightSegments;
		}
	
	private List<FlightLeg> loadFlightLegs(){
		List<FlightLeg> flightLegList = new ArrayList<>();
		
		FlightLeg flightLeg = new FlightLeg.FlightLegBuilder(getOriginFlightLeg(), getDestinationFlightLeg(), new LocalDateTime(2018,10,12,04,12,0), new LocalDateTime(2018,11,11,04,17,0)).build();
		flightLegList.add(flightLeg);
		return flightLegList;
	}
	
	private Origin getOriginFlightLeg(){
		Origin origin = new Origin();
		origin.setIdentifier("LHR");
		Gate gate = new Gate();
		gate.setNumber("6");
		origin.setGate(gate);
		origin.setTerminal("5");
		return origin;
	}
	
	
	private Origin getOriginFlightSegment(){
		Origin origin = new Origin();
		
		origin.setIdentifier("LHR");
		Gate gate = new Gate();
		gate.setNumber("5");
		origin.setGate(gate);
		origin.setTerminal("1");
		return origin;
	}
	
	private Destination getDestinationFlightSegment(){
		Destination destination = new Destination();
		destination.setTerminal("9");
		Gate gate = new Gate();
		gate.setNumber("7");
		destination.setGate(gate);
		destination.setIdentifier("BAH");
		return destination;
	}
	
	private Destination getDestinationFlightLeg(){
		Destination destination = new Destination();
		destination.setTerminal("5");
		Gate gate = new Gate();
		gate.setNumber("3");
		destination.setGate(gate);
		destination.setIdentifier("BAL");
		return destination;
	}
	
	private List<Carrier> loadCarriers(){
		List<Carrier> carrierList = new ArrayList<>();
		Carrier carrier = new Carrier();
		carrier.setCode("BA");
		carrier.setFlightNumber("124");
		carrier.setOperationalSuffix("OS");
		carrier.setType(CarrierType.MARKETING);
		carrierList.add(carrier);
		return carrierList;
	}
	
	private Session getSession() {
		Session session = new Session();
		session.setChannel("channel");
		session.setLocation("location");
		session.setScope("scope");
		session.setSessionIdentifier("sessionIdentifier");
		session.setStatus("status");
		session.setTokenNumber("tokenNumber");
		return session;
	}
	

}
