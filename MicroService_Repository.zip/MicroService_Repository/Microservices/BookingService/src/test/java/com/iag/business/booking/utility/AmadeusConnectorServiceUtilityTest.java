package com.iag.business.booking.utility;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.proxy.ServiceProxy;


public class AmadeusConnectorServiceUtilityTest {
    private static final String BLANK_VALUE = StringUtils.EMPTY;
    private AmadeusConnectorServiceUtility amadeusConnectorServiceUtility;

    @Mock
    private ServiceProxy configurationInfrastructureServiceProxy;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        amadeusConnectorServiceUtility = new AmadeusConnectorServiceUtility(configurationInfrastructureServiceProxy);

    }
    @Test
    public void findingMessageConfigurationValueWithBlankKey() {

    	String validKey = "booking.error.msg-message-business-REQUEST_UNAUTHORIZED";
        String validValue = "";
        Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUS_NAMESPACE, getUrlKey(validKey)))
                .thenReturn(validValue);
        String value = amadeusConnectorServiceUtility.getMessageConfigurationValue(validKey);
        Assert.assertNull(value);

    }

    @Test
    public void findingMessageConfigurationValueWithNullKey() {

        Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUS_NAMESPACE, getUrlKey(BLANK_VALUE)))
                .thenReturn(BLANK_VALUE);
        String value = amadeusConnectorServiceUtility.getMessageConfigurationValue(BLANK_VALUE);
        Assert.assertEquals(BLANK_VALUE, value);

    }

   

    String getUrlKey(String key) {
        return new StringBuilder()
                .append(BookingServiceConstants.MESSAGE_CONFIGURATION_KEYWORD)
                .append(key.replace(BookingServiceConstants.KEY_SEPARATOR_DOT,
                		BookingServiceConstants.KEY_SEPARATOR)).toString();

    }

}
