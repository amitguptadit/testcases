package com.iag.business.booking.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.application.exception.ValidationServiceException;
import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.error.BookingErrorCode;
import com.iag.business.booking.proxy.ServiceProxy;
import com.iag.business.booking.exception.ValidationServiceExceptionGenerator;



public class ValidationServiceExceptionGeneratorTest {

	private static final String path = "booking-identifier";

	private static final String developerMessage_Key = "booking.error.DATA_INVALID.developer_message_passengeridentifier";

	private static final String developerMessage = "Booking Identifier is invalid";

	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;
	@Mock
	private ServiceProxy configurationInfrastructureServiceProxy;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		validationServiceExceptionGenerator = new ValidationServiceExceptionGenerator(
				configurationInfrastructureServiceProxy);
	}
	
	@Test
	public void shouldNotGetMessageConfigurationValue() {
		String value = validationServiceExceptionGenerator.getMessageConfigurationValue("");
		assertEquals("", value);
	}

	@Test
	public void shouldCreateServiceExceptionWithChildError() {
		List<ValidationServiceException> validationServiceExceptionList = new ArrayList<ValidationServiceException>();
		ValidationServiceException childValidationServiceException1 = new ValidationServiceException(
				BookingErrorCode.DATA_INVALID.name());
		ValidationServiceException childValidationServiceException2 = new ValidationServiceException(
				BookingErrorCode.DATA_INVALID.name());
		validationServiceExceptionList.add(childValidationServiceException1);
		validationServiceExceptionList.add(childValidationServiceException2);
		ValidationServiceException outputValidationServiceException = validationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionList);
		assertEquals(BookingErrorCode.REQUEST_INVALID.name(), outputValidationServiceException.getCode());
		assertEquals(2, outputValidationServiceException.getValidationExceptions().size());
		Iterator<ValidationServiceException> iterator = outputValidationServiceException.getValidationExceptions()
				.iterator();
		assertEquals(BookingErrorCode.DATA_INVALID.name(), iterator.next().getCode());
		assertEquals(BookingErrorCode.DATA_INVALID.name(), iterator.next().getCode());
	}

	@Test
	public void shouldCreateServiceExceptionWithEmptyList() {
		List<ValidationServiceException> validationServiceExceptionList = new ArrayList<ValidationServiceException>();
		ValidationServiceException validationServiceException = validationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionList);
		assertNotNull(validationServiceException);
		assertEquals(BookingErrorCode.REQUEST_INVALID.name(), validationServiceException.getCode());
	}

	@Test
	public void shouldCreateValidationError() {
		Mockito.when(configurationInfrastructureServiceProxy
				.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE, "booking.error.DATA_INVALID.developer_message_passengeridentifier"))
				.thenReturn(developerMessage);
		ValidationServiceException validationServiceException = validationServiceExceptionGenerator
				.createValidationError(BookingErrorCode.REQUEST_INVALID.name(), path, developerMessage_Key);
		assertNotNull(validationServiceException);
		assertEquals(BookingErrorCode.REQUEST_INVALID.name(), validationServiceException.getCode());
		assertEquals(path, validationServiceException.getPath());
		assertEquals(developerMessage, validationServiceException.getDeveloperMessage());
	}

	@Test
	public void shouldCreateServiceException() {
		Mockito.when(configurationInfrastructureServiceProxy
				.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE,"booking.error.DATA_INVALID.developer_message_passengeridentifier"))
				.thenReturn(developerMessage);
		ValidationServiceException validationServiceException = validationServiceExceptionGenerator
				.createServiceException(BookingErrorCode.DATA_INVALID.name(), path, developerMessage_Key);
		assertNotNull(validationServiceException);
		assertEquals(BookingErrorCode.REQUEST_INVALID.name(), validationServiceException.getCode());
		assertEquals(BookingErrorCode.DATA_INVALID.name(),
				validationServiceException.getValidationExceptions().iterator().next().getCode());
		assertEquals(path, validationServiceException.getValidationExceptions().iterator().next().getPath());
		assertEquals(developerMessage,
				validationServiceException.getValidationExceptions().iterator().next().getDeveloperMessage());
	}

	@Test
	public void checkBusinessMessagewithErrorCode() {
		Mockito.when(
				configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE,"booking.error.REQUEST_INVALID.code"))
				.thenReturn("Request Invalid");
		String businessMessage = validationServiceExceptionGenerator
				.getMessageConfigurationValue("booking.error.REQUEST_INVALID.code");
		assertEquals("Request Invalid", businessMessage);
	}

}
