package com.iag.business.booking.repository.amadeus.proxy;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.sleuth.Log;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.support.MarshallingUtils;

import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.business.booking.error.BookingErrorCode;
import com.iag.business.booking.repository.impl.mapper.request.AmedeusRequestHeaderMapper;
import com.iag.domain.model.session.Session;

/**
 * The class AmadeusWebServiceProxy.
 */
@Component
public class AmadeusWebServiceProxy {
	@Autowired
	Jaxb2Marshaller amadeusMarshaller;
	@Autowired
	Jaxb2Marshaller amadeusUnMarshaller;

	@Autowired
	AmedeusRequestHeaderMapper amedeusRequestHeaderMapper;
	private static final Logger LOG = LoggerFactory.getLogger(AmadeusWebServiceProxy.class);

	@Autowired
	private WebServiceTemplate amadeusWebServiceTemplate;

	/**
	 * getWebServiceResponse.
	 * 
	 * @param requestObject
	 * @param soapActionUri
	 * @return response
	 */

	public DCSIDCCPRIdentificationReply getBookingResponse(final Object requestObject, final String soapActionUri,
			final Session session) {
		DCSIDCCPRIdentificationReply response = null;
		try {
			response = (DCSIDCCPRIdentificationReply) amadeusWebServiceTemplate.marshalSendAndReceive(requestObject,
					new WebServiceMessageCallback() {
						/**
						 * This method is used to set the SOAP URI at runtime.
						 * 
						 * @param message
						 */
						public void doWithMessage(final WebServiceMessage message) {
							SoapMessage soapMessage = (SoapMessage) message;
							amedeusRequestHeaderMapper.mapHeaders(soapMessage, soapActionUri, session);
							soapMessage.setSoapAction(soapActionUri);
							try {
								LOG.debug("URI : " + soapActionUri);
								LOG.debug("RequestObject : " + requestObject);
								LOG.debug("Message : " + message);
								MarshallingUtils.marshal(amadeusMarshaller, requestObject, message);
							} catch (IOException exception) {
								LOG.error("exception occured while calling Amadeus->{} ", exception.getMessage());
								throwWebServiceException(exception);
							}
						}
					});
		} catch (Exception exception) {
			LOG.info("exception occured while calling Amadeus->{} ", exception.getMessage());
			throwWebServiceException(exception);
		}
		return response;
	}


	/**
	 * This private method is responsible to handle the webServiceException if
	 * any in response from AmadeusWebSerfvice. It should throw the exception
	 * based on the nature.
	 * 
	 * @param exception
	 *            WebServiceIOException
	 */
	private void throwWebServiceException(final Exception exception) {
		
		ApplicationServiceException ex = new ApplicationServiceException(BookingErrorCode.SYSTEM_UNAVAILABLE.name());
        ex.setDeveloperMessage(exception.getMessage());
        throw ex;
	}

}
