package com.iag.domain.model.flight;

public enum AcceptanceAndBoardingStatus {

	OPEN,
	CLOSED,
	NOTOPEN,
	SUSPENDED
}
