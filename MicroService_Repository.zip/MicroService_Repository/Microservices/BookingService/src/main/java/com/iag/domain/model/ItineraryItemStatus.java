package com.iag.domain.model;

public enum ItineraryItemStatus {

    CONFIRMED,
    UNCONFIRMED,
    DELAYED


}