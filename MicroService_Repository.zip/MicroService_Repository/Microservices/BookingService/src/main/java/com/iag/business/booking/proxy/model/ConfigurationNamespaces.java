package com.iag.business.booking.proxy.model;

import java.util.ArrayList;
import java.util.List;

public class ConfigurationNamespaces {

	private String name;
	private List<ConfigurationItems> configurationItems = new ArrayList<>();
	private List<ConfigurationNamespace> configurationNamespaces;
	
	
	public String getName() {
		return name;
	}

	public List<ConfigurationNamespace> getConfigurationNamespaces() {
		return configurationNamespaces;
	}

	public void setConfigurationNamespaces(List<ConfigurationNamespace> configurationNamespaces) {
		this.configurationNamespaces = configurationNamespaces;
	}

	public void setConfigurationItems(List<ConfigurationItems> configurationItems) {
		this.configurationItems = configurationItems;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ConfigurationItems> getConfigurationItems() {
		return configurationItems;
	}

	public void setConfigurationItem(List<ConfigurationItems> configurationItems) {
		this.configurationItems = configurationItems;
	}
}
