package com.iag.business.booking.exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.error.ContentProvider;
import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.proxy.ServiceProxy;

/**
 * Implementation of Base class of ContentProvider to support application error
 * module.
 */
@Component
public class DefaultContentProvider implements ContentProvider {

	private final ServiceProxy configurationInfrastructureServiceProxy;

	/**
	 * Constructs ExceptionHandler instance with the supplied service proxy.
	 * 
	 * @param configurationInfrastructureServiceProxy
	 */
	@Autowired
	public DefaultContentProvider(final ServiceProxy configurationInfrastructureServiceProxy) {
		this.configurationInfrastructureServiceProxy = configurationInfrastructureServiceProxy;
	}

	/**
	 * Passing key to proxy, get value and set it in bussinesMessage,
	 * developerLink.
	 * 
	 * @param error
	 *            passing service object to method.
	 * @return String obejct.
	 */
	public String getContent(final String error) {
		return configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE, error);
	}
}
