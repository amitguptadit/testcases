/**
 * 
 */
package com.iag.business.booking.proxy;

public interface ServiceProxy {

	/**
	 * Retrieves configuration item corresponding to supplied key.
	 * 
	 * @param key
	 * @return
	 */
	//String retrieveConfiguration(final String key);
	
	String retrieveConfiguration(String configurationName, String key);

}
