package com.iag.domain.model.address;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.iag.domain.model.location.Location;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * PostalAddress class represents postal address which could be of various types such as
 * Temporary, Business, Home postal addresses.
 * @param addressLines : List of address lines in String.
 * @param city : String city corresponding to this {@link Address}.
 * @param postCode : String post code corresponding to this {@link Address}.
 * @param country : It represents {@link Location} information.
 * @param state : It represents {@link Location} information.
 * @param city : It represents {@link Location} information.
 * @param county : It represents {@link Location} information.
 * @param companyName : Name of the company if its a company address.
 * @param placeType :it represents(@link PostalAddressType) information.
 */

public final class DestinationAddress extends PostalAddress implements Serializable {
 
}
