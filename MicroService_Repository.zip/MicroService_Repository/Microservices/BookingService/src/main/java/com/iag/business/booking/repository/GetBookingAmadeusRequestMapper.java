package com.iag.business.booking.repository;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.amadeus.xml.ccprrq_17_1_1a.DCSIDCCPRIdentification;
import com.amadeus.xml.ccprrq_17_1_1a.DCSIDCCPRIdentification.SetOfCriteria;
import com.amadeus.xml.ccprrq_17_1_1a.DocumentMessageDetailsTypeU;
import com.amadeus.xml.ccprrq_17_1_1a.DocumentMessageNameTypeU;
import com.amadeus.xml.ccprrq_17_1_1a.DocumentMessageTypeU;
import com.amadeus.xml.ccprrq_17_1_1a.FlightDetailsQueryType;
import com.amadeus.xml.ccprrq_17_1_1a.OutboundCarrierDetailsTypeI;
import com.amadeus.xml.ccprrq_17_1_1a.OutboundFlightNumberDetailstypeI;
import com.amadeus.xml.ccprrq_17_1_1a.ReservationControlInformationDetailsType;
import com.amadeus.xml.ccprrq_17_1_1a.ReservationControlInformationType;
import com.amadeus.xml.ccprrq_17_1_1a.StructuredDateTimeType;
import com.amadeus.xml.ccprrq_17_1_1a.StructuredPeriodInformationType;
import com.amadeus.xml.ccprrq_17_1_1a.TravellerDetailsType;
import com.amadeus.xml.ccprrq_17_1_1a.TravellerInformationType;
import com.amadeus.xml.ccprrq_17_1_1a.TravellerSurnameInformationType;
import com.google.common.base.Strings;
import com.iag.domain.model.booking.BookingSearchCriteria;

public class GetBookingAmadeusRequestMapper {

	String NATIONAL_IDENTITY_CARD = "NATIONAL_IDENTITY_CARD";
	String PASSPORT = "PASSPORT";

	public DCSIDCCPRIdentification mapGetbookingRequest(BookingSearchCriteria bookingSearchCriteria) {
		DCSIDCCPRIdentification dcsidccprIdentification = new DCSIDCCPRIdentification();
		List<SetOfCriteria> setOfCriteria;
		setOfCriteria = populateSetOfCriteria(bookingSearchCriteria);
		dcsidccprIdentification.setSetOfCriteria(setOfCriteria);
		return dcsidccprIdentification;
	}

	private List<SetOfCriteria> populateSetOfCriteria(BookingSearchCriteria bookingSearchCriteria) {
		List<SetOfCriteria> setOfCriterias = new ArrayList<SetOfCriteria>();
		SetOfCriteria setOfCriteria = new SetOfCriteria();
		ReservationControlInformationType reservationControlInformationType = new ReservationControlInformationType();
		ReservationControlInformationDetailsType reservationControlInformationDetailsType = new ReservationControlInformationDetailsType();
		TravellerInformationType customerDetail = new TravellerInformationType();
		TravellerDetailsType otherPaxDetails = new TravellerDetailsType();
		TravellerSurnameInformationType paxDetail = new TravellerSurnameInformationType();
		List<DocumentMessageTypeU> documentDetails = new ArrayList<>();
		DocumentMessageTypeU documentMessageType = new DocumentMessageTypeU();
		DocumentMessageNameTypeU issueDetail = new DocumentMessageNameTypeU();
		DocumentMessageDetailsTypeU documentMEssageDetailsType = new DocumentMessageDetailsTypeU();
		FlightDetailsQueryType flightDetailsQueryType = new FlightDetailsQueryType();
		OutboundFlightNumberDetailstypeI outboundFlightNumberDetailsType = new OutboundFlightNumberDetailstypeI();
		OutboundCarrierDetailsTypeI outboundCarrierDetailsType = new OutboundCarrierDetailsTypeI();


		if (!Strings.isNullOrEmpty(bookingSearchCriteria.getFirstName())) {
			otherPaxDetails.setGivenName(bookingSearchCriteria.getFirstName());
			customerDetail.setOtherPaxDetails(otherPaxDetails);
		}
		if (!Strings.isNullOrEmpty(bookingSearchCriteria.getFamilyName())) {
			paxDetail.setSurname(bookingSearchCriteria.getFamilyName());
			customerDetail.setPaxDetails(paxDetail);
			setOfCriteria.setCustomerDetails(customerDetail);
		}

		if (!Strings.isNullOrEmpty(bookingSearchCriteria.getIdentifierType())) {
			if (bookingSearchCriteria.getIdentifierType().equalsIgnoreCase(NATIONAL_IDENTITY_CARD)) {
				issueDetail.setDocumentCode("I");
			} else if (bookingSearchCriteria.getIdentifierType().equalsIgnoreCase(PASSPORT)) {
				issueDetail.setDocumentCode("I");
			}
			documentMessageType.setIssueDetails(issueDetail);
		}

		if (!Strings.isNullOrEmpty(bookingSearchCriteria.getToken())) {
			documentMEssageDetailsType.setTravelerDocumentId(bookingSearchCriteria.getToken());
			documentMessageType.setTravelerDocumentDetails(documentMEssageDetailsType);
			documentDetails.add(documentMessageType);
			setOfCriteria.setDocumentDetails(documentDetails);
		}

		if (!Strings.isNullOrEmpty(bookingSearchCriteria.getFlightNumber())
				|| !Strings.isNullOrEmpty(bookingSearchCriteria.getDestination())) {
			if (!Strings.isNullOrEmpty(bookingSearchCriteria.getFlightNumber())) {
				outboundFlightNumberDetailsType
						.setFlightNumber(bookingSearchCriteria.getFlightNumber().substring(0, 2));
				flightDetailsQueryType.setFlightDetails(outboundFlightNumberDetailsType);
				outboundCarrierDetailsType.setMarketingCarrier(bookingSearchCriteria.getFlightNumber().substring(2,
						bookingSearchCriteria.getFlightNumber().length()));
				flightDetailsQueryType.setCarrierDetails(outboundCarrierDetailsType);
			}
			if (!Strings.isNullOrEmpty(bookingSearchCriteria.getDestination())) {
				flightDetailsQueryType.setBoardPoint("LCY");
				flightDetailsQueryType.setOffPoint(bookingSearchCriteria.getDestination());
			}
			DateTime currentDate = DateTime.now().withZone(DateTimeZone.forID("Europe/London"));
			
			
			
			StructuredPeriodInformationType period = new StructuredPeriodInformationType();
			StructuredDateTimeType beginDate = new StructuredDateTimeType();
			beginDate.setYear(String.valueOf(currentDate.getYear()));
			beginDate.setMonth(String.valueOf(currentDate.getMonthOfYear()));
			beginDate.setDay("20");
			System.out.println( " Current Date " + currentDate.getDayOfMonth());
			period.setBeginDateTime(beginDate);
			
			StructuredDateTimeType endDate = new StructuredDateTimeType();
			endDate.setYear(String.valueOf(currentDate.getYear()));
			endDate.setMonth(String.valueOf(currentDate.getMonthOfYear()));
			endDate.setDay(String.valueOf("21"));
			System.out.println( " Current Next Date " + (currentDate.getDayOfMonth() + 1));
			System.out.println( " Current full Date " + currentDate);
			period.setEndDateTime(endDate);
			period.setBusinessSemantic("SDT");
			setOfCriteria.setSearchDateTimeRange(period);
		}
		if (!Strings.isNullOrEmpty(bookingSearchCriteria.getBookingIdentifier())) {
			reservationControlInformationDetailsType.setControlNumber(bookingSearchCriteria.getBookingIdentifier());
			reservationControlInformationType.setReservation(reservationControlInformationDetailsType);
			setOfCriteria.setRecordLocator(reservationControlInformationType);
		}
		
		
		setOfCriteria.setTravelCriteria(flightDetailsQueryType);
		setOfCriterias.add(setOfCriteria);
		return setOfCriterias;
	}
	
	

}
