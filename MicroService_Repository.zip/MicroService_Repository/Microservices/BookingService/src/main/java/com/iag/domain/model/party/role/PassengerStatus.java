package com.iag.domain.model.party.role;

public enum PassengerStatus {

    CHECKEDIN,
    NOTCHECKEDIN,
    STANDBY
    
}
