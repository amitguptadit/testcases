package com.iag.domain.model;

/**
 * Enum class for storing types of carrier. 
 */

public enum CarrierType {

    OPERATING,
    MARKETING
    
}