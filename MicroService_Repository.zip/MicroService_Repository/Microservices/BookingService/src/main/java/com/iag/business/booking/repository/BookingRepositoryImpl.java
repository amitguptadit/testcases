package com.iag.business.booking.repository;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amadeus.xml.ccprrq_17_1_1a.DCSIDCCPRIdentification;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply;
import com.iag.business.booking.amadeus.error.AmadeusErrorCode;
import com.iag.business.booking.amadeus.error.ApplicationServiceExceptionGenerator;
import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.proxy.ConfigurationInfrastructureServiceProxy;
import com.iag.business.booking.repository.amadeus.proxy.AmadeusWebServiceProxy;
import com.iag.business.booking.repository.mapper.BookingResponseMapper;
import com.iag.domain.model.booking.Booking;
import com.iag.domain.model.booking.BookingSearchCriteria;
import com.iag.domain.model.session.Session;

@Repository
public class BookingRepositoryImpl extends AmadeusWebServiceProxy implements BookingRepository {

	
	@Autowired
	private ConfigurationInfrastructureServiceProxy serviceProxy;
	private static final Logger logger = LoggerFactory.getLogger(BookingRepositoryImpl.class);
	@Autowired
	private BookingResponseMapper bookingResponseMapper;
	@Autowired
	ApplicationServiceExceptionGenerator applicationServiceExceptionGenerator;

	private static final String RESMSG_BOOKINGIDENTIFER = ".response_message_bookingidentifier";
	private static final String RESCODE_BOOKING = "17569";

	public Booking getBooking(BookingSearchCriteria bookingSearchCriteria, Session session) {
		logger.info("method start : getBooking()");
		DCSIDCCPRIdentificationReply dcsidccprIdentificationReply = populateAndCallAmadeusRequest(bookingSearchCriteria,
				session);
		logger.info("method End: getBooking()");
		return bookingResponseMapper.map(dcsidccprIdentificationReply);
	}

	@Override
	public List<Booking> getBookings(BookingSearchCriteria bookingSearchCriteria, Session session) {
		logger.info("method start : getBookings()");
		DCSIDCCPRIdentificationReply dcsidccprIdentificationReply = populateAndCallAmadeusRequest(bookingSearchCriteria,
				session);
		logger.info("method End: getBookings()");
		return bookingResponseMapper.maps(dcsidccprIdentificationReply);
	}

	/**
	 * @param bookingSearchCriteria
	 * @param session
	 * @return
	 */
	private DCSIDCCPRIdentificationReply populateAndCallAmadeusRequest(BookingSearchCriteria bookingSearchCriteria,
			Session session) {
		GetBookingAmadeusRequestMapper amadeusRequestMapper = new GetBookingAmadeusRequestMapper();
		DCSIDCCPRIdentification dcsidccprIdentification = amadeusRequestMapper
				.mapGetbookingRequest(bookingSearchCriteria);

		DCSIDCCPRIdentificationReply dcsidccprIdentificationReply = getBookingResponse(dcsidccprIdentification,
				serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUS_NAMESPACE, BookingServiceConstants.AMADEUS_SOAP_ACTION_URL), session);

		if (dcsidccprIdentificationReply.getErrors().size() > 0) {

			String errorCode = dcsidccprIdentificationReply.getErrors().get(0).getErrorOrWarningCodeDetails()
					.getErrorDetails().getErrorCode();

			if (errorCode.equals(RESCODE_BOOKING)) {
				logger.debug("Error in Amadeus response.");
				throw applicationServiceExceptionGenerator.createAplicationExceptionWithDeveloperMessage(
						AmadeusErrorCode.BOOKING_NOT_FOUND.name(),
						AmadeusErrorCode.BOOKING_NOT_FOUND.name() + RESMSG_BOOKINGIDENTIFER);
			} else {
				logger.debug("Error in Amadeus response.");
				throw applicationServiceExceptionGenerator.createAplicationExceptionWithDeveloperMessage(
						AmadeusErrorCode.SYSTEM_UNAVAILABLE.name(),
						AmadeusErrorCode.SYSTEM_UNAVAILABLE.name() + RESMSG_BOOKINGIDENTIFER);

			}

		}
		return dcsidccprIdentificationReply;
	}

}
