package com.iag.business.booking.constants;

public class BookingServiceConstants {
	public static final String AMADEUS_SOAP_ACTION_URL = "amadeus_soapAction_url";
	public static final String FLIGHT_SEGMENT_STATUS_CONFIRM = "flight_segment_status_confirm";
	public static final String ATTRIBUTE_TYPE_RETURN = "ATTRIBUTE_TYPE_RETURN";
	public static final String ATTRIBUTE_TYPE_INBOUND = "ATTRIBUTE_TYPE_INBOUND";
	public static final String ATTRIBUTE_TYPE_ONWARD = "ATTRIBUTE_TYPE_ONWARD";
	public static final String GATE_NO_NA = "GATE_NO_NA";
	public static final String FLIGHT_LEG_DEPARTURE_STD = "FLIGHT_LEG_DEPARTURE_STD";
	public static final String FLIGHT_LEG_ARRIVAL_STA = "FLIGHT_LEG_ARRIVAL_STA";
	public static final String SESSION_NODE_KEY = "Session";
	public static final String SESSION_ID_NODE_KEY = "SessionId";
	public static final String SEQUENCE_NUMBER_NODE_KEY = "SequenceNumber";
	public static final String SECURITY_TOKEN_NODE_KEY = "SecurityToken";
	public static final String AMADEUS_GATEWAY_WEBURL = "AMADEUS_GATEWAY_WEBURL";
	public static final String AMADEUS_RESPONSE_MARSHALLER = "AMADEUS_RESPONSE_MARSHALLER";
	public static final String AMADEUS_RESPONSE_UNMARSHALLER = "AMADEUS_RESPONSE_UNMARSHALLER";
	public static final String MESSAGE_CONFIGURATION_KEYWORD = "msg-";
	public static final String KEY_SEPARATOR_DOT = ".";
	public static final String KEY_SEPARATOR = "-";
	public static final String ACCEPTANCESTATUS = "AC";
	public static final String BOARDINGSTATUS = "BO";
	public static final String OPEN = "OP";
	public static final String CLOSED = "CL";
	public static final String SUSPENDED = "SPD";
	public static final String NOTOPEN = "NO";
	public static final String ERROR_NAMESPACE = "Error";
	public static final String AMADEUS_NAMESPACE = "AmadeusConnectivity";
	public static final String AMADEUSCODES_NAMESPACE = "AmadeusCodes";
	
	
}
