package com.iag.domain.model.party;

import java.io.Serializable;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.joda.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.iag.domain.model.adapters.JodaLocalDateAdapter;
import com.iag.domain.model.adapters.JsonJodaDateDeSerializer;
import com.iag.domain.model.adapters.JsonJodaDateSerializer;
import com.iag.domain.model.location.Location;
import com.iag.domain.model.utility.ToStringBuilder;

/**
 * Identification details of a person such as passport details, national id details etc.
 * @param <K> The id number of this RegisteredIdentifier.
 * @param areaOfApplicability : a list of {@link Location} where this identifier is valid.
 * @param type : type of identifier e.g.PASSPORT.
 * @param placeOfIssue : placeOfIssue as a Location type.
 */
@SuppressWarnings("serial")
@JsonInclude(Include.NON_EMPTY)
public class RegisteredIdentifier<K> implements Serializable {
	
	private RegisteredIdentifierType type;
	private Location<?> areaOfApplicability;
	private String token;
	private Location<?> placeOfIssue;
	private Person<K> person;
	@XmlJavaTypeAdapter(JodaLocalDateAdapter.class)
	@JsonSerialize(using = JsonJodaDateSerializer.class)
	@JsonDeserialize(using = JsonJodaDateDeSerializer.class)
	@JsonInclude(Include.ALWAYS)
	private LocalDate expiryDate;
	

	/**
	 * private default constructor helps to create instances of this class at
	 * runtime by frameworks like jaxb.
	 */
	@SuppressWarnings("unused")
	private RegisteredIdentifier() {

	}

	/**
	 * Populate token,areaOfApplicability and type of a registered Identifier.
	 * 
	 * @param token
	 * @param areaOfApplicability
	 * @param type
	 * @param placeOfIssue
	 */
	public RegisteredIdentifier(final String token, final Location<?> areaOfApplicability,
			final RegisteredIdentifierType type, final Location<?> placeOfIssue, LocalDate expiryDate, Person person) {

		this.token = token;
		this.areaOfApplicability = areaOfApplicability;
		this.type = type;
		this.placeOfIssue = placeOfIssue;
		this.expiryDate = expiryDate;
		this.person = person;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public String getToken() {
		return token;
	}

	public Location<?> getAreaOfApplicability() {
		return areaOfApplicability;
	}

	public RegisteredIdentifierType getType() {
		return type;
	}

	public Location<?> getPlaceOfIssue() {
		return placeOfIssue;
	}

	public Person<K> getPerson() {
		return person;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}

	@Override
	public final String toString() {
		return ToStringBuilder.generateToString(this);
	}

}
