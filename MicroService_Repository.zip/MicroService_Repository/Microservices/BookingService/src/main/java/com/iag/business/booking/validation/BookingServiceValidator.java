package com.iag.business.booking.validation;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.iag.application.exception.ValidationServiceException;
import com.iag.business.booking.exception.ValidationServiceExceptionGenerator;

@Component
public class BookingServiceValidator {
	private static final Logger logger = LoggerFactory.getLogger(BookingServiceValidator.class);

	private final BookingIdentifierValidation bookingIdentifierValidation;
	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	@Autowired
	public BookingServiceValidator(BookingIdentifierValidation bookingIdentifierValidation,
			ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.bookingIdentifierValidation = bookingIdentifierValidation;
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * @param bookingIdentifier
	 */
	public void validate(final String bookingIdentifier) {
		logger.debug("start method: validate() ");

		List<ValidationServiceException> validationServiceExceptionlist = Lists.newArrayList();
		ValidationServiceException bookingValidationException = bookingIdentifierValidation.validate(bookingIdentifier);
         
		if (bookingValidationException != null)
			validationServiceExceptionlist.add(bookingValidationException);

		if (!validationServiceExceptionlist.isEmpty()) {
			throw validationServiceExceptionGenerator
					.createServiceExceptionWithChildError(validationServiceExceptionlist);
		}
		logger.info("method End: validate() ");

	}
}
