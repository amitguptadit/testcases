package com.iag.business.booking.urlgenerator;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.google.common.collect.FluentIterable;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;

/**
 * Provides generator to generate service url by consuming service name.
 */
@Component
public class ServiceUrlGenerator {
	private final EurekaClient springDiscoveryClient;

	private String url;

	private static final String COLON = ":";

	private static final String URL_PATH_SEPARATOR = "://";

	private static final String SCHEME = "http";

	/**
	 * Instantiate service url generator to generate service url.
	 * 
	 * @param springDiscoveryClient
	 */
	@Autowired
	public ServiceUrlGenerator(final EurekaClient springDiscoveryClient) {
		this.springDiscoveryClient = springDiscoveryClient;
	}

	/**
	 * Generates complete service URL by consuming service name.
	 * 
	 * @param serviceName
	 *            - Eureka application name to be looked up
	 * @return url
	 * 
	 */
	public String generateUrl(final String serviceName) {

		Application application = springDiscoveryClient.getApplication(serviceName);

		if (application != null) {

			List<InstanceInfo> serviceInstances = application.getInstances();
			if (CollectionUtils.isEmpty(serviceInstances)) {
				return null;
			}
			InstanceInfo instanceInfo = FluentIterable.from(serviceInstances).first().get();

			url = SCHEME + URL_PATH_SEPARATOR + instanceInfo.getIPAddr() + COLON + instanceInfo.getPort();
		}

		/*
		 * List<ServiceInstance> serviceInstances =
		 * springDiscoveryClient.getInstances(serviceName); if
		 * (CollectionUtils.isEmpty(serviceInstances)) { return null; }
		 */
		// return serviceInstances.get(0).getUri().toString();

		return url;
	}
}