package com.iag.domain.model.adapters;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.ReadablePartial;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

/**
 * JodaDateTimeAdapter convert LocalDate into String format and vice-versa.
 */
public class JodaLocalDateAdapter extends XmlAdapter<String, LocalDate> {

  /*
   * (non-Javadoc)
   * @see javax.xml.bind.annotation.adapters.XmlAdapter#unmarshal(java.lang.Object)
   */
  @Override
  public LocalDate unmarshal(final String date) {
    if (date == null) {
      return null;
    }
    DateTime dateTime = ISODateTimeFormat.dateParser().parseDateTime(date);
    return new LocalDate(dateTime.getYear(), dateTime.getMonthOfYear(), dateTime.getDayOfMonth(), null);
  }

  /*
   * (non-Javadoc)
   * @see javax.xml.bind.annotation.adapters.XmlAdapter#marshal(java.lang.Object)
   */
  @Override
  public String marshal(final LocalDate localDate) {
    return print(localDate, ISODateTimeFormat.date());
  }

  private static String print(final ReadablePartial readablePartial, final DateTimeFormatter dateTimeFormatter) {
    if (readablePartial == null) {
      return null;
    }
    return dateTimeFormatter.print(readablePartial);
  }
}
