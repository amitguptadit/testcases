package com.iag.business.booking.service;


import java.util.List;

import com.iag.domain.model.booking.Booking;
import com.iag.domain.model.booking.BookingSearchCriteria;
import com.iag.domain.model.booking.Bookings;
import com.iag.domain.model.session.Session;

public interface BookingService {

	Booking getBooking(String bookingIdentifier, Session session);

	List<Booking> getBookings(BookingSearchCriteria bookingSearchCriteria, Session session);

}
