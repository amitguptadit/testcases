package com.iag.business.booking.exception;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.exception.ValidationServiceException;
import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.error.BookingErrorCode;
import com.iag.business.booking.proxy.ServiceProxy;

@Component
public class ValidationServiceExceptionGenerator {

	private static final Logger logger = LoggerFactory.getLogger(ValidationServiceExceptionGenerator.class);

	@Autowired
	private ServiceProxy configurationInfrastructureServiceProxy;
	public static final String MESSAGE_CONFIGURATION_KEYWORD = "msg-";
	public static final String KEY_SEPARATOR_DOT = ".";
	public static final String KEY_SEPARATOR = "-";

	/**
	 * constructor method.
	 * 
	 * @param configurationInfrastructureServiceProxy
	 */

	@Autowired
	public ValidationServiceExceptionGenerator(final ServiceProxy configurationInfrastructureServiceProxy) {
		this.configurationInfrastructureServiceProxy = configurationInfrastructureServiceProxy;
	}

	/**
	 * This method is used to create validationServiceExceptionList.
	 * 
	 * @param serviceErrorCode
	 * @param path
	 * @param developerMessage
	 * @return
	 */
	public ValidationServiceException createValidationError(final String serviceErrorCode, final String path,
			final String developerMessage) {
		ValidationServiceException validationServiceException = new ValidationServiceException(serviceErrorCode);
		validationServiceException.setPath(path);
		validationServiceException.setDeveloperMessage(getMessageConfigurationValue(developerMessage));
		return validationServiceException;
	}

	/**
	 * Method to create ValidationServiceException with child errors.
	 * 
	 * @param validationServiceExceptionList
	 * @return
	 */
	public ValidationServiceException createServiceExceptionWithChildError(
			final List<ValidationServiceException> validationServiceExceptionList) {
		logger.info("start End: createServiceExceptionWithChildError()");

		ValidationServiceException validationServiceException = new ValidationServiceException(
				BookingErrorCode.REQUEST_INVALID.name());
		for (ValidationServiceException childValidationServiceException : validationServiceExceptionList) {
			validationServiceException.addValidationException(childValidationServiceException);
		}
		logger.info("method End: createServiceExceptionWithChildError()");
		return validationServiceException;
	}

	/**
	 * Method to create Service exception with path, error code and developer
	 * message.
	 * 
	 * @param errorCode
	 * @param errorPath
	 * @param developerMessage
	 * @return
	 */
	public ValidationServiceException createServiceException(final String errorCode, final String errorPath,
			final String developerMessage) {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				BookingErrorCode.REQUEST_INVALID.name());
		validationServiceException
				.addValidationException(createValidationError(errorCode, errorPath, developerMessage));
		return validationServiceException;
	}

	/**
	 * Function to get the message based on the message key.
	 * 
	 * @param key
	 * @return
	 */
	public String getMessageConfigurationValue(final String key) {
		if (!StringUtils.EMPTY.equals(StringUtils.trimToEmpty(key))) {
			return configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE, key);
		}
		return StringUtils.EMPTY;
	}

}
