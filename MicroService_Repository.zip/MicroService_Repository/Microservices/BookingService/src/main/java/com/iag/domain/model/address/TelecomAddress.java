package com.iag.domain.model.address;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.iag.domain.model.utility.ToStringBuilder;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * TelecomAddress class represents telecom details which could be various types
 * such as mobile,residential phone etc.
 * 
 * @param countryDiallingCode
 *          : two letter iso country code represented as String.
 * @param areaCode
 *          : numeric Area Code for this {@link Address} represented as String.
 * @param number
 *          : the numeric phone number represented as String.
 */
@JsonInclude(Include.NON_EMPTY)
public class TelecomAddress extends Address implements Serializable {
  private String countryDiallingCode;
  private String areaCode;
  private String number;

  /**
   * private default constructor helps to create instances of this class at
   * runtime by frameworks like jaxb.
   */
  @SuppressWarnings("unused")
  private TelecomAddress() {
  }

  /**
   * Constructs object to initialise the device type,number of Telecom and area
   * code,country code.
   * 
   * @param isoCountryCode
   * @param areaCode
   * @param countryCode
   * @param number
   * @param deviceType
   * @param platformType
   */
  public TelecomAddress(final String number) {
    this.number = number;
  }
  
  /**
   * The direct dialling code required to call the telecom address from another country. Also referred to as the International Subscriber Dialling (ISD) code. This value is not prefixed with leading zeros or a plus (+), for example, UK telephone numbers will have a country code value of 44. If the country dialling code is not present then the countryCode is used for validating the telecom address.
   * 
   */
  @JsonProperty("countryDiallingCode")
  public void setCountryDiallingCode(String countryDiallingCode) {
      this.countryDiallingCode = countryDiallingCode;
  }
  

  public String getCountryDiallingCode() {
    return countryDiallingCode;
  }
  
  /**
   * The area code of the telephone number. The total length of combination of the countryDiallingCode, area code and the number cannot exceed 20 characters. Numeric only.
   * 
   */
  @JsonProperty("areaCode")
  public void setAreaCode(String areaCode) {
      this.areaCode = areaCode;
  }

  public String getAreaCode() {
    return areaCode;
  }
  
  public String getNumber() {
    return number;
  }

  
  @Override
  public int hashCode() {
    return HashCodeBuilder.reflectionHashCode(this);
  }

  @Override
  public boolean equals(final Object obj) {
    return EqualsBuilder.reflectionEquals(this, obj);
  }

  @Override
  public final String toString() {
    return ToStringBuilder.generateToString(this);
  }

}
