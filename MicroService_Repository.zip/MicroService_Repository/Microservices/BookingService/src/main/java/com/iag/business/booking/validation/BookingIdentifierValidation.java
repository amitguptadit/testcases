/**
 * 
 */
package com.iag.business.booking.validation;

import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.error.MessageConstants;
import com.iag.application.exception.ValidationServiceException;
import com.iag.business.booking.error.BookingErrorCode;
import com.iag.business.booking.exception.ValidationServiceExceptionGenerator;

/**
 * @author n485122
 *
 */
@Component
public class BookingIdentifierValidation {
	private static final Logger logger = LoggerFactory.getLogger(BookingIdentifierValidation.class);
	private static final String BOOKINGIDENTIFER = "[a-zA-Z0-9]{1,20}";
	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;
	private static final String BOOKINGIDENTIFER_PATH = "booking-identifier";
	private static final String DEVMSG_BOOKINGIDENTIFER = ".developer_message_bookingidentifier";

	/**
	 * @param validationServiceExceptionGenerator
	 */
	@Autowired
	public BookingIdentifierValidation(final ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	public ValidationServiceException validate(final String bookingIdentifier) {
		logger.info("start method:validate(), Booking-Identifier: {}", bookingIdentifier);
		ValidationServiceException bookingValidationServiceException = null;

		Pattern bookingIdentifierMatcher = Pattern.compile(BOOKINGIDENTIFER);
		if (!bookingIdentifierMatcher.matcher(bookingIdentifier).matches()) {
			bookingValidationServiceException = validationServiceExceptionGenerator.createValidationError(
					BookingErrorCode.DATA_INVALID.name(), BOOKINGIDENTIFER_PATH,
					MessageConstants.BOOKING_ERROR + BookingErrorCode.DATA_INVALID.name() + DEVMSG_BOOKINGIDENTIFER);

		}
		logger.info("end method: validate()");
		return bookingValidationServiceException;
	}

}
