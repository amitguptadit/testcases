package com.iag.domain.model.adapters;

import java.io.IOException;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.ISODateTimeFormat;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

/**
 * JsonJodaDateDeSerializer used to deserialize the LocalDate.
 * It converts json string of LocalDate into joda LocalDate object.
 */
public class JsonJodaDateDeSerializer extends JsonDeserializer<LocalDate> {

  /**
   * It converts date in String format to {@link LocalDate}.
   */
  @Override
  public LocalDate deserialize(final JsonParser jsonparser, final DeserializationContext deserializationcontext)
      throws IOException {
    DateTime dateTime = ISODateTimeFormat.dateParser().parseDateTime(jsonparser.getText());
    return new LocalDate(dateTime.getYear(), dateTime.getMonthOfYear(), dateTime.getDayOfMonth(), null);

  }
}
