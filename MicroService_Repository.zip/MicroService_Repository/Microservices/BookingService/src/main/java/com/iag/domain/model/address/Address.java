package com.iag.domain.model.address;

import javax.xml.bind.annotation.XmlSeeAlso;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

/**
 * Address class defines a prototype for all types of addresses such as EmailAddress,
 * PostalAddress, TelecomAddress etc.
 * @param preferred : if set to true, would make this address preferred one.
 * @param type : Type of address e.g.BUSINESS, RESIDENTIAL
 */
@XmlSeeAlso({PostalAddress.class })
@JsonSubTypes({
    @JsonSubTypes.Type(value = PostalAddress.class, name = "postalAddress"),
})
@JsonInclude(Include.NON_EMPTY)
public abstract class Address {
  }
