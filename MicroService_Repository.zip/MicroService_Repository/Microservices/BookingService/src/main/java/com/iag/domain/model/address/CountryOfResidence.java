
package com.iag.domain.model.address;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iag.domain.model.utility.ToStringBuilder;


/**
 * ISO 3166-1 code for the country. Is a 2 letter code specific to a country.e.g. GB, ES etc.
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "type",
    "identifier"
})
public class CountryOfResidence {

    public CountryOfResidence(String type, String identifier) {
		super();
		this.type = type;
		this.identifier = identifier;
	}

	/**
     * COUNTY, COUNTRY of the area/region.
     * (Required)
     * 
     */
    @JsonProperty("type")
    @JsonPropertyDescription("COUNTY, COUNTRY of the area/region.")
    private String type;
    /**
     * Identifier of the region/area.
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    @JsonPropertyDescription("Identifier of the region/area.")
    private String identifier;
   
    /**
     * COUNTY, COUNTRY of the area/region.
     * (Required)
     * 
     */
    @JsonProperty("type")
    public String getType() {
        return type;
    }

    
    /**
     * Identifier of the region/area.
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    public String getIdentifier() {
        return identifier;
    }

    
    
    @Override
    public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {
      return ToStringBuilder.generateToString(this);
    }


    
}
