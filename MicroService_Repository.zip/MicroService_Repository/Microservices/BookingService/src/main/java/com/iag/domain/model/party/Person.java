package com.iag.domain.model.party;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.joda.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.iag.domain.model.adapters.JodaLocalDateAdapter;
import com.iag.domain.model.adapters.JsonJodaDateDeSerializer;
import com.iag.domain.model.adapters.JsonJodaDateSerializer;
import com.iag.domain.model.address.PostalAddress;
import com.iag.domain.model.address.TelecomAddress;
import com.iag.domain.model.location.Location;
import com.iag.domain.model.utility.ToStringBuilder;

/**
 * This class depicts a Person and contains personal information about that Person.
 * More specifically, a Person could be a loyalty member taking benefits of a
 * Loyalty programme.
 * @param <K> id for a Person.
 * @param dateOfBirth : dob of the person represented in {@link LocalDate}.
 * @param personName : name of this person represented as {@link PersonName}.
 * @param otherNames : list of other names for this person represented as {@link PersonName}.
 * @param gender : gender of this person e.g. MALE.
 * @param registeredIdentifiers : list of all identifications for this person represented as
 *          {@link RegisteredIdentifier}.
 * @param locale : locale to which this person belongs.
 * @param countryOfResidence : countryOfResidence for this person represented as {@link Location}.
 */
@SuppressWarnings("serial")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@JsonTypeName("person")
@JsonInclude(Include.NON_EMPTY)
public final class Person<K> extends Party<K> {
  @XmlJavaTypeAdapter(JodaLocalDateAdapter.class)
  @JsonSerialize(using = JsonJodaDateSerializer.class)
  @JsonDeserialize(using = JsonJodaDateDeSerializer.class)
  private LocalDate dateOfBirth;
  private PersonName personName;
  private Gender gender;
  @JsonProperty("registered-Identifiers")
  private List<RegisteredIdentifier<?>> registeredIdentifiers;
  private Location<?> countryOfResidence;
  /**
   * 
   * (Required)
   * 
   */
  @JsonProperty("telecomAddresses")
  private List<TelecomAddress> telecomAddresses = new ArrayList<TelecomAddress>();
  /**
   * 
   * (Required)
   * 
   */
  @JsonProperty("postalAddresses")
  private List<PostalAddress> postalAddresses = new ArrayList<PostalAddress>();
  
  @JsonProperty("nationality")
  private Nationality nationality;
  
  /**
   * Default constructor,reflectively picked by frameworks like jaxb to create and initialise the state of object.
   */
  private Person() {

  }

  /**
   * Class can not be directly instantiated from the client code.
   * @param builder
   */
  private Person(final PersonBuilder<K> builder) {
    this();
    this.dateOfBirth = builder.dateOfBirth;
    this.personName = builder.personName;
    this.gender = builder.gender;
    this.registeredIdentifiers = builder.registeredIdentifiers;
    this.countryOfResidence = builder.countryOfResidence;
    this.postalAddresses = builder.postalAddresses;
    this.nationality = builder.nationality;
    this.telecomAddresses = builder.telecomAddresses;
  }


  public LocalDate getDateOfBirth() {
    return dateOfBirth;
  }

  public PersonName getPersonName() {
    return personName;
  }

  public Gender getGender() {
    return gender;
  }

  public List<TelecomAddress> getTelecomAddresses(){
	  return telecomAddresses;
  }

  public  List<PostalAddress> getPostalAddresses(){
	  return postalAddresses;
  }
  
  public Nationality getNationality() {
	  return nationality;
  }
  
  /**
   * It returns Identification details of a person such as passport details.
   * @return List<RegisteredIdentifier<?>>
   */
  public List<RegisteredIdentifier<?>> getRegisteredIdentifiers() {
    return registeredIdentifiers;
  }
  
  public Location<?> getCountryOfResidence() {
    return countryOfResidence;
  }

  /**
   * Builder Class of Person which populates mandatory fields and allows some of its fields to be populated
   * optionally,making Person immutable at the same time.
   * @param <K>
   */
  public static class PersonBuilder<K> {
    private LocalDate dateOfBirth;
    private PersonName personName;
    private Gender gender;
    private List<RegisteredIdentifier<?>> registeredIdentifiers;
    private Location<?> countryOfResidence;
    
    @JsonProperty("telecomAddresses")
    private List<TelecomAddress> telecomAddresses = new ArrayList<TelecomAddress>();
    


	/**
     * 
     * (Required)
     * 
     */
    @JsonProperty("postalAddresses")
    private List<PostalAddress> postalAddresses = new ArrayList<PostalAddress>();
    
    @JsonProperty("nationality")
    private Nationality nationality;
    
    //private ProfileStatus profileStatus;
    /**
     * Builder constructor only receives the required attributes.
     * @param name
     */
    public PersonBuilder(final PersonName name) {
      this.personName = name;
    }
    
    
    
    public PersonBuilder<K> setPostalAddresses(List<PostalAddress> postalAddresses) {
		this.postalAddresses = postalAddresses;
		return this;
	}
    
    public PersonBuilder<K> setTelecomAddresses(List<TelecomAddress> telecomAddresses) {
		this.telecomAddresses = telecomAddresses;
		return this;
	}
    
    /**
     * Initialise optional attributes gender.
     * @param residence
     * @return
     */
    public PersonBuilder<K> setRegisteredIdentifier(final List<RegisteredIdentifier<?>> registeredIdentifiers) {
      this.registeredIdentifiers = registeredIdentifiers;
      return this;
    }
    
    /**
     * Initialise optional attributes gender.
     * @param residence
     * @return
     */
    public PersonBuilder<K> setDateOfBirth(final LocalDate dateOfBirth) {
      this.dateOfBirth = dateOfBirth;
      return this;
    }
    
    /**
     * Initialise optional attributes gender.
     * @param residence
     * @return
     */
    public PersonBuilder<K> setGender(final Gender gender) {
      this.gender = gender;
      return this;
    }
    
    /**
     * Initialise optional attributes nationality.
     * @param residence
     * @return
     */
    public PersonBuilder<K> setNationality(final Nationality nationality) {
      this.nationality = nationality;
      return this;
    }
    
    

    /**
     * Initialise optional attributes countryOfResidence.
     * @param residence
     * @return
     */
    public PersonBuilder<K> setCountryOfResidence(final Location<?> residence) {
      this.countryOfResidence = residence;
      return this;
    }


   /*public PersonBuilder<K> setProfileStatus(final ProfileStatus profileStatus) {
     this.profileStatus = profileStatus;
     return this;
   }*/
   

    /**
     * Method finally returns the built instance.
     * @return
     */
    public Person<K> build() {
      return new Person<K>(this);
    }
  }

  @Override
  public int hashCode() {
    return HashCodeBuilder.reflectionHashCode(this);
  }

  @Override
  public boolean equals(final Object obj) {
    return EqualsBuilder.reflectionEquals(this, obj);
  }

  @Override
  public String toString() {
    return ToStringBuilder.generateToString(this);
  }

}
