package com.iag.domain.model.booking;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iag.domain.model.utility.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"total-records",
    "bookings"
})
public class Bookings {
	
	/**
     * 
     * (Required)
     * 
     */
    @JsonProperty("bookings")
    private List<Booking> bookings = new ArrayList<Booking>();
    
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("total-records")
    private int totalRecords;
    
    public Bookings(BookingsBuilder bookingsBuilder) {
		this.bookings = bookingsBuilder.bookings;
		this.totalRecords = bookingsBuilder.totalRecords;
	}


    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("bookings")
    public List<Booking> getBookings() {
        return bookings;
    }
    
    public static class BookingsBuilder {
    	
    	 /**
         * 
         * (Required)
         * 
         */
        @JsonProperty("bookings")
        private List<Booking> bookings = new ArrayList<Booking>();
        
        /**
         * 
         * (Required)
         * 
         */
        @JsonProperty("total-records")
        private int totalRecords;
        
        
        /**
         * Builder constructor only receives the required attributes.
         * @param bookings
         */
        public BookingsBuilder(final List<Booking> bookings, int totalRecords) {
          this.bookings = bookings;
          this.totalRecords = totalRecords;
        }
        
        /**
         * Method finally returns the built instance.
         * @return
         */
        public Bookings build() {
          return new Bookings(this);
        }
    	
    }
    
    @Override
    public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {
      return ToStringBuilder.generateToString(this);
    }
    
}
