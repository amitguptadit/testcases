package com.iag.domain.model.flight;

public enum FlightSegmentType {

    INBOUND,
    OUTBOUND,
    ONWARD,
    RETURN
}
