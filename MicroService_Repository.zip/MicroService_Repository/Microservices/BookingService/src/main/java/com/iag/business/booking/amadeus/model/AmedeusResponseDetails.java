package com.iag.business.booking.amadeus.model;

public class AmedeusResponseDetails {

	private Object response;
	private String securityToken;
	private int sequenceNumber;
	private String sessionId;

	public Object getSoapResponse() {
		return response;
	}

	public void setSoapResponse(Object response) {
		this.response = response;
	}

	public String getSecurityToken() {
		return securityToken;
	}

	public void setSecurityToken(String securityToken) {
		this.securityToken = securityToken;
	}

	public int getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(int sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public AmedeusResponseDetails set(AmedeusResponseDetails extractSoapHeader) {
		return this;
	}

}
