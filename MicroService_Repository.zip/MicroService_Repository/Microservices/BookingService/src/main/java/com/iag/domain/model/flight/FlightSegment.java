
package com.iag.domain.model.flight;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.joda.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.iag.domain.model.Carrier;
import com.iag.domain.model.Destination;
import com.iag.domain.model.Origin;
import com.iag.domain.model.adapters.JodaLocalDateTimeAdapter;
import com.iag.domain.model.adapters.JsonJodaDateTimeDeSerializer;
import com.iag.domain.model.adapters.JsonJodaDateTimeSerializer;
import com.iag.domain.model.utility.ToStringBuilder;

/**
 * a flight segment as the operation of a flight with a single flight designator
 * between the point where passengers first board an aircraft and the
 * passengers' final destination. A flight designator includes an airline code,
 * which has two letters or a number and a letter in combination, and a flight
 * number of up to four digits. A flight segment can include any number of stops
 * where passengers board and deplane the same aircraft operated by a single
 * airline.
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "identifier", "type", "statuses", "origin", "destination", "scheduledDepartureLocalDatetime",
		"scheduledArrivalLocalDatetime", "carriers", "flightLegs" })
public class FlightSegment implements Serializable {

	private FlightSegment() {
	}

	/**
	 * identifier for the flight segment
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("identifier")
	@JsonPropertyDescription("identifier for the flight sergment\n")
	private String identifier;

	/**
	 * Segment type - INBOUND : flights taken by passenger before arriving at
	 * current airport - OUTBOUND : next flight which passenger can undertake -
	 * ONWARD : Flight which can be taken next to OUTBOUND flight - RETURN :
	 * return flight to the same airport passenger is currently at
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("type")
	@JsonPropertyDescription("Segment type\n- INBOUND : flights taken by passenger before arriving at current airport\n- OUTBOUND : next flight which passenger can undertake\n- ONWARD : Flight which can be taken next to OUTBOUND flight\n- RETURN : return flight to the same airport passenger is currently at\n")
	private FlightSegmentType type;
	/**
	 * Status of the flight - CONFIRMED : If the flight is confirmed -
	 * UNCONFIRMED : If the flight is still not confirmed - DELAYED : If the
	 * flight is delayed
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("statuses")
	@JsonPropertyDescription("Statuses of the flight\n- CONFIRMED : If the flight is confirmed\n- UNCONFIRMED : If the flight is still not confirmed\n- DELAYED : If the flight is delayed\n")
	private FlightSegmentStatuses status;
	/**
	 * Origin location of the first leg of the segment (Required)
	 * 
	 */
	@JsonProperty("origin")
	@JsonPropertyDescription("Origin location of the first leg of the segment")
	private Origin origin;
	/**
	 * Destination location of the last leg of the segment (Required)
	 * 
	 */
	@JsonProperty("destination")
	@JsonPropertyDescription("Destination location of the last leg of the segment")
	private Destination destination;
	/**
	 * Scheduled departure local date and time of the flight from origin
	 * location of the first leg. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601
	 * calendar date format. (Required)
	 * 
	 */
	@JsonProperty("scheduledDepartureLocalDatetime")
	@JsonPropertyDescription("Scheduled departure local date and time of the flight from origin location of the first leg. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.")
	@XmlJavaTypeAdapter(JodaLocalDateTimeAdapter.class)
	@JsonSerialize(using = JsonJodaDateTimeSerializer.class)
	@JsonDeserialize(using = JsonJodaDateTimeDeSerializer.class)
	private LocalDateTime scheduledDepartureLocalDatetime;
	/**
	 * Scheduled arrival local date and time of flight at destination location
	 * of the last leg. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar
	 * date format. (Required)
	 * 
	 */
	@JsonProperty("scheduledArrivalLocalDatetime")
	@JsonPropertyDescription("Scheduled arrival local date and time of flight at destination location of the last leg. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.")
	@XmlJavaTypeAdapter(JodaLocalDateTimeAdapter.class)
	@JsonSerialize(using = JsonJodaDateTimeSerializer.class)
	@JsonDeserialize(using = JsonJodaDateTimeDeSerializer.class)
	private LocalDateTime scheduledArrivalLocalDatetime;
	/**
	 * collection of carriers (Required)
	 * 
	 */
	@JsonProperty("carriers")
	@JsonPropertyDescription("collection of carriers")
	private List<Carrier> carriers = new ArrayList<Carrier>();
	/**
	 * flight legs which form part of the flight segment (Required)
	 * 
	 */
	@JsonProperty("flightLegs")
	@JsonPropertyDescription("flight legs which form part of the flight segment")
	private List<FlightLeg> flightLegs = new ArrayList<FlightLeg>();

	public FlightSegment(FlightSegmentBuilder flightSegmentBuilder) {
		this.type = flightSegmentBuilder.type;
		this.status = flightSegmentBuilder.status;
		this.origin = flightSegmentBuilder.origin;
		this.destination = flightSegmentBuilder.destination;
		this.carriers = flightSegmentBuilder.carriers;
		this.scheduledDepartureLocalDatetime = flightSegmentBuilder.scheduledDepartureLocalDatetime;
		this.scheduledArrivalLocalDatetime = flightSegmentBuilder.scheduledArrivalLocalDatetime;
		this.flightLegs = flightSegmentBuilder.flightLegs;
		this.identifier = flightSegmentBuilder.identifier;
	}
	
	/**
	 * Identifier
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("identifier")
	public String getIdentifer() {
		return identifier;
	}

	/**
	 * Segment type - INBOUND : flights taken by passenger before arriving at
	 * current airport - OUTBOUND : next flight which passenger can undertake -
	 * ONWARD : Flight which can be taken next to OUTBOUND flight - RETURN :
	 * return flight to the same airport passenger is currently at
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("type")
	public FlightSegmentType getType() {
		return type;
	}

	/**
	 * Status of the flight - CONFIRMED : If the flight is confirmed -
	 * UNCONFIRMED : If the flight is still not confirmed - DELAYED : If the
	 * flight is delayed
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("statuses")
	public FlightSegmentStatuses getStatus() {
		return status;
	}

	/**
	 * Origin location of the first leg of the segment (Required)
	 * 
	 */
	@JsonProperty("origin")
	public Origin getOrigin() {
		return origin;
	}

	/**
	 * Destination location of the last leg of the segment (Required)
	 * 
	 */
	@JsonProperty("destination")
	public Destination getDestination() {
		return destination;
	}

	/**
	 * Scheduled departure local date and time of the flight from origin
	 * location of the first leg. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601
	 * calendar date format. (Required)
	 * 
	 */
	@JsonProperty("scheduledDepartureLocalDatetime")
	public LocalDateTime getScheduledDepartureLocalDatetime() {
		return scheduledDepartureLocalDatetime;
	}

	/**
	 * Scheduled arrival local date and time of flight at destination location
	 * of the last leg. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar
	 * date format. (Required)
	 * 
	 */
	@JsonProperty("scheduledArrivalLocalDatetime")
	public LocalDateTime getScheduledArrivalLocalDatetime() {
		return scheduledArrivalLocalDatetime;
	}

	/**
	 * collection of carriers (Required)
	 * 
	 */
	@JsonProperty("carriers")
	public List<Carrier> getCarriers() {
		return carriers;
	}

	/**
	 * flight legs which form part of the flight segment (Required)
	 * 
	 */
	@JsonProperty("flightLegs")
	public List<FlightLeg> getFlightLegs() {
		return flightLegs;
	}

	public static class FlightSegmentBuilder {
		
		/**
		 * identifier for the flight segment
		 * 
		 * (Required)
		 * 
		 */
		@JsonProperty("identifier")
		@JsonPropertyDescription("identifier for the flight sergment\n")
		private String identifier;
		
		@JsonProperty("type")
		@JsonPropertyDescription("Segment type\n- INBOUND : flights taken by passenger before arriving at current airport\n- OUTBOUND : next flight which passenger can undertake\n- ONWARD : Flight which can be taken next to OUTBOUND flight\n- RETURN : return flight to the same airport passenger is currently at\n")
		private FlightSegmentType type;
		/**
		 * Status of the flight - CONFIRMED : If the flight is confirmed -
		 * UNCONFIRMED : If the flight is still not confirmed - DELAYED : If the
		 * flight is delayed
		 * 
		 * (Required)
		 * 
		 */
		@JsonProperty("statuses")
		@JsonPropertyDescription("Statuses of the flight\n- CONFIRMED : If the flight is confirmed\n- UNCONFIRMED : If the flight is still not confirmed\n- DELAYED : If the flight is delayed\n")
		private FlightSegmentStatuses status;
		/**
		 * Origin location of the first leg of the segment (Required)
		 * 
		 */
		@JsonProperty("origin")
		@JsonPropertyDescription("Origin location of the first leg of the segment")
		private Origin origin;
		/**
		 * Destination location of the last leg of the segment (Required)
		 * 
		 */
		@JsonProperty("destination")
		@JsonPropertyDescription("Destination location of the last leg of the segment")
		private Destination destination;
		/**
		 * Scheduled departure local date and time of the flight from origin
		 * location of the first leg. Format yyyy-mm-ddThh:mm:ss.ffffff,
		 * ISO-8601 calendar date format. (Required)
		 * 
		 */
		@JsonProperty("scheduledDepartureLocalDatetime")
		@JsonPropertyDescription("Scheduled departure local date and time of the flight from origin location of the first leg. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.")
		@XmlJavaTypeAdapter(JodaLocalDateTimeAdapter.class)
		@JsonSerialize(using = JsonJodaDateTimeSerializer.class)
		@JsonDeserialize(using = JsonJodaDateTimeDeSerializer.class)
		private LocalDateTime scheduledDepartureLocalDatetime;
		/**
		 * Scheduled arrival local date and time of flight at destination
		 * location of the last leg. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601
		 * calendar date format. (Required)
		 * 
		 */
		@JsonProperty("scheduledArrivalLocalDatetime")
		@JsonPropertyDescription("Scheduled arrival local date and time of flight at destination location of the last leg. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.")
		@XmlJavaTypeAdapter(JodaLocalDateTimeAdapter.class)
		@JsonSerialize(using = JsonJodaDateTimeSerializer.class)
		@JsonDeserialize(using = JsonJodaDateTimeDeSerializer.class)
		private LocalDateTime scheduledArrivalLocalDatetime;
		/**
		 * collection of carriers (Required)
		 * 
		 */
		@JsonProperty("carriers")
		@JsonPropertyDescription("collection of carriers")
		private List<Carrier> carriers = new ArrayList<Carrier>();
		/**
		 * flight legs which form part of the flight segment (Required)
		 * 
		 */
		@JsonProperty("flightLegs")
		@JsonPropertyDescription("flight legs which form part of the flight segment")
		private List<FlightLeg> flightLegs = new ArrayList<FlightLeg>();

		public FlightSegmentBuilder(final FlightSegmentType flightSegmentType,
				final FlightSegmentStatuses flightSegmentStatus, final Origin origin, final Destination destination,
				final LocalDateTime scheduledDepartureLocalDatetime, final LocalDateTime scheduledArrivalLocalDatetime,
				final List<FlightLeg> flightLegs) {
			this.type = flightSegmentType;
			this.status = flightSegmentStatus;
			this.origin = origin;
			this.destination = destination;
			this.flightLegs = flightLegs;
			this.scheduledDepartureLocalDatetime = scheduledDepartureLocalDatetime;
			this.scheduledArrivalLocalDatetime = scheduledArrivalLocalDatetime;
		}

		/**
		 * collection of carriers (Required)
		 * 
		 */
		@JsonProperty("carriers")
		public FlightSegmentBuilder setCarriers(List<Carrier> carriers) {
			this.carriers = carriers;
			return this;
		}
		
		/**
		 * collection of carriers (Required)
		 * 
		 */
		@JsonProperty("identifier")
		public FlightSegmentBuilder setIdentifier(String identifier) {
			this.identifier = identifier;
			return this;
		}

		/**
		 * Method finally returns the built instance.
		 * 
		 * @return
		 */
		public FlightSegment build() {
			return new FlightSegment(this);
		}
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(final Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.generateToString(this);
	}

}
