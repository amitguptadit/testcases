package com.iag.application.exception;

/**
 * Validation exception factory to create validation exception from supplied input.This class is purposefully made
 * package private as its scope is within the package. Client using the error framework should not be aware of this low
 * level implementation.
 */
final class ValidationServiceExceptionFactory implements AbstractServiceExceptionFactory {

  private static final String PARENT_ERROR_CODE_POSTFIX = ".parent.code";
  private static final String ERROR_CODE_POSTFIX = ".code";

  @Override
  public ServiceException createServiceException(final String errorCode,
      final ExceptionProvider exceptionProvider) {
    // Create the parent
    ValidationServiceException parentValidationServiceException =
        new ValidationServiceException(exceptionProvider.getCode(errorCode + PARENT_ERROR_CODE_POSTFIX));

    ValidationServiceException exception =
        new ValidationServiceException(exceptionProvider.getCode(errorCode + ERROR_CODE_POSTFIX));
    parentValidationServiceException.addValidationException(exception);
    return parentValidationServiceException;
  }
}
