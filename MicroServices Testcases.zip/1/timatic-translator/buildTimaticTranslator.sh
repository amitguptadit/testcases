#!/bin/bash
##############################################################################
# 				Script to build the translator component
##############################################################################
#  Use Jdk 8 for building Springboot microservices
echo "Installing the necessary jar files in maven repository......................."
mvn install:install-file -Dfile="common/lib/castor-0.9.6.jar" -DgroupId="aero.sita" -DartifactId="castor" -Dversion="0.1" -Dpackaging="jar"
mvn install:install-file -Dfile="QueryInterface/build/jar/t3-QueryInterface-0.1.jar" -DgroupId="aero.sita" -DartifactId="QueryInterface" -Dversion="0.1" -Dpackaging="jar"
mvn install:install-file -Dfile="common/lib/xercesImpl-2.6.2.jar" -DgroupId="aero.sita" -DartifactId="xercesImpl" -Dversion="0.1" -Dpackaging="jar"
mvn install:install-file -Dfile="common/lib/GroboUtils-5-core.jar" -DgroupId="aero.sita" -DartifactId="GroboUtils" -Dversion="0.1" -Dpackaging="jar"
mvn install:install-file -Dfile="common/lib/commons-pool-1.6.jar" -DgroupId="aero.sita" -DartifactId="commons-pool" -Dversion="0.1" -Dpackaging="jar"
mvn install:install-file -Dfile="common/build/jar/t3-common-0.1.jar" -DgroupId="aero.sita" -DartifactId="common" -Dversion="0.1" -Dpackaging="jar"
mvn install:install-file -Dfile="common/lib/xalan.jar" -DgroupId="aero.sita" -DartifactId="xalan" -Dversion="0.1" -Dpackaging="jar"
mvn install:install-file -Dfile="common/lib/commons-lang-2.6.jar" -DgroupId="aero.sita" -DartifactId="commons-lang" -Dversion="0.1" -Dpackaging="jar"
mvn install:install-file -Dfile="common/lib/ojdbc6.jar" -DgroupId="aero.sita" -DartifactId="ojdbc6" -Dversion="0.1" -Dpackaging="jar"

mvn --file timatic-translator/pom.xml clean install

echo "Translator microservices jar built successfully"
