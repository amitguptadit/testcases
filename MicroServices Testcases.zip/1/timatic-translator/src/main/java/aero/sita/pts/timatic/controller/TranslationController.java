//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.
//**************************************************************************

package aero.sita.pts.timatic.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import aero.sita.pts.timatic.queryinterface.DocumentXMLProcessor;
import aero.sita.pts.timatic.queryinterface.XMLProcessor;
import aero.sita.pts.timatic.queryinterface.castor.generated.DocumentResponse;
import aero.sita.pts.timatic.service.TranslationService;

/**
 * The Class TranslationController.
 * 
 * @version $Id: TranslationController.java 13415 2019-01-04 14:50:34Z $
 * @author Gaurav Lal
 */
@EnableAutoConfiguration(exclude = HibernateJpaAutoConfiguration.class)
@RestController
public class TranslationController {

	/** The translation service. */
	@Autowired
	private TranslationService translationService;

	// logger
	private static final Logger logger = LoggerFactory.getLogger(TranslationController.class);

	/**
	 * Language translator.
	 *
	 * @param entityMap
	 *            the entity map
	 * @return the response entity
	 */
	@RequestMapping(value = "/translator", method = RequestMethod.POST)
	public ResponseEntity<String> languageTranslator(@RequestBody MultiValueMap<String, String> entityMap) {

		/** The xp. */
		XMLProcessor xp = null;
		/** The document response. */
		DocumentResponse documentResponse = null;

		/** The translated document response. */
		DocumentResponse translatedDocumentResponse = null;

		/** The translated xml response. */
		String translatedXmlResponse = null;

		String xmlResponse = entityMap.get("xmlResponse").get(0);
		String responseObjectType = entityMap.get("responseObjectType").get(0);
		String translationLanguage = entityMap.get("translationLanguage").get(0);
		logger.debug("xmlResponse: " + xmlResponse + " responseObjectType: " + responseObjectType);
		logger.info(" requested translationLanguage: " + translationLanguage);

		translatedXmlResponse = xmlResponse;
		try {
			Class classType = Class.forName(responseObjectType);
			if (null != translationLanguage) {
				xp = new DocumentXMLProcessor();
				documentResponse = (DocumentResponse) xp.parseXMLStringToDocumentResponse(xmlResponse, classType);
				translatedDocumentResponse = translationService.getTranslatedResponseObject(documentResponse,
						translationLanguage);
				translatedXmlResponse = xp.parseResponseToXMLString(translatedDocumentResponse);
				logger.debug("translatedXmlResponse: " + translatedXmlResponse);
			}
		} catch (Exception e) {
			logger.error("Error fetching the translations...");
			logger.error(e.getMessage(), e);
		}

		return new ResponseEntity<String>(translatedXmlResponse, HttpStatus.OK);
	}

}
