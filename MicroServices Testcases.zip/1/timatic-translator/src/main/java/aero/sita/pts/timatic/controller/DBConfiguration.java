//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.
//**************************************************************************
package aero.sita.pts.timatic.controller;

import java.util.Properties;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

// TODO: Auto-generated Javadoc
/**
 * Database configuration for Timatic translator functionality.
 *
 * @author Shweta Sharma
 * @version $Id: DBConfiguration.java 13415 2019-01-10 14:50:34Z $
 */

@Configuration
@EnableTransactionManagement
@ConfigurationProperties("spring.datasource")
public class DBConfiguration {

	 //logger
    private static final Logger logger = LoggerFactory.getLogger(DBConfiguration.class);
	/** The driver class name. */
	private String driverClassName;
	
	/** The url. */
	private String url;
	
	/** The username. */
	private String username;
	
	/** The password. */
	private String password;

	/** The dialect. */
	@Value("${hibernate.dialect}")
	private String DIALECT;

	/** The show sql. */
	@Value("${hibernate.show_sql}")
	private String SHOW_SQL;

	/** The packages to scan. */
	@Value("${entitymanager.packagesToScan}")
	private String PACKAGES_TO_SCAN;

	/**
	 * Dev data source connection.
	 *
	 * @return the string
	 */
	@Profile("dev")
	@Bean
	public String devDataSourceConnection() {
		return "DB Connection started for ..... DEV";
	}

	/**
	 * Test data source connection.
	 *
	 * @return the string
	 */
	@Profile("test")
	@Bean
	public String testDataSourceConnection() {
		return "DB Connection started for ..... TEST";
	}

	/**
	 * Stage data source connection.
	 *
	 * @return the string
	 */
	@Profile("stage")
	@Bean
	public String stageDataSourceConnection() {
		return "DB Connection started for ..... STAGE";
	}

	/**
	 * Prod data source connection.
	 *
	 * @return the string
	 */
	@Profile("prod")
	@Bean
	public String prodDataSourceConnection() {
		return "DB Connection started for ..... PROD";
	}
	
	/**
	 * Local data source connection.
	 *
	 * @return the string
	 */
	@Profile("local")
	@Bean
	public String localDataSourceConnection() {
		return "DB Connection started for ..... local";
	}

	/**
	 * Bean definition for SessionFactory.
	 * 
	 * @return LocalSessionFactoryBean.
	 */
	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource());
		sessionFactory.setPackagesToScan(PACKAGES_TO_SCAN);
		Properties hibernateProperties = new Properties();
		hibernateProperties.put("hibernate.dialect", DIALECT);
		hibernateProperties.put("hibernate.show_sql", SHOW_SQL);
		sessionFactory.setHibernateProperties(hibernateProperties);
		logger.info("session factory configured successfully");
		return sessionFactory;
	}

	/**
	 * Data source.
	 *
	 * @return the data source
	 */
	private DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driverClassName);
		dataSource.setUrl(url);
		dataSource.setUsername(username);
		dataSource.setPassword(password);
		return dataSource;
	}

	/**
	 * Bean definition for HibernateTransactionManager.
	 * 
	 * @return HibernateTransactionManager.
	 */
	@Bean
	public HibernateTransactionManager transactionManager() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setDataSource(dataSource());
		transactionManager.setSessionFactory(sessionFactory().getObject());
		return transactionManager;
	}

	/**
	 * Gets the driver class name.
	 *
	 * @return the driver class name
	 */
	public String getDriverClassName() {
		return driverClassName;
	}

	/**
	 * Sets the driver class name.
	 *
	 * @param driverClassName the new driver class name
	 */
	public void setDriverClassName(String driverClassName) {
		this.driverClassName = driverClassName;
	}

	/**
	 * Gets the url.
	 *
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * Sets the url.
	 *
	 * @param url the new url
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * Gets the username.
	 *
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * Sets the username.
	 *
	 * @param username the new username
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

}