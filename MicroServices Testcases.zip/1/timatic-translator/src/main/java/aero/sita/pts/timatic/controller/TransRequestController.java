//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.
//**************************************************************************

package aero.sita.pts.timatic.controller;

import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import aero.sita.pts.timatic.service.TransRequestService;
import aero.sita.pts.timatic.util.TranslatorUtil;

/**
 * The Class TransRequestController.
 *
 * @author Rajesh Varma
 * @version $Id: TransRequestController.java 13415 2019-01-04 14:50:34Z $
 */
@RestController
public class TransRequestController {

	/** The Constant logger. */
	// logger
	private static final Logger logger = LoggerFactory.getLogger(TransRequestController.class);

	/** The trans request service. */
	private TransRequestService transRequestService;

	/** The servlet context. */
	@Autowired
	private ServletContext servletContext;

	/** The env. */
	@Autowired
	private Environment env;

	/** The translator util. */
	@Autowired
	private TranslatorUtil translatorUtil;

	/**
	 * Language translator.
	 *
	 * @param entityMap
	 *            the entity map
	 * @return the response entity
	 */
	@RequestMapping(value = "/transrequest", method = RequestMethod.POST)
	public ResponseEntity<String> languageTranslator(@RequestBody Map<String, String> entityMap) {

		return new ResponseEntity<String>("", HttpStatus.OK);
	}

	/**
	 * This method calls the TransPerfect Api to get the valid sessionID
	 *
	 * @return the response entity
	 */
	@RequestMapping(value = "/translator/session", method = RequestMethod.GET)
	public ResponseEntity<String> getTransSession() {

		JSONObject sessionNode = null;
		ResponseEntity<String> response = null;
		if (servletContext.getAttribute("sessionTimeStamp") != null) {
			long currentTime = System.currentTimeMillis();
			long sessionTimeStamp = (long) servletContext.getAttribute("sessionTimeStamp");
			long diff = currentTime - sessionTimeStamp;
			sessionNode = (JSONObject) servletContext.getAttribute("sessionNode");
			if (diff < 1800000 && (null != sessionNode) && StringUtils.isNotBlank(sessionNode.toString())) {
				logger.info("Returing session ID from ServletContext " + sessionNode.toString());
				return new ResponseEntity<String>(sessionNode.toString(), HttpStatus.OK);
			}
		}

		try {
			RestTemplate restTemplate = new RestTemplate(translatorUtil.getHttpClientRequest());
			transRequestService = new TransRequestService(restTemplate, env);
			response = transRequestService.getTransSessionResponse();
			String responseBody = response.getBody();
			logger.debug("responseBody from Trans Perfect " + responseBody);
			if (StringUtils.isNotBlank(responseBody)) {
				JSONObject jsonObject = new JSONObject(responseBody);
				sessionNode = (JSONObject) jsonObject.get("response_data");
				logger.info("Session ID from Trans Perfect " + sessionNode);

			} else {
				logger.error("Response body from Trans Perfect is empty " + response);
				return new ResponseEntity<String>("Response body from Trans Perfect is empty ",
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (HttpClientErrorException e) {
			logger.error("Error while calling transperfect to get session id ...", e);
			return new ResponseEntity<String>(e.toString(), e.getStatusCode());
		} catch (Exception e) {
			logger.error("Error while calling transperfect to get session id ...", e);
			return new ResponseEntity<String>(e.toString(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		servletContext.setAttribute("sessionNode", sessionNode);
		servletContext.setAttribute("sessionTimeStamp", System.currentTimeMillis());
		return new ResponseEntity<String>(sessionNode.toString(), response.getStatusCode());
	}
}
