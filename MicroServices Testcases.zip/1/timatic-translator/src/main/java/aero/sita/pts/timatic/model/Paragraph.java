package aero.sita.pts.timatic.model;

import java.io.Serializable;

//**************************************************************************
//This code contains copyright information which is the proprietary property
//of SITA Advanced Travel Solutions. No part of this code may be reproduced,
//stored or transmitted in any form without the prior written permission of
//SITA Advanced Travel Solutions.
//
//Copyright © SITA Advanced Travel Solutions 2019
//Confidential. All rights reserved.
//**************************************************************************
/**
 * The Class Paragraph.
 */
public class Paragraph implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -563526674512867330L;

	/** The paragraph id. */
	private String paragraphId;

	/** The paragraph translated text. */
	private String paragraphTranslatedText;

	/** The language. */
	private String language;

	/**
	 * Gets the paragraph id.
	 *
	 * @return the paragraph id
	 */
	public String getParagraphId() {
		return paragraphId;
	}

	/**
	 * Sets the paragraph id.
	 *
	 * @param paragraphId the new paragraph id
	 */
	public void setParagraphId(String paragraphId) {
		this.paragraphId = paragraphId;
	}

	/**
	 * Gets the paragraph translated text.
	 *
	 * @return the paragraph translated text
	 */
	public String getParagraphTranslatedText() {
		return paragraphTranslatedText;
	}

	/**
	 * Sets the paragraph translated text.
	 *
	 * @param paragraphTranslatedText the new paragraph translated text
	 */
	public void setParagraphTranslatedText(String paragraphTranslatedText) {
		this.paragraphTranslatedText = paragraphTranslatedText;
	}

	/**
	 * Gets the language.
	 *
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * Sets the language.
	 *
	 * @param language the new language
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

}
