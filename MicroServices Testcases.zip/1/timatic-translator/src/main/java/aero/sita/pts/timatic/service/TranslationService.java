//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.
//**************************************************************************

package aero.sita.pts.timatic.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import aero.sita.pts.timatic.dao.TranslationDAO;
import aero.sita.pts.timatic.model.Paragraph;
import aero.sita.pts.timatic.queryinterface.castor.generated.DocumentChildParagraph;
import aero.sita.pts.timatic.queryinterface.castor.generated.DocumentParagraph;
import aero.sita.pts.timatic.queryinterface.castor.generated.DocumentResponse;
import aero.sita.pts.timatic.queryinterface.castor.generated.ParagraphText;
import aero.sita.pts.timatic.queryinterface.castor.generated.SectionInformation;
import aero.sita.pts.timatic.queryinterface.castor.generated.SubsectionInformation;

/**
 * The Class TranslationService.
 */
@Service
public class TranslationService {

    /** The translation DAO. */
    @Autowired
    private TranslationDAO translationDAO;

    //logger
    private static final Logger logger = LoggerFactory.getLogger(TranslationService.class);
	/**
	 * Gets the translated response object.
	 *
	 * @param documentResponse
	 *            the document response
	 * @return the translated response object
	 */
	public DocumentResponse getTranslatedResponseObject(DocumentResponse documentResponse, String translationLanguage) {

		logger.debug("getTranslatedResponseObject starts");
		Set<String> paragraphIdList = new HashSet<>();
		Set<SectionInformation> sectionInformationList = new HashSet<>();

		if (documentResponse != null && documentResponse.getDocumentCheckResponse() != null) {
			sectionInformationList = new HashSet<SectionInformation>(Arrays.asList(documentResponse
					.getDocumentCheckResponse().getDocumentCountryInformation(0).getSectionInformation()));
		}
		sectionInformationList.forEach(sectionInformation -> {
			extractSectionInformation(paragraphIdList, sectionInformation);
		});

		logger.info("All paragraph Ids from DocumentResponse : "+ paragraphIdList.toString());
		
		Map<String, Paragraph> translatedParagraphList = null;
		if (paragraphIdList != null && !paragraphIdList.isEmpty()) {
			logger.info("before DAO call for fetching the translations");
			translatedParagraphList = translationDAO.getTranslatedParagraphList(paragraphIdList, translationLanguage);
			logger.info("translations fetched from Db");
		}
		
		DocumentResponse translatedDocumentResponse = getTranslatedDocumentResponse(documentResponse,
				translatedParagraphList);
		logger.debug("getTranslatedResponseObject ends");
		return translatedDocumentResponse;

	}

	/**
	 * Extract section information.
	 *
	 * @param paragraphIdList
	 *            the paragraph id list
	 * @param sectionInformation
	 *            the section information
	 */
	private void extractSectionInformation(Set<String> paragraphIdList, SectionInformation sectionInformation) {
		extractDocumentParagraph(Arrays.asList(sectionInformation.getDocumentParagraph()), paragraphIdList);
		List<SubsectionInformation> subsectionInformationList = Arrays
				.asList(sectionInformation.getSubsectionInformation());

		subsectionInformationList.forEach(subSectionInformation -> {
			extractDocumentParagraph(Arrays.asList(subSectionInformation.getDocumentParagraph()), paragraphIdList);
		});
	}
    
    /**
     * Gets the translated document response.
     *
     * @param documentResponse      the document response
     * @param sectionInformation    the section information
     * @param subSectionInformation the sub section information
     * @param paragraphList         the paragraph list
     * @return the translated document response
     */
    private DocumentResponse getTranslatedDocumentResponse(DocumentResponse documentResponse,
            Map<String, Paragraph> translatedParagraphMap) {
    
    	List<SectionInformation> sectionInformationList = new ArrayList<SectionInformation>();
		if (documentResponse != null && documentResponse.getDocumentCheckResponse() != null) {
			sectionInformationList = Arrays.asList(
					documentResponse.getDocumentCheckResponse().getDocumentCountryInformation(0).getSectionInformation());
		}
    
        sectionInformationList.forEach(sectionInformation -> {
            translateDocumentParagraph(Arrays.asList(sectionInformation.getDocumentParagraph()), translatedParagraphMap);
    
            List<SubsectionInformation> subsectionInformationList = Arrays
                    .asList(sectionInformation.getSubsectionInformation());
    
            subsectionInformationList.forEach(subSectionInformation -> {
                translateDocumentParagraph(Arrays.asList(subSectionInformation.getDocumentParagraph()),
                        translatedParagraphMap);
                });
            });
        return documentResponse;
    }
    
    /**
     * Translate document paragraph.
     *
     * @param documentParagraphList the document paragraph list
     * @param paragraphListMap      the paragraph list map
     */
    private void translateDocumentParagraph(List<DocumentParagraph> documentParagraphList,
            Map<String, Paragraph> translateparagraphMap) {
    
        documentParagraphList.forEach(documentParagraph -> {
            Paragraph para= translateparagraphMap.get(documentParagraph.getParagraphId());
            if(para!=null && para.getParagraphId()!=null) {
                ParagraphText ptext = new ParagraphText();
                ptext.setContent(para.getParagraphTranslatedText());
                documentParagraph.setParagraphText(ptext);
            }
            
            List<DocumentChildParagraph> documentChildParagraphList = Arrays
                    .asList(documentParagraph.getDocumentChildParagraph());
    
            translateDocumentChildParagraph(documentChildParagraphList, translateparagraphMap);
            });
    
    }
    
	/**
	 * Extract document child paragraph.
	 * 
	 * @param documentChildParagraphList
	 *            the document child paragraph list
	 * @param paragraphListMap
	 *            the paragraph list map
	 */
	private void translateDocumentChildParagraph(List<DocumentChildParagraph> documentChildParagraphList,
			Map<String, Paragraph> translateparagraphMap) {
		documentChildParagraphList.forEach(documentChildParagraph -> {

			if (translateparagraphMap != null && !translateparagraphMap.isEmpty()) {
				if (translateparagraphMap.get(documentChildParagraph.getParagraphId()) != null) {
					ParagraphText ptext = new ParagraphText();
					ptext.setContent(
							translateparagraphMap.get(documentChildParagraph.getParagraphId()).getParagraphTranslatedText());
					documentChildParagraph.setParagraphText(ptext);
				}
			}
			if (documentChildParagraph != null && documentChildParagraph.getDocumentChildParagraphCount() > 0) {
				logger.info("translating paragraphs recursively...");
				translateDocumentChildParagraph(Arrays.asList(documentChildParagraph.getDocumentChildParagraph()),
						translateparagraphMap);
			}
		});

	}

    /**
     * Extract document paragraph.
     *
     * @param documentParagraphLists the document paragraph lists
     * @param paragraphIdList        the paragraph id list
     */
	private void extractDocumentParagraph(List<DocumentParagraph> documentParagraphLists, Set<String> paragraphIdList) {
		documentParagraphLists.forEach(documentParagraph -> {
			paragraphIdList.add(documentParagraph.getParagraphId());
			logger.debug("paragraph Id added in paragraphIdList : " + documentParagraph.getParagraphId());
			List<DocumentChildParagraph> documentChildParagraphList = Arrays
					.asList(documentParagraph.getDocumentChildParagraph());

			extractDocumentChildParagraph(documentChildParagraphList, paragraphIdList);
		});
	}
    
    /**
     * Extract document child paragraph.
     *
     * @param documentChildParagraphList the document child paragraph list
     * @param paragraphIdList            the paragraph id list
     */
	private void extractDocumentChildParagraph(List<DocumentChildParagraph> documentChildParagraphList,
			Set<String> paragraphIdList) {
		documentChildParagraphList.forEach(documentChildParagraph -> {
			paragraphIdList.add(documentChildParagraph.getParagraphId());
			logger.debug("paragraph Id added in paragraphIdList : " + documentChildParagraph.getParagraphId());
			if (documentChildParagraph.getDocumentChildParagraphCount() > 0) {
				extractDocumentChildParagraph(Arrays.asList(documentChildParagraph.getDocumentChildParagraph()),
						paragraphIdList);
			}

		});
	}

}
