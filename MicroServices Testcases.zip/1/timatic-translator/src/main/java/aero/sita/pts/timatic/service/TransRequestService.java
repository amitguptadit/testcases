//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.
//**************************************************************************
package aero.sita.pts.timatic.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

// TODO: Auto-generated Javadoc
/**
 * The Class TransRequestService.
 *
 * @author Gaurav Lal
 * @version $Id: TransRequestService.java 13415 2019-01-31 14:50:34Z $
 */
@Service
public class TransRequestService {

	/** The env. */
	@Autowired
	private Environment env;

	/** The rest template. */
	private RestTemplate restTemplate;

	/** The trans perfect url. */
	private String TRANS_PERFECT_URL = "trans.perfect.url";

	/** The trans perfect username. */
	private String TRANS_PERFECT_USERNAME = "trans.perfect.username";

	/** The trans perfect password. */
	private String TRANS_PERFECT_PASSWORD = "trans.perfect.password";

	/** The username. */
	private String USERNAME = "username";

	/** The password. */
	private String PASSWORD = "password";

	/**
	 * Instantiates a new trans request service.
	 */
	public TransRequestService() {
	}

	/**
	 * Instantiates a new trans request service.
	 *
	 * @param restTemplate
	 *            the rest template
	 * @param env
	 *            the env
	 */
	public TransRequestService(RestTemplate restTemplate, Environment env) {
		this.restTemplate = restTemplate;
		this.env = env;

	}

	/**
	 * Gets the trans session response.
	 *
	 * @return the trans session response
	 * @throws Exception
	 *             the exception
	 */
	public ResponseEntity<String> getTransSessionResponse() throws Exception {

		ResponseEntity<String> response = null;

		String requestUrl = env.getProperty(TRANS_PERFECT_URL);
		String userName = env.getProperty(TRANS_PERFECT_USERNAME);
		String password = env.getProperty(TRANS_PERFECT_PASSWORD);

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.setCacheControl(CacheControl.noCache());

		Map<String, String> entityMap = new HashMap<String, String>();
		entityMap.put(USERNAME, userName);
		entityMap.put(PASSWORD, password);

		HttpEntity<Map<String, String>> entity = new HttpEntity<Map<String, String>>(entityMap, httpHeaders);

		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		restTemplate.getMessageConverters().add(new StringHttpMessageConverter());

		response = restTemplate.exchange(requestUrl, HttpMethod.POST, entity, String.class);

		return response;
	}
}
