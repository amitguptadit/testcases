//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.
//**************************************************************************

package aero.sita.pts.timatic.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("aero.sita.pts.timatic")
@SpringBootApplication
@EnableAutoConfiguration
public class TranslatorApplication {
	private static final Logger logger = LoggerFactory.getLogger(TranslatorApplication.class);
	public static void main(String[] args) {
		SpringApplication.run(TranslatorApplication.class, args);
		logger.info("Translator microservices Started");
	}
}
