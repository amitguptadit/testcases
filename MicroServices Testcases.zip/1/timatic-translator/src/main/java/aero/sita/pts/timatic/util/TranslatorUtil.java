//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.
//**************************************************************************
package aero.sita.pts.timatic.util;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;

/**
 * The Class TranslatorUtil.
 */
@Component
public class TranslatorUtil {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(TranslatorUtil.class);

	/**
	 * Gets the http client request.
	 *
	 * @return the http client request
	 */
	public HttpComponentsClientHttpRequestFactory getHttpClientRequest() {

		TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;
		SSLContext sslContext = null;
		try {
			sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy)
					.build();
		} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
			logger.error("Error while creating sslContext ..." + e);
		}

		SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient);
		return requestFactory;

	}

}
