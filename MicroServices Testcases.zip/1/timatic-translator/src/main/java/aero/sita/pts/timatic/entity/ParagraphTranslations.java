//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.
//**************************************************************************

package aero.sita.pts.timatic.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity class for table PARAGRAPH_TRANSLATIONS.
 * @version $Id: ParagraphTranslations.java 13415 2019-01-10 14:50:34Z $
 * @author Shweta Sharma
 */

@Entity
@Table(name="PARAGRAPH_TRANSLATIONS")
public class ParagraphTranslations {

    @Id
    @Column(name="PARAGRAPH_TRANSLATIONS_ID")
    private String paragraphTranslationsId;
    
    @Column(name="PARAGRAPH_ID")
    private String paragraphId;
    
    @Column(name="TRANSLATION_TEXT")
    private String translatedText;
    
    @Column(name="TRANS_LANGUAGE")
    private String transLanguage;
    
    @Column(name="TRANSLATION_STATUS")
    private String translationStatus;
    
    /**
     * @return String
     */
    public String getParagraphTranslationsId() {
        return paragraphTranslationsId;
    }
    
    /**
     * @param paragraphTranslationsId
     *      paragraph Translations Id
     */
    public void setParagraphTranslationsId(String paragraphTranslationsId) {
        this.paragraphTranslationsId = paragraphTranslationsId;
    }
    
    /**
     * @return String
     */
    public String getParagraphId() {
        return paragraphId;
    }
    
    /**
    * @param paragraphId 
    *           paragraph ID
    */
    public void setParagraphId(String paragraphId) {
        this.paragraphId = paragraphId;
    }
    
    /**
     * @return String
     */
    public String getTranslatedText() {
        return translatedText;
    }
    
    /**
    * @param translatedText
    *       translated Text
    */
    public void setTranslatedText(String translatedText) {
        this.translatedText = translatedText;
    }
    
    /**
     * @return String
     */
    public String getTransLanguage() {
        return transLanguage;
    }
    
    /**
    * @param transLanguage
    *       translation Language
    */
    public void setTransLanguage(String transLanguage) {
        this.transLanguage = transLanguage;
    }
    
    /**
     * @return String
     */
    public String getTranslationStatus() {
        return translationStatus;
    }
    
    /**
     * @param translationStatus
     *      translation Status
     */
    public void setTranslationStatus(String translationStatus) {
        this.translationStatus = translationStatus;
    }
    
    /**
     * Constructor.
     */
    public ParagraphTranslations() {
        super();
    }
    
}