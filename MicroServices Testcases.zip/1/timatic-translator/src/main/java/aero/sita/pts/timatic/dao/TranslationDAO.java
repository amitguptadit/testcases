//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.
//**************************************************************************

package aero.sita.pts.timatic.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;

import aero.sita.pts.timatic.entity.ParagraphTranslations;
import aero.sita.pts.timatic.model.Paragraph;

/**
 * The Class TranslationDAO.
 */
@Repository
@Transactional
public class TranslationDAO {

	   //logger
    private static final Logger logger = LoggerFactory.getLogger(TranslationDAO.class);
    
    @Autowired
    private LocalSessionFactoryBean sessionFactory;

    private Session getSession() {
        return sessionFactory.getObject().getCurrentSession();
    }

    /**
     * Gets the translated paragraph list.
     *
     * @param paragraphIdList the paragraph id list
     * @param translationLanguage the translation language
     * @return the paragraph list
     */
    public Map<String, Paragraph> getTranslatedParagraphList(Set<String> paragraphIdList, String translationLanguage ) {
    	logger.debug("getTranslatedParagraphList started");
        @SuppressWarnings("unchecked")
        Set<ParagraphTranslations> paragraphTranslations = new HashSet<>(getSession()
            .createQuery("from ParagraphTranslations p where p.paragraphId in (:ids) and p.translationStatus!='OBSOLETE' and lower(p.transLanguage)= :transLanguage")
            .setParameterList("ids", paragraphIdList)
            .setParameter("transLanguage", translationLanguage.toLowerCase()).list());
        Map<String, Paragraph> paragraphMap= new HashMap<String, Paragraph>();
        
        paragraphTranslations.forEach(st-> {
            Paragraph para= new Paragraph();
            para.setLanguage(st.getTransLanguage());
            para.setParagraphTranslatedText(st.getTranslatedText());
            para.setParagraphId(st.getParagraphId());
            paragraphMap.put(st.getParagraphId(),para);
        });
        logger.info("fetched translations for the paragraph Ids: "+ paragraphMap.keySet().toString());
        return paragraphMap;
    }

}
