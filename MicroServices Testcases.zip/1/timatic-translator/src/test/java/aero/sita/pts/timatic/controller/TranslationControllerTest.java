//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.
//**************************************************************************

package aero.sita.pts.timatic.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import aero.sita.pts.timatic.queryinterface.castor.generated.DocumentResponse;

/**
 * The jUnit Test Class for TranslationDAO.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringBootTest(classes= {TranslatorApplication.class})
public class TranslationControllerTest {

	@Autowired
	TranslationController controller;
	
	private String xmlResponse = "<documentResponse xmlns=\"http://www.opentravel.org/OTA/2003/05/beta\"><requestID>6916</requestID><customerCode>5552</customerCode>" +
			"<documentCheckResponse><sufficientDocumentation>Conditional</sufficientDocumentation><documentCountryInformation><countryCode>US</countryCode>" +
			"<countryName>USA</countryName><destinationCode>LAX</destinationCode><sufficientDocumentation>Conditional</sufficientDocumentation><sectionInformation>" +
			"<sectionName>Geographical Information</sectionName><documentParagraph paragraphId=\"13765\"><paragraphType>Information</paragraphType>" +
			"<paragraphText>Capital - Washington, D.C. (WAS). The passport and visa regulations of the USA apply to: <br/>- All 50 states of the USA " +
			"(including Alaska and Hawaii) and the District of Columbia;<br/>- Puerto Rico;<br/>- Virgin Isl.;<br/>- The US possessions of Swains Isl.;<br/>- " +
			"The following US protectorates: Caroline, Johnston, Midway and Wake Isl.<br/>For Guam (Mariana Isl.), Marshall Isl., Micronesia (Federated States), " +
			"Palau and Samoa (American), see respective areas. </paragraphText></documentParagraph></sectionInformation>\r\n"
			+ "</documentCountryInformation></documentCheckResponse></documentResponse>	\r\n" + "";

	/**
	 * The jUnit Test case to test LanguageTranslator API and get successful response.
	 */
	@Test
	public void testLanguageTranslatorSuccess() {

		MultiValueMap<String, String> entityMap = new LinkedMultiValueMap<>();
		entityMap.add("translationLanguage", "es");
		entityMap.add("responseObjectType", DocumentResponse.class.getName());
		entityMap.add("xmlResponse", xmlResponse);

		ResponseEntity<String> result = controller.languageTranslator(entityMap);
		Assert.assertNotNull(result);
		Assert.assertSame(result.getStatusCode(), HttpStatus.OK);
	}
	
	/**
	 * The jUnit Test case to test LanguageTranslator API with failure response.
	 */
	@Test
	public void testLanguageTranslatorFailure() {

		MultiValueMap<String, String> entityMap = new LinkedMultiValueMap<>();
		entityMap.add("translationLanguage", "es");
		entityMap.add("responseObjectType", DocumentResponse.class.getName());
		entityMap.add("xmlResponse", xmlResponse);

		ResponseEntity<String> result = controller.languageTranslator(entityMap);
		Assert.assertNotNull(result);
		Assert.assertSame(result.getStatusCode(), HttpStatus.OK);
	}

}
