//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.
//**************************************************************************

package aero.sita.pts.timatic.dao;

import java.util.HashSet;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import aero.sita.pts.timatic.controller.TranslatorApplication;
import aero.sita.pts.timatic.dao.TranslationDAO;

/**
 * The jUnit Test Class for TranslationDAO.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringBootTest(classes= {TranslatorApplication.class})
public class TranslationDAOTest {

	@Autowired
    private TranslationDAO translationDAO;
	
    @Test
    public void testGetTranslatedParagraphList() {
    	
      HashSet<String> paragraphIdList = new HashSet<String>();
      paragraphIdList.add("13765");
      paragraphIdList.add("27372");
      paragraphIdList.add("26018");
      Assert.assertNotNull(translationDAO.getTranslatedParagraphList(paragraphIdList, "es"));
    }

}
