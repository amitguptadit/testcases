//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.

package aero.sita.pts.timatic.service;

import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

// TODO: Auto-generated Javadoc
/**
 * The Class TransRequestServiceTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class TransRequestServiceTest {

	/** The trans request service. */
	TransRequestService transRequestService;

	/** The env. */
	@Mock
	private Environment env;

	/** The rest template. */
	@Mock
	private RestTemplate restTemplate;

	/**
	 * Test get trans session response.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public void testGetTransSessionResponse() throws Exception {

		when(env.getProperty("trans.perfect.url")).thenReturn("testUrl");
		when(env.getProperty("trans.perfect.username")).thenReturn("username");
		when(env.getProperty("trans.perfect.password")).thenReturn("password");

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.setCacheControl(CacheControl.noCache());

		Map<String, String> entityMap = new HashMap<String, String>();
		entityMap.put("username", "username");
		entityMap.put("password", "password");

		HttpEntity<Map<String, String>> entity = new HttpEntity<Map<String, String>>(entityMap, httpHeaders);
		ResponseEntity<String> mockResponse = new ResponseEntity<>(
				"{\"status\":200,\"message\":\"Logged in successfully\",\"response_data\":{\"user_session_key\":\"Bys2zvpcPtNszzN\"}}",
				HttpStatus.OK);
		when(restTemplate.exchange("testUrl", HttpMethod.POST, entity, String.class)).thenReturn(mockResponse);
		transRequestService = new TransRequestService(restTemplate, env);
		ResponseEntity<String> response = transRequestService.getTransSessionResponse();
		Assert.assertNotNull(response);
		Assert.assertSame(response.getStatusCode(), HttpStatus.OK);

		JSONObject jsonObject = new JSONObject(response.getBody());
		JSONObject sessionNode = (JSONObject) jsonObject.get("response_data");
		Assert.assertEquals(sessionNode.get("user_session_key").toString(), "Bys2zvpcPtNszzN");

	}

}
