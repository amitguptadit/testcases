//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.

package aero.sita.pts.timatic.controller;

import static org.mockito.Mockito.when;

import javax.servlet.ServletContext;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;

import aero.sita.pts.timatic.service.TransRequestService;
import aero.sita.pts.timatic.util.TranslatorUtil;

// TODO: Auto-generated Javadoc
/**
 * The Class TransRequestControllerTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class TransRequestControllerTest {

	/** The trans request controller. */
	@InjectMocks
	TransRequestController transRequestController;

	/** The trans request service. */
	@Mock
	TransRequestService transRequestService;

	/** The servlet context. */
	@Mock
	ServletContext servletContext;

	/** The translator util. */
	@Mock
	TranslatorUtil translatorUtil;

	/**
	 * Test get trans session from servlet context.
	 *
	 * @throws JSONException
	 *             the JSON exception
	 */
	@Test
	public void testGetTransSessionFromServletContext() throws JSONException {

		when(servletContext.getAttribute("sessionTimeStamp")).thenReturn(System.currentTimeMillis());

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("user_session_key", "cjILcp4c7uH00X0");

		when(servletContext.getAttribute("sessionNode")).thenReturn(jsonObject);

		ResponseEntity<String> response = transRequestController.getTransSession();
		Assert.assertNotNull(response);
		Assert.assertSame(response.getStatusCode(), HttpStatus.OK);

		JSONObject json = new JSONObject(response.getBody());
		Assert.assertEquals(json.get("user_session_key").toString(), "cjILcp4c7uH00X0");

	}

	/**
	 * Test get trans session.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public void testGetTransSession() throws Exception {

		when(servletContext.getAttribute("sessionTimeStamp")).thenReturn(null);

		ResponseEntity<String> mockResponse = new ResponseEntity<>(
				"{\"status\":200,\"message\":\"Logged in successfully\",\"response_data\":{\"user_session_key\":\"Bys2zvpcPtNszzN\"}}",
				HttpStatus.OK);
		when(translatorUtil.getHttpClientRequest()).thenReturn(new HttpComponentsClientHttpRequestFactory());

		ResponseEntity<String> response = transRequestController.getTransSession();
		Assert.assertNotNull(response);
		Assert.assertSame(response.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * Test get trans session with null response.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public void testGetTransSessionWithNullResponse() throws Exception {

		when(servletContext.getAttribute("sessionTimeStamp")).thenReturn(null);

		ResponseEntity<String> response = transRequestController.getTransSession();
		Assert.assertNotNull(response);
		Assert.assertSame(response.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR);

	}

	/**
	 * Test get trans session with null response body.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public void testGetTransSessionWithNullResponseBody() throws Exception {

		when(servletContext.getAttribute("sessionTimeStamp")).thenReturn(null);

		ResponseEntity<String> mockResponse = new ResponseEntity<>(null, HttpStatus.OK);

		ResponseEntity<String> response = transRequestController.getTransSession();
		Assert.assertNotNull(response);
		Assert.assertSame(response.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR);

	}

}
