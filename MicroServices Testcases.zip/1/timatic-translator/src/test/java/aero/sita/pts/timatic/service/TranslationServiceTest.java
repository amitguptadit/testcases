//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2019
// Confidential. All rights reserved.
//**************************************************************************

package aero.sita.pts.timatic.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import aero.sita.pts.timatic.controller.TranslatorApplication;
import aero.sita.pts.timatic.queryinterface.castor.generated.DocumentCheckResponse;
import aero.sita.pts.timatic.queryinterface.castor.generated.DocumentChildParagraph;
import aero.sita.pts.timatic.queryinterface.castor.generated.DocumentCountryInfoChoice;
import aero.sita.pts.timatic.queryinterface.castor.generated.DocumentCountryInformation;
import aero.sita.pts.timatic.queryinterface.castor.generated.DocumentParagraph;
import aero.sita.pts.timatic.queryinterface.castor.generated.DocumentResponse;
import aero.sita.pts.timatic.queryinterface.castor.generated.ParagraphText;
import aero.sita.pts.timatic.queryinterface.castor.generated.SectionInformation;
import aero.sita.pts.timatic.queryinterface.castor.generated.SubsectionInformation;
import aero.sita.pts.timatic.queryinterface.castor.generated.types.ParagraphType;
import aero.sita.pts.timatic.service.TranslationService;

/**
 * The jUnit Test Class for TranslationDAO.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringBootTest(classes= {TranslatorApplication.class})
public class TranslationServiceTest {

	@Autowired
    private TranslationService translationService;
	
	@MockBean
	private DocumentCountryInfoChoice countryInfoChoice;
	
    @Test
    public void testGetTranslatedResponseObject() {
    
      DocumentResponse docResp = createDocumentResponse();
      Assert.assertNotNull(translationService.getTranslatedResponseObject(docResp, "es"));
    }

	private DocumentResponse createDocumentResponse() {
		DocumentResponse docResp = new DocumentResponse();
		  docResp.setRequestID(6916);
		  docResp.hasRequestID();
		  docResp.setCustomerCode("5552");
		  DocumentCountryInformation dci= new DocumentCountryInformation();
		  dci.setCountryCode("US");
		  dci.setCountryName("USA");
		  dci.setDocumentCountryInfoChoice(countryInfoChoice);
		  
		  ParagraphText paragraphText= new ParagraphText();
		  paragraphText.setContent("Passengers with an Authorization for Parole of an Alien into the United States (Form I-512).");
		  ParagraphText childParagraphText= new ParagraphText();
		  paragraphText.setContent("Passengers with a Hong Kong (SAR China) &quot;Document of Identity for Visa Purposes&quot;. ");
		  DocumentChildParagraph[] childParagraph = new DocumentChildParagraph[1];
		  childParagraph[0] = new DocumentChildParagraph();
		  childParagraph[0].setParagraphId("26199");
		  childParagraph[0].setParagraphType(ParagraphType.EXCEPTION);
		  childParagraph[0].setParagraphText(childParagraphText);
		  DocumentParagraph[] documentParagraph = new DocumentParagraph[1];
		  documentParagraph[0] = new DocumentParagraph();
		  documentParagraph[0].setParagraphId("38276");
		  documentParagraph[0].setParagraphType(ParagraphType.EXCEPTION);
		  documentParagraph[0].setParagraphText(paragraphText);
		  documentParagraph[0].setDocumentChildParagraph(childParagraph);
		  SubsectionInformation[] subsectionInformation = new SubsectionInformation[1]; 
		  subsectionInformation[0]= new SubsectionInformation();
		  subsectionInformation[0].setSubsectionName("Passport Exemptions:");
		  subsectionInformation[0].setDocumentParagraph(documentParagraph);
		  SectionInformation[] sectionInformation= new SectionInformation[1];
		  sectionInformation[0] = new SectionInformation();
		  sectionInformation[0].setSectionName("Passport");
		  sectionInformation[0].setDocumentParagraph(documentParagraph);
		  sectionInformation[0].setSubsectionInformation(subsectionInformation);
		  dci.setSectionInformation(sectionInformation);
		  DocumentCountryInformation[] dciArray = new DocumentCountryInformation[1];
		  dciArray[0]=dci;
		  DocumentCheckResponse checkResponse = new DocumentCheckResponse();
		  checkResponse.setDocumentCountryInformation(dciArray);
		  docResp.setDocumentCheckResponse(checkResponse);
		return docResp;
	}

}
