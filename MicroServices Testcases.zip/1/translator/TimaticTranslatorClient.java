//**************************************************************************
// This code contains copyright information which is the proprietary property
// of SITA Advanced Travel Solutions. No part of this code may be reproduced,
// stored or transmitted in any form without the prior written permission of
// SITA Advanced Travel Solutions.
//
// Copyright © SITA Advanced Travel Solutions 2001-2019
// Confidential. All rights reserved.
//**************************************************************************

package aero.sita.pts.timatic.translator;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.log4j.Logger;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.MultivaluedMapImpl;

/**
 * This Class is the entry point for Timatic Translation web service.
 *
 * @author glal
 * @version $Id: TimaticTranslatorClient.java 14054 2019-01-11 17:57:00Z $
 */
public class TimaticTranslatorClient {

	private static final Logger LOG = Logger.getLogger(TimaticTranslatorClient.class);

	/**
	 * Gets the translation in specific language.
	 *
	 * @param xmlResponse
	 *            the xml response
	 * @param responseObjectType
	 *            the response object type
	 * @param documentLanguage
	 *            the document Language
	 * @return the translations
	 */
	public String getTranslations(String xmlResponse, String responseObjectType, String documentLanguage) {

		String requestUrl = "http://localhost:8080/translator";
		boolean isError = false;
		String response = null;
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(requestUrl);
			MultivaluedMap<String, String> formData = new MultivaluedMapImpl();
			formData.add("xmlResponse", xmlResponse);
			formData.add("responseObjectType", responseObjectType);
			formData.add("translationLanguage", documentLanguage);
			LOG.debug("xmlResponse: " + xmlResponse + " responseObjectType: " + responseObjectType);
			LOG.info("requested documentLanguage: " + documentLanguage);

			ClientResponse clientResponse = webResource.type(MediaType.APPLICATION_FORM_URLENCODED_TYPE)
					.post(ClientResponse.class, formData);

			response = clientResponse.getEntity(String.class);

		} catch (Exception e) {
			isError = true;
			LOG.error("Error occurs while calling Translator application" + e);
		}

		// if error returns the original xml response
		if (isError) {
			return xmlResponse;
		}

		return response;
	}

}
