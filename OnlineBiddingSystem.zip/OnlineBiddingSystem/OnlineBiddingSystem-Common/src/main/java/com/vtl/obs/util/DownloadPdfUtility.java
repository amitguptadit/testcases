package com.vtl.obs.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.vtl.obs.hb.beans.HBid;

public class DownloadPdfUtility {

	private static Font TIME_ROMAN = new Font(Font.FontFamily.TIMES_ROMAN, 18,
			Font.BOLD);
	private static Font TIME_ROMAN_SMALL = new Font(
			Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

	public static Document createPDF(String file, List<HBid> hBidList,
			int reportId) {

		Document document = null;

		try {

			document = new Document();
			PdfWriter.getInstance(document, new FileOutputStream(file));
			document.open();

			addMetaData(document);
			addTitlePage(document, reportId);

			if (reportId == 1)
				createAllBids(document, hBidList);
			else if (reportId == 2)
				createOpenBids(document, hBidList);

			document.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		return document;
	}

	public static Document createUserBidPDF(String file, List<HBid> hBidList,
			int reportId, String userId, Map bidStatusMap, Map userBidPriceMap, Map userBidAttachmentMap) {

		Document document = null;

		try {

			document = new Document();
			PdfWriter.getInstance(document, new FileOutputStream(file));
			document.open();

			addMetaData(document);
			addTitlePage(document, reportId);

			if (reportId == 3)
				createUserBids(document, hBidList, userId, bidStatusMap,
						userBidPriceMap,userBidAttachmentMap);

			document.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		return document;
	}

	private static void addMetaData(Document document) {
		document.addTitle("Generate PDF report");
		document.addSubject("Generate PDF report");
		document.addAuthor("Quadrant");
		document.addCreator("Anurag");
	}

	private static void addTitlePage(Document document, int reportId)
			throws DocumentException {

		String titleOnPage = "";

		if (reportId == 1)
			titleOnPage = "Bid Wise Report";
		else if(reportId == 2)
			titleOnPage = "Open Bid Report";
		else if(reportId == 3)
			titleOnPage = "User Bid Report";

		Paragraph preface = new Paragraph();
		creteEmptyLine(preface, 1);
		preface.add(new Paragraph(titleOnPage, TIME_ROMAN));

		creteEmptyLine(preface, 1);
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
		preface.add(new Paragraph("Report created on "
				+ simpleDateFormat.format(new Date()), TIME_ROMAN_SMALL));
		document.add(preface);

	}

	private static void creteEmptyLine(Paragraph paragraph, int number) {
		for (int i = 0; i < number; i++) {
			paragraph.add(new Paragraph(" "));
		}
	}

	private static void createOpenBids(Document document, List<HBid> hBidList)
			throws DocumentException {
		Paragraph paragraph = new Paragraph();
		creteEmptyLine(paragraph, 2);
		document.add(paragraph);
		PdfPTable table = new PdfPTable(11);

		PdfPCell c1 = new PdfPCell(new Phrase("S.No."));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Id"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Name"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Description"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Type"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid TypeId"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Price"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid OpenDate"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid CloseDate"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Status"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Attachment"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		table.setHeaderRows(1);

		int counter = 0;
		for (HBid hBid : hBidList) {

			counter = counter + 1;

			table.setWidthPercentage(100);

			table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);

			table.addCell(Integer.toString(counter));
			table.addCell(Integer.toString(hBid.getBidId()));
			table.addCell(hBid.getBidName());
			table.addCell(hBid.getBidDescription());
			table.addCell(hBid.getBidType().getBidType());
			table.addCell(Integer.toString(hBid.getBidType().getBidTypeId()));
			table.addCell(Double.toString(hBid.getBidPrice()));
			table.addCell(hBid.getBidOpenDate());
			table.addCell(hBid.getBidCloseDate());
			table.addCell(hBid.getBidStatus());
			table.addCell(hBid.getAttachmentName());
		}
		document.add(table);
	}

	private static void createAllBids(Document document, List<HBid> hBidList)
			throws DocumentException {
		Paragraph paragraph = new Paragraph();
		creteEmptyLine(paragraph, 2);
		document.add(paragraph);
		PdfPTable table = new PdfPTable(9);

		PdfPCell c1 = new PdfPCell(new Phrase("S.No."));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Id"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Name"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Description"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid OpenDate"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid CloseDate"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Price"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Status"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Attachment"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		table.setHeaderRows(1);

		int counter = 0;
		for (HBid hBid : hBidList) {

			counter = counter + 1;

			table.setWidthPercentage(100);

			table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);

			table.addCell(Integer.toString(counter));
			table.addCell(Integer.toString(hBid.getBidId()));
			table.addCell(hBid.getBidName());
			table.addCell(hBid.getBidDescription());
			table.addCell(hBid.getBidOpenDate());
			table.addCell(hBid.getBidCloseDate());
			table.addCell(Double.toString(hBid.getBidPrice()));
			table.addCell(hBid.getBidStatus());
			table.addCell(hBid.getAttachmentName());

		}
		document.add(table);
	}

	private static void createUserBids(Document document, List<HBid> hBidList,
			String userId, Map bidStatusMap, Map userBidPriceMap,
			Map userBidAttachmentMap) throws DocumentException {
		Paragraph paragraph = new Paragraph();
		creteEmptyLine(paragraph, 2);
		document.add(paragraph);
		PdfPTable table = new PdfPTable(15);

		PdfPCell c1 = new PdfPCell(new Phrase("S.No."));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Id"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Name"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Description"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Type"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Type Id"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Price"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid OpenDate"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid CloseDate"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Status"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Bid Attachment"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("User Id"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("User Bid Status"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("User Bid Price"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("User Bid Attachment"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);
		
		table.setHeaderRows(1);

		int counter = 0;
		for (HBid hBid : hBidList) {

			counter = counter + 1;

			table.setWidthPercentage(100);

			table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);

			table.addCell(Integer.toString(counter));
			table.addCell(Integer.toString(hBid.getBidId()));
			table.addCell(hBid.getBidName());
			table.addCell(hBid.getBidDescription());
			table.addCell(hBid.getBtype());
			table.addCell(Integer.toString(hBid.getBidType().getBidTypeId()));
			table.addCell(Double.toString(hBid.getBidPrice()));
			table.addCell(hBid.getBidOpenDate());
			table.addCell(hBid.getBidCloseDate());			
			table.addCell(hBid.getBidStatus());
			table.addCell(hBid.getAttachmentName());
			table.addCell(userId);
			table.addCell(bidStatusMap.get(hBid.getBidName()).toString());
			table.addCell(userBidPriceMap.get(hBid.getBidName()).toString());
			table.addCell(userBidAttachmentMap.get(hBid.getBidName()).toString());
		}
		document.add(table);
	}
}
