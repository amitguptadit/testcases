package com.vtl.obs.exceptions;

/**
 *
 * @author Amit Gupta
 * @version 1.0
 *
 *          BusinessException is the base class for all business exceptions
 *          thrown within PPS applications.
 *
 */
public class BusinessException extends Exception {

	private static final long serialVersionUID = -2072230307133891411L;

	private String errCode;
	private String errMsg;

	public BusinessException() {
		super();
	}

	public BusinessException(Throwable cause) {
		super(cause);
	}

	public BusinessException(String errCode, String errMsg, Throwable cause) {
		super("[" + errCode + ":" + errMsg + "]", cause);
		this.errCode = errCode;
		this.errMsg = errMsg;
	}

	public BusinessException(String errCode, String errMsg) {
		super("[" + errCode + ":" + errMsg + "]");
		this.errCode = errCode;
		this.errMsg = errMsg;
	}

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

}
