package com.vtl.obs.hb.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="tbl_bid")
public class HBid 
{
	@Id
	@GeneratedValue
	private int bidId;
	private String bidName;
	private String bidDescription;
	private String bidOpenDate;
	@ManyToOne(optional = false)
    @JoinColumn(name = "bidTypeId")
    private HBidType bidType;
	private String bidCloseDate;
	private Double bidPrice;
	//private String bidAttachment;
	private String bidStatus;
	private String btype;
		
	//----------
	private String attachmentName;
	//@Column(name = "attachmentData", unique = false, nullable = false, length = 500000)
	/*
	 @Lob
    @Column(name="attachmentData", nullable=false, columnDefinition="mediumblob")	  
	 */
	
	@Lob
    @Column(name="attachmentData",unique = false, nullable=false, columnDefinition="mediumblob")
    private byte[] attachmentData;
    
	public String getAttachmentName() {
		return attachmentName;
	}
	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}
	public byte[] getAttachmentData() {
		return attachmentData;
	}
	public void setAttachmentData(byte[] attachmentData) {
		this.attachmentData = attachmentData;
	}
	public String getBidOpenDate() {
		return bidOpenDate;
	}
	public void setBidOpenDate(String bidOpenDate) {
		this.bidOpenDate = bidOpenDate;
	}
	public String getBidCloseDate() {
		return bidCloseDate;
	}
	public void setBidCloseDate(String bidCloseDate) {
		this.bidCloseDate = bidCloseDate;
	}
	public String getBtype() {
		return btype;
	}
	public void setBtype(String btype) {
		this.btype = btype;
	}
	public int getBidId() {
		return bidId;
	}
	public void setBidId(int bidId) {
		this.bidId = bidId;
	}
	@Column(name = "bidName", unique = true, nullable = false)
	public String getBidName() {
		return bidName.trim();
	}
	public void setBidName(String bidName) {
		this.bidName = bidName;
	}
	public String getBidDescription() {
		return bidDescription;
	}
	public void setBidDescription(String bidDescription) {
		this.bidDescription = bidDescription;
	}
	public HBidType getBidType() {
		return bidType;
	}
	public void setBidType(HBidType bidType) {
		this.bidType = bidType;
	}
	
	
	public Double getBidPrice() {
		return bidPrice;
	}
	public void setBidPrice(Double bidPrice) {
		this.bidPrice = bidPrice;
	}
	
	public String getBidStatus() {
		return bidStatus;
	}
	public void setBidStatus(String bidStatus) {
		this.bidStatus = bidStatus;
	}
	
}
