package com.vtl.obs.hb.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_req_reload_validation")
public class RequestReloadValidation
{
	@Id
	@GeneratedValue
	private int validationId;
	public int isValidRequest;
	public String requestURI;
	public int getValidationId() {
		return validationId;
	}
	public void setValidationId(int validationId) {
		this.validationId = validationId;
	}
	public int getIsValidRequest() {
		return isValidRequest;
	}
	public void setIsValidRequest(int isValidRequest) {
		this.isValidRequest = isValidRequest;
	}
	public String getRequestURI() {
		return requestURI;
	}
	public void setRequestURI(String requestURI) {
		this.requestURI = requestURI;
	}

}
