package com.vtl.obs.hb.beans.umf;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_umf_mail")
public class HBumfMail
{

	@Id
	@GeneratedValue
	private int mailId;
	private String senderId;
	private String receiverId;
	private Date mailDateTime;
	private String content;
	public int getMailId() {
		return mailId;
	}
	public void setMailId(int mailId) {
		this.mailId = mailId;
	}
	public String getSenderId() {
		return senderId;
	}
	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}
	public String getReceiverId() {
		return receiverId;
	}
	public void setReceiverId(String receiverId) {
		this.receiverId = receiverId;
	}
	public Date getMailDateTime() {
		return mailDateTime;
	}
	public void setMailDateTime(Date mailDateTime) {
		this.mailDateTime = mailDateTime;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}

}
