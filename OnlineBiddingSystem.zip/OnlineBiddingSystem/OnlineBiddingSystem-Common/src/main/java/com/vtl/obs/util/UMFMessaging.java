package com.vtl.obs.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.bind.JAXBContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.vtl.obs.config.UmfConfig;

public class UMFMessaging {

	public static final Logger logger = Logger.getLogger("UMFMessaging.class");

	@Autowired
	private UmfConfig umfConfig;

	public Boolean callUMFInterface(String msisdn, String umfMessageToSend,String app_name,String app_user_name,String app_password) {
		Boolean flag = Boolean.FALSE;
		HttpURLConnection connection = null;
		try {


			URL url = new URL(umfConfig.getUmfInterface()+app_name+"/requests");
			SmsSenderServiceXml obj = new SmsSenderServiceXml();

			String prefixAdd = "91";
			if (msisdn.length() == 10) {
				msisdn = (new StringBuilder()).append(prefixAdd).append(msisdn)
						.toString();
			}
			obj.setAddress("tel:+" + msisdn);

			obj.setOutboundSMSTextMessage(umfMessageToSend);

			//obj.setSenderAddress(umfConfig.getUmfUserName());
			obj.setSenderAddress(app_name);
			connection = (HttpURLConnection) url.openConnection();
			/*connection.setRequestProperty("username",
					umfConfig.getUmfUserName());
			connection.setRequestProperty("password",
					umfConfig.getUmfPassword());*/

			logger.info("UMF URL :"+umfConfig.getUmfInterface()+app_name+"/requests");
			logger.info(" setSenderAddress :"+app_name+", username:"+app_user_name+" ,password :"+app_password);
			connection.setRequestProperty("username",
					app_user_name);
			connection.setRequestProperty("password",
					app_password);
			connection.setRequestMethod("POST");
			connection.setDoOutput(true);
			connection.setRequestProperty("Content-Type", "application/xml");

			JAXBContext jc = JAXBContext.newInstance(obj.getClass());
			OutputStream xml = connection.getOutputStream();
			jc.createMarshaller().marshal(obj, xml);
			logger.info( "XML to be sent in request body is : " + xml);

			if (connection.getResponseCode() == 200) {
				BufferedReader in = null;
				in = new BufferedReader(new InputStreamReader(
						connection.getInputStream()));
				String response = null;
				flag = Boolean.TRUE;
				while ((response = in.readLine()) != null) {
					logger.info(response);
				}
			} else if (connection.getResponseCode() == 400) {
				logger.error("Bad request");
				BufferedReader in = null;
				in = new BufferedReader(new InputStreamReader(
						connection.getInputStream()));
				String response = null;

				while ((response = in.readLine()) != null) {
					logger.info(response);
				}
			} else {
				logger.error("Exception code :" + connection.getResponseCode());
			}
		} catch (Exception e) {
			flag = Boolean.FALSE;
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			e.printStackTrace(writer);
			logger.error(stack.toString());
		} finally {
			connection.disconnect();
		}
		return flag;
	}//
}
