package com.vtl.obs.beans;

public class BidBean 
{
	private int bidId;
	private String bidName;
	private String bidDescription;
	private String bidOpenDate;
	private String bidType;
	private String bidCloseDate;
	private String bidPrice;
	private String bidStatus;
	private String btype;

	/*
	 <th width="21%">bidId</th>
                                            <th width="21%">bidCloseDate</th>
                                             <th width="21%">bidDescription</th>
                                              <th width="21%">bidName</th>
                                              <th width="21%">bidOpenDate</th>
                                              <th width="21%">bidPrice</th>
                                              <th width="21%">bidStatus</th>
                                              <th width="21%">bidTypeId</th>
                                              <th width="21%">btype</th>
	 */
}
