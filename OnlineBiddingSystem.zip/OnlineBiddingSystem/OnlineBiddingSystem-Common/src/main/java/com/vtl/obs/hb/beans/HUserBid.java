package com.vtl.obs.hb.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Lob;
@Entity
@Table(name="tbl_user_bid")
public class HUserBid 
{
	@Id
	@GeneratedValue
	private int userBidId;
	
	@ManyToOne(optional = false)
    @JoinColumn(name = "huserId")
    private HUser huserId;
	
	@ManyToOne(optional = false)
    @JoinColumn(name = "bidId")
    private HBid bidId;
	private String userbidStatus;
	private Double userbidPrice;
	private Date userBidOpenDate;
	private Date userBidCreatedDate;
	private String userBidAppliedDate;
	private String userBidCloseDate;
	private String userBidComment;	
	private String userBidAttachmentName;
	@Lob
    @Column(name="userBidAttachmentData",unique = false, nullable=true, columnDefinition="mediumblob")
    private byte[] userAttachmentData;
    
	public String getUserBidAttachmentName() {
		return userBidAttachmentName;
	}
	public void setUserBidAttachmentName(String userBidAttachmentName) {
		this.userBidAttachmentName = userBidAttachmentName;
	}
	public byte[] getUserAttachmentData() {
		return userAttachmentData;
	}
	public void setUserAttachmentData(byte[] userAttachmentData) {
		this.userAttachmentData = userAttachmentData;
	}
	public String getUserBidCloseDate() {
		return userBidCloseDate;
	}
	public void setUserBidCloseDate(String userBidCloseDate) {
		this.userBidCloseDate = userBidCloseDate;
	}
	public int getUserBidId() {
		return userBidId;
	}
	public void setUserBidId(int userBidId) {
		this.userBidId = userBidId;
	}
	public HUser getHuserId() {
		return huserId;
	}
	public void setHuserId(HUser huserId) {
		this.huserId = huserId;
	}
	public HBid getBidId() {
		return bidId;
	}
	public void setBidId(HBid bidId) {
		this.bidId = bidId;
	}
	public String getUserbidStatus() {
		return userbidStatus;
	}
	public void setUserbidStatus(String userbidStatus) {
		this.userbidStatus = userbidStatus;
	}
	public Double getUserbidPrice() {
		return userbidPrice;
	}
	public void setUserbidPrice(Double userbidPrice) {
		this.userbidPrice = userbidPrice;
	}
	public Date getUserBidOpenDate() {
		return userBidOpenDate;
	}
	public void setUserBidOpenDate(Date userBidOpenDate) {
		this.userBidOpenDate = userBidOpenDate;
	}
	public Date getUserBidCreatedDate() {
		return userBidCreatedDate;
	}
	public void setUserBidCreatedDate(Date userBidCreatedDate) {
		this.userBidCreatedDate = userBidCreatedDate;
	}
	public String getUserBidAppliedDate() {
		return userBidAppliedDate;
	}
	public void setUserBidAppliedDate(String userBidAppliedDate) {
		this.userBidAppliedDate = userBidAppliedDate;
	}
	public String getUserBidComment() {
		return userBidComment;
	}
	public void setUserBidComment(String userBidComment) {
		this.userBidComment = userBidComment;
	}
	
}
