package com.vtl.obs.hb.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_bid_type")
public class HBidType 
{
	@Id
	@GeneratedValue
	private int bidTypeId;
	private String bidType;
	public int getBidTypeId() {
		return bidTypeId;
	}
	public void setBidTypeId(int bidTypeId) {
		this.bidTypeId = bidTypeId;
	}
	public String getBidType() {
		return bidType;
	}
	public void setBidType(String bidType) {
		this.bidType = bidType;
	}
	
}
