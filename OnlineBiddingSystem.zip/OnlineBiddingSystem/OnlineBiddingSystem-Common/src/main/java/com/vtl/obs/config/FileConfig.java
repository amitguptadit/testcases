package com.vtl.obs.config;

public class FileConfig {

	private String remoteFileSourcePath;
	private String remoteFileBackupPath;
	private String localFilePath;
	private String backupSuccessFilePath;
	private String backupFailureFilePath;
	private String rechargeWalletFileName;
	private String rechargeWalletFileExtension;

	private String scpHost;
	private String scpUserName;
	private String scpPassword;
	private String scpMktUserName;
	private String scpMktPassword;
	private Integer scpPort;

	public String getRemoteFileSourcePath() {
		return remoteFileSourcePath;
	}

	public void setRemoteFileSourcePath(String remoteFileSourcePath) {
		this.remoteFileSourcePath = remoteFileSourcePath;
	}

	public String getRemoteFileBackupPath() {
		return remoteFileBackupPath;
	}

	public void setRemoteFileBackupPath(String remoteFileBackupPath) {
		this.remoteFileBackupPath = remoteFileBackupPath;
	}

	public String getLocalFilePath() {
		return localFilePath;
	}

	public void setLocalFilePath(String localFilePath) {
		this.localFilePath = localFilePath;
	}

	public String getBackupSuccessFilePath() {
		return backupSuccessFilePath;
	}

	public void setBackupSuccessFilePath(String backupSuccessFilePath) {
		this.backupSuccessFilePath = backupSuccessFilePath;
	}

	public String getBackupFailureFilePath() {
		return backupFailureFilePath;
	}

	public void setBackupFailureFilePath(String backupFailureFilePath) {
		this.backupFailureFilePath = backupFailureFilePath;
	}

	public String getRechargeWalletFileName() {
		return rechargeWalletFileName;
	}

	public void setRechargeWalletFileName(String rechargeWalletFileName) {
		this.rechargeWalletFileName = rechargeWalletFileName;
	}

	public String getRechargeWalletFileExtension() {
		return rechargeWalletFileExtension;
	}

	public void setRechargeWalletFileExtension(
			String rechargeWalletFileExtension) {
		this.rechargeWalletFileExtension = rechargeWalletFileExtension;
	}

	public String getScpHost() {
		return scpHost;
	}

	public void setScpHost(String scpHost) {
		this.scpHost = scpHost;
	}

	public String getScpUserName() {
		return scpUserName;
	}

	public void setScpUserName(String scpUserName) {
		this.scpUserName = scpUserName;
	}

	public String getScpPassword() {
		return scpPassword;
	}

	public void setScpPassword(String scpPassword) {
		this.scpPassword = scpPassword;
	}

	public String getScpMktUserName() {
		return scpMktUserName;
	}

	public void setScpMktUserName(String scpMktUserName) {
		this.scpMktUserName = scpMktUserName;
	}

	public String getScpMktPassword() {
		return scpMktPassword;
	}

	public void setScpMktPassword(String scpMktPassword) {
		this.scpMktPassword = scpMktPassword;
	}

	public Integer getScpPort() {
		return scpPort;
	}

	public void setScpPort(Integer scpPort) {
		this.scpPort = scpPort;
	}

}