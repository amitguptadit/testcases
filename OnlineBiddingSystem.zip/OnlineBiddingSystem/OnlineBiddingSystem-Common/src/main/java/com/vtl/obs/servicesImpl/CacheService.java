package com.vtl.obs.servicesImpl;

//import org.apache.log4j.Logger;

import com.vtl.obs.cache.OBSCacheManager;
import com.vtl.obs.exceptions.BusinessException;
import com.vtl.obs.exceptions.DatabaseException;
import com.vtl.obs.services.ICacheService;

public class CacheService implements ICacheService {
	private OBSCacheManager ppsCacheManager;
	private Integer ppsCacheSize;

	//private final static Logger logger = Logger.getLogger(CacheService.class);


	@Override
	public Boolean cachePPSServicePlanConfiguration() throws BusinessException,
			DatabaseException {
		Boolean flag = Boolean.FALSE;

		return flag;
	}

	public OBSCacheManager getPpsCacheManager() {
		return ppsCacheManager;
	}

	public void setPpsCacheManager(OBSCacheManager ppsCacheManager) {
		this.ppsCacheManager = ppsCacheManager;
	}

	public Integer getPpsCacheSize() {
		return ppsCacheSize;
	}

	public void setPpsCacheSize(Integer ppsCacheSize) {
		this.ppsCacheSize = ppsCacheSize;
	}

}