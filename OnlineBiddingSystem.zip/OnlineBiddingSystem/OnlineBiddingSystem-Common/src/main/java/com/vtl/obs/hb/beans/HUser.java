package com.vtl.obs.hb.beans;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="tbl_user")
public class HUser 
{
	@Id
	@GeneratedValue
	private int huserId;
	private String userId;
	private String username;
	private String password;
	private String msisdn;
	private String email;
	private Double  userPrice;
	private String userType;
	@ManyToOne(optional = false)
    @JoinColumn(name = "roleType")
    private HUserRoleDetails userRoleType;
	private String isloggedIn;
	private Date createdDate;
	private Date lastloginTime;
	
	
	public Double getUserPrice() {
		return userPrice;
	}
	public void setUserPrice(Double userPrice) {
		this.userPrice = userPrice;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public int getHuserId() {
		return huserId;
	}
	public void setHuserId(int huserId) {
		this.huserId = huserId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public HUserRoleDetails getUserRoleType() {
		return userRoleType;
	}
	public void setUserRoleType(HUserRoleDetails userRoleType) {
		this.userRoleType = userRoleType;
	}
	public String getIsloggedIn() {
		return isloggedIn;
	}
	public void setIsloggedIn(String isloggedIn) {
		this.isloggedIn = isloggedIn;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getLastloginTime() {
		return lastloginTime;
	}
	public void setLastloginTime(Date lastloginTime) {
		this.lastloginTime = lastloginTime;
	}

}
