package com.vtl.obs.services;
import com.vtl.obs.exceptions.BusinessException;
import com.vtl.obs.exceptions.DatabaseException;




public interface ICacheService {

	/**
	 * This method is used to cache the PPS Master Data
	 *
	 * @return
	 * @throws BusinessException
	 * @throws DatabaseException
	 */
	Boolean cachePPSServicePlanConfiguration() throws BusinessException, DatabaseException;


}
