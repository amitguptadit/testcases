package com.vtl.obs.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.MultipartPostMethod;
import javax.xml.bind.JAXBContext;

import org.apache.log4j.Logger;

public class EmailService 
{
	private String mailServerUrl;
	public static final Logger logger = Logger.getLogger("EmailService.class");
	
	public String getMailServerUrl() {
		return mailServerUrl;
	}
	public void setMailServerUrl(String mailServerUrl) {
		this.mailServerUrl = mailServerUrl;
	}
	public Boolean sendMail(String userName,String password,String mailSubject,String mailContent,String mailRecepientsTo,String mailRecepientsCc) 
	{
		Boolean flag = Boolean.FALSE;
		HttpURLConnection httpConn = null;
		try {
			 		
					logger.info(" sendMail()# userName :"+userName+" password :"+password+" mailSubject:"+mailSubject+" mailContent :"+mailContent+"" +
							" mailRecepientsTo :"+mailRecepientsTo+" mailRecepientsCc :"+mailRecepientsCc);
					

					System.out.println(" sendMail()# userName :"+userName+" password :"+password+" mailSubject:"+mailSubject+" mailContent :"+mailContent+"" +
							" mailRecepientsTo :"+mailRecepientsTo+" mailRecepientsCc :"+mailRecepientsCc);

					
							//MultipartPostMethod method = new MultipartPostMethod("http://172.17.4.136:8081/messaging/email/1.0/outbound/VTL_EMAIL/requests");
							MultipartPostMethod method = new MultipartPostMethod(mailServerUrl);
							method.addRequestHeader("Content-type", "multipart/form-data");// multipart-mixed
							method.addRequestHeader("userName", userName);
							method.addRequestHeader("password",password);
							String payload = "<?xml version= \"1.0\" encoding= \"UTF-8\" standalone= \"yes\"?>";
							payload += "<EmailRequest>";
							payload += "<mailSubject>"+mailSubject+"</mailSubject>";
							payload += "<mailContent>"+mailContent+"</mailContent>";                                               
							//payload += "<mailFrom>amit.gupta2@videocon.com</mailFrom>";                                   							
							//payload += "<mailRecepientsTo>amit.gupta2@videocon.com</mailRecepientsTo>";
							payload += "<mailRecepientsTo>"+mailRecepientsTo+"</mailRecepientsTo>";
							//payload += "<mailRecepientsCc>saurabh.srivastava@infotelconnect.com</mailRecepientsCc>";
							//payload += "<mailRecepientsBcc>anuj.singh@videocon.com</mailRecepientsBcc>";
							payload += "</EmailRequest>";
							method.addParameter("payload", payload);
							System.out.println(payload);
							logger.info(payload);
							HttpClient client = new HttpClient();
							int statusCode = client.executeMethod(method);					
							System.out.println("sendMail()#statusCode :"+statusCode);
							logger.info("sendMail()#statusCode :"+statusCode);
					flag = Boolean.TRUE;
			} catch (Exception e) {
			flag = Boolean.FALSE;
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			e.printStackTrace(writer);
			logger.error(stack.toString());
		} finally {
			//connection.disconnect();
		}
		return flag;

	}

}
