package com.vtl.obs.util.spring;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;

/**

 * This class holds the reference to ApplicationContext variable. The springContext
 * variable gets instantiated in AppContextInitializer listener class.
 *
 */
public class CustomBeanProvider {

    private static final Log log = LogFactory.getLog(CustomBeanProvider.class);

    private static ApplicationContext springContext = null;

    /**
     * @param springContext the springContext to set
     */
    public static void setSpringContext(ApplicationContext springContext) {
        CustomBeanProvider.springContext = springContext;
    }

    /**
     * Get a handle to Spring ApplicationContext
     *
     * @return the springContext
     */
    public static ApplicationContext getSpringContext() {
        return springContext;
    }

    /**
     * Get a bean from Spring.
     *
     * @param name bean name
     * @return bean instance
     */
    public static <T> T getBean(String name) {
        if (log.isDebugEnabled())
            log.debug("Retrieving Spring bean: " + name);

        return TypeCast.<T> cast(springContext.getBean(name));
    }
}
