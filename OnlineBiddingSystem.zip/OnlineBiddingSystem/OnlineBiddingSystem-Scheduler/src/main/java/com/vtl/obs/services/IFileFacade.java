package com.vtl.obs.services;

public interface IFileFacade {

	void startProcess();

	void processFiles(String[] filesAvailable);
}
