package com.vtl.obs.daoImpl;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.vtl.obs.dao.IFileDao;
import com.vtl.obs.exceptions.BusinessException;
import com.vtl.obs.exceptions.DatabaseException;
import com.vtl.obs.util.OBSConstants;

/**
 * @author Amit Gupta
 * @version 1.0
 *
 */

public class FileDao implements IFileDao {

	private DataSource dataSource;
	private final static Logger logger = Logger.getLogger(FileDao.class);



	private Boolean validMSISDN(String mobileNumber) {

		Boolean isValidateMSISDN = true;
		int size = 0;

		// check the length
		if (mobileNumber != null) {
			size = mobileNumber.length();
		}
		if (size != OBSConstants.MSISDN_LENGTH) {
			return false;
		}

		// check for characters in mobile number
		for (int i = 0; i < size; i++) {
			if (!isNumeric(mobileNumber.charAt(i))) {
				isValidateMSISDN = false;
				break;
			}
		}

		return isValidateMSISDN;

	}

	private Boolean isNumeric(char c) {
		Boolean result = false;

		char[] numbers = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
		for (char s : numbers) {
			if (c == s) {
				result = true;
				break;
			}
		}

		return result;
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public Boolean persistRecord(String sourceFilePath, String fileName,
			String circleId) throws BusinessException, DatabaseException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean truncateTable() throws DatabaseException {
		// TODO Auto-generated method stub
		return null;
	}

}
