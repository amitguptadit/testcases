package com.vtl.obs.dao;

import com.vtl.obs.exceptions.BusinessException;
import com.vtl.obs.exceptions.DatabaseException;
/**
 * @author Anuj Singh
 * @version 1.0
 *
 */

public interface IFileDao {

	/**
	 * This method is used to persist the record of file
	 *
	 * @param sourceFilePath
	 * @param fileName
	 * @param fileId
	 * @param currCal
	 * @return
	 * @throws DatabaseException
	 * @throws BusinessException
	 */
	Boolean persistRecord(String sourceFilePath, String fileName, String circleId) throws BusinessException, DatabaseException;
	Boolean truncateTable() throws DatabaseException;

}



