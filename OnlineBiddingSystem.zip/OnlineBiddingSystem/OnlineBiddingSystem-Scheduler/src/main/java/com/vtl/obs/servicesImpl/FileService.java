package com.vtl.obs.servicesImpl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.vtl.obs.config.FileConfig;
import com.vtl.obs.daoImpl.FileDao;
import com.vtl.obs.exceptions.BusinessException;
import com.vtl.obs.exceptions.DatabaseException;
import com.vtl.obs.services.IFileService;
import com.vtl.obs.util.OBSConstants;
import com.vtl.obs.util.OBSInterfaceService;
import com.vtl.obs.util.ResponseConstants;
import com.vtl.obs.util.spring.SchedulerContextFactory;


public class FileService implements IFileService {

	private FileConfig fileConfig;
	private FileDao fileDao;
	private OBSInterfaceService  ppsInterfaceService;
	private Boolean isInteractRePPSService;

	private final static Logger logger = Logger.getLogger(FileService.class);

	public Boolean truncateTable() throws DatabaseException {
		Boolean flag = Boolean.FALSE;
		logger.info("truncating the table ");
		flag = fileDao.truncateTable();

		logger.info(" status of the truncating the table :" + flag);

		return flag;

	}

	@Override
	public Boolean ProcessFile(String sourceFilePath, String fileName,
			Calendar currCal) {
		Boolean flag = Boolean.FALSE;
		logger.info("Processing the file :" + fileName);

		File file = new File(sourceFilePath + File.separator + fileName);
		BufferedReader buffReader = null;
		FileReader fileReader = null;
		if (file.isFile() && file.canRead()) {
			try {
				fileReader = new FileReader(file);
				buffReader = new BufferedReader(fileReader);
				String line;
				String msisdn = null;
				String faceValue = null;
				String marketSegmentId = null;
				String imsi = null;
				String eventType = null;
				while ((line = buffReader.readLine()) != null) {
					if (line.startsWith("SLOT_NUMBER")) {
						logger.info(" Read First line from PCRF Dump File : "
								+ line);
					} else {
						logger.info(" Read line from PCRF Dump File : " + line);
						StringTokenizer tokenizer = new StringTokenizer(line,
								OBSConstants.SEPERATOR_X);
						while (tokenizer.hasMoreTokens()) {}

						flag = fileDao.persistRecord(msisdn, faceValue,
								marketSegmentId);

						if (flag) {
							logger.info("Number Exist in our DB with MSISDN : "
									+ msisdn
									+ " Facevalue : "
									+ faceValue
									+ " CircleId : " + marketSegmentId);
						} else {
							if (isInteractRePPSService) {
								logger.info("ReProvisioning on  MSISDN : "
										+ msisdn + " Facevalue : "
										+ faceValue + " CircleId : "
										+ marketSegmentId);
								/*ppsInterfaceService.callPPSService(
										RechargeWalletConstants.TYPE_CVN, msisdn,  //change karna hai baad me
										faceValue, imsi, eventType,
										marketSegmentId);*/
							} else {
								logger.info("PPS Web Service Interaction is suspend currently.");
							}
						}
					}
				}

			}  catch (Exception e) {
				StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
						.getResponseCode()
						+ ":"
						+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
						+ ":" + stack.toString());
			}finally {
				if (buffReader != null) {
					try {
						buffReader.close();
					} catch (IOException e) {
						StringWriter stack = new StringWriter();
						PrintWriter writer = new PrintWriter(stack);
						e.printStackTrace(writer);
						logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
								.getResponseCode()
								+ ":"
								+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
								+ ":" + stack.toString());
					}
					buffReader = null;
				}
				if (fileReader != null) {
					try {
						fileReader.close();
					} catch (IOException e) {
						StringWriter stack = new StringWriter();
						PrintWriter writer = new PrintWriter(stack);
						e.printStackTrace(writer);
						logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
								.getResponseCode()
								+ ":"
								+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
								+ ":" + stack.toString());
					}
					fileReader = null;
				}
			}

		}

		logger.info("File " + fileName
				+ " records persistance status of the file:" + flag);

		return flag;
	}

	public List<String> downloadFile(FileConfig fileConfig, Calendar currCal,
			String remoteSourceFilePath, String remoteBackupFilePath,
			String localFilePath, final String fileName,
			final String fileExtension) throws BusinessException {

		List<String> fileList = new ArrayList<String>();
		// For LocalTest remove comment below line and comment it our all below section
		// fileList.add("PPS-BASE-2014-02-27.csv");

		Session session = null;
		Channel channel = null;
		try {
			JSch ssh = (JSch) SchedulerContextFactory.getInstance().getBean(
					"jsch");
			JSch.setConfig("StrictHostKeyChecking", "no");
			session = ssh.getSession(fileConfig.getScpUserName(),
					fileConfig.getScpHost(), fileConfig.getScpPort());
			session.setPassword(fileConfig.getScpPassword());
			session.connect();
			channel = session.openChannel("sftp");
			channel.connect();
			logger.info("SFTP Login to " + fileConfig.getScpHost()
					+ " is successful");
			ChannelSftp channelSftp = (ChannelSftp) channel;

			Boolean isSourcePathExixt = Boolean.FALSE;
			Boolean isBackupPathExixt = Boolean.FALSE;

			SftpATTRS sourcePathAttrs = channelSftp.stat(fileConfig
					.getRemoteFileSourcePath());

			if (sourcePathAttrs != null) {
				isSourcePathExixt = Boolean.TRUE;
			} else {
				logger.error(ResponseConstants.ERR_DIRECTORY_NOT_EXIST
						.getResponseCode()
						+ ":"
						+ ResponseConstants.ERR_DIRECTORY_NOT_EXIST
								.getResponseMsg()
						+ fileConfig.getRemoteFileSourcePath());
			}

			SftpATTRS destPathAttrs = channelSftp.stat(fileConfig
					.getRemoteFileBackupPath());

			if (destPathAttrs != null) {
				isBackupPathExixt = Boolean.TRUE;
			} else {
				logger.error(ResponseConstants.ERR_DIRECTORY_NOT_EXIST
						.getResponseCode()
						+ ":"
						+ ResponseConstants.ERR_DIRECTORY_NOT_EXIST
								.getResponseMsg()
						+ fileConfig.getRemoteFileBackupPath());
			}


			if (isSourcePathExixt && isBackupPathExixt) {
				@SuppressWarnings("unchecked")

				Vector<LsEntry> remoteFileVector = channelSftp.ls(fileConfig
						.getRemoteFileSourcePath()
						+ File.separator
						+ fileName
						+ "*" + fileExtension);



				if (remoteFileVector != null && remoteFileVector.size() > 0) {
					Enumeration<LsEntry> enumLsEntry = remoteFileVector
							.elements();
					while (enumLsEntry.hasMoreElements()) {
						try {
							LsEntry entry = (LsEntry) enumLsEntry.nextElement();
							logger.info("File : " + entry.getFilename()
									+ " is present at SCP location - "
									+ fileConfig.getRemoteFileSourcePath());
							channelSftp.get(
									fileConfig.getRemoteFileSourcePath()
											+ File.separator
											+ entry.getFilename(),
									localFilePath);
							logger.info("File : " + entry.getFilename()
									+ " is downloaded at the local location - "
									+ localFilePath);
							fileList.add(entry.getFilename());

							channelSftp.rename(
									fileConfig.getRemoteFileSourcePath()
											+ File.separator
											+ entry.getFilename(),
									fileConfig.getRemoteFileBackupPath()
											+ File.separator
											+ entry.getFilename());
							logger.info("File : " + entry.getFilename()
									+ " is moved to remote backup location - "
									+ fileConfig.getRemoteFileBackupPath());
						} catch (SftpException e) {
							StringWriter stack = new StringWriter();
							PrintWriter writer = new PrintWriter(stack);
							e.printStackTrace(writer);
							logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode()
									+ ":"
									+ ResponseConstants.ERR_SYSTEM_EXCEPTION
											.getResponseMsg()
									+ ":"
									+ stack.toString());
						}

					}
				}
			}
		} catch (JSchException e) {
			throw new BusinessException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		} catch (SftpException e) {
			throw new BusinessException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		} catch (Exception e) {
			throw new BusinessException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		} finally {
			if (channel != null) {
				channel.disconnect();
			}
			if (session != null) {
				session.disconnect();
			}
		}
		return fileList;
	}




	public Boolean moveFiles(String remoteFilePath, String localFilePath,
			String... files) {
		Boolean flag = Boolean.FALSE;
		for (String fileName : files) {
			File sourceFile = new File(remoteFilePath + File.separator
					+ fileName);
			File destinationFile = new File(localFilePath + File.separator
					+ fileName);
			flag = sourceFile.renameTo(destinationFile);
		}
		return flag;
	}

	public FileConfig getFileConfig() {
		return fileConfig;
	}

	public void setFileConfig(FileConfig fileConfig) {
		this.fileConfig = fileConfig;
	}

	public FileDao getFileDao() {
		return fileDao;
	}

	public void setFileDao(FileDao fileDao) {
		this.fileDao = fileDao;
	}



	public Boolean getIsInteractRePPSService() {
		return isInteractRePPSService;
	}

	public void setIsInteractRePPSService(Boolean isInteractRePPSService) {
		this.isInteractRePPSService = isInteractRePPSService;
	}






}
