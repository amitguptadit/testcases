package com.vtl.obs.schedulers;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;

import com.vtl.obs.config.FileConfig;
import com.vtl.obs.exceptions.BusinessException;
import com.vtl.obs.services.IFileService;
import com.vtl.obs.util.ResponseConstants;

/**
 * @author Amit Gupta
 * @version 1.0
 */
public class BaseUploadScheduler {

	private final static Logger logger = Logger
			.getLogger(BaseUploadScheduler.class);

	private IFileService fileService;
	private FileConfig fileConfig;

	/**
	 * This method is used as a job for the base upload scheduler
	 */
	public void performTask() {
		logger.info("BaseUploadScheduler is started at "
				+ Calendar.getInstance().getTime());
		this.startBaseUpload();
		logger.info("BaseUploadScheduler is finished at "
				+ Calendar.getInstance().getTime());
		
		
	}

	/**
	 * This method is used to perform the steps of base uploading
	 */
	private void startBaseUpload() {
		Calendar currCal = Calendar.getInstance();

		final String currDate = String.format("%02d",
				(currCal.get(Calendar.DATE)))
				+ String.format("%02d", (currCal.get(Calendar.MONTH) + 1))
				+ currCal.get(Calendar.YEAR)
				+ String.format("%02d", (currCal.get(Calendar.HOUR_OF_DAY)));

		String fileName = fileConfig.getRechargeWalletFileName().replaceAll("DDMMYYYHH",currDate);

		logger.info("File which is expected to like to be present at FTP location ->"+ fileName);
		// find out files at FTP location and download
		List<String> downloadedFileList = null;
		try {
			downloadedFileList = fileService.downloadFile(fileConfig, currCal,
					fileConfig.getRemoteFileSourcePath(),
					fileConfig.getRemoteFileBackupPath(),
					fileConfig.getLocalFilePath(), fileName,
					fileConfig.getRechargeWalletFileExtension());
		} catch (BusinessException e) {
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			e.printStackTrace(writer);
			logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
					.getResponseCode()
					+ ":"
					+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
					+ ":" + stack.toString());
			return;
		}

		logger.info("File Handled By Another Process : "+ fileName);
	}

	public IFileService getFileService() {
		return fileService;
	}

	public void setFileService(IFileService fileService) {
		this.fileService = fileService;
	}

	public FileConfig getFileConfig() {
		return fileConfig;
	}

	public void setFileConfig(FileConfig fileConfig) {
		this.fileConfig = fileConfig;
	}

}
