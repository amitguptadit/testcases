package com.vtl.obs.services;

import java.util.Calendar;
import java.util.List;

import com.vtl.obs.config.FileConfig;
import com.vtl.obs.exceptions.BusinessException;
import com.vtl.obs.exceptions.DatabaseException;

public interface IFileService {

	List<String> downloadFile(FileConfig fileConfig, Calendar currCal,
			String remoteSourceFilePath, String remoteBackupFilePath,
			String localFilePath, final String fileName,
			final String fileExtension) throws BusinessException;

	Boolean ProcessFile(String sourceFilePath, String fileName, Calendar currCal);

	Boolean truncateTable() throws DatabaseException;

	Boolean moveFiles(String remoteFilePath, String localFilePath,
			String... files);

}
