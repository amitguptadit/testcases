package com.vtl.obs.util.spring;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.WebApplicationContext;

/**
 *
 * @author Amit Gupta
 * @version 1.0
 *
 *          A utility listener to get hold of Spring ApplicationContext and put
 *          that in {@link CustomBeanProvider}. That way all other code can
 *          access Spring ApplicationContext statically.
 *          <p>
 *          This listener should be configured in <code>web.xml</code> just
 *          after Spring's own initializing listener as shown below-
 *          <p>
 *
 *          <pre>
 *  &lt;listener&gt;
 *         &lt;listener-class&gt;org.springframework.web.context.ContextLoaderListener&lt;/listener-class&gt;
 *     &lt;/listener&gt;
 *     &lt;listener&gt;
 *         &lt;listener-class&gt;com.sb.framework.util.AppContextInitializer&lt;/listener-class&gt;
 *     &lt;/listener&gt;
 * </pre>
 *
 */
public class AppContextInitializer implements ServletContextListener {

	private final Log log = LogFactory.getLog(AppContextInitializer.class);

	/**
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		try {
			ServletContext sc = sce.getServletContext();
			CustomBeanProvider
					.setSpringContext((ApplicationContext) sc
							.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE));

			/*
			String useCache = sc
					.getInitParameter(RechargeWalletConstants.PARAM_USE_CACHE_NAME);
			log.info("Is Cache enabled : " + useCache);
			if (RechargeWalletConstants.VALUE_TRUE
					.equals(useCache)) {
				ICacheService cacheService = (CacheService) CustomBeanProvider
						.getBean("cacheService");
				cacheService.cachePPSServicePlanConfiguration();
			}
			*/
			log.info("Success - applicationContext instantiation . . .");
		} catch (Exception e) {
			log.error("Error While instantiating Application Context: ", e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
	}

}
