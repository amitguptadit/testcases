/*
 * @author amit.gupta2
 *
 */
package com.vtl.obs.daoImpl;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.vtl.obs.beans.User;
import com.vtl.obs.dao.UserDao;
import com.vtl.obs.hb.beans.HUser;
import com.vtl.obs.util.HibernateUtil;

public class UserDaoImpl implements UserDao {

	public static final Logger logger = Logger.getLogger("UserDaoImpl.class");

	@Autowired
	private HibernateUtil hibernateDao;

	@Override
	public boolean isValidUser(User user)
	{
		Session session = null;
		Boolean status = Boolean.FALSE;
		try {

			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			String loginUid = null;

			Criteria criteria = session
					.createCriteria(HUser.class)
					.add(Restrictions.eq("userId", user.getEmail()))
					.add(Restrictions
							.eq("password",
									user.getPassword()));


			loginUid = ((criteria.uniqueResult() != null) ? criteria
					.uniqueResult().toString() : "NA");

			logger.info("[  huserId is  : "
					+ loginUid + ", criteria :" + criteria.toString()+" ]");
			session.getTransaction().commit();
			session.close();

			if (loginUid.equalsIgnoreCase("NA")) {
				status = Boolean.FALSE;
			} else {
				status = Boolean.TRUE;
			}


		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error(" HibernateException:>>"
					+ stack.toString());
		}
		catch (Exception e)
		{
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error(" Exception :>>"
					+ stack.toString());

		}
		return status;
	}

}
