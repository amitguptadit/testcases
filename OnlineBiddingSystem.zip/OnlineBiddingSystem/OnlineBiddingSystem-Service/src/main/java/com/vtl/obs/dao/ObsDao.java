package com.vtl.obs.dao;

import java.util.List;
import java.util.Map;


import com.vtl.obs.hb.beans.HBid;
import com.vtl.obs.hb.beans.HBidType;
import com.vtl.obs.hb.beans.HUser;
import com.vtl.obs.hb.beans.HUserBid;
import com.vtl.obs.hb.beans.HUserRoleDetails;

public interface ObsDao {
	public void removeUserBid(HUser hUser,int bidId);
	public HUser getHUserOnBasisOfMsisdn(String msisdn);
	public Map<String,String> getUserbidAttachmentListOnBasisOfAllUsersWithBidId(List<HUser> hUserList,int bidId);
	public Map<String,Double> getUserbidPriceListOnBasisOfAllUsersWithBidId(List<HUser> hUserList,int bidId);
	public HUser getHUser(int roleType);
	public Map<String,String> getUserbidCommentListOnBasisOfBidId(List<HBid> userListOnBasisOfBidId,HUser hUser);
	public List<String> userMappedBidsNameList(HUser hUser);
	public List<String> userAvialableBidNameList(HUser hUser) ;
	public HUserBid getUsrWiseBid(HUser hUser, HBid prevHBid);

	public Map<String,Double> getUserbidPriceListOnBasisOfBidId(List<HBid> userListOnBasisOfBidId,HUser hUser);
	public Map<String,String> getUserbidStatusListOnBasisOfBidId(List<HBid> userListOnBasisOfBidId,HUser hUser);
	public Map<String,String> getUserbidAttachmentListOnBasisOfBidId(List<HBid> userListOnBasisOfBidId,HUser hUser);
	
	public List<HBid> viewBidListOnBasisOfUserIdPagination(List<HBid> bidListOnBasisOfUserId, int offset,int noOfRecords);
	public List<HUser> viewUserListOnBasisOfBidIdPagination(List<HUser> hUserList, int offset,int noOfRecords);
	//public List<HUser> HUserBid getUsrWiseBid(HBid prevHBid);
	//bidId
	public List<HUser> getUserListOnBasisOfBidId(HBid prevHBid);
	public List<HBid> getBidListOnBasisOfUserId(HUser hUser);
	
	public HUserRoleDetails getRoleType(String userId);

	public Boolean updateUser(HUser hUser);

	public List<HBid> viewUserWiseBidPagination(HBid hBid, String bidStatus,
			int offset, int noOfRecords);

	public Map<String,String> getUserbidStatusList(List<HUser> hUserList,int bidId);
	public List<HUserBid> getUsrWiseBidList(HUser hUser,String userbidStatus);

	public int getNoOfRecords(String bidStatus);

	public List<HBid> viewBidPagination(String bidStatus, int offset,
			int noOfRecords);

	public Boolean checkBidExist(String bidName);

	public Boolean checkHUserExist(String userId);

	public Boolean createUserBids(HUserBid hUserbid);

	public List<String> BidNameList();
	
	public List<HBid> getAllBids();
	
	public List<HBid> getAllOpenBids();


	public HUserRoleDetails getHUserRoleType(String userRoleType);

	public Boolean createUser(HUser hUser);

	public List<String> UserTypeList();

	public List<String> BidTypeList();

	public HBidType getHBidType(String bidType);

	public HBid getHBid(int bidId);

	public HBid getHBid(String bidName);

	public HUser getHUser(String userId);

	public Boolean createBids(HBid hbid);

	public List<String> getCliList();

	public List<HBid> BidList();

	public List<HUser> viewAllUsers();

	public List<HBid> viewAllBids();

	public void deleteUser(int userId);

	public void deleteBid(int bidId);

	public Boolean updateBid(HBid hBid);

	public Boolean checkMsisdn(String msisdn);
	

}
