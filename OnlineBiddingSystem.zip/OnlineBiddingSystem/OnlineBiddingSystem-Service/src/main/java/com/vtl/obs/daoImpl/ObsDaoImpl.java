/*
 * @author amit.gupta2
 *
 */

package com.vtl.obs.daoImpl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.vtl.obs.dao.ObsDao;
import com.vtl.obs.hb.beans.HBid;
import com.vtl.obs.hb.beans.HBidType;
import com.vtl.obs.hb.beans.HUser;
import com.vtl.obs.hb.beans.HUserBid;
import com.vtl.obs.hb.beans.HUserRoleDetails;
import com.vtl.obs.util.HibernateUtil;


public class ObsDaoImpl implements ObsDao {

	public static final Logger logger = Logger.getLogger("ObsDaoImpl.class");

	@Autowired
	private HibernateUtil hibernateDao;

	
	
	@Override
    public Map<String,String> getUserbidCommentListOnBasisOfBidId(List<HBid> userListOnBasisOfBidId,HUser hUser)
    {
           Session session = null;
            Map<String,String> userBidCommentNameMap=null;
           try {
                  session = hibernateDao.getHibernateSessionFactory().openSession();
                  session.beginTransaction();
                  
                  userBidCommentNameMap=new HashMap<String,String>();
                  for(HBid hBid:userListOnBasisOfBidId)
                  {
                        Query qry1 = session.createQuery("select userBidComment from HUserBid where huserId="
                                      + hUser.getHuserId() + " and bidId="+hBid.getBidId()+"");
                        List<String> userBidCommentLs=(List<String>)qry1.list();
                        
                        String userBidComment=userBidCommentLs.get(0);
                        logger.info("getUserbidCommentListOnBasisOfBidId()#userBidComment :"+userBidComment);
                        //userbidStatusList.add(userbidStatus);
                        userBidCommentNameMap.put(hBid.getBidName(), userBidComment);
                  }
                  logger.info("getUserbidCommentListOnBasisOfBidId()#userBidCommentNameMap.size() :"+userBidCommentNameMap.size());                                    
                  session.getTransaction().commit();
                  session.close();
           } catch (HibernateException es) {
                  es.printStackTrace();
                  session.getTransaction().rollback();
                  StringWriter stack = new StringWriter();
                  es.printStackTrace(new PrintWriter(stack));
                  logger.error("getUserbidCommentListOnBasisOfBidId()# HibernateException:>>" + stack.toString());
           } catch (Exception e) {
                  StringWriter stack = new StringWriter();
                  e.printStackTrace(new PrintWriter(stack));
                  logger.error("getUserbidCommentListOnBasisOfBidId()# Exception :>>" + stack.toString());
           }
           return userBidCommentNameMap;            
    }

	@Override
	public HUserBid getUsrWiseBid(HUser hUser, HBid prevHBid) {

		Session session = null;
		HUserBid hUserBid = null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from HUserBid where bidId="
					+ prevHBid.getBidId() + " and huserId="
					+ hUser.getHuserId());
			hUserBid = (HUserBid) qry.uniqueResult();
			// if (logins == null)
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getHBid()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getHBid()# Exception :>>" + stack.toString());

		}
		return hUserBid;

	}

	@Override
	public Boolean checkMsisdn(String msisdn) {
		Session session = null;
		Boolean succFlag =Boolean.TRUE;;
		try {
			HUser hUser = null;
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			/*Query qry = session.createQuery("from HUser where msisdn='"
					+ msisdn + "'");
					
					//qry.setFirstResult(start);
					//qry.setMaxResults(maxRows);
			hUser = (HUser) qry.uniqueResult();
			 */
			
			Criteria criteria = session.createCriteria(HUser.class)
					.add(Restrictions.eq("msisdn", msisdn))
					.setFirstResult(0).setMaxResults(1);

			logger.info("[ checkMsisdn()#criteria :" + criteria.toString() + " ]");
			hUser =(HUser)criteria.uniqueResult();
			session.getTransaction().commit();
			session.close();
			if (hUser == null) {
				succFlag = Boolean.FALSE;
				logger.info("checkMsisdn()#msisdn :" + msisdn
						+ " does not exists.");
			}
			logger.info("checkMsisdn()#hUser :" + hUser + ",succFlag :"
					+ succFlag);
			System.out.println("checkMsisdn()#hUser :" + hUser + ",succFlag :"
					+ succFlag);
			
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("checkMsisdn()# HibernateException:>>"
					+ stack.toString());
			succFlag = Boolean.FALSE;
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("checkMsisdn()# Exception :>>" + stack.toString());
			succFlag = Boolean.FALSE;

		}

		System.out.println("checkMsisdn()#return succFlag :" + succFlag);
		return succFlag;

	}

	@Override
	public HUserRoleDetails getRoleType(String userId) {
		Session session = null;
		HUserRoleDetails hUserRoleDetails = null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			// select userRole from
			Query qry = session
					.createQuery("select userRoleType from HUser where userId='"
							+ userId + "'");
			hUserRoleDetails = (HUserRoleDetails) qry.uniqueResult();
			session.getTransaction().commit();
			session.close();
			logger.info("getRoleType()# getting hUserRoleDetails :"
					+ hUserRoleDetails + " for userId :" + userId);
		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getRoleType()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getRoleType()# Exception :>>" + stack.toString());

		}
		return hUserRoleDetails;
	}

	@Override
	public HUser getHUser(String userId) {
		Session session = null;
		HUser hUser = null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from HUser where userId='"
					+ userId + "'");
			hUser = (HUser) qry.uniqueResult();
			session.getTransaction().commit();
			session.close();
			logger.info("getHUser()# getting hUser" + hUser);
		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getHUser()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getHUser()# Exception :>>" + stack.toString());

		}
		return hUser;

	}
	
	@Override
	public HUser getHUser(int roleType) {
		Session session = null;
		HUser hUser = null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from HUser where roleType="
					+ roleType + "");
			hUser = (HUser) qry.uniqueResult();
			session.getTransaction().commit();
			session.close();
			logger.info("getHUser()# getting hUser" + hUser+", roleType :"+roleType);
		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getHUser()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getHUser()# Exception :>>" + stack.toString());

		}
		return hUser;

	}


	@Override
	public HBid getHBid(int bidId) {
		Session session = null;
		HBid hBid = null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from HBid where bidId=" + bidId
					+ "");
			hBid = (HBid) qry.uniqueResult();
			// if (logins == null)
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getHBid()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getHBid()# Exception :>>" + stack.toString());

		}
		return hBid;

	}

	@Override
	public HBid getHBid(String bidName) {
		Session session = null;
		HBid hBid = null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from HBid where bidName='"
					+ bidName + "'");
			hBid = (HBid) qry.uniqueResult();
			// if (logins == null)
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getHBid()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getHBid()# Exception :>>" + stack.toString());

		}
		return hBid;

	}

	@Override
	public HUserRoleDetails getHUserRoleType(String userRoleType) {

		Session session = null;
		HUserRoleDetails hUserRoleDetails = null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session
					.createQuery("from HUserRoleDetails where userRole='"
							+ userRoleType + "'");
			hUserRoleDetails = (HUserRoleDetails) qry.uniqueResult();
			// if (logins == null)
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getHUserRoleType()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getHUserRoleType()# Exception :>>" + stack.toString());

		}
		return hUserRoleDetails;
	}

	@Override
	public Boolean updateUser(HUser hUser) {
		Session session = null;
		Boolean succFlag = Boolean.FALSE;
		try {

			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			session.saveOrUpdate(hUser); // update with Old Entry
			session.getTransaction().commit();
			session.close();
			succFlag = Boolean.TRUE;
			logger.error("updateUser()#user " + hUser.getHuserId()
					+ " updated successfully");
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("updateUser()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("updateUser()# Exception :>>" + stack.toString());

		}
		return succFlag;
	}

	@Override
	public Boolean createUser(HUser hUser) {
		Session session = null;
		Boolean succFlag = Boolean.FALSE;
		try {

			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			session.save(hUser); // update with Old Entry
			// session.saveOrUpdate(hUser); // update with Old Entry
			session.getTransaction().commit();
			session.close();
			succFlag = Boolean.TRUE;

		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("createUser()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("createUser()# Exception :>>" + stack.toString());

		}
		return succFlag;
	}

	@Override
	public List<String> UserTypeList() {

		Session session = null;
		Boolean status = Boolean.FALSE;
		List<String> userTypeList = new ArrayList<String>();
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session
					.createQuery("select userRole from HUserRoleDetails where roleType !=1");
			// Query qry =
			// session.createQuery("select userRole from HUserRoleDetails");
			userTypeList = qry.list();
			session.getTransaction().commit();
			session.close();

		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("UserTypeList()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("UserTypeList()# Exception :>>" + stack.toString());

		}
		return userTypeList;
	}

	@Override
	public List<HUserBid> getUsrWiseBidList(HUser hUser,String userbidStatus) {
		Session session = null;
		List<HUserBid> hUserBidList = new ArrayList<HUserBid>();
		try {
			/*
			 * tbl_user_bid get bidId,userbidStatus on basis of huserId
			 */
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			// where huserId=8;
			// 8-aug

			/*Query qry = session.createQuery("from HUserBid where huserId="
					+ hUser.getHuserId() + " and userbidStatus='Open'");*/
			
			Query qry = session.createQuery("from HUserBid where huserId="
					+ hUser.getHuserId() + " and userbidStatus='"+userbidStatus+"'");
			// 6-aug Query qry =
			// session.createQuery("from HUserBid where huserId="+8+""); //doing
			// 8 for testing with admin user
			hUserBidList = qry.list();

			logger.info("getUsrWiseBidList() # " + hUser.getHuserId()
					+ " hUserBidList size:" + hUserBidList.size());
			System.out.println("getUsrWiseBidList() # " + hUser.getHuserId()
					+ " hUserBidList size:" + hUserBidList.size());
			session.getTransaction().commit();
			session.close();

		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getUsrWiseBidStatus()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getUsrWiseBidStatus()# Exception :>>"
					+ stack.toString());

		}
		return hUserBidList;

	}
	
	//userAvialableBidNameList(prevHUser)
	//userMappedBidsNameList
	@Override
	public List<String> userMappedBidsNameList(HUser hUser) {

		Session session = null;
		Boolean status = Boolean.FALSE;
		List<String> bidList = new ArrayList<String>();
		List<Integer> hUserBidNameList = new ArrayList<Integer>();
		List<Integer> hBidNameList = new ArrayList<Integer>();
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			
			logger.info("userMappedBidsNameList()# huserId :"+hUser.getHuserId());
			Query qry = session.createQuery("select bidId from HUserBid where huserId="
					+ hUser.getHuserId());
			//hUserBidNameList =qry.list();
			List<HBid>  userBidList=qry.list();
			Query qry1 = session.createQuery("from HBid");
			List<HBid> hBidList = qry1.list();
			
			for(HBid hBid_user:userBidList)
			{
				logger.info("userMappedBidsNameList()# hBid_user.getBidId():-->"+hBid_user.getBidId());
				for(HBid hBid:hBidList)
				{
					if(hBid_user.getBidId()==hBid.getBidId())
					{
						bidList.add(hBid.getBidName());
						System.out.println("userMappedBidsNameList()# addBidName:"+hBid.getBidName()+",hBid.getBidId()"+hBid.getBidId());
						logger.info("userMappedBidsNameList()# addBidName:"+hBid.getBidName()+",hBid.getBidId()"+hBid.getBidId());
					}
				}
				
			}
									
			session.getTransaction().commit();
			session.close();

		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("userMappedBidsNameList()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("userMappedBidsNameList()# Exception :>>" + stack.toString());

		}
		return bidList;
	}
	
	@Override
	public List<String> userAvialableBidNameList(HUser hUser) {

		Session session = null;
		Boolean status = Boolean.FALSE;
		List<String> bidList = new ArrayList<String>();
		
		List<String> bidList1 = new ArrayList<String>();
		List<String> bidList2 = new ArrayList<String>();
		
		List<Integer> hUserBidNameList = new ArrayList<Integer>();
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			
			logger.info("userAvialableBidNameList()# huserId :"+hUser.getHuserId());
			Query qry = session.createQuery("select bidId from HUserBid where huserId="
					+ hUser.getHuserId());
			
			List<HBid>  userBidList=qry.list();
			Query qry1 = session.createQuery("from HBid");
			List<HBid> hBidList = qry1.list();
			
			
			for(HBid hBid:hBidList)	
			{
				//logger.info("userAvialableBidNameList()# hBid.getBidId()::-->"+hBid.getBidId());
				bidList2.add(hBid.getBidName());
				
				for(HBid hBid_user:userBidList)
				{
					if(hBid_user.getBidId()==hBid.getBidId())
					{
						bidList1.add(hBid.getBidName());
					}
					else
					{
						
						//System.out.println("userAvialableBidNameList()# addBidName:"+hBid.getBidName()+",hBid.getBidId()"+hBid.getBidId());
						//logger.info("userAvialableBidNameList()# addBidName:"+hBid.getBidName()+",hBid.getBidId()"+hBid.getBidId());
						
					}
				}				
			}			
			logger.info("userAvialableBidNameList()# bidList2::-->"+bidList2);
			
			bidList2.removeAll(bidList1);
			bidList=bidList2;
			
			logger.info("userAvialableBidNameList()# bidList1::-->"+bidList1);
			
			logger.info(bidList+"userAvialableBidNameList()# bidList2::-->"+bidList2);
			
			

			
			session.getTransaction().commit();
			session.close();

		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("userAvialableBidNameList()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("userAvialableBidNameList()# Exception :>>" + stack.toString());

		}
		return bidList;
	}

	@Override
	public List<String> BidNameList() {

		Session session = null;
		Boolean status = Boolean.FALSE;
		List<String> bidList = new ArrayList<String>();
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("select bidName from HBid");
			bidList = qry.list();
			session.getTransaction().commit();
			session.close();

		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("BidNameList()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("BidNameList()# Exception :>>" + stack.toString());

		}
		return bidList;
	}

	@Override
	public List<String> BidTypeList() {

		Session session = null;
		Boolean status = Boolean.FALSE;
		List<String> bidList = new ArrayList<String>();
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("select bidType from HBidType");
			bidList = qry.list();
			session.getTransaction().commit();
			session.close();

		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("BidTypeList()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("BidTypeList()# Exception :>>" + stack.toString());

		}
		return bidList;
	}

	@Override
	public int getNoOfRecords(String bidStatus) {
		Session session = null;
		int noOfRecords = 0;
		try {

			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from HUserBid where userbidStatus='"
					+ bidStatus + "'");
			noOfRecords = qry.list().size();

			logger.info("noOfRecords: " + noOfRecords + ", userbidStatus="
					+ bidStatus);
			session.getTransaction().commit();
			session.close();

		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getNoOfRecords()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getNoOfRecords()# Exception :>>" + stack.toString());

		}
		return noOfRecords;
	}

	@Override
	public List<HBid> viewBidPagination(String bidStatus, int offset,
			int noOfRecords) {
		Session session = null;
		List<HBid> bidList = new ArrayList<HBid>();
		try {
			System.out.println("[----------viewBidPagination()----------]");

			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Criteria criteria = session.createCriteria(HBid.class)
					.add(Restrictions.eq("bidStatus", bidStatus))
					.setFirstResult(offset).setMaxResults(noOfRecords);

			// .setMaxResults(3);

			logger.info("[ criteria :" + criteria.toString() + " ]");

			bidList = criteria.list();
			System.out.println("BidList()#bidList size :" + bidList.size());
			logger.info("BidList()#bidList size :" + bidList.size());

			session.getTransaction().commit();
			session.close();

		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("viewBidPagination()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("viewBidPagination()# Exception :>>"
					+ stack.toString());

		}
		return bidList;
	}

	@Override
	public List<HBid> viewUserWiseBidPagination(HBid hBid, String bidStatus,
			int offset, int noOfRecords) {
		Session session = null;
		List<HBid> bidList = new ArrayList<HBid>();
		try {
			System.out
					.println("[----------viewUserWiseBidPagination()----------bidStatus :]"+bidStatus);

			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Criteria criteria=null;
			if(!bidStatus.equalsIgnoreCase("Apply"))
			{
				if(!bidStatus.equalsIgnoreCase("Exit"))
				{
					criteria = session.createCriteria(HBid.class)
							.add(Restrictions.eq("bidStatus", bidStatus))					
						.add(Restrictions.eq("bidId", hBid.getBidId()))
						//hBid
						.setFirstResult(offset).setMaxResults(noOfRecords);
					bidList = criteria.list();
				}
				else
				{
					criteria = session.createCriteria(HBid.class)					
						.add(Restrictions.eq("bidId", hBid.getBidId()))
						//hBid
						.setFirstResult(offset).setMaxResults(noOfRecords);
					bidList = criteria.list();
					List<HBid> hhbidList = new ArrayList<HBid>();
					for(HBid hhBid:bidList)
					{
						/*if(bidStatus.equalsIgnoreCase("Exit"))
						{
							hhBid.setBidStatus("Exit");
						}
						else if(bidStatus.equalsIgnoreCase("Apply"))
						{
							hhBid.setBidStatus("Apply");
						}*/
						hhbidList.add(hhBid);
					}
					bidList=hhbidList;
				}
			}
			else
			{
				criteria = session.createCriteria(HBid.class)					
					.add(Restrictions.eq("bidId", hBid.getBidId()))
					//hBid
					.setFirstResult(offset).setMaxResults(noOfRecords);
				bidList = criteria.list();
				List<HBid> hhbidList = new ArrayList<HBid>();
				for(HBid hhBid:bidList)
				{
					/*if(bidStatus.equalsIgnoreCase("Exit"))
					{
						hhBid.setBidStatus("Exit");
					}
					else if(bidStatus.equalsIgnoreCase("Apply"))
					{
						hhBid.setBidStatus("Apply");
					}*/
					hhbidList.add(hhBid);
				}
				bidList=hhbidList;
			}
			// .setMaxResults(3);

			logger.info("[ criteria :" + criteria.toString() + " ]");

			// List<HBid> ls=criteria.list();

			
			System.out.println("BidList()#bidList size :" + bidList.size());
			logger.info("BidList()#bidList size :" + bidList.size());

			session.getTransaction().commit();
			session.close();

		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("viewUserWiseBidPagination()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("viewUserWiseBidPagination()# Exception :>>"
					+ stack.toString());

		}
		return bidList;
	}

	@Override
	public List<HBid> BidList() {

		Session session = null;
		Boolean status = Boolean.FALSE;
		List<HBid> bidList = new ArrayList<HBid>();
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from HBid");
			bidList = qry.list();
			System.out.println("BidList()#bidList size :" + bidList.size());
			logger.info("BidList()#bidList size :" + bidList.size());
			session.getTransaction().commit();
			session.close();

		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("BidTypeList()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("BidTypeList()# Exception :>>" + stack.toString());

		}

		return bidList;
	}

	@Override
	public HBidType getHBidType(String bidType) {

		Session session = null;
		HBidType hBidType = null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from HBidType where bidType='"
					+ bidType + "'");
			hBidType = (HBidType) qry.uniqueResult();
			// if (logins == null)
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getHBidType()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getHBidType()# Exception :>>" + stack.toString());

		}
		return hBidType;
	}

	@Override
	public Boolean createUserBids(HUserBid hUserbid) {
		Session session = null;
		Boolean succFlag = Boolean.FALSE;
		try {
				
		
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			// session.save(hUserbid); // New Entry every time

			session.saveOrUpdate(hUserbid); // update with Old Entry
			session.getTransaction().commit();
			session.close();
			succFlag = Boolean.TRUE;
			System.out.println("createUserBids()#Creation of UserBids Done");

		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("createUserBids()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("createUserBids()# Exception :>>" + stack.toString());

		}

		return succFlag;
	}

	@Override
	public Boolean checkHUserExist(String userId) {
		Session session = null;
		Boolean succFlag = Boolean.FALSE;
		try {
			HUser hUser = null;
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from HUser where userId='"
					+ userId + "'");
			hUser = (HUser) qry.uniqueResult();

			session.getTransaction().commit();
			session.close();
			if (hUser == null) {
				succFlag = Boolean.TRUE;
				logger.info("checkHUserExist()#userId :" + userId
						+ " does not exists.");
			}
			logger.info("checkHUserExist()#hUser :" + hUser + ",succFlag :"
					+ succFlag);
			System.out.println("checkHUserExist()#hUser :" + hUser
					+ ",succFlag :" + succFlag);
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("checkHUserExist()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("checkHUserExist()# Exception :>>" + stack.toString());

		}

		System.out.println("checkBidExist()#return succFlag :" + succFlag);
		return succFlag;

	}

	@Override
	public Boolean checkBidExist(String bidName) {

		Session session = null;
		Boolean succFlag = Boolean.FALSE;
		try {
			HBid hbid = null;
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from HBid where bidName='"
					+ bidName + "'");
			hbid = (HBid) qry.uniqueResult();

			session.getTransaction().commit();
			session.close();
			if (hbid == null) {
				succFlag = Boolean.TRUE;
			}
			logger.info("checkBidExist()#hbid :" + hbid + ",succFlag :"
					+ succFlag);
			System.out.println("checkBidExist()#hbid :" + hbid + ",succFlag :"
					+ succFlag);
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("createBids()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("createBids()# Exception :>>" + stack.toString());

		}

		System.out.println("checkBidExist()#return succFlag :" + succFlag);
		return succFlag;

	}

	@Override
	public Boolean createBids(HBid hbid) {
		Session session = null;
		Boolean succFlag = Boolean.FALSE;
		try {
			hbid.setBidDescription(hbid.getBidDescription().trim());
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			// session.save(subs); // New Entry every time

			session.saveOrUpdate(hbid); // update with Old Entry
			session.getTransaction().commit();
			session.close();
			succFlag = Boolean.TRUE;

		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("createBids()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("createBids()# Exception :>>" + stack.toString());

		}

		return succFlag;
	}

	@Override
	public List<String> getCliList() {

		Session session = null;
		List<String> cliList = new ArrayList<String>();
		try {

			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("select cli from CLI");
			cliList = qry.list();
			session.getTransaction().commit();
			session.close();

		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getCliList()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getCliList()# Exception :>>" + stack.toString());
		}
		return cliList;
	}

	// ------------Anu-
	@Override
	public List<HUser> viewAllUsers() {

		Session session = null;
		List<HUser> userList = new ArrayList<HUser>();
		try {

			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from HUser");
			userList = qry.list();
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("viewAllUsers()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("viewAllUsers()# Exception :>>" + stack.toString());
		}
		return userList;
	}

	@Override
	public List<HBid> viewAllBids() {
		Session session = null;
		List<HBid> bidList = new ArrayList<HBid>();
		try {

			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("from HBid");
			bidList = qry.list();
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("viewAllBids()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("viewAllBids()# Exception :>>" + stack.toString());
		}
		return bidList;
	}

	@Override
	public Boolean updateBid(HBid hBid) {
		Session session = null;
		Boolean succFlag = Boolean.FALSE;
		try {

			hBid.setBidDescription(hBid.getBidDescription().trim());
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			session.saveOrUpdate(hBid); // update with Old Entry
			session.getTransaction().commit();
			session.close();
			succFlag = Boolean.TRUE;
			logger.error("updateBid()#bid " + hBid.getBidName()
					+ " updated successfully");
		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("updateBid()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("updateBid()# Exception :>>" + stack.toString());
		}
		return succFlag;
	}

	@Override
	public void deleteUser(int userId) {
		Session session = hibernateDao.getHibernateSessionFactory()
				.openSession();
		Transaction txn = null;
		try {

			txn = session.beginTransaction();
			System.out.println("deleteUser()-1 method......." + userId);
			logger.info("deleteUser() method-1......." + userId);

			Query qry = session.createQuery("from HUserBid where huserId="
					+ userId + "");
			List<HUserBid> hUserBidList = (List<HUserBid>) qry.list();

			for (HUserBid hUserBid : hUserBidList) {
				session.delete(hUserBid);
				logger.info("deleteUser()# deleted hUserBid:" + hUserBid
						+ " for huserId :" + userId);
			}
			HUser hUser = (HUser) session.get(HUser.class, userId);
			session.delete(hUser);
			logger.info("deleteUser()# deleted hUser:" + hUser
					+ " for huserId :" + userId);
			txn.commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("deleteUser()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("deleteUser()# Exception :>>" + stack.toString());
		}
	}
	
	@Override
	public void removeUserBid(HUser hUser,int bidId) {

		Session session = hibernateDao.getHibernateSessionFactory()
				.openSession();
		Transaction txn = null;
		try {
			
			txn = session.beginTransaction();
			System.out.println("removeUserBid()#Removing bidId :"+bidId+"and huserId="
					+ hUser.getHuserId());
			logger.info("removeUserBid()#Removing bidId :"+bidId+"and huserId="
					+ hUser.getHuserId());
			
			Query qry = session.createQuery("from HUserBid where bidId="
					+ bidId + " and huserId="
					+ hUser.getHuserId());
			List<HUserBid> hUserBidList = (List<HUserBid>) qry.list();

			for (HUserBid hUserBid : hUserBidList) {
				session.delete(hUserBid);
				logger.info("removeUserBid()# deleted hUserBid:" + hUserBid
						+ " for bidId :" + bidId);
			}

			
			txn.commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("removeUserBid()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("removeUserBid()# Exception :>>" + stack.toString());
		}
	}


	@Override
	public void deleteBid(int bidId) {

		Session session = hibernateDao.getHibernateSessionFactory()
				.openSession();
		Transaction txn = null;
		try {
			txn = session.beginTransaction();
			System.out.println("deleteBid()#Bid delete method......."+bidId);
			logger.info("deleteBid()#Bid delete method......."+bidId);
			
			Query qry = session.createQuery("from HUserBid where bidId="
					+ bidId + "");
			List<HUserBid> hUserBidList = (List<HUserBid>) qry.list();

			for (HUserBid hUserBid : hUserBidList) {
				session.delete(hUserBid);
				logger.info("deleteBid()# deleted hUserBid:" + hUserBid
						+ " for bidId :" + bidId);
			}

			HBid hBid = (HBid) session.get(HBid.class, bidId);
			session.delete(hBid);
			txn.commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("deleteBid()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("deleteBid()# Exception :>>" + stack.toString());
		}
	}
	

	//public List<HBid> viewBidListOnBasisOfUserIdPagination(List<HBid> bidListOnBasisOfUserId, int offset,int noOfRecords);
	
	@Override
	public List<HBid> viewBidListOnBasisOfUserIdPagination(List<HBid> bidListOnBasisOfUserId, int offset,
			int noOfRecords) {
		Session session = null;
		List<HBid> hBidLs = new ArrayList<HBid>();
		try {
			 offset=0;
			 noOfRecords=100;
			if(offset==0 && noOfRecords<bidListOnBasisOfUserId.size())
			{
				for(int i=0;i<bidListOnBasisOfUserId.size();i++)
				{
					hBidLs.add(bidListOnBasisOfUserId.get(i));
				}
				logger.info("viewUserListOnBasisOfBidIdPagination()#offset==0 && noOfRecords<bidListOnBasisOfUserId.size()#hBidLs size :" + hBidLs.size());
			}
			else if(offset>=0 && noOfRecords<bidListOnBasisOfUserId.size())
			{
				for(int i=offset;i<bidListOnBasisOfUserId.size();i++)
				{
					hBidLs.add(bidListOnBasisOfUserId.get(i));
				}
				logger.info("viewUserListOnBasisOfBidIdPagination()#offset>=0 && noOfRecords<bidListOnBasisOfUserId.size()#hBidLs size :" + hBidLs.size());
			}
			else
			{
				for(int i=offset;i<bidListOnBasisOfUserId.size();i++)
				{
					hBidLs.add(bidListOnBasisOfUserId.get(i));
				}
				logger.info("viewUserListOnBasisOfBidIdPagination()#Else hBidLs size :" + hBidLs.size());
			}
			
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("viewUserListOnBasisOfBidIdPagination()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("viewUserListOnBasisOfBidIdPagination()# Exception :>>"
					+ stack.toString());

		}
		return hBidLs;
	}
	
	@Override
	public List<HUser> viewUserListOnBasisOfBidIdPagination(List<HUser> hUserList, int offset,
			int noOfRecords) {
		Session session = null;
		List<HUser> hUserLs = new ArrayList<HUser>();
		try {
			 offset=0;
			 noOfRecords=100;
			if(offset==0 && noOfRecords<hUserList.size())
			{
				for(int i=0;i<hUserList.size();i++)
				{
					hUserLs.add(hUserList.get(i));
				}
				logger.info("viewUserListOnBasisOfBidIdPagination()#offset==0 && noOfRecords<hUserList.size()#hUserLs size :" + hUserLs.size());
			}
			else if(offset>=0 && noOfRecords<hUserList.size())
			{
				for(int i=offset;i<hUserList.size();i++)
				{
					hUserLs.add(hUserList.get(i));
				}
				logger.info("viewUserListOnBasisOfBidIdPagination()#offset>=0 && noOfRecords<hUserList.size()#hUserLs size :" + hUserLs.size());
			}
			else
			{
				for(int i=offset;i<hUserList.size();i++)
				{
					hUserLs.add(hUserList.get(i));
				}
				logger.info("viewUserListOnBasisOfBidIdPagination()#Else hUserLs size :" + hUserLs.size());
			}
			/*System.out.println("[----------viewBidPagination()----------]");

			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Criteria criteria = session.createCriteria(HUser.class)
					.add(Restrictions.eq("bidStatus", bidStatus))
					.setFirstResult(offset).setMaxResults(noOfRecords);

			logger.info("[ criteria :" + criteria.toString() + " ]");

			bidList = criteria.list();
			System.out.println("BidList()#bidList size :" + bidList.size());
			logger.info("BidList()#bidList size :" + bidList.size());

			session.getTransaction().commit();
			session.close();
			*/

		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("viewUserListOnBasisOfBidIdPagination()# HibernateException:>>"
					+ stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("viewUserListOnBasisOfBidIdPagination()# Exception :>>"
					+ stack.toString());

		}
		return hUserLs;
	}

	@Override
	public Map<String,Double> getUserbidPriceListOnBasisOfBidId(List<HBid> userListOnBasisOfBidId,HUser hUser)
	{
		Session session = null;
		 Map<String,Double> userbidPriceMap=null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			
			userbidPriceMap=new HashMap<String,Double>();
			for(HBid hBid:userListOnBasisOfBidId)
			{
				Query qry1 = session.createQuery("select userbidPrice from HUserBid where huserId="
						+ hUser.getHuserId() + " and bidId="+hBid.getBidId()+"");
				List<Double> userbidPriceLs=(List<Double>)qry1.list();
				
				Double userbidPrice=userbidPriceLs.get(0);
				logger.info("getUserbidPriceListOnBasisOfBidId()#userbidPrice :"+userbidPrice);
				//userbidStatusList.add(userbidStatus);
				userbidPriceMap.put(hBid.getBidName(), userbidPrice);
			}
			logger.info("getUserbidPriceListOnBasisOfBidId()#userbidPriceMap.size() :"+userbidPriceMap.size());
						
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getUserbidPriceListOnBasisOfBidId()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getUserbidPriceListOnBasisOfBidId()# Exception :>>" + stack.toString());

		}
		return userbidPriceMap;		
		
	}
	@Override
	public Map<String,String> getUserbidStatusListOnBasisOfBidId(List<HBid> userListOnBasisOfBidId,HUser hUser)
	{
		Session session = null;
		 Map<String,String> userbidStatusMap=null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			
			userbidStatusMap=new HashMap<String,String>();
			for(HBid hBid:userListOnBasisOfBidId)
			{
				Query qry1 = session.createQuery("select userbidStatus from HUserBid where huserId="
						+ hUser.getHuserId() + " and bidId="+hBid.getBidId()+"");
				List<String> userbidStatusLs=(List<String>)qry1.list();
				
				String userbidStatus=userbidStatusLs.get(0);
				logger.info("getUserbidStatusListOnBasisOfBidId()#userbidStatus :"+userbidStatus);
				//userbidStatusList.add(userbidStatus);
				userbidStatusMap.put(hBid.getBidName(), userbidStatus);
			}
			logger.info("getUserbidStatusListOnBasisOfBidId()#userbidStatusMap.size() :"+userbidStatusMap.size());
						
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getUserbidStatusListOnBasisOfBidId()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getUserbidStatusListOnBasisOfBidId()# Exception :>>" + stack.toString());

		}
		return userbidStatusMap;		
		
	}
	@Override
	public Map<String,String> getUserbidAttachmentListOnBasisOfBidId(List<HBid> userListOnBasisOfBidId,HUser hUser)
	{
		Session session = null;
		 Map<String,String> userBidAttachmentNameMap=null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			
			userBidAttachmentNameMap=new HashMap<String,String>();
			for(HBid hBid:userListOnBasisOfBidId)
			{
				Query qry1 = session.createQuery("select userBidAttachmentName from HUserBid where huserId="
						+ hUser.getHuserId() + " and bidId="+hBid.getBidId()+"");
				List<String> userBidAttachmentNameLs=(List<String>)qry1.list();
				
				String userBidAttachmentName=userBidAttachmentNameLs.get(0);
				logger.info("getUserbidAttachmentListOnBasisOfBidId()#userBidAttachmentName :"+userBidAttachmentName);
				//userbidStatusList.add(userbidStatus);
				userBidAttachmentNameMap.put(hBid.getBidName(), userBidAttachmentName);
			}
			logger.info("getUserbidAttachmentListOnBasisOfBidId()#userBidAttachmentNameMap.size() :"+userBidAttachmentNameMap.size());
						
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getUserbidAttachmentListOnBasisOfBidId()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getUserbidAttachmentListOnBasisOfBidId()# Exception :>>" + stack.toString());

		}
		return userBidAttachmentNameMap;		
	}
	@Override
	public Map<String,String> getUserbidStatusList(List<HUser> hUserList,int bidId)
	{
		Session session = null;
		 Map<String,String> userbidStatusMap=null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			
			userbidStatusMap=new HashMap<String,String>();
			for(HUser hUser:hUserList)
			{
				Query qry1 = session.createQuery("select userbidStatus from HUserBid where huserId="
						+ hUser.getHuserId() + " and bidId="+bidId+"");
				List<String> userbidStatusLs=(List<String>)qry1.list();
				
				String userbidStatus=userbidStatusLs.get(0);
				logger.info("getUserListOnBasisOfBidId()#userbidStatus :"+userbidStatus);
				//userbidStatusList.add(userbidStatus);
				userbidStatusMap.put(hUser.getUserId(), userbidStatus);
			}
			logger.info("getUserListOnBasisOfBidId()#userbidStatusList.size() :"+userbidStatusMap.size());
						
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getUserListOnBasisOfBidId()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getUserListOnBasisOfBidId()# Exception :>>" + stack.toString());

		}
		return userbidStatusMap;		
	}
	@Override
	public List<HUser> getUserListOnBasisOfBidId(HBid prevHBid) {
		/*
		 //public List<HUser> HUserBid getUsrWiseBid(HBid prevHBid);
		//bidId
		public List<HUser> getUserListOnBasisOfBidId(HBid prevHBid);
		
		Query qry = session.createQuery("select bidId from HUserBid where huserId="
					+ hUser.getHuserId());
			//hUserBidNameList =qry.list();
			List<HBid>  userBidList=qry.list();
		 */
		
		Session session = null;
		List<HUser> hUserList=null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("select huserId from HUserBid where bidId="
					+ prevHBid.getBidId());
			hUserList=qry.list();
			//public HUserBid getUsrWiseBid(HUser hUser, HBid prevHBid);
			//public List<HUserBid> getUsrWiseBidList(HUser hUser,String userbidStatus);
			List<String> userbidStatusList=new ArrayList<String>();
			for(HUser hUser:hUserList)
			{
				Query qry1 = session.createQuery("select userbidStatus from HUserBid where huserId="
						+ hUser.getHuserId() + " and bidId="+prevHBid.getBidId()+"");
				List<String> userbidStatusLs=(List<String>)qry1.list();
				
				String userbidStatus=userbidStatusLs.get(0);
				logger.info("getUserListOnBasisOfBidId()#userbidStatus :"+userbidStatus);
				userbidStatusList.add(userbidStatus);				
			}
			logger.info("getUserListOnBasisOfBidId()#userbidStatusList.size() :"+userbidStatusList.size());
			/*
			 List<HUserBid> hUserBidList = (List<HUserBid>) qry.list();
			 Query qry = session.createQuery("from HUserBid where huserId="
					+ hUser.getHuserId() + " and userbidStatus='"+userbidStatus+"'");
			// 6-aug Query qry =
			// session.createQuery("from HUserBid where huserId="+8+""); //doing
			// 8 for testing with admin user
			hUserBidList = qry.list();

			 */
			
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getUserListOnBasisOfBidId()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getUserListOnBasisOfBidId()# Exception :>>" + stack.toString());

		}
		return hUserList;		
	}

	@Override
	public List<HBid> getBidListOnBasisOfUserId(HUser hUser) {
		Session session = null;
		List<HBid>  userBidList=null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Query qry = session.createQuery("select bidId from HUserBid where huserId="
					+ hUser.getHuserId());
			userBidList=qry.list();
			
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getBidListOnBasisOfUserId()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getBidListOnBasisOfUserId()# Exception :>>" + stack.toString());

		}
		return userBidList;		
		
	}

	@Override
	public Map<String,String> getUserbidAttachmentListOnBasisOfAllUsersWithBidId(
			List<HUser> hUserList, int bidId) {

		Session session = null;
		 Map<String,String> userBidAttachmentNameMap=null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			
			userBidAttachmentNameMap=new HashMap<String,String>();
			
			for(HUser hUser:hUserList)
			{
				Query qry1 = session.createQuery("select userBidAttachmentName from HUserBid where huserId="
					+ hUser.getHuserId() + " and bidId="+bidId+"");

				List<String> userBidAttachmentNameLs=(List<String>)qry1.list();
								
				String userBidAttachmentName=userBidAttachmentNameLs.get(0);
				logger.info("getUserbidAttachmentListOnBasisOfAllUsersWithBidId()#userBidAttachmentName :"+userBidAttachmentName);
				
				
				
				userBidAttachmentNameMap.put(hUser.getUserId(), userBidAttachmentName);
				
			}
			logger.info("getUserbidAttachmentListOnBasisOfAllUsersWithBidId()#userBidAttachmentNameMap.size() :"+userBidAttachmentNameMap.size());
						
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getUserbidAttachmentListOnBasisOfAllUsersWithBidId()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getUserbidAttachmentListOnBasisOfAllUsersWithBidId()# Exception :>>" + stack.toString());

		}
	return userBidAttachmentNameMap;

	}

	@Override
	public Map<String, Double> getUserbidPriceListOnBasisOfAllUsersWithBidId(
			List<HUser> hUserList, int bidId) {
		
		Session session = null;
		 Map<String,Double> userbidPriceMap=null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			
			userbidPriceMap=new HashMap<String,Double>();
			
			for(HUser hUser:hUserList)
			{
				Query qry1 = session.createQuery("select userbidPrice from HUserBid where huserId="
					+ hUser.getHuserId() + " and bidId="+bidId+"");

				List<Double> userbidPriceLs=(List<Double>)qry1.list();
				
				Double userbidPrice=userbidPriceLs.get(0);
				logger.info("getUserbidPriceListOnBasisOfAllUsersWithBidId()#userbidPrice :"+userbidPrice);
				
				userbidPriceMap.put(hUser.getUserId(), userbidPrice);
				
			}
			logger.info("getUserbidPriceListOnBasisOfAllUsersWithBidId()#userbidPriceMap.size() :"+userbidPriceMap.size());
						
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getUserbidPriceListOnBasisOfAllUsersWithBidId()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getUserbidPriceListOnBasisOfAllUsersWithBidId()# Exception :>>" + stack.toString());

		}
	return userbidPriceMap;

	}

	@Override
	public HUser getHUserOnBasisOfMsisdn(String msisdn) {
		Session session = null;
		HUser hUser = null;
		try {
			
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
				
			Criteria criteria = session.createCriteria(HUser.class)
					.add(Restrictions.eq("msisdn", msisdn))
					.setFirstResult(0).setMaxResults(1);

			logger.info("[ getHUserOnBasisOfMsisdn()#criteria :" + criteria.toString() + " ]");
			hUser =(HUser)criteria.uniqueResult();
			session.getTransaction().commit();
			session.close();
			
			logger.info("getHUserOnBasisOfMsisdn()#hUser :" + hUser +", msisdn :"+msisdn);
			System.out.println("getHUserOnBasisOfMsisdn()#hUser :" + hUser +", msisdn :"+msisdn);
			
		} catch (HibernateException es) {
			es.printStackTrace();

			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getHUserOnBasisOfMsisdn()# HibernateException:>>"
					+ stack.toString());
			
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getHUserOnBasisOfMsisdn()# Exception :>>" + stack.toString());
			
		}
		return hUser;
	}
	@Override
	public List<HBid> getAllBids() {
		Session session = null;
		HBid hBid = null;
		List<HBid> hBidList = null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Criteria criteria = session.createCriteria(HBid.class);			
			hBidList =criteria.list();
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getHBid()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getHBid()# Exception :>>" + stack.toString());

		}
		return hBidList;
	}

	@Override
	public List<HBid> getAllOpenBids() {
		Session session = null;		
		List<HBid> hBidList = null;
		try {
			session = hibernateDao.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			Criteria criteria = session.createCriteria(HBid.class).add(Restrictions.eq("bidStatus", "Open"));			
			hBidList =criteria.list();
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException es) {
			es.printStackTrace();
			session.getTransaction().rollback();
			StringWriter stack = new StringWriter();
			es.printStackTrace(new PrintWriter(stack));
			logger.error("getHBid()# HibernateException:>>" + stack.toString());
		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("getHBid()# Exception :>>" + stack.toString());
		}
		return hBidList;
	}

}
