package com.vtl.obs.servicesImpl;

import org.springframework.beans.factory.annotation.Autowired;

import com.vtl.obs.services.IOBSMail;
import com.vtl.obs.util.EmailService;


public class OBSMailImpl implements IOBSMail
{

	@Autowired
	private EmailService emailService;

	private String emailUserName;
	private String emailPassword;
	
	
	
	@Override
	public Boolean sendingMail(String mailSubject, String mailContent,
			String mailRecepientsTo, String mailRecepientsCc) {
		// TODO Auto-generated method stub
		return emailService.sendMail(emailUserName, emailPassword, mailSubject, mailContent, mailRecepientsTo, mailRecepientsCc);
	}

	public String getEmailUserName() {
		return emailUserName;
	}

	public void setEmailUserName(String emailUserName) {
		this.emailUserName = emailUserName;
	}

	public String getEmailPassword() {
		return emailPassword;
	}

	public void setEmailPassword(String emailPassword) {
		this.emailPassword = emailPassword;
	}



}

