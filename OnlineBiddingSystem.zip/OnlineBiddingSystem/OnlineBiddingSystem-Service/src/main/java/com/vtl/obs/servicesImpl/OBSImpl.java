package com.vtl.obs.servicesImpl;


import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.vtl.obs.services.IOBS;
import com.vtl.obs.util.UMFMessaging;


public class OBSImpl  implements IOBS
{
	
	public static final Logger logger = Logger.getLogger("OBSImpl.class");
	
	private String qtlVendorPassword;
	private String qtlUploadFilePath;
	private String serviceURL;
	
	private String umfCliName = null;
	private List<String> umfCliNameList = null;

	private String umfUserName = null;
	private List<String> umfUserNameList = null;

	private String umfPassword = null;
	private List<String> umfPasswordList = null;
	
	@Autowired
	private UMFMessaging umfMessaging;
	
	public void init()
	{
		if (umfCliName != null) {

			String[] arrAllowedClis = umfCliName.split(",");
			for (String allowedCli : arrAllowedClis) {
				umfCliNameList.add(allowedCli);
			}
		}

		if (umfUserName != null) {

			String[] arrAllowedUser = umfUserName.split(",");
			for (String allowedUser : arrAllowedUser) {
				umfUserNameList.add(allowedUser);
			}
		}

		if (umfPassword != null) {

			String[] arrAllowedPwd = umfPassword.split(",");
			for (String allowedPwd : arrAllowedPwd) {
				umfPasswordList.add(allowedPwd);
			}
		}
	}
	@Override
	public String sendMessage(String msisdn ,String msgContent)
	{
		//(String transId,String msisdn, String msgContent, String cli_name)
		String messageStatus ="FALSE";
		try
		{
						
			/*String App_name="ALERT",App_user_name="VTLALERT",App_password="QUxFUlRAU0VDUkVU";
			
			messageStatus = umfMessaging.callUMFInterface(msisdn,msgContent,
				App_name,App_user_name,App_password).toString();			
			logger.info(" sendMessage()# App_name:"+App_name+",App_user_name :"+App_user_name+",App_password :"+App_password);			
			logger.info(" sendMessage()# customerMessageStatus:"+messageStatus+",msisdn :"+msisdn+",content :"+msgContent);
			 */
			
			String smscUsername = "", smscPassword = "";
			int inx = umfCliNameList.indexOf(umfCliName.trim());
			smscUsername = umfUserNameList.get(inx);
			smscPassword = umfPasswordList.get(inx);

			messageStatus = umfMessaging.callUMFInterface(msisdn, msgContent
			,umfCliName.trim(), smscUsername, smscPassword).toString();
			
			logger.info(" sendMessage()# customerMessageStatus: "+messageStatus+",umfCliName:" + umfCliName.trim()
					+ ",user_name :" + smscUsername + ",password :"
					+ smscPassword);

			System.out.println(" sendMessage()# customerMessageStatus:"
			+ messageStatus + ",msisdn :" + msisdn + ",content :"
			+ msgContent);

		
		}
		catch(Exception e)
		{
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("submitMessage()# Exception :>>" + stack.toString());
		}
		return messageStatus;
	}
	
	public String getUmfCliName() {
		return umfCliName;
	}
	public void setUmfCliName(String umfCliName) {
		this.umfCliName = umfCliName;
	}
	public List<String> getUmfCliNameList() {
		return umfCliNameList;
	}
	public void setUmfCliNameList(List<String> umfCliNameList) {
		this.umfCliNameList = umfCliNameList;
	}
	public String getUmfUserName() {
		return umfUserName;
	}
	public void setUmfUserName(String umfUserName) {
		this.umfUserName = umfUserName;
	}
	public List<String> getUmfUserNameList() {
		return umfUserNameList;
	}
	public void setUmfUserNameList(List<String> umfUserNameList) {
		this.umfUserNameList = umfUserNameList;
	}
	public String getUmfPassword() {
		return umfPassword;
	}
	public void setUmfPassword(String umfPassword) {
		this.umfPassword = umfPassword;
	}
	public List<String> getUmfPasswordList() {
		return umfPasswordList;
	}
	public void setUmfPasswordList(List<String> umfPasswordList) {
		this.umfPasswordList = umfPasswordList;
	}
	public UMFMessaging getUmfMessaging() {
		return umfMessaging;
	}
	public void setUmfMessaging(UMFMessaging umfMessaging) {
		this.umfMessaging = umfMessaging;
	}
	@Override
	public String uploadFilePath() {
		return this.qtlUploadFilePath;
	}
	public String getQtlUploadFilePath() {
		return qtlUploadFilePath;
	}
	public void setQtlUploadFilePath(String qtlUploadFilePath) {
		this.qtlUploadFilePath = qtlUploadFilePath;
	}
	@Override
	public String getVendorPassword() {
		
		return this.qtlVendorPassword;
	}
	public String getQtlVendorPassword() {
		return qtlVendorPassword;
	}
	public void setQtlVendorPassword(String qtlVendorPassword) {
		this.qtlVendorPassword = qtlVendorPassword;
	}
	@Override
	public String getSmsServiceURL() {
		
		return this.serviceURL;
	}
	public String getServiceURL() {
		return serviceURL;
	}
	public void setServiceURL(String serviceURL) {
		this.serviceURL = serviceURL;
	}
	
	


}
