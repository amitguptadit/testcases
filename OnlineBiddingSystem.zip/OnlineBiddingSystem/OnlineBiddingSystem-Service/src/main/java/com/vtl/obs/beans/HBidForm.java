package com.vtl.obs.beans;

import java.util.List;

import com.vtl.obs.hb.beans.HBid;

public class HBidForm {

	private List<HBid> bidLists;

	public List<HBid> getBidLists() {
		return bidLists;
	}

	public void setBidLists(List<HBid> bidLists) {
		this.bidLists = bidLists;
	}
		
}
