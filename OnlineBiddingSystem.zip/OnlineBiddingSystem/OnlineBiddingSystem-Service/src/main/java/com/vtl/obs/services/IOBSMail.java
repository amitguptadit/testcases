package com.vtl.obs.services;

public interface IOBSMail {

	public Boolean sendingMail(String mailSubject,String mailContent,String mailRecepientsTo,String mailRecepientsCc);
}
