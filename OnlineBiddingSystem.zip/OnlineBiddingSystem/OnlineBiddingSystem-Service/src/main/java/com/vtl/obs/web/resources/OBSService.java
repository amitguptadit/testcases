/*
 * @author amit.gupta
 */
package com.vtl.obs.web.resources;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.vtl.obs.beans.HBidForm;
import com.vtl.obs.beans.ReloadValidation;
import com.vtl.obs.beans.UmfFileUpload;
import com.vtl.obs.beans.User;
import com.vtl.obs.dao.ObsDao;
import com.vtl.obs.dao.UserDao;
import com.vtl.obs.hb.beans.HBid;
import com.vtl.obs.hb.beans.HUser;
import com.vtl.obs.hb.beans.HUserBid;
import com.vtl.obs.hb.beans.HUserRoleDetails;
import com.vtl.obs.services.IOBS;
import com.vtl.obs.services.IOBSMail;
import com.vtl.obs.util.DownloadPdfUtility;
import com.vtl.obs.util.HibernateUtil;
import com.vtl.obs.util.OBSUtility;
import com.vtl.obs.web.Exception.CustomGenericException;

@Controller
public class OBSService {

	public static final Logger logger = Logger.getLogger("OBSService.class");

	@Autowired
	private IOBS iobs;

	@Autowired
	private IOBSMail iobsMail;

	@Autowired
	private ReloadValidation requestReloadBean;

	@Autowired
	private OBSUtility obsUtility;
	@Autowired
	private HibernateUtil hibernateDao;
	@Autowired
	private UserDao userDao;
	@Autowired
	private ObsDao obsDao;

	@ModelAttribute("ReloadValidation")
	public ReloadValidation reqReload() {
		return requestReloadBean;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView getuserPage() {

		return new ModelAndView("login", "command", new User());
	}

	@RequestMapping(value = "/signout", method = RequestMethod.GET)
	public @ResponseBody
	ModelAndView signout(ModelMap model, HttpSession session) {
		session.removeAttribute("userRole");
		session.removeAttribute("user");
		return new ModelAndView("login", "command", new User());
	}

	
	
	@RequestMapping(value = "/contactUs", method = RequestMethod.GET)
	public @ResponseBody
	ModelAndView contact(ModelMap model, HttpSession session) {
		
		return new ModelAndView("contactUs", "command", new User());
	}
	
	// ----------forget Password---------------
	@RequestMapping(value = "/forgotpassword", method = RequestMethod.GET)
	public String forgotPassword(Model model, HttpSession session) {
		try {

			logger.info(" Go for processForgotPasswordSuccess()");
		} catch (Exception ex) {
			logger.info("forgotPassword()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "forgotPasswordSucc";
	}

	// frmforgotpassword
	@RequestMapping(value = "/forgotPasswordSuccess", method = RequestMethod.POST)
	public @ResponseBody
	ModelAndView processForgotPasswordSuccess(ModelMap model,
			@ModelAttribute("frmforgotpassword") HUser hUser,
			BindingResult result) {
		try {
			String retstr = "";
			System.out
					.println("processForgotPasswordSuccess()# hUser.getUserId() :"
							+ hUser.getUserId()
							+ ", msisdn :"
							+ hUser.getMsisdn());

			logger.info("processForgotPasswordSuccess()# hUser.getUserId() :"
					+ hUser.getUserId() + ", msisdn :" + hUser.getMsisdn());
			if (hUser.getMsisdn() == null) {
				retstr = "Please enter the all valid values  ..!";
			} else if (!obsDao.checkMsisdn(hUser.getMsisdn())) {
				retstr = "Requested Msisdn does not exits  ..!";
				logger.info(retstr);
			} else {
				hUser=obsDao.getHUserOnBasisOfMsisdn(hUser.getMsisdn());
				// iobs
				// (String msisdn ,String msgContent,int msgId);
				String msgContent = iobs.getVendorPassword();

				String msgStatus = iobs.sendMessage(hUser.getMsisdn(),
						msgContent);
				if ((msgStatus.trim()).equalsIgnoreCase("TRUE")) {

					retstr = "Forgot Password message successfully sent on User MSISDN.";

				} else {
					retstr = "Forgot Password message have some technical issue.Please try later..";
				}
				
				System.out.println(retstr);
				logger.info(retstr);
				//-----------sending mail----------
				String mailContent=msgContent;
				String mailRecepientsTo=hUser.getEmail();
				String mailRecepientsCc="NA";
				String mailSubject="forgotPasswordSuccess";
				Boolean mailStatus=iobsMail.sendingMail(mailSubject, mailContent, mailRecepientsTo, mailRecepientsCc);
				if(mailStatus)
				{
					String str="mail has been sent,to "+mailRecepientsTo+",subject :"+mailSubject+",mailContent :"+mailContent;
					logger.info(str);
				}
				else
				{
					String str="mail  sending fail,to "+mailRecepientsTo+",subject :"+mailSubject+",mailContent :"+mailContent;
					logger.info(str);
				}
				//-----------end sending mail--------
				model.addAttribute("message", retstr);
				return new ModelAndView("incorrectUserIdPassword", model);

			}
			if (hUser.getMsisdn() != null) {
				model.addAttribute("submitFormResult", retstr);
			}

		} catch (Exception ex) {
			logger.info("processForgotPasswordSuccess()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return new ModelAndView("forgotPasswordSucc", model);

	}
//------------------------------Download Reports-----------------
	@RequestMapping(value = "/Excel_bidDetails_managebid", method = RequestMethod.GET)
	public ModelAndView downloadExcel_bidDetails_managebid(Model model, HttpSession session,
			 HttpServletResponse response)
	{
		HBid hBid=null;
		try
		{
			
			//int bidIds = Integer.parseInt(bidId);
			int bidIds =1;
			hBid = obsDao.getHBid(bidIds);

			logger.info("downloadExcel_bidDetails_managebid()# bidIds " + bidIds);	
				
		}
		catch (Exception ex) {
			logger.info("downloadExcel_bidDetails_managebid()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return new ModelAndView("excelView_bidDetails_managebid", "hBid", hBid);
	}
	//--------------------------[ End Download Reports	]------------
	// ---------------[ usrmanage ]--------------------
	@RequestMapping(value = "/usrmanage", method = RequestMethod.GET)
	public String userManage(Model model, HttpSession session) {
		try {
			// public HUser getHUser(String userId)
			User user = (User) session.getAttribute("user");
			System.out.println("userManage()#userID is :" + user.getEmail());
			HUser hUser = obsDao.getHUser(user.getEmail());
			logger.info("userManage()#userID is :" + user.getEmail()
					+ ", hUser :" + hUser);
			model.addAttribute("hUser", hUser);

		} catch (Exception ex) {
			logger.info("userManage()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "userManage";
	}

	@RequestMapping(value = "/userManageSuccess", method = RequestMethod.POST)
	public @ResponseBody
	ModelAndView processUserManagement(ModelMap model, HttpSession session,
			@ModelAttribute("usrmanagement") HUser hUser, BindingResult result) {
		try {
			User user = (User) session.getAttribute("user");
			HUser prevHUser = obsDao.getHUser(user.getEmail());
			System.out.println("processUserManagement()# hUser.getUserId() :"
					+ prevHUser.getUserId() + ",old msisdn :"
					+ prevHUser.getMsisdn() + ",new update msisdn :"
					+ hUser.getMsisdn() + ",session user  :" + user.getEmail());

			logger.info("processUserManagement()# hUser.getUserId() :"
					+ prevHUser.getUserId() + ",old msisdn :"
					+ prevHUser.getMsisdn() + ",new update msisdn :"
					+ hUser.getMsisdn() + ",session user  :" + user.getEmail());
			String retstr = "User Management have some technical issue , Please try later ..!";
			if (prevHUser.getEmail() == null || prevHUser.getUserId() == null
					|| hUser.getMsisdn() == null) {
				retstr = "Please enter the all valid values  ..!";
			} else if (obsDao.checkHUserExist(prevHUser.getUserId()) == Boolean.FALSE) {
				retstr = "User allready Exits  ..! Go for processUserManagement";
				prevHUser.setMsisdn(hUser.getMsisdn());
				if (obsDao.updateUser(prevHUser)) {
					retstr = prevHUser.getUserId() + " updated successfully";
					logger.info("processUserManagement()#user "
							+ prevHUser.getUserId() + " updated successfully");
				} else {
					retstr = prevHUser.getUserId()
							+ " updation is fail.Please try later..!!";

				}
				logger.info(retstr);

			} else {
				System.out.println(retstr);
				logger.info(retstr);
			}

			if (prevHUser.getUserId() != null && prevHUser.getMsisdn() != null) {
				model.addAttribute("submitFormResult", retstr);
			}

		} catch (Exception ex) {
			logger.info("processUserManagement()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return new ModelAndView("userManage", model);

	}

	// -------------- [ end usrmanage ]------------
	// -------------usercreation--------------------
	@RequestMapping(value = "/usercreation", method = RequestMethod.GET)
	public String userCreation(Model model) {
		try {

			System.out.println("userCreation()");
			System.out.println("userCreation()# BidNameList Size  :"
					+ obsDao.BidNameList().size());
			logger.info("userCreation()# BidNameList Size  :"
					+ obsDao.BidNameList().size());
			model.addAttribute("bidsName", obsDao.BidNameList());
			model.addAttribute("userType", obsDao.UserTypeList());
			System.out.println("userCreation()# go Tiles createUsers");
		} catch (Exception ex) {
			logger.info("userCreation()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "createUsers";
	}

	// createUserSuccess
	@RequestMapping(value = "/createUserSuccess", method = RequestMethod.POST)
	public @ResponseBody
	ModelAndView processUserCreation(ModelMap model, HttpSession session,
			@ModelAttribute("usrcreation") HUser hUser,
			@RequestParam("lstFruits") String listBids, BindingResult result,
			SessionStatus status) {
		// BindingResult result,
		System.out.println(" we are in processUserCreation() -1");
		logger.info(" we are in processUserCreation() -1");
		try {
			System.out.println(" we are in processUserCreation() ");

			System.out.println("processUserCreation()# hUser.getUserId() :"
					+ hUser.getUserId());
			logger.info("processUserCreation()# hUser.getUserId() :"
					+ hUser.getUserId() + ", getUserRole  :"
					+ hUser.getUserType());
			Boolean userCreateSuccessFlag = Boolean.FALSE;
			// createUser(HUser hUser)
			User user = (User) session.getAttribute("user");

			System.out.println("listFruits :" + listBids);
			System.out.println(listBids
					+ " processUserCreation()# session user  :"
					+ user.getEmail());
			logger.info(listBids + " processUserCreation()# session user  :"
					+ user.getEmail());

			// public Boolean createUserBids(HUserBid hUserbid)

			System.out.println("processUserCreation()# getUserRole  :"
					+ hUser.getUserType());

			// userType
			hUser.setCreatedDate(new Date());
			hUser.setPassword("password@123");
			hUser.setUserRoleType(obsDao.getHUserRoleType(hUser.getUserType()));
			// hUser.setUserRoleType(obsDao.getHUserRoleType(hUser.getUserRoleType().getUserRole()));

			String retstr = "User creation Fail ..!";
			// if(hUser.getEmail()==null||hUser.getEmail().equals("")||hUser.getUserId()==null||hUser.getUserId().equals("")||hUser.getMsisdn()==null||hUser.getMsisdn().equals(""))
			if (hUser.getEmail() == null || hUser.getUserId() == null
					|| hUser.getMsisdn() == null) {
				retstr = "Please enter the all valid values  ..!";
				// public Boolean checkHUserExist(String userId)
				logger.info(retstr);
			} else if (listBids == null || listBids.equals("")) {
				retstr = "Please select at least one bid for user creation ..!";
			} else if (obsDao.checkHUserExist(hUser.getUserId()) == Boolean.FALSE) {
				retstr = "User allready Exits  ..!";
				logger.info(retstr);
			}// else if (obsDao.createUser(hUser)&&
				// obsDao.checkHUserExist(hUser.getUserId()))
			else if (obsDao.createUser(hUser)) {
				retstr = "User created Successfully..!";
				System.out.println(retstr);
				logger.info(retstr);

				StringTokenizer tz = new StringTokenizer(listBids, ",");

				System.out.println("countTokens :" + tz.countTokens());
				while (tz.hasMoreTokens()) {
					HUserBid hUserBids = null;
					String bidName = tz.nextToken();
					logger.info("processUserCreation()# bidName :" + bidName);
					HBid prevHBid = obsDao.getHBid(bidName);

					hUserBids = obsDao.getUsrWiseBid(hUser, prevHBid);

					if (hUserBids == null) {
						hUserBids = new HUserBid();
						hUserBids.setUserBidCreatedDate(new Date());
						// public HBid getHBid(String bidName)
						// userId
						// HUserBid.bidId
						// setHuserId(HUser huserId)
						hUserBids.setUserbidPrice(hUser.getUserPrice());
						hUserBids
								.setHuserId(obsDao.getHUser(hUser.getUserId()));// HUser
						hUserBids.setUserbidStatus("open");

						hUserBids.setBidId(prevHBid);
						// 5-aug hUserBid.set
						// createUserBids()#
						// HibernateException:>>org.hibernate.PropertyValueException:
						// not-null property references a null or
						// transient value:
						// com.vtl.obs.hb.beans.HUserBid.huserId

						logger.info("processUserCreation()#createdUserBids :"
								+ obsDao.createUserBids(hUserBids));
						System.out.println("createUserBids DONE()");
						userCreateSuccessFlag = Boolean.TRUE;
					} else {
						logger.info("processUserCreation()#for bidName :"
								+ bidName
								+ "Allready present : hUserBids.getUserBidId():"
								+ hUserBids.getUserBidId()
								+ ",hUserBids.getHuserId()"
								+ hUserBids.getHuserId());
					}
				}

				if(userCreateSuccessFlag)
				{
					//14-Oct2016 String serviceURL="http://172.17.4.149:8080/OnlineBiddingSystem-Service/";
					//String serviceURL="https://connecttenders.infotelconnect.com/OnlineBiddingSystem-Service/";
					String serviceURL=iobs.getSmsServiceURL();
					String msgContent = "Your Account has been created.. your UserId is "+hUser.getUserId()+" and password password@123"+" and Login URL is "+serviceURL;

					String msgStatus = iobs.sendMessage(hUser.getMsisdn(),
							msgContent);
					if ((msgStatus.trim()).equalsIgnoreCase("TRUE"))
					{

						
						logger.info("processUserCreation()#User create  message successfully sent on User MSISDN.");

					} 
					else
					{
						
						logger.info("processUserCreation()#User create message have some technical issue.Please try later..");
					}					
					//-----------sending mail----------
					String mailContent=msgContent;
					String mailRecepientsTo=hUser.getEmail();
					String mailRecepientsCc="NA";
					String mailSubject="createUserSuccess";
					Boolean mailStatus=iobsMail.sendingMail(mailSubject, mailContent, mailRecepientsTo, mailRecepientsCc);
					if(mailStatus)
					{
						String str="mail has been sent,to "+mailRecepientsTo+",subject :"+mailSubject+",mailContent :"+mailContent;
						logger.info(str);
					}
					else
					{
						String str="mail  sending fail,to "+mailRecepientsTo+",subject :"+mailSubject+",mailContent :"+mailContent;
						logger.info(str);
					}
					//-----------end sending mail--------
				}
				
			} else {
				System.out.println(retstr);
				logger.info(retstr);
			}

			System.out.println("processUserCreation()# BidNameList Size  :"
					+ obsDao.BidNameList().size());
			model.addAttribute("bidsName", obsDao.BidNameList());
			model.addAttribute("userType", obsDao.UserTypeList());
			if ((hUser.getEmail() != null && hUser.getUserId() != null && hUser
					.getMsisdn() != null)
					|| listBids == null
					|| listBids.equals("")
					|| (userCreateSuccessFlag = Boolean.FALSE)) {
				model.addAttribute("submitFormResult", retstr);
			}
			

		} catch (Exception ex) {
			logger.info("processUserCreation()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return new ModelAndView("createUsers", model);
	}

	// ----------------------user's closed Bid History--------
	@RequestMapping(value = "getUserClosedBidHistoryPagination", method = RequestMethod.GET)
	public String userClosedBidHistoryPagination(Model model,
			@RequestParam("page") String page,
			@RequestParam("startPaginationFlag") String paginationFlag,
			@RequestParam("bidStatus") String bidStatus, HttpSession session) {
		try {
			int startPaginationFlag = 0;
			System.out
					.println("<----------userClosedBidHistoryPagination(),page"
							+ page + ",paginationFlag :" + paginationFlag);
			logger.info(" userClosedBidHistoryPagination()# page :" + page
					+ ",paginationFlag :" + paginationFlag);
			List<HBid> list = null;
			User user = (User) session.getAttribute("user");

			int page1 = Integer.parseInt(page);

			if (paginationFlag.equals("")) {
				System.out
						.println("userClosedBidHistoryPagination()#paginationFlag-1 :"
								+ paginationFlag);
			} else if (paginationFlag.equals(null)) {
				System.out
						.println("userClosedBidHistoryPagination()#paginationFlag-2 :"
								+ paginationFlag);
			} else {
				startPaginationFlag = Integer.parseInt(paginationFlag);
				if (startPaginationFlag == 1) {
					page1 = page1 + 1;
				}
			}

			int recordsPerPage = 1000;
			int noOfRecords = obsDao.getNoOfRecords(bidStatus);
			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			list = obsDao.viewBidPagination(bidStatus, (page1 - 1)
					* recordsPerPage, recordsPerPage);

			model.addAttribute("bidStatus", bidStatus);
			model.addAttribute("noOfPages", noOfPages);
			model.addAttribute("currentPage", page1);
			model.addAttribute("bidList", list);

			System.out
					.println("userClosedBidHistoryPagination()#noOfPages----->>>>"
							+ noOfPages);
			System.out.println("userClosedBidHistoryPagination()#page :" + page
					+ " startPaginationFlag :" + startPaginationFlag
					+ "#list size:" + list.size() + "# model :" + model);
			logger.info("userClosedBidHistoryPagination()#page :" + page
					+ " startPaginationFlag :" + startPaginationFlag
					+ "#list size:" + list.size() + "# model :" + model);

		} catch (Exception ex) {
			logger.info("userClosedBidHistoryPagination()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "userClosedBidHistory";
	}

	@RequestMapping(value = "/usrclosebidhistory", method = RequestMethod.GET)
	public String userClosedBidHistoryView(Model model, HttpSession session) {
		try {
			/*
			 * 
			 * tbl_user_bid get bidId,userbidStatus on basis of huserId
			 * getUsrWiseBidStatus(HUser) usrWiseBidView(HUser)
			 */
			User user = (User) session.getAttribute("user");
			// public HUser getHUser(String userId);

			System.out.println("userClosedBidHistoryView()#userID is :"
					+ user.getEmail());
			logger.info("userClosedBidHistoryView()#userID is :"
					+ user.getEmail());
			HUser hUser = obsDao.getHUser(user.getEmail());

			logger.info("userClosedBidHistoryView()#hUser :" + hUser);
			String bidStatus = "Closed";
			List<HUserBid> usrBidList = obsDao.getUsrWiseBidList(hUser,
					bidStatus);
			// Login login = fmsDao.getLoginBean(user.getEmail());

			// public List<HUserBid> getUsrWiseBidList(HUser hUser)
			System.out.println("userClosedBidHistoryView()#usrBidList size :"
					+ usrBidList.size());
			logger.info("userClosedBidHistoryView()#usrBidList size :"
					+ usrBidList.size());
			// 6-aug2016 model.addAttribute("bidList", obsDao.BidList());
			if (usrBidList.size() > 0) {
				int page1 = 0;
				List<HBid> list = null;
				int recordsPerPage = 1000;

				int noOfRecords = obsDao.getNoOfRecords(bidStatus);

				int noOfPages = (int) Math.ceil(noOfRecords * 1.0
						/ recordsPerPage);

				for (HUserBid usrbid : usrBidList) {
					list = obsDao.viewUserWiseBidPagination(usrbid.getBidId(),
							bidStatus, (page1 - 1) * recordsPerPage,
							recordsPerPage);
					// list.add(obsDao.viewUserWiseBidPagination(usrbid.getBidId(),bidStatus,
					// (page1 - 1) * recordsPerPage,recordsPerPage).get(0));
				}

				// list = obsDao.viewBidPagination(bidStatus, (page1 - 1) *
				// recordsPerPage,recordsPerPage);
				// viewUserWiseBidPagination(HBid hBid, String bidStatus,int
				// offset, int noOfRecords)
				// model.addAttribute("noOfPages",2);
				model.addAttribute("bidStatus", bidStatus);
				model.addAttribute("noOfPages", noOfPages);
				model.addAttribute("currentPage", page1);

				model.addAttribute("bidList", list);

				model.addAttribute("startPaginationFlag", "1");

				System.out
						.println("userClosedBidHistoryView()#bidList size()#--->"
								+ list.size());
				logger.info("userClosedBidHistoryView()#bidList size()#--->"
						+ list.size());
				if (list.size() == noOfRecords) {
					model.addAttribute("stopPaginationFlag", "1");
					logger.info("userClosedBidHistoryView()#stopPaginationFlag:1, list.size():"
							+ list.size() + ",noOfRecords :" + noOfRecords);
				}

				if (list.size() == 0) {
					model.addAttribute("submitFormResult",
							"Sorry! No Record Found..!!");
				}
			} else {
				model.addAttribute("submitFormResult",
						"Sorry! No Record Found..!!");
			}
		} catch (Exception ex) {
			logger.info("userClosedBidHistoryView()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "userClosedBidHistory";
	}

	// ---------------------End user's Closed Bid History-------

	// ----------------------user's exit Bid History--------
	@RequestMapping(value = "getUserExitBidHistoryPagination", method = RequestMethod.GET)
	public String userExitBidHistoryPagination(Model model,
			@RequestParam("page") String page,
			@RequestParam("startPaginationFlag") String paginationFlag,
			@RequestParam("bidStatus") String bidStatus, HttpSession session) {
		try {
			int startPaginationFlag = 0;
			System.out.println("<----------userExitBidHistoryPagination(),page"
					+ page + ",paginationFlag :" + paginationFlag);
			logger.info(" userExitBidHistoryPagination()# page :" + page
					+ ",paginationFlag :" + paginationFlag);
			List<HBid> list = null;
			User user = (User) session.getAttribute("user");

			int page1 = Integer.parseInt(page);

			if (paginationFlag.equals("")) {
				System.out
						.println("userExitBidHistoryPagination()#paginationFlag-1 :"
								+ paginationFlag);
			} else if (paginationFlag.equals(null)) {
				System.out
						.println("userExitBidHistoryPagination()#paginationFlag-2 :"
								+ paginationFlag);
			} else {
				startPaginationFlag = Integer.parseInt(paginationFlag);
				if (startPaginationFlag == 1) {
					page1 = page1 + 1;
				}
			}

			int recordsPerPage = 1000;
			int noOfRecords = obsDao.getNoOfRecords(bidStatus);
			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			list = obsDao.viewBidPagination(bidStatus, (page1 - 1)
					* recordsPerPage, recordsPerPage);

			model.addAttribute("bidStatus", bidStatus);
			model.addAttribute("noOfPages", noOfPages);
			model.addAttribute("currentPage", page1);
			model.addAttribute("bidList", list);

			System.out
					.println("userExitBidHistoryPagination()#noOfPages----->>>>"
							+ noOfPages);
			System.out.println("userExitBidHistoryPagination()#page :" + page
					+ " startPaginationFlag :" + startPaginationFlag
					+ "#list size:" + list.size() + "# model :" + model);
			logger.info("userExitBidHistoryPagination()#page :" + page
					+ " startPaginationFlag :" + startPaginationFlag
					+ "#list size:" + list.size() + "# model :" + model);

		} catch (Exception ex) {
			logger.info("userExitBidHistoryPagination()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "userExitBidHistory";
	}

	@RequestMapping(value = "/usrexitbidhistory", method = RequestMethod.GET)
	public String userExitBidHistoryView(Model model, HttpSession session) {
		try {
			User user = (User) session.getAttribute("user");
			System.out.println("userExitBidHistoryView()#userID is :"
					+ user.getEmail());
			logger.info("userExitBidHistoryView()#userID is :"
					+ user.getEmail());
			HUser hUser = obsDao.getHUser(user.getEmail());
			List<HBid> bidListOnBasisOfUserId = obsDao
                    .getBidListOnBasisOfUserId(hUser);

			Map<String, Double> userbidPriceMap = obsDao
                    .getUserbidPriceListOnBasisOfBidId(bidListOnBasisOfUserId,
                                  hUser);
       Map<String, String> userbidCommentMap = obsDao
                    .getUserbidCommentListOnBasisOfBidId(bidListOnBasisOfUserId,
                                  hUser);
       Map<String, String> userBidAttachmentMap = obsDao
                    .getUserbidAttachmentListOnBasisOfBidId(
                                  bidListOnBasisOfUserId, hUser);
			logger.info("userExitBidHistoryView()#hUser :" + hUser);
			String bidStatus = "Exit";
			List<HUserBid> usrBidList = obsDao.getUsrWiseBidList(hUser,
					bidStatus);
			System.out.println("userExitBidHistoryView()#usrBidList size :"
					+ usrBidList.size());
			logger.info("userExitBidHistoryView()#usrBidList size :"
					+ usrBidList.size());
			if (usrBidList.size() > 0) {
				int page1 = 0;
				List<HBid> list = null;
				int recordsPerPage = 1000;

				int noOfRecords = obsDao.getNoOfRecords(bidStatus);

				int noOfPages = (int) Math.ceil(noOfRecords * 1.0
						/ recordsPerPage);

				for (HUserBid usrbid : usrBidList) {
					list = obsDao.viewUserWiseBidPagination(usrbid.getBidId(),
							bidStatus, (page1 - 1) * recordsPerPage,
							recordsPerPage);
				}

				model.addAttribute("bidStatus", bidStatus);
				model.addAttribute("noOfPages", noOfPages);
				model.addAttribute("currentPage", page1);

				model.addAttribute("bidList", list);

				model.addAttribute("startPaginationFlag", "1");
				model.addAttribute("userbidPriceMap", userbidPriceMap);
				model.addAttribute("userbidCommentMap", userbidCommentMap);
				model.addAttribute("userBidAttachmentMap", userBidAttachmentMap);

				System.out
						.println("userExitBidHistoryView()#bidList size()#--->"
								+ list.size());
				logger.info("userExitBidHistoryView()#bidList size()#--->"
						+ list.size());
				if (list.size() == noOfRecords) {
					model.addAttribute("stopPaginationFlag", "1");
					logger.info("userExitBidHistoryView()#stopPaginationFlag:1, list.size():"
							+ list.size() + ",noOfRecords :" + noOfRecords);
				}

				if (list.size() == 0) {
					model.addAttribute("submitFormResult",
							"Sorry! No Record Found..!!");
				}
			} else {
				model.addAttribute("submitFormResult",
						"Sorry! No Record Found..!!");
			}
		} catch (Exception ex) {
			logger.info("userExitBidHistoryView()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "userExitBidHistory";
	}

	// ---------------------End user's Exit Bid History-------

	// ---------------------user's usrappliedbidhistory--------
	@RequestMapping(value = "getuserAppliedBidHistoryPagination", method = RequestMethod.GET)
	public String userAppliedBidHistoryPagination(Model model,
			@RequestParam("page") String page,
			@RequestParam("startPaginationFlag") String paginationFlag,
			@RequestParam("bidStatus") String bidStatus, HttpSession session) {
		try {
			int startPaginationFlag = 0;
			System.out
					.println("<----------userAppliedBidHistoryPagination(),page"
							+ page + ",paginationFlag :" + paginationFlag);
			logger.info(" userAppliedBidHistoryPagination()# page :" + page
					+ ",paginationFlag :" + paginationFlag);
			List<HBid> list = null;
			User user = (User) session.getAttribute("user");

			int page1 = Integer.parseInt(page);

			if (paginationFlag.equals("")) {
				System.out
						.println("userAppliedBidHistoryPagination()#paginationFlag-1 :"
								+ paginationFlag);
			} else if (paginationFlag.equals(null)) {
				System.out
						.println("userAppliedBidHistoryPagination()#paginationFlag-2 :"
								+ paginationFlag);
			} else {
				startPaginationFlag = Integer.parseInt(paginationFlag);
				if (startPaginationFlag == 1) {
					page1 = page1 + 1;
				}
			}

			int recordsPerPage = 1000;
			int noOfRecords = obsDao.getNoOfRecords(bidStatus);
			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			list = obsDao.viewBidPagination(bidStatus, (page1 - 1)
					* recordsPerPage, recordsPerPage);

			model.addAttribute("bidStatus", bidStatus);
			model.addAttribute("noOfPages", noOfPages);
			model.addAttribute("currentPage", page1);
			model.addAttribute("bidList", list);

			System.out
					.println("userAppliedBidHistoryPagination()#noOfPages----->>>>"
							+ noOfPages);
			System.out.println("userAppliedBidHistoryPagination()#page :"
					+ page + " startPaginationFlag :" + startPaginationFlag
					+ "#list size:" + list.size() + "# model :" + model);
			logger.info("userAppliedBidHistoryPagination()#page :" + page
					+ " startPaginationFlag :" + startPaginationFlag
					+ "#list size:" + list.size() + "# model :" + model);

		} catch (Exception ex) {
			logger.info("userAppliedBidHistoryPagination()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "usrappliedbidhistory";
		// userAppliedBidHistory
	}

	// usrappliedbidhistory
	@RequestMapping(value = "/usrappliedbidhistory", method = RequestMethod.GET)
    public String userAppliedBidHistoryView(Model model, HttpSession session) {
           try {
                  /*
                   * 
                   * tbl_user_bid get bidId,userbidStatus on basis of huserId
                   * getUsrWiseBidStatus(HUser) usrWiseBidView(HUser)
                   */
                  User user = (User) session.getAttribute("user");
                  // public HUser getHUser(String userId);

                  System.out.println("userAppliedBidHistoryView()#userID is :"
                               + user.getEmail());
                  logger.info("userAppliedBidHistoryView()#userID is :"
                               + user.getEmail());
                  HUser hUser = obsDao.getHUser(user.getEmail());

                  List<HBid> bidListOnBasisOfUserId = obsDao
                               .getBidListOnBasisOfUserId(hUser);
                  
                  Map<String, Double> userbidPriceMap = obsDao
                               .getUserbidPriceListOnBasisOfBidId(bidListOnBasisOfUserId,
                                             hUser);
                  Map<String, String> userbidCommentMap = obsDao
                               .getUserbidCommentListOnBasisOfBidId(bidListOnBasisOfUserId,
                                             hUser);
                  Map<String, String> userBidAttachmentMap = obsDao
                               .getUserbidAttachmentListOnBasisOfBidId(
                                             bidListOnBasisOfUserId, hUser);
                  String bidStatus = "Apply";
                  logger.info("userAppliedBidHistoryView()#hUser :" + hUser);
                  List<HUserBid> usrBidList = obsDao.getUsrWiseBidList(hUser,
                               bidStatus);
                  // Login login = fmsDao.getLoginBean(user.getEmail());

                  // public List<HUserBid> getUsrWiseBidList(HUser hUser)
                  System.out.println("userAppliedBidHistoryView()#usrBidList size :"
                               + usrBidList.size());
                  logger.info("userAppliedBidHistoryView()#usrBidList size :"
                               + usrBidList.size());
                  // 6-aug2016 model.addAttribute("bidList", obsDao.BidList());
                  if (usrBidList.size() > 0) {
                        int page1 = 0;
                        List<HBid> list = null;
                        int recordsPerPage = 1000;

                        int noOfRecords = obsDao.getNoOfRecords(bidStatus);

                        int noOfPages = (int) Math.ceil(noOfRecords * 1.0
                                      / recordsPerPage);

                        for (HUserBid usrbid : usrBidList) {
                               list = obsDao.viewUserWiseBidPagination(usrbid.getBidId(),
                                             bidStatus, (page1 - 1) * recordsPerPage,
                                             recordsPerPage);
                               // model.addAttribute("usrbid", usrbid);
                               // list.add(obsDao.viewUserWiseBidPagination(usrbid.getBidId(),bidStatus,
                               // (page1 - 1) * recordsPerPage,recordsPerPage).get(0));
                        }

                        // list = obsDao.viewBidPagination(bidStatus, (page1 - 1) *
                        // recordsPerPage,recordsPerPage);
                        // viewUserWiseBidPagination(HBid hBid, String bidStatus,int
                        // offset, int noOfRecords)
                        // model.addAttribute("noOfPages",2);
                        model.addAttribute("bidStatus", bidStatus);
                        model.addAttribute("noOfPages", noOfPages);
                        model.addAttribute("currentPage", page1);

                        model.addAttribute("bidList", list);
                        model.addAttribute("userbidPriceMap", userbidPriceMap);
                        model.addAttribute("userBidAttachmentMap", userBidAttachmentMap);
                        model.addAttribute("userbidCommentMap", userbidCommentMap);
                        model.addAttribute("userId", hUser.getUserId());                                                
                        //model.addAttribute("hUserBidList", usrBidList);

                        model.addAttribute("startPaginationFlag", "1");

                        System.out
                                      .println("userAppliedBidHistoryView()#bidList size()#--->"
                                                    + list.size());
                        logger.info("userAppliedBidHistoryView()#bidList size()#--->"
                                      + list.size());
                        if (list.size() == noOfRecords) {
                               model.addAttribute("stopPaginationFlag", "1");
                               logger.info("userAppliedBidHistoryView()#stopPaginationFlag:1, list.size():"
                                             + list.size() + ",noOfRecords :" + noOfRecords);
                        }

                        if (list.size() == 0) {
                               model.addAttribute("submitFormResult",
                                             "Sorry! No Record Found..!!");
                        }
                  } else {
                        model.addAttribute("submitFormResult",
                                      "Sorry! No Record Found..!!");
                  }
           } catch (Exception ex) {
                  logger.info("userAppliedBidHistoryView()#This is custom ERROR message.Please try later..!! ,Exception :"
                               + ex);
                  throw new CustomGenericException("E888",
                               "This is custom ERROR message.Please try later..!!");
           }
           return "userAppliedBidHistory";
    }

	// ----------------------End user's openbidhistory----------
	// ------------------ user's Bid Pending view ----------
	@RequestMapping(value = "getUserbidPendingPagination", method = RequestMethod.GET)
	public String userbidPendingPagination(Model model,
			@RequestParam("page") String page,
			@RequestParam("startPaginationFlag") String paginationFlag,
			@RequestParam("bidStatus") String bidStatus, HttpSession session) {
		try {
			int startPaginationFlag = 0;
			System.out.println("<----------userbidPendingPagination(),page"
					+ page + ",paginationFlag :" + paginationFlag);
			logger.info(" userbidPendingPagination()# page :" + page
					+ ",paginationFlag :" + paginationFlag);
			List<HBid> list = null;
			User user = (User) session.getAttribute("user");

			int page1 = Integer.parseInt(page);

			if (paginationFlag.equals("")) {
				System.out
						.println("userbidPendingPagination()#paginationFlag-1 :"
								+ paginationFlag);
			} else if (paginationFlag.equals(null)) {
				System.out
						.println("userbidPendingPagination()#paginationFlag-2 :"
								+ paginationFlag);
			} else {
				startPaginationFlag = Integer.parseInt(paginationFlag);
				if (startPaginationFlag == 1) {
					page1 = page1 + 1;
				}
			}

			int recordsPerPage = 1000;
			int noOfRecords = obsDao.getNoOfRecords(bidStatus);
			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			list = obsDao.viewBidPagination(bidStatus, (page1 - 1)
					* recordsPerPage, recordsPerPage);

			
			Map <String,String> currentDaysDiffMap=new HashMap<String,String>();
			for(HBid hBid:list)
			{
				Long currentDaysDiff = obsUtility.numberOfDays(hBid.getBidCloseDate());
				if (currentDaysDiff < 0) 
				{	
					currentDaysDiffMap.put(hBid.getBidName(),"NA");
					//model.addAttribute("currentDaysDiff", "NA");
				}
				else
				{	
					currentDaysDiffMap.put(hBid.getBidName(),"OK");
					
				}
			}
			model.addAttribute("currentDaysDiffMap",currentDaysDiffMap);
			
			model.addAttribute("bidStatus", bidStatus);
			model.addAttribute("noOfPages", noOfPages);
			model.addAttribute("currentPage", page1);
			model.addAttribute("bidList", list);

			System.out.println("userbidPendingPagination()#noOfPages----->>>>"
					+ noOfPages);
			System.out.println("userbidPendingPagination()#page :" + page
					+ " startPaginationFlag :" + startPaginationFlag
					+ "#list size:" + list.size() + "# model :" + model);
			logger.info("userbidPendingPagination()#page :" + page
					+ " startPaginationFlag :" + startPaginationFlag
					+ "#list size:" + list.size() + "# model :" + model);

		} catch (Exception ex) {
			logger.info("userbidPendingPagination()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "userBidPending";
	}

	// usrbidpendingview
	@RequestMapping(value = "/usrbidpendingview", method = RequestMethod.GET)
	public String userBidPendingView(Model model, HttpSession session) {
		try {
			/*
			 * 
			 * tbl_user_bid get bidId,userbidStatus on basis of huserId
			 * getUsrWiseBidStatus(HUser) usrWiseBidView(HUser)
			 */
			User user = (User) session.getAttribute("user");
			// public HUser getHUser(String userId);

			System.out.println("userBidPendingView()#userID is :"
					+ user.getEmail());
			logger.info("userBidPendingView()#userID is :" + user.getEmail());
			HUser hUser = obsDao.getHUser(user.getEmail());

			logger.info("userBidPendingView()#hUser :" + hUser);
			String bidStatus = "Open";
			List<HUserBid> usrBidList = obsDao.getUsrWiseBidList(hUser,
					bidStatus);
			// Login login = fmsDao.getLoginBean(user.getEmail());

			// public List<HUserBid> getUsrWiseBidList(HUser hUser)
			System.out.println("userBidPendingView()#usrBidList size :"
					+ usrBidList.size());
			logger.info("userBidPendingView()#usrBidList size :"
					+ usrBidList.size());
			// 6-aug2016 model.addAttribute("bidList", obsDao.BidList());
			if (usrBidList.size() > 0) {
				int page1 = 0;
				// List<HBid> list = null;
				int recordsPerPage = 1000;

				int noOfRecords = obsDao.getNoOfRecords(bidStatus);

				int noOfPages = (int) Math.ceil(noOfRecords * 1.0
						/ recordsPerPage);

				List<HBid> list = new ArrayList<HBid>();

				List<HBid> arlist = null;
				for (HUserBid usrbid : usrBidList) {

					arlist = obsDao.viewUserWiseBidPagination(
							usrbid.getBidId(), bidStatus, (page1 - 1)
									* recordsPerPage, recordsPerPage);
					list.add(arlist.get(0));
				}
				
				Map <String,String> currentDaysDiffMap=new HashMap<String,String>();
				for(HBid hBid:list)
				{
					Long currentDaysDiff = obsUtility.numberOfDays(hBid.getBidCloseDate());
					if (currentDaysDiff < 0) 
					{	
						currentDaysDiffMap.put(hBid.getBidName(),"NA");
						//model.addAttribute("currentDaysDiff", "NA");
					}
					else
					{	
						currentDaysDiffMap.put(hBid.getBidName(),"OK");
						
					}
				}
				model.addAttribute("currentDaysDiffMap",currentDaysDiffMap);
				
				//hBid.getBidName()
				// list = obsDao.viewBidPagination(bidStatus, (page1 - 1) *
				// recordsPerPage,recordsPerPage);
				// viewUserWiseBidPagination(HBid hBid, String bidStatus,int
				// offset, int noOfRecords)
				// model.addAttribute("noOfPages",2);
				
				
				model.addAttribute("bidStatus", bidStatus);
				model.addAttribute("noOfPages", noOfPages);
				model.addAttribute("currentPage", page1);

				model.addAttribute("bidList", list);

				model.addAttribute("startPaginationFlag", "1");

				System.out.println("userBidPendingView()#bidList size()#--->"
						+ list.size());
				logger.info("userBidPendingView()#bidList size()#--->"
						+ list.size());
				if (list.size() == noOfRecords) {
					model.addAttribute("stopPaginationFlag", "1");
					logger.info("userBidPendingView()#stopPaginationFlag:1, list.size():"
							+ list.size() + ",noOfRecords :" + noOfRecords);
				}

				if (list.size() == 0) {
					model.addAttribute("submitFormResult",
							"Sorry! No Record Found..!!");
				}
			} else {
				model.addAttribute("submitFormResult",
						"Sorry! No Record Found..!!");
			}
		} catch (Exception ex) {
			logger.info("userBidPendingView()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "userBidPending";
	}

	// ----------------- End user's Bid Pending view -----------
	// ------------------closed Bid-----------------
	@RequestMapping(value = "getClosedBidPagination", method = RequestMethod.GET)
	public String bidClosedPagination(Model model,
			@RequestParam("page") String page,
			@RequestParam("startPaginationFlag") String paginationFlag,
			@RequestParam("bidStatus") String bidStatus, HttpSession session) {
		try {
			int startPaginationFlag = 0;
			System.out.println("<----------getClosedBidPagination(),page"
					+ page + ",paginationFlag :" + paginationFlag);
			logger.info(" getClosedBidPagination()# page :" + page
					+ ",paginationFlag :" + paginationFlag);
			List<HBid> list = null;
			User user = (User) session.getAttribute("user");

			int page1 = Integer.parseInt(page);

			if (paginationFlag.equals("")) {
				System.out
						.println("getClosedBidPagination()#paginationFlag-1 :"
								+ paginationFlag);
			} else if (paginationFlag.equals(null)) {
				System.out
						.println("getClosedBidPagination()#paginationFlag-2 :"
								+ paginationFlag);
			} else {
				startPaginationFlag = Integer.parseInt(paginationFlag);
				if (startPaginationFlag == 1) {
					page1 = page1 + 1;
				}
			}

			int recordsPerPage = 1000;
			int noOfRecords = obsDao.getNoOfRecords(bidStatus);
			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			list = obsDao.viewBidPagination(bidStatus, (page1 - 1)
					* recordsPerPage, recordsPerPage);

			model.addAttribute("bidStatus", bidStatus);
			model.addAttribute("noOfPages", noOfPages);
			model.addAttribute("currentPage", page1);
			model.addAttribute("bidList", list);

			System.out.println("getClosedBidPagination()#noOfPages----->>>>"
					+ noOfPages);
			System.out.println("getClosedBidPagination()#page :" + page
					+ " startPaginationFlag :" + startPaginationFlag
					+ "#list size:" + list.size() + "# model :" + model);
			logger.info("getClosedBidPagination()#page :" + page
					+ " startPaginationFlag :" + startPaginationFlag
					+ "#list size:" + list.size() + "# model :" + model);

		} catch (Exception ex) {
			logger.info("getClosedBidPagination()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "closedbid";
	}

	// (Model model, HttpSession session @ModelAttribute("transaction")
	// TransactionBean transactionBean,BindingResult result)
	@RequestMapping(value = "/closedbid", method = RequestMethod.GET)
	public String closedBid(Model model, HttpSession session) {
		try {

			logger.info("openBid()");
			System.out.println("openBid()");
			// 6-aug2016 model.addAttribute("bidList", obsDao.BidList());
			int page1 = 0;
			List<HBid> list = null;
			int recordsPerPage = 1000;

			String bidStatus = "Closed";
			int noOfRecords = obsDao.getNoOfRecords(bidStatus);

			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);

			list = obsDao.viewBidPagination(bidStatus, (page1 - 1)
					* recordsPerPage, recordsPerPage);
			// model.addAttribute("noOfPages",2);
			model.addAttribute("bidStatus", bidStatus);
			model.addAttribute("noOfPages", noOfPages);
			model.addAttribute("currentPage", page1);

			model.addAttribute("bidList", list);

			model.addAttribute("startPaginationFlag", "1");

			System.out.println("closedBid()#bidList size()#" + list.size());
			if (list.size() == noOfRecords) {
				model.addAttribute("stopPaginationFlag", "1");
				logger.info("closedBid()#stopPaginationFlag:1, list.size():"
						+ list.size() + ",noOfRecords :" + noOfRecords);
			}
			if (list.size() == 0) {
				model.addAttribute("submitFormResult",
						"Sorry! No Record Found..!!");
			}
		} catch (Exception ex) {
			logger.info("closedBid()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "closedBid";
	}

	// ------------------End closed Bid-------------
	// ------------------openBidUsers--------------------
	// getopenBidUserPagination
	@RequestMapping(value = "/openBidUsers", method = RequestMethod.GET)
	public String openBidUser(Model model, HttpSession session,
			@RequestParam("value") String bidId) {
		try {
			logger.info("openBidUser()+ bidId" + bidId);
			System.out.println("openBidUser()+ bidId" + bidId);
			// 6-aug2016 model.addAttribute("bidList", obsDao.BidList());
			int page1 = 0;
			List<HUser> list = null;

			// public List<HUser> getUserListOnBasisOfBidId(HBid prevHBid)
			int recordsPerPage = 10000000;

			String bidStatus = "Open";
			int noOfRecords = obsDao.getNoOfRecords(bidStatus);

			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);

			/*
			 * public List<HUser>
			 * viewUserListOnBasisOfBidIdPagination(List<HUser> hUserList, int
			 * offset, int noOfRecords)
			 */

			// public List<HUser> getUserListOnBasisOfBidId(HBid prevHBid)

			// public HBid getHBid(int bidId);
			int bidIds = Integer.parseInt(bidId);
			HBid hBid = obsDao.getHBid(bidIds);

			List<HUser> userListOnBasisOfBidId = obsDao
					.getUserListOnBasisOfBidId(hBid);
			// public Map<String,String> getUserbidStatusList(List<HUser>
			// hUserList,int bidId)
			
			Map<String, Double> userbidPriceMap = obsDao
					.getUserbidPriceListOnBasisOfAllUsersWithBidId(userListOnBasisOfBidId, bidIds);
			Map<String, String> userBidAttachmentMap = obsDao
					.getUserbidAttachmentListOnBasisOfAllUsersWithBidId(
							userListOnBasisOfBidId, bidIds);
			
			
			Map<String, String> mp = obsDao.getUserbidStatusList(
					userListOnBasisOfBidId, bidIds);
			logger.info(mp.get("1") + "#" + mp.get("5") + "mp.size() "
					+ mp.size()
					+ ",openBidUser()#userListOnBasisOfBidId size()#"
					+ userListOnBasisOfBidId.size());
			list = obsDao.viewUserListOnBasisOfBidIdPagination(
					userListOnBasisOfBidId, (page1 - 1) * recordsPerPage,
					recordsPerPage);

			
			
			model.addAttribute("bidId", hBid.getBidId());
			model.addAttribute("bidName", hBid.getBidName());
			
			
			model.addAttribute("bidDesc", hBid.getBidDescription());
			model.addAttribute("bidType", hBid.getBtype());
			model.addAttribute("bidTypeId", hBid.getBidType().getBidTypeId());
			//<td>${listValue.bidType.bidTypeId}</td>
			model.addAttribute("bidPrice", hBid.getBidPrice());
			model.addAttribute("bidOpenDate", hBid.getBidOpenDate());
			model.addAttribute("bidCloseDate", hBid.getBidCloseDate());
			model.addAttribute("bidStatus", hBid.getBidStatus());
			model.addAttribute("bidAttachment", hBid.getAttachmentName());
			
			
			
			model.addAttribute("userbidPriceMap", userbidPriceMap);
			model.addAttribute("userBidAttachmentMap", userBidAttachmentMap);
			model.addAttribute("mp", mp);

			model.addAttribute("noOfPages", noOfPages);
			model.addAttribute("currentPage", page1);

			model.addAttribute("hUserList", list);

			model.addAttribute("startPaginationFlag", "1");

			System.out.println("openBidUser()#bidList size()#" + list.size());
			logger.info("openBidUser()#bidList size()#" + list.size());
			if (list.size() == noOfRecords) {
				model.addAttribute("stopPaginationFlag", "1");
				logger.info("openBidUser()#stopPaginationFlag:1, list.size():"
						+ list.size() + ",noOfRecords :" + noOfRecords);
			}

			if (list.size() == 0) {
				model.addAttribute("submitFormResult",
						"Sorry! No Record Found..!!");
			}
		} catch (Exception ex) {
			logger.info("openBidUser()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "openBidUser";
	}

	// ------------------End openBidUsers-----------------
	// ------------------open Bid-------------------
	@RequestMapping(value = "getOpenBidPagination", method = RequestMethod.GET)
	public String bidOpenPagination(Model model,
			@RequestParam("page") String page,
			@RequestParam("startPaginationFlag") String paginationFlag,
			@RequestParam("bidStatus") String bidStatus, HttpSession session) {
		try {
			int startPaginationFlag = 0;
			System.out.println("<----------bidPagination(),page" + page
					+ ",paginationFlag :" + paginationFlag);
			logger.info(" bidPagination()# page :" + page + ",paginationFlag :"
					+ paginationFlag);
			List<HBid> list = null;
			User user = (User) session.getAttribute("user");

			int page1 = Integer.parseInt(page);

			if (paginationFlag.equals("")) {
				System.out.println("bidPagination()#paginationFlag-1 :"
						+ paginationFlag);
			} else if (paginationFlag.equals(null)) {
				System.out.println("bidPagination()#paginationFlag-2 :"
						+ paginationFlag);
			} else {
				startPaginationFlag = Integer.parseInt(paginationFlag);
				if (startPaginationFlag == 1) {
					page1 = page1 + 1;
				}
			}

			int recordsPerPage = 1000;
			int noOfRecords = obsDao.getNoOfRecords(bidStatus);
			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
			list = obsDao.viewBidPagination(bidStatus, (page1 - 1)
					* recordsPerPage, recordsPerPage);

			model.addAttribute("bidStatus", bidStatus);
			model.addAttribute("noOfPages", noOfPages);
			model.addAttribute("currentPage", page1);
			model.addAttribute("bidList", list);

			System.out
					.println("bidPagination()#noOfPages----->>>>" + noOfPages);
			System.out.println("bidPagination()#page :" + page
					+ " startPaginationFlag :" + startPaginationFlag
					+ "#list size:" + list.size() + "# model :" + model);
			logger.info("bidPagination()#page :" + page
					+ " startPaginationFlag :" + startPaginationFlag
					+ "#list size:" + list.size() + "# model :" + model);

		} catch (Exception ex) {
			logger.info("bidPagination()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "openbid";
	}

	@RequestMapping(value = "/downloadBidAttachment", method = RequestMethod.GET)
	public void downloadfile(Model model, HttpSession session,
			@RequestParam("value") String bidId, HttpServletResponse response) {// throws
																				// Throwable
		try {
			// public HBid getHBid(String bidName);
			/*
			 * // obtains ServletContext ServletContext context =
			 * getServletContext();
			 * 
			 * // gets MIME type of the file String mimeType =
			 * context.getMimeType(filePath); if (mimeType == null) { // set to
			 * binary type if MIME mapping not found mimeType =
			 * "application/octet-stream"; } System.out.println("MIME type: " +
			 * mimeType);
			 * 
			 * // modifies response response.setContentType(mimeType);
			 */
			logger.info("downloadfile()# bidId " + bidId);
			int bidIds = Integer.parseInt(bidId);
			HBid hBid = obsDao.getHBid(bidIds);

			// response.setContentType(file.contentType);
			response.setContentType("application/octet-stream");
			response.addHeader("Content-Disposition", "attachment; filename=\""
					+ hBid.getAttachmentName() + "\"");
			response.setContentLength(hBid.getAttachmentData().length);

			response.getOutputStream().write(hBid.getAttachmentData());

			response.flushBuffer();
		} catch (Exception ex) {
			logger.info("downloadfile()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
	}

	@RequestMapping(value = "/downloadUserBidAttachment", method = RequestMethod.GET)
	public void downloadUserBidfile(Model model, HttpSession session,
			@RequestParam("userId") String userId,
			@RequestParam("bidId") String bidId, HttpServletResponse response) {// throws
		// Throwable
		try {
			logger.info("downloadUserBidfile()# bidId " + bidId
					+ " user id is " + userId);
			// int userIds = Integer.parseInt(userId);
			int bidIds = Integer.parseInt(bidId);

			HUser hUser = obsDao.getHUser(userId);
			HBid hBid = obsDao.getHBid(bidIds);

			HUserBid hUserBid = obsDao.getUsrWiseBid(hUser, hBid);

			// response.setContentType(file.contentType);
			response.setContentType("application/octet-stream");
			response.addHeader("Content-Disposition", "attachment; filename=\""
					+ hUserBid.getUserBidAttachmentName() + "\"");
			response.setContentLength(hUserBid.getUserAttachmentData().length);
			response.getOutputStream().write(hUserBid.getUserAttachmentData());
			response.flushBuffer();
		} catch (Exception ex) {
			logger.info("downloadUserBidfile()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
	}

	// (Model model, HttpSession session @ModelAttribute("transaction")
	// TransactionBean transactionBean,BindingResult result)
	@RequestMapping(value = "/openbid", method = RequestMethod.GET)
	public String openBid(Model model, HttpSession session) {
		try {
			logger.info("openBid()");
			System.out.println("openBid()");
			// 6-aug2016 model.addAttribute("bidList", obsDao.BidList());
			int page1 = 0;
			List<HBid> list = null;
			int recordsPerPage = 10000000;

			String bidStatus = "Open";
			int noOfRecords = obsDao.getNoOfRecords(bidStatus);

			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);

			list = obsDao.viewBidPagination(bidStatus, (page1 - 1)
					* recordsPerPage, recordsPerPage);
			// model.addAttribute("noOfPages",2);
			model.addAttribute("bidStatus", bidStatus);
			model.addAttribute("noOfPages", noOfPages);
			model.addAttribute("currentPage", page1);

			model.addAttribute("bidList", list);

			model.addAttribute("startPaginationFlag", "1");

			System.out.println("openBid()#bidList size()#" + list.size());
			if (list.size() == noOfRecords) {
				model.addAttribute("stopPaginationFlag", "1");
				logger.info("openBid()#stopPaginationFlag:1, list.size():"
						+ list.size() + ",noOfRecords :" + noOfRecords);
			}

			if (list.size() == 0) {
				model.addAttribute("submitFormResult",
						"Sorry! No Record Found..!!");
			}
		} catch (Exception ex) {
			logger.info("openBid()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "openBid";
	}

	// ------------------End open Bid-------------------
	// -------------BidCreation----------------------
	@RequestMapping(value = "/bidcreation", method = RequestMethod.GET)
	public String bidCreation(Model model) {
		try {
			model.addAttribute("btype", obsDao.BidTypeList());

		} catch (Exception ex) {
			logger.info("createSubscription()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "createBid";
	}

	@RequestMapping(value = "/createBidsSuccess", method = RequestMethod.POST)
	public @ResponseBody
	ModelAndView processbidCreation(ModelMap model, HttpSession session,
			@ModelAttribute("uploadForm") UmfFileUpload uploadFrm,
			@ModelAttribute("bidscreation") HBid hbid, BindingResult result,
			SessionStatus status) {
		
		//filext == "jpg" || filext == "pdf"||filext == "docx"||filext == "doc"||filext == "png"||filext == "jpeg"||filext == "txt"
		try {
			User user = (User) session.getAttribute("user");
			System.out.println("processbidCreation()# session user  :"
					+ user.getEmail());
			// System.out.println("processCreateSubsSuccess()# bidType :" +
			// bidType);
			System.out.println(hbid.getBidCloseDate()
					+ "processbidCreation()# hbid :" + hbid.getBidOpenDate());
			hbid.setBidStatus("Open");
			// hbid.setBidType(obsDao.getHBidType("internal"));
			hbid.setBidType(obsDao.getHBidType(hbid.getBtype()));

			String retstr = "Bids creation Fail ..!";

			Long currentDaysDiff = obsUtility.numberOfDays(hbid
					.getBidOpenDate());
			Long daysDiff = obsUtility.diffDays(hbid.getBidOpenDate(),
					hbid.getBidCloseDate());
			System.out.println("daysDiff " + daysDiff + ",currentDaysDiff :"
					+ currentDaysDiff);
			logger.info("daysDiff " + daysDiff + ",currentDaysDiff :"
					+ currentDaysDiff);
			if (obsDao.checkBidExist(hbid.getBidName()) == Boolean.FALSE) {
				retstr = "Bids Name " + hbid.getBidName()
						+ " allready exist.Please choose diff. name ..!!";
			} else if (currentDaysDiff < 0) {
				retstr = "  Bid Open date can not be less than current date  !!";
			} else if (daysDiff <= 0) {
				retstr = "Bid Closer Date always be greater than Bid Open date  !!";
			} else {
				// =========================8-aug2016==========
				// ----------------[ FileUpload ]-------------
				// String saveDirectory = iobs.uploadFilePath();
			
				String saveDirectory = iobs.uploadFilePath();
				obsUtility.makedir(saveDirectory);
				saveDirectory=saveDirectory+"/"+ hbid.getBidName().trim();
				obsUtility.makedir(saveDirectory);
				saveDirectory=saveDirectory +"/"+ obsUtility.getMonth(1)+"/";
				Boolean mkDir = obsUtility.makedir(saveDirectory);
				// obsUtility(hbid.getBidId())
				logger.info("mkDir --->:" + mkDir);
				if (mkDir) {
					logger.info("Directory Path created :" + saveDirectory);
				} else {
					logger.info("path does not created saveDirectory :"
							+ saveDirectory);
				}
				List<MultipartFile> umfFiles = uploadFrm.getUmfFiles();
				List<String> fileNames = new ArrayList<String>();
				System.out.println("[ processbidCreation()# umfFiles :"
						+ umfFiles + ",fileNames :" + fileNames + " ]");
				logger.info("[ processbidCreation()# umfFiles :" + umfFiles
						+ ",fileNames :" + fileNames + " ]");
				if (null != umfFiles && umfFiles.size() > 0) {
					for (MultipartFile multipartFile : umfFiles) {

						String fileName = multipartFile.getOriginalFilename();

						logger.info("[ processbidCreation()# getOriginalFilename :" + fileName + " ]");
						if (!"".equalsIgnoreCase(fileName)) {
							// InputStream inputStream = null;
							// inputStream=multipartFile.getInputStream();
							byte[] aFileBytes = multipartFile.getBytes();
							// Handle file content -
							// multipartFile.getInputStream()
							if(new File(saveDirectory).exists())
							{
								logger.info("[ processbidCreation()# Exist getOriginalFilename -1:" + saveDirectory
										+ " ]");
							}
							else
							{
								logger.info("[ processbidCreation()#Not Exits getOriginalFilename -2:" + saveDirectory
									 + " ]");
							}
							multipartFile.transferTo(new File(saveDirectory
									+ fileName));
							fileNames.add(fileName);

							// ------------------ReadFile-----------
							String line = "";
							File f1 = new File(saveDirectory + fileName);
							
							String ext = FilenameUtils
									.getExtension(saveDirectory + fileName);
							System.out
									.println("processbidCreation()#File extension is :"
											+ ext);
							logger.info("processbidCreation()#File extension is :"
									+ ext);
							if (ext.equals("jpg") || ext.equals("png")
									|| ext.equals("pdf")||ext.equals("docx")||ext.equals("doc")||ext.equals("jpeg")||ext.equals("txt")||ext.equals("xls")||ext.equals("xlsx")) {
								//filext == "jpg" || filext == "pdf"||filext == "docx"||filext == "doc"||filext == "png"||filext == "jpeg"||filext == "txt"
								if (f1.exists()) {

									logger.info("processbidCreation()#Uploaded the Message file:"
											+ saveDirectory + fileName);
									logger.info("processbidCreation()#Uploaded file aFileBytes :"
											+ aFileBytes);

									// if(obsDao.createBids(hbid) &&
									// obsDao.checkBidExist(hbid.getBidName()))
									if (obsDao.checkBidExist(hbid.getBidName())) {
										hbid.setAttachmentName(fileName);
										hbid.setAttachmentData(aFileBytes);
										// =========================8-aug2016============
										if (obsDao.createBids(hbid)) {
											retstr = "Bid created Successfully..!";
											System.out.println(retstr);
										}
										logger.info(retstr);

									} else {
										System.out.println(retstr);
										logger.info(retstr);
									}
									// f1.delete();
								}// End if (f1.exists())
							} else {

								logger.info("processbidCreation()#Please upload valid jpg,png File format ,This is custom ERROR message");
								throw new CustomGenericException("E888",
										"Please upload valid csv,txt  File format ,This is custom ERROR message");

							}

							// -----------------End ReadFile--------
						}
					}
				}
				// ----------------[ End of file Upload ]----------
			}// End of else

			model.addAttribute("btype", obsDao.BidTypeList());
			logger.info(retstr);
			if ((hbid.getBidName() != null && hbid.getBidOpenDate() != null)
					|| daysDiff <= 0 || currentDaysDiff < 0) {
				model.addAttribute("submitFormResult", retstr);
			}

		} catch (Exception ex) {
			logger.info("processbidCreation()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return new ModelAndView("createBid", model);
	}

	// -------------End BidCreation----------------------
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String user(@ModelAttribute("user") User user, BindingResult result,
			Model model, HttpSession session) {

		System.out.println("HibernateUtil-->"
				+ hibernateDao.getHibernateSessionFactory());
		System.out.println("user id :" + user.getEmail() + " and password :"
				+ user.getPassword());
		logger.info("user id :" + user.getEmail() + " and password :"
				+ user.getPassword());

		try {
			if (user.getEmail() == null || user.getEmail().equals("")) {
				user.setCaptcha("");
				model.addAttribute("message", "User Id is required");
				return "incorrectUserIdPassword";
			}

			if (user.getPassword() == null || user.getPassword().equals("")) {
				user.setCaptcha("");
				model.addAttribute("message", "Password is required");
				return "incorrectUserIdPassword";
			}

			System.out.println("user id :" + user.getEmail()
					+ " and password :" + user.getPassword());

			if (userDao.isValidUser(user)) {

				// HUserRoleDetails getRoleType(String userId)
				HUserRoleDetails hUserRoleDetails = obsDao.getRoleType(user
						.getEmail());
				user.setRoleType(hUserRoleDetails.getRoleType());
				HUser prevHUser = obsDao.getHUser(user.getEmail());
				session.setAttribute("userRole",
						Integer.toString(user.getRoleType()));
				session.setAttribute("user", user);
				logger.info("user id and password matches," + user.getEmail()
						+ "user Role" + user.getRoleType());
				System.out.println("user id and password matches,"
						+ user.getEmail() + "user Role" + user.getRoleType());

				return "home";

			} else {
				user.setCaptcha("");
				model.addAttribute("message",
						"Incorrect UserId or Password..!! ");
				return "incorrectUserIdPassword";
			}
		} catch (Exception ex) {
			logger.info("user()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
	}// End user()

	// ------------------openUsersBid--------------------
	@RequestMapping(value = "/openUsersBid", method = RequestMethod.GET)
	public String openUserBid(Model model, HttpSession session,
			@RequestParam("value") String userId) {
		try {
			logger.info("openUserBid()+ userId" + userId);
			System.out.println("openUserBid()+ userId" + userId);

			int page1 = 0;
			List<HBid> list = null;

			int recordsPerPage = 10000000;

			String bidStatus = "Open";
			int noOfRecords = obsDao.getNoOfRecords(bidStatus);

			int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);

			HUser hUser = obsDao.getHUser(userId);

			List<HBid> bidListOnBasisOfUserId = obsDao
					.getBidListOnBasisOfUserId(hUser);
			
			Map<String, String> mp = obsDao.getUserbidStatusListOnBasisOfBidId(
					bidListOnBasisOfUserId, hUser);
			Map<String, Double> userbidPriceMap = obsDao
					.getUserbidPriceListOnBasisOfBidId(bidListOnBasisOfUserId,
							hUser);
			Map<String, String> userBidAttachmentMap = obsDao
					.getUserbidAttachmentListOnBasisOfBidId(
							bidListOnBasisOfUserId, hUser);
			
			logger.info("openUserBid()#bidListOnBasisOfUserId size()#"
					+ bidListOnBasisOfUserId.size());
			
			list = obsDao.viewBidListOnBasisOfUserIdPagination(
					bidListOnBasisOfUserId, (page1 - 1) * recordsPerPage,
					recordsPerPage);
			model.addAttribute("mp", mp);
			model.addAttribute("userbidPriceMap", userbidPriceMap);
			model.addAttribute("userId", userId);
			model.addAttribute("userBidAttachmentMap", userBidAttachmentMap);

			model.addAttribute("noOfPages", noOfPages);
			model.addAttribute("currentPage", page1);

			model.addAttribute("hBidList", list);

			model.addAttribute("startPaginationFlag", "1");

			System.out.println("openUserBid()#bidList size()#" + list.size());
			logger.info("openUserBid()#bidList size()#" + list.size());
			if (list.size() == noOfRecords) {
				model.addAttribute("stopPaginationFlag", "1");
				logger.info("openUserBid()#stopPaginationFlag:1, list.size():"
						+ list.size() + ",noOfRecords :" + noOfRecords);
			}

			if (list.size() == 0) {
				model.addAttribute("submitFormResult",
						"Sorry! No Record Found..!!");
			}
		} catch (Exception ex) {
			logger.info("openUserBid()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "openUserBid";
	}

	// --------------Anu---------
	@RequestMapping(value = "/manageuser")
	public String manageUser(Model model, @ModelAttribute("huser") HUser user) {
		System.out
				.println("we are in manageUser(),user :" + user.getUsername());
		try {
			if (obsDao.viewAllUsers().size() == 0) {
				model.addAttribute("submitFormResult",
						"Sorry! No Record Found..!!");
			}
			model.addAttribute("userList", obsDao.viewAllUsers());
		} catch (Exception ex) {
			logger.info("manageUser()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "userDetails";
	}

	//public String manageBid(Model model, @ModelAttribute("hbid") HBid bid) {
	@RequestMapping(value = "/managebid")
	public String manageBid(Model model) {
		//System.out.println("we are in manageBid(),BidName :" + bid.getBidName());
		System.out.println("we are in manageBid()");
		logger.info("we are in manageBid()");
		try {

			if (obsDao.viewAllBids().size() == 0) {
				model.addAttribute("submitFormResult",
						"Sorry! No Record Found..!!");
			}
			model.addAttribute("bidList", obsDao.viewAllBids());
		} catch (Exception ex) {
			logger.info("manageBid()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return "bidDetails";
	}
	//-----------------
	
	@RequestMapping(value = "/changeAdminPassword", method = RequestMethod.POST)
	public String changeAdminPassword(Model model,
			@RequestParam("userId") String userId) {

		System.out.println("User Id is :" + userId);

		logger.info("changeAdminPassword()#User Id is :" + userId);
		HUser prevHUser = obsDao.getHUser(userId);
		logger.info("changeAdminPassword()#hUser :" + prevHUser + " createdDate "
				+ prevHUser.getCreatedDate() + ",User Id is :" + userId);
		model.addAttribute("userId", userId);
		model.addAttribute("hUser", prevHUser);

		
		return "changeAdminPassword";
	}
	
	@RequestMapping(value = "/changeAdminPasswordSuccess", method = RequestMethod.POST)
	public @ResponseBody
	ModelAndView processChangeAdminPasswordSuccess(ModelMap model, HttpSession session,
			 @RequestParam("newpassword") String newpassword,
			@RequestParam("confirmpassword") String confirmpassword
			) {
		try {
			/*
			ModelAndView processUserUpdate(ModelMap model, HttpSession session,
			@RequestParam("lstFruits") String listBids,
			@RequestParam("username") String editable_username,
			@RequestParam("email") String editable_email,
			@RequestParam("msisdn") String editable_msisdn,
			@RequestParam("createdDate") String createdDate,
			@RequestParam("userId") String userId, SessionStatus status) {
	
			 */
			User user = (User) session.getAttribute("user");
			HUser prevHUser = obsDao.getHUser(user.getEmail());
			System.out.println("processChangeAdminPasswordSuccess()# hUser.getUserId() :"
					+ prevHUser.getUserId() + ",old password :"
					+ prevHUser.getPassword() + ",newpassword :"
					+ newpassword + ",confirmpassword  :" + confirmpassword);

			logger.info("processChangeAdminPasswordSuccess()# hUser.getUserId() :"
					+ prevHUser.getUserId() + ",old password :"
					+ prevHUser.getPassword() + ",newpassword :"
					+ newpassword + ",confirmpassword  :" + confirmpassword);
			String retstr = "User Management have some technical issue , Please try later ..!";
			if (newpassword == null || prevHUser.getUserId() == null
					|| confirmpassword == null) {
				retstr = "Please enter the all valid values  ..!";
			} 
			else if(!newpassword.equals(confirmpassword))
			{
				retstr = "new password  and confirm password shuld be same!";
			}
			else if (obsDao.checkHUserExist(prevHUser.getUserId()) == Boolean.FALSE) {
				retstr = "User allready Exits  ..! Go for processChangeAdminPasswordSuccess";
				prevHUser.setPassword(confirmpassword);
				if (obsDao.updateUser(prevHUser)) {
					retstr = prevHUser.getUserId() + " password  successfully has been changed";
					logger.info("processChangeAdminPasswordSuccess()#user "
							+ prevHUser.getUserId() + " password  successfully has been changed ");
				} else {
					retstr = prevHUser.getUserId()
							+ " password change  is fail.Please try later..!!";

				}
				logger.info(retstr);

			} else {
				System.out.println(retstr);
				logger.info(retstr);
			}

			if (prevHUser.getUserId() != null && prevHUser.getMsisdn() != null) {
				model.addAttribute("submitFormResult", retstr);
			}
			model.addAttribute("hUser", prevHUser);

		} catch (Exception ex) {
			logger.info("processChangeAdminPasswordSuccess()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return new ModelAndView("changeAdminPassword", model);

	}
	//---------------

	@RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	public String userUpdation(Model model,
			@RequestParam("userId") String userId) {

		System.out.println("User Id is :" + userId);

		logger.info("userUpdation()#User Id is :" + userId);
		HUser prevHUser = obsDao.getHUser(userId);
		logger.info("userUpdation()#hUser :" + prevHUser + " createdDate "
				+ prevHUser.getCreatedDate() + ",User Id is :" + userId);
		model.addAttribute("userId", userId);
		model.addAttribute("hUser", prevHUser);

		model.addAttribute("mappedBidsName",
				obsDao.userMappedBidsNameList(prevHUser));
		model.addAttribute("bidsName",
				obsDao.userAvialableBidNameList(prevHUser));
		return "updateUser";
	}

	@RequestMapping(value = "/updateUserSuccess", method = RequestMethod.POST)
	public @ResponseBody
	ModelAndView processUserUpdate(ModelMap model, HttpSession session,
			@RequestParam(value = "lstFruits", required=false) String listBids,
			@RequestParam(value = "rmBidList", required=false) String removeBidList,
			@RequestParam("username") String editable_username,
			@RequestParam("email") String editable_email,
			@RequestParam("msisdn") String editable_msisdn,
			@RequestParam("createdDate") String createdDate,
			@RequestParam("userId") String userId, SessionStatus status) {
		try {
			//rmBidList
			//public void test(@RequestParam(value = "i", required=false) Integer i
			/*@RequestParam("lstFruits") String listBids,*/
			
			Boolean userUpdateFlag=Boolean.FALSE;
			Boolean userMsgFlag=Boolean.FALSE;
			ArrayList<String> usrAddBidList=new ArrayList<String>();
			HUser hUser = obsDao.getHUser(userId);
			logger.info("processUserUpdate()# removeBidList :"+removeBidList+",listBids :" + listBids
					+ ",for userId :" + userId + ",username "
					+ editable_username + " msisdn :" + editable_msisdn
					+ " email :" + editable_email);

			HUser prevHUser = obsDao.getHUser(userId);

			logger.info("processUserUpdate()# prevHUser.getUserId()"
					+ prevHUser.getUserId() + " ,hUser.getUserId()"
					+ hUser.getUserId());
			String retstr = "User Updation Fail ..!";

			if (editable_username == null || editable_username.equals("")
					|| editable_msisdn == null || editable_msisdn.equals("")
					|| editable_email == null || editable_email.equals("")
					|| !hUser.getUserId().equals(prevHUser.getUserId())) {
				retstr = "Please enter the all valid values  ..!";
				
			} else if ((listBids == null || listBids.equals(""))&&(obsDao.userMappedBidsNameList(prevHUser).size()==0)) {
				retstr = "Please select at least one bid for updateUser ..!";
			} else if (obsDao.checkHUserExist(prevHUser.getUserId()) == Boolean.FALSE) {

				retstr = "User allready Exits  ..! Go for processUserManagement";
				/*
				 * 14-Aug2016 prevHUser.setUsername(hUser.getUsername());
				 * prevHUser.setMsisdn(hUser.getMsisdn());
				 * prevHUser.setEmail(hUser.getEmail());
				 */

				prevHUser.setUsername(editable_username);
				prevHUser.setMsisdn(editable_msisdn);
				prevHUser.setEmail(editable_email);
				Boolean hUserBids_Update = Boolean.FALSE;
				
				logger.info("processUserUpdate()#removeBidList "+removeBidList+" # listBids : "+listBids);
				
				if(removeBidList!=null)
				{
				
					//===============Removing UserBid===============
					StringTokenizer rmtz = new StringTokenizer(removeBidList, ",");
					while (rmtz.hasMoreTokens())
					{
						String removebidName = rmtz.nextToken();
						
						HBid prevHBid = obsDao.getHBid(removebidName);
						obsDao.removeUserBid(hUser,prevHBid.getBidId());
						
						hUserBids_Update = Boolean.TRUE;
						logger.info("processUserUpdate()#Removing User Bid:"
								+ removebidName);
						
					}
					//==================End of Removing UserBid=========
				}
				
				// ----------------------------------------------------------
				if(listBids!=null)
				{
					
						StringTokenizer tz = new StringTokenizer(listBids, ",");		
						System.out.println("countTokens :" + tz.countTokens());
						while (tz.hasMoreTokens()) {
							HUserBid hUserBids = null;
							String bidName = tz.nextToken();
							logger.info("processUserUpdate()#go for createdUserBids :bidName:"
									+ bidName);
							HBid prevHBid = obsDao.getHBid(bidName);
							hUserBids = obsDao.getUsrWiseBid(hUser, prevHBid);
							
							if (hUserBids == null) {
								hUserBids = new HUserBid();
		
								hUserBids.setUserBidCreatedDate(new Date());
		
								hUserBids.setUserbidPrice(hUser.getUserPrice());
								hUserBids
										.setHuserId(obsDao.getHUser(hUser.getUserId()));// HUser
								hUserBids.setUserbidStatus("open");
		
								hUserBids.setBidId(prevHBid);
		
								logger.info("processUserUpdate()#createdUserBids : hUserBids:"
										+ hUserBids + ",prevHBid :" + prevHBid+",adding Bid :"+bidName);
								if (obsDao.createUserBids(hUserBids)) {
									System.out.println("processUserUpdate DONE()");
									hUserBids_Update = Boolean.TRUE;
									userMsgFlag=Boolean.TRUE;
									usrAddBidList.add(bidName);
								}
								logger.info(retstr);
							} else {
								logger.info("processUserUpdate()#for bidName :"
										+ bidName
										+ "Allready present : hUserBids.getUserBidId():"
										+ hUserBids.getUserBidId()
										+ ",hUserBids.getHuserId()"
										+ hUserBids.getHuserId());
							}
						}// End of while
				}//if(listBids!=null)
				else if(obsDao.userMappedBidsNameList(prevHUser).size()>0)
				{
					hUserBids_Update = Boolean.TRUE;
				}
				
				
				if(hUserBids_Update)
				{				
					if (obsDao.updateUser(prevHUser)) {
						retstr = prevHUser.getUserId()
								+ " updated successfully..!!";
						userUpdateFlag=Boolean.TRUE;
						logger.info("processUserUpdate()#user "
								+ prevHUser.getUserId()
								+ " updated successfully..!!, userUpdateFlag :"+userUpdateFlag);
						// amit updated successfully..
						
						// ---------------------
					} else {
						retstr = prevHUser.getUserId()
								+ " updation is fail.Please try later..!!";
					}
				}

				logger.info("processUserUpdate()#user " + prevHUser.getUserId()
						+ " hUserBids_Update :" + hUserBids_Update+",userMsgFlag :"+userMsgFlag+", userUpdateFlag :"+userUpdateFlag);
				/*if (obsDao.updateUser(prevHUser) && hUserBids_Update) {
					retstr = prevHUser.getUserId()
							+ " updated successfully..!!";
					userUpdateFlag=Boolean.TRUE;
					logger.info("processUserUpdate()#user "
							+ prevHUser.getUserId()
							+ " updated successfully..!!, userUpdateFlag :"+userUpdateFlag);
					// amit updated successfully..
					
					// ---------------------
				} else {
					retstr = prevHUser.getUserId()
							+ " updation is fail.Please try later..!!";
				}*/
				logger.info(retstr);

			}// End else
			
			
			if(userUpdateFlag && userMsgFlag)
			{
				//String msgContent = prevHUser.getUserId()+ " updated successfully.";
				
				String biddingNames=usrAddBidList.toString();
				logger.info("processUserUpdate()#usrAddBidList:"+biddingNames);
				
				StringBuilder sb = new StringBuilder(biddingNames);
				sb.deleteCharAt(0);
				sb.deleteCharAt(biddingNames.length()-2);
				biddingNames=sb.toString();				
				sb=null;
				//String msgContent ="New Bid  "+biddingNames+" allocated to "+prevHUser.getUserId();
				String msgContent ="New Tender  "+biddingNames+" open to "+prevHUser.getUserId();
				String msgStatus = iobs.sendMessage(hUser.getMsisdn(),
						msgContent);
				if ((msgStatus.trim()).equalsIgnoreCase("TRUE"))
				{


					logger.info("processUserUpdate()#User MSG:"+prevHUser.getUserId()+ " updated successfully.");
				} 
				else
				{

					logger.info("processUserUpdate()#User MSG:"+prevHUser.getUserId()+ " updated successfully.  message have some technical issue.Please try later..");
				}
				
				//-----------sending mail----------
				String mailContent=msgContent;
				String mailRecepientsTo=hUser.getEmail();
				String mailRecepientsCc="NA";
				String mailSubject="UserUpdateSuccess";
				Boolean mailStatus=iobsMail.sendingMail(mailSubject, mailContent, mailRecepientsTo, mailRecepientsCc);
				if(mailStatus)
				{
					String str="mail has been sent,to "+mailRecepientsTo+",subject :"+mailSubject+",mailContent :"+mailContent;
					logger.info(str);
				}
				else
				{
					String str="mail  sending fail,to "+mailRecepientsTo+",subject :"+mailSubject+",mailContent :"+mailContent;
					logger.info(str);
				}
				//-----------end sending mail--------
				
				
				usrAddBidList.clear();
				
			}

			//logger.info("processUserUpdate()#-3 "+removeBidList+" # listBids : "+listBids);
			model.addAttribute("userId", userId);
			model.addAttribute("hUser", prevHUser);

			model.addAttribute("mappedBidsName",
					obsDao.userMappedBidsNameList(prevHUser));
			model.addAttribute("bidsName",
					obsDao.userAvialableBidNameList(prevHUser));
			if (prevHUser.getUserId() != null || listBids == null
					|| listBids.equals("") || editable_username == null
					|| editable_username.equals("") || editable_msisdn == null
					|| editable_msisdn.equals("") || editable_email == null
					|| editable_email.equals("")
					|| !hUser.getUserId().equals(prevHUser.getUserId())) {
				model.addAttribute("submitFormResult", retstr);
			}
			

		} catch (Exception ex) {
			logger.info("processUserUpdate()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return new ModelAndView("updateUser", model);
	}

	@RequestMapping(value = "/updateAdminUserSuccess", method = RequestMethod.POST)
	public @ResponseBody
	ModelAndView processAdminUserUpdate(ModelMap model, HttpSession session,
			@RequestParam("username") String editable_username,
			@RequestParam("email") String editable_email,
			@RequestParam("msisdn") String editable_msisdn,
			@RequestParam("createdDate") String createdDate,
			@RequestParam("userId") String userId, SessionStatus status) 
{

		try
		{
		
			String retstr = "User Updation Fail ..!";
			HUser hUser = obsDao.getHUser(userId);
			logger.info("processAdminUserUpdate()# createdDate :" + createdDate
			+ ",for userId :" + userId + ",username "
			+ editable_username + " msisdn :" + editable_msisdn
			+ " email :" + editable_email);
			
			HUser prevHUser = obsDao.getHUser(userId);

		
			if (prevHUser.getEmail() == null || prevHUser.getUserId() == null
							|| hUser.getMsisdn() == null) {
						retstr = "Please enter the all valid values  ..!";
					} else if (obsDao.checkHUserExist(prevHUser.getUserId()) == Boolean.FALSE) {
						retstr = "User allready Exits  ..! Go for processUserManagement";
						
						
						
						
						prevHUser.setUsername(editable_username);
						prevHUser.setMsisdn(editable_msisdn);
						prevHUser.setEmail(editable_email);
						

						if (obsDao.updateUser(prevHUser)) {
							retstr = prevHUser.getUserId() + " updated successfully";
							logger.info("processAdminUserUpdate()#user "
									+ prevHUser.getUserId() + " updated successfully");
						} else {
							retstr = prevHUser.getUserId()
									+ " updation is fail.Please try later..!!";
		
						}
						logger.info(retstr);
		
					} else {
						System.out.println(retstr);
						logger.info(retstr);
					}
		
			
						model.addAttribute("userId", userId);
						model.addAttribute("hUser", prevHUser);
			
						model.addAttribute("mappedBidsName",
						obsDao.userMappedBidsNameList(prevHUser));
						model.addAttribute("bidsName",
						obsDao.userAvialableBidNameList(prevHUser));

					if (prevHUser.getUserId() != null && prevHUser.getMsisdn() != null) {
						model.addAttribute("submitFormResult", retstr);
					}
		
				} catch (Exception ex) {
					logger.info("processAdminUserUpdate()#This is custom ERROR message.Please try later..!! ,Exception :"
							+ ex);
					throw new CustomGenericException("E888",
							"This is custom ERROR message.Please try later..!!");
		}
		return new ModelAndView("updateUser", model);


}
	
	@RequestMapping(value = "/updateBid", method = RequestMethod.POST)
	public String bidUpdation(Model model, @RequestParam("bidId") int bidId) {

		HBid prevHBid = obsDao.getHBid(bidId);
		System.out.println("bidUpdation() method BID Id is :" + bidId
				+ "and HBidId is " + prevHBid.getBidName());
		logger.info("bidUpdation() method BID Id is :" + bidId
				+ "and HBidId is " + prevHBid.getBidName());
		model.addAttribute("bidId", bidId);
		model.addAttribute("hBid", prevHBid);
		/*
		 * HBid hBid = obsDao.getHBid(bidName); model.addAttribute("hBid",
		 * hBid);
		 */
		return "updateBid";
	}

	@RequestMapping(value = "/updateBidSuccess", method = RequestMethod.POST)
	public @ResponseBody
	ModelAndView processBidUpdate(ModelMap model, HttpSession session,
			@ModelAttribute("uploadForm") UmfFileUpload uploadFrm,
			@ModelAttribute("bidupdation") HBid hBid, BindingResult result) {
		try {

			Boolean updateBidSuccessFlag=Boolean.FALSE;
			HBid prevHBid = obsDao.getHBid(hBid.getBidId());

			System.out
					.println("processBidUpdate()#without session hBid.getBidId() :"
							+ hBid.getBidId() + " and prevHBid " + prevHBid);
			logger.info("processBidUpdate()#without session hBid.getBidId() :"
					+ hBid.getBidId() + " and prevHBid " + prevHBid);
			String retstr = "Bid Updation Fail ..!";

			if (hBid.getBidName() == null || hBid.getBidDescription() == null
					|| hBid.getBidOpenDate() == null
					|| hBid.getBidCloseDate() == null
					|| hBid.getBidPrice() == null) {
				retstr = "Please enter the all valid values  ..!!";
			} else if (obsDao.checkBidExist(prevHBid.getBidName()) == Boolean.FALSE) {

				retstr = "Bid Name already Exits  ..!!";

				// =========================8-aug2016==========
				// ----------------[ FileUpload ]-------------

				String saveDirectory = iobs.uploadFilePath();
				obsUtility.makedir(saveDirectory);
				Boolean mkDir = obsUtility.makedir(saveDirectory + "/"
						+ prevHBid.getBidName() + "/" + obsUtility.getMonth(1)
						+ "/");
				// obsUtility(hbid.getBidId())
				logger.info("mkDir --->:" + mkDir);
				if (mkDir) {
					saveDirectory = saveDirectory + "/" + prevHBid.getBidName()
							+ "/" + obsUtility.getMonth(1) + "/";
				} else {
					logger.info("processBidUpdate()#path does not created saveDirectory :"
							+ saveDirectory);
				}
				List<MultipartFile> umfFiles = uploadFrm.getUmfFiles();
				List<String> fileNames = new ArrayList<String>();
				System.out.println("[ processBidUpdate()# Files :" + umfFiles
						+ ",fileNames :" + fileNames + " ]");
				logger.info("[ processBidUpdate()# Files :" + umfFiles
						+ ",fileNames :" + fileNames + " ]");
				//if (fileNames.size() > 0) {
					if (null != umfFiles && umfFiles.size() > 0) {
						for (MultipartFile multipartFile : umfFiles) {

							String fileName = multipartFile
									.getOriginalFilename();
							if(!fileName.equals("")){
							if (!"".equalsIgnoreCase(fileName)) {
								// InputStream inputStream = null;
								// inputStream=multipartFile.getInputStream();
								byte[] aFileBytes = multipartFile.getBytes();
								// Handle file content -
								// multipartFile.getInputStream()
								multipartFile.transferTo(new File(saveDirectory
										+ fileName));
								fileNames.add(fileName);

								// ------------------ReadFile-----------
								String line = "";
								File f1 = new File(saveDirectory + fileName);
								String ext = FilenameUtils
										.getExtension(saveDirectory + fileName);
								System.out
										.println("processBidUpdate()#File extension is :"
												+ ext);
								logger.info("processBidUpdate()#File extension is :"
										+ ext);
								if (ext.equals("jpg") || ext.equals("png")
										|| ext.equals("pdf")||ext.equals("docx")||ext.equals("doc")||ext.equals("jpeg")||ext.equals("txt")||ext.equals("xls")||ext.equals("xlsx")) {
									if (f1.exists()) {

										logger.info("processBidUpdate()#Uploaded the Message file:"
												+ saveDirectory + fileName);
										logger.info("processBidUpdate()#Uploaded file aFileBytes :"
												+ aFileBytes);
										prevHBid.setAttachmentName(fileName);
										prevHBid.setAttachmentData(aFileBytes);
										prevHBid.setBidName(hBid.getBidName());
										prevHBid.setBidDescription(hBid
												.getBidDescription());
										prevHBid.setBidOpenDate(hBid
												.getBidOpenDate());
										prevHBid.setBidCloseDate(hBid
												.getBidCloseDate());
										prevHBid.setBidPrice(hBid.getBidPrice());

										if (obsDao.updateBid(prevHBid)) {
											retstr = prevHBid.getBidName()
													+ " updated successfully.!!";
											updateBidSuccessFlag=Boolean.TRUE;
											logger.info("processBidUpdate()#user "
													+ prevHBid.getBidId()
													+ " updated successfully");
										} else {
											retstr = prevHBid.getBidName()
													+ " updation is fail.Please try later..!!";
										}
										logger.info(retstr);

										// f1.delete();
									}// End if (f1.exists())
								} else {
									logger.info("processBidUpdate()#Please upload valid jpg,png File format ,This is custom ERROR message");									
									
									retstr=	"Invalid uploaded file,Please upload valid file format";
									logger.info("processBidUpdate()#"+retstr);
									model.addAttribute("submitFormResult", retstr);
									return new ModelAndView("updateBid", model);

									/*throw new CustomGenericException("E888",
											"Please upload valid csv,txt  File format ,This is custom ERROR message");*/

								}

								// -----------------End ReadFile--------
							}
							}else {
								logger.info(retstr);

								prevHBid.setBidName(hBid.getBidName());
								prevHBid.setBidDescription(hBid.getBidDescription());
								prevHBid.setBidOpenDate(hBid.getBidOpenDate());
								prevHBid.setBidCloseDate(hBid.getBidCloseDate());
								prevHBid.setBidPrice(hBid.getBidPrice());

								if (obsDao.updateBid(prevHBid)) {
									retstr = prevHBid.getBidName()
											+ " updated successfully.!!";
									updateBidSuccessFlag=Boolean.TRUE;
									logger.info("processBidUpdate()#user "
											+ prevHBid.getBidId() + " updated successfully without attachment");
								} else {
									retstr = prevHBid.getBidName()
											+ " updation is fail.Please try later..!!";
								}
								logger.info(retstr);

							}

							
						}//End of loop
					}

				// ----------------[ End of file Upload ]----------
				// **********************************************

				// **********************************************
			} else {
				System.out.println(retstr);
				logger.info(retstr);
			}
			
			if(updateBidSuccessFlag)
			{
				

				User user = (User) session.getAttribute("user");
				// public HUser getHUser(String userId);

				System.out.println("processBidUpdate()#userID is :"
						+ user.getEmail());
				
				HUser hUser = obsDao.getHUser(user.getEmail());

				logger.info("processBidUpdate()#userID is :"
						+ user.getEmail()+" msisdn :"+hUser.getMsisdn());
				
				String msgContent = "You have successfully updated your Bid : " + prevHBid.getBidName();
				String msgStatus = iobs.sendMessage(hUser.getMsisdn(),
						msgContent);
				if ((msgStatus.trim()).equalsIgnoreCase("TRUE"))
				{


					logger.info("processBidUpdate()#User MSG:You have successfully updated your Bid : " + prevHBid.getBidName());
				} 
				else
				{

					logger.info("processBidUpdate()#User MSG:You have successfully updated for your Bid : " + prevHBid.getBidName()+"  message have some technical issue.Please try later..");
				}
				
				//-----------sending mail----------
				String mailContent=msgContent;
				String mailRecepientsTo=hUser.getEmail();
				String mailRecepientsCc="NA";
				String mailSubject="updateBidSuccess";
				Boolean mailStatus=iobsMail.sendingMail(mailSubject, mailContent, mailRecepientsTo, mailRecepientsCc);
				if(mailStatus)
				{
					String str="mail has been sent,to "+mailRecepientsTo+",subject :"+mailSubject+",mailContent :"+mailContent;
					logger.info(str);
				}
				else
				{
					String str="mail  sending fail,to "+mailRecepientsTo+",subject :"+mailSubject+",mailContent :"+mailContent;
					logger.info(str);
				}
				//-----------end sending mail--------
				
			}

			
			if (hBid.getBidName() != null) {
				model.addAttribute("submitFormResult", retstr);
			}
		} catch (Exception ex) {
			logger.info("processBidUpdate()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return new ModelAndView("updateBid", model);
	}
	@RequestMapping(value = "/deleteUser", method = RequestMethod.POST)
	public void getUserDelete(@RequestParam("huserId") int huserId,
			HttpSession session, Model model) {

		System.out.println("selected Row is :" + huserId);

		try {
			obsDao.deleteUser(huserId);
			try {
				if (obsDao.viewAllUsers().size() == 0) {
					model.addAttribute("submitFormResult",
							"Sorry! No Record Found..!!");
				}
				model.addAttribute("userList", obsDao.viewAllUsers());
			} catch (Exception ex) {
				logger.info("getUserDelete()#This is custom ERROR message.Please try later..!! ,Exception :"
						+ ex);
				throw new CustomGenericException("E888",
						"This is custom ERROR message.Please try later..!!");
			}
		} catch (Exception ex) {
			logger.info("getUserDelete()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
	}

	@RequestMapping(value = "/deleteBid", method = RequestMethod.POST)
	public void getBidDelete(@RequestParam("bidId") int bidId,
			HttpSession session, Model model) {

		System.out.println("getBidDelete()#selected Row is :" + bidId);
		logger.info("getBidDelete()#selected Row is :" + bidId);

		try {
			obsDao.deleteBid(bidId);
			try {
				if (obsDao.viewAllBids().size() == 0) {
					model.addAttribute("submitFormResult",
							"Sorry! No Record Found..!!");
				}
				model.addAttribute("bidList", obsDao.viewAllBids());
			} catch (Exception ex) {
				logger.info("getBidDelete()#This is custom ERROR message.Please try later..!! ,Exception :"
						+ ex);
				throw new CustomGenericException("E888",
						"This is custom ERROR message.Please try later..!!");
			}
		} catch (Exception ex) {
			logger.info("getBidDelete()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
	}

	@RequestMapping(value = "/applyBid", method = RequestMethod.POST)
	public String bidApply(Model model, @RequestParam("bidId") int bidId) {

		System.out.println("BID Id is :" + bidId);
		HBid hBid = obsDao.getHBid(bidId);
		Long currentDaysDiff = obsUtility.numberOfDays(hBid.getBidCloseDate());
		logger.info("bidApply()#BID Id is :" + bidId+",currentDaysDiff :"+currentDaysDiff);
		if (currentDaysDiff < 0) 
		{	
			model.addAttribute("currentDaysDiff", "NA");
		}
		else
		{	
			model.addAttribute("currentDaysDiff", "OK");
		}
		model.addAttribute("bidId", bidId);
		model.addAttribute("hBid", hBid);
		return "applyBid";
	}

	@RequestMapping(value = "/applyBidSuccess", method = RequestMethod.POST)
	public @ResponseBody
	ModelAndView processBidApply(ModelMap model,
			@RequestParam("bidId") int bidId,
			@RequestParam("userbidPrice") Double userbidPrice,
			@RequestParam("userBidComment") String userBidComment,
			@ModelAttribute("uploadForm") UmfFileUpload uploadFrm,
			BindingResult result, SessionStatus status, HttpSession session) {
		try {
			Boolean applyBidSuccessFlag=Boolean.FALSE;
			Date date = null;
			HBid prevHBid = obsDao.getHBid(bidId);

			User user = (User) session.getAttribute("user");
			System.out.println("processBidApply()#userID is :"
					+ user.getEmail());
			logger.info("processBidApply()#userID is :" + user.getEmail());
			HUser hUser = obsDao.getHUser(user.getEmail());

			HUserBid hUserBid = obsDao.getUsrWiseBid(hUser, prevHBid);
			System.out.println("bidId =" + prevHBid.getBidId()
					+ " and huserId =" + hUser.getHuserId()
					+ " and HUserBid instance is " + hUserBid);
			/*
			 * //14-aug2016 SimpleDateFormat formatter = new
			 * SimpleDateFormat("yyyy-mm-dd"); try { date =
			 * formatter.parse(userBidCloseDate); System.out.println(date);
			 * System.out.println(formatter.format(date)); } catch (Exception e)
			 * { e.printStackTrace(); }
			 */
			System.out
					.println("processBidApply()#without session hBid.getBidId() :"
							+ bidId
							+ " and prevHBid "
							+ prevHBid.getBidName()
							+ " User Bid Price : " + userbidPrice);
			logger.info("processBidApply()#without session hBid.getBidId() :"
					+ bidId + " and prevHBid " + prevHBid.getBidName()
					+ " User Bid Price : " + userbidPrice + ",uploadFrm :"
					+ uploadFrm);
			String retstr = "User Bid Apply Fail ..!";

			/*
			 * //14-aug2016 Long daysDiff1 =
			 * obsUtility.diffDays(prevHBid.getBidOpenDate(), userBidCloseDate);
			 * 
			 * Long daysDiff = obsUtility.diffDays(userBidCloseDate,
			 * prevHBid.getBidCloseDate());
			 */
			if (prevHBid.getBidName() == null
					|| prevHBid.getBidDescription() == null
					|| prevHBid.getBidOpenDate() == null
					|| prevHBid.getBidCloseDate() == null
					|| prevHBid.getBidPrice() == null) {
				retstr = "Please enter the all valid values  ..!";
			} else if (obsDao.checkBidExist(prevHBid.getBidName()) == Boolean.FALSE) {
				retstr = "Bid Name already Exits  ..!! ";
				try {
					if (prevHBid != null && hUserBid != null) {
						hUserBid.setUserbidStatus("Apply");
						hUserBid.setUserBidAppliedDate(obsUtility.date(1));
						hUserBid.setUserbidPrice(userbidPrice);
						hUserBid.setUserBidComment(userBidComment.trim());
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.toString());
				}
				// **********************13-Aug2016 FILE
				// UPLOAD*******************************
				// ----------------[ FileUpload ]-------------

				String saveDirectory = iobs.uploadFilePath();
				obsUtility.makedir(saveDirectory);
				Boolean mkDir = obsUtility.makedir(saveDirectory + "/"
						+ prevHBid.getBidName() + "/" + obsUtility.getMonth(1)
						+ "/");
				// obsUtility(hbid.getBidId())
				logger.info("processBidApply()#mkDir --->:" + mkDir
						+ ", prev BidName :" + prevHBid.getBidName()
						+ ",prev BidId :" + prevHBid.getBidId());
				if (mkDir) {
					saveDirectory = saveDirectory + "/" + prevHBid.getBidName()
							+ "/" + obsUtility.getMonth(1) + "/";
				} else {
					logger.info("processBidApply()#path does not created saveDirectory :"
							+ saveDirectory);
				}
				List<MultipartFile> umfFiles = uploadFrm.getUmfFiles();
				List<String> fileNames = new ArrayList<String>();
				System.out.println("[ processUserUpdate()# Files :" + umfFiles
						+ ",fileNames :" + fileNames + " ]");
				logger.info("[ processBidApply()# Files :" + umfFiles
						+ ",fileNames :" + fileNames + " ]");

				if (null != umfFiles && umfFiles.size() > 0) {
					for (MultipartFile multipartFile : umfFiles) {

						String fileName = multipartFile.getOriginalFilename();

						logger.info("processBidApply()#--1-->fileName :"
								+ fileName);
						if (!fileName.equals("")) {

							if (!"".equalsIgnoreCase(fileName)) {
								// InputStream inputStream = null;
								// inputStream=multipartFile.getInputStream();
								byte[] aFileBytes = multipartFile.getBytes();
								// Handle file content -
								// multipartFile.getInputStream()
								multipartFile.transferTo(new File(saveDirectory
										+ fileName));
								fileNames.add(fileName);
								logger.info("processBidApply()#--2-->fileName :"
										+ fileName);
								// ------------------ReadFile-----------
								String line = "";
								File f1 = new File(saveDirectory + fileName);
								String ext = FilenameUtils
										.getExtension(saveDirectory + fileName);
								System.out
										.println("processBidApply()#File extension is :"
												+ ext
												+ " ,fileName :"
												+ fileName);
								logger.info("processBidApply()#File extension is :"
										+ ext + " ,fileName :" + fileName);
								if (ext.equals("jpg") || ext.equals("png")
										|| ext.equals("pdf")||ext.equals("docx")||ext.equals("doc")||ext.equals("jpeg")||ext.equals("txt")||ext.equals("xls")||ext.equals("xlsx")) {
									if (f1.exists()) {

										logger.info("processBidApply()#Uploaded the Message file:"
												+ saveDirectory + fileName);
										logger.info("processBidApply()#Uploaded file aFileBytes :"
												+ aFileBytes);
										hUserBid.setUserBidAttachmentName(fileName);
										hUserBid.setUserAttachmentData(aFileBytes);
										logger.info("processBidApply()# userBidAttachmentName :"
												+ fileName
												+ " prev BidName :"
												+ prevHBid.getBidName()
												+ ",prev BidId :"
												+ prevHBid.getBidId());

										if (obsDao.updateBid(prevHBid)
												&& obsDao
														.createUserBids(hUserBid)) {
											retstr = "Bid : "
													+ prevHBid.getBidName()
													+ " applied successfully..!!";
											applyBidSuccessFlag=Boolean.TRUE;
											logger.info("processBidApply()#user "
													+ prevHBid.getBidId()
													+ " bid status changed to apply successfully # userBidAttachmentName :"
													+ fileName
													+ " prev BidName :"
													+ prevHBid.getBidName()
													+ ",prev BidId :"
													+ prevHBid.getBidId());
											

										} else {
											retstr = prevHBid.getBidName()
													+ " Apply is fail.Please try later..!!";
										}

										logger.info(retstr);

									}// End if (f1.exists())
								} else {

									logger.info("processBidUpdate()#Please upload valid jpg,png File format ,This is custom ERROR message");
									throw new CustomGenericException("E888",
											"Please upload valid csv,txt  File format ,This is custom ERROR message");

								}

								// -----------------End ReadFile--------
							}
						} else {

							hUserBid.setUserBidAttachmentName(null);
							hUserBid.setUserAttachmentData(null);
							if (obsDao.updateBid(prevHBid)
									&& obsDao.createUserBids(hUserBid)) {
								retstr = "Bid : " + prevHBid.getBidName()
										+ " applied successfully..!!";
								applyBidSuccessFlag=Boolean.TRUE;
								logger.info("processBidApply()#user "
										+ prevHBid.getBidId()
										+ " bid status changed to apply successfully without userBidAttachmentName");
							} else {
								retstr = prevHBid.getBidName()
										+ " Apply is fail.Please try later..!!";
							}

							logger.info(retstr);
						}

					}// End of loop
				}

				// ----------------[ End of file Upload ]----------
				// *******************13-Aug2016 FILE
				// UPLOAD**********************************

			} else {
				System.out.println(retstr);
				logger.info(retstr);
			}
			logger.info(" applyBidSuccessFlag:"+applyBidSuccessFlag);
			
			if(applyBidSuccessFlag)
			{
				String msgContent = "You have successfully applied for Bid : " + prevHBid.getBidName();

				String msgStatus = iobs.sendMessage(hUser.getMsisdn(),
						msgContent);
				if ((msgStatus.trim()).equalsIgnoreCase("TRUE"))
				{


					logger.info("processBidApply()#User MSG:You have successfully applied for Bid : " + prevHBid.getBidName());
				} 
				else
				{

					logger.info("processBidApply()#User MSG:You have successfully applied for Bid : " + prevHBid.getBidName()+"  message have some technical issue.Please try later..");
				}
				
				//-----------sending mail----------
				String mailContent=msgContent;
				String mailRecepientsTo=hUser.getEmail();
				String mailRecepientsCc="NA";
				String mailSubject="applyBidSuccess";
				Boolean mailStatus=iobsMail.sendingMail(mailSubject, mailContent, mailRecepientsTo, mailRecepientsCc);
				if(mailStatus)
				{
					String str="mail has been sent,to "+mailRecepientsTo+",subject :"+mailSubject+",mailContent :"+mailContent;
					logger.info(str);
				}
				else
				{
					String str="mail  sending fail,to "+mailRecepientsTo+",subject :"+mailSubject+",mailContent :"+mailContent;
					logger.info(str);
				}
				//-----------end sending mail--------
				
				HUser adminhUser = obsDao.getHUser(1);
				
				logger.info("processBidApply():adminhUser:"+adminhUser);
				String adminMsgContent = "User  : " + hUser.getUserId()+" has been applied for Bid : " + prevHBid.getBidName();
				String adminMsgStatus = iobs.sendMessage(adminhUser.getMsisdn(),
						adminMsgContent);
				
				if ((adminMsgStatus.trim()).equalsIgnoreCase("TRUE"))
				{


					logger.info("processBidApply()#Admin MSG:User  : " + hUser.getUserId()+" has been applied for Bid : " + prevHBid.getBidName());
				} 
				else
				{

					logger.info("processBidApply()#Admin MSG:User  : " + hUser.getUserId()+" has been applied for Bid : " + prevHBid.getBidName()+"  message have some technical issue.Please try later..");
				}

				//-----------sending mail----------
				mailContent=msgContent;
				mailRecepientsTo=adminhUser.getEmail();
				mailRecepientsCc="NA";
				mailSubject="applyBidSuccess";
				mailStatus=iobsMail.sendingMail(mailSubject, mailContent, mailRecepientsTo, mailRecepientsCc);
				if(mailStatus)
				{
					String str="mail has been sent,to "+mailRecepientsTo+",subject :"+mailSubject+",mailContent :"+mailContent;
					logger.info(str);
				}
				else
				{
					String str="mail  sending fail,to "+mailRecepientsTo+",subject :"+mailSubject+",mailContent :"+mailContent;
					logger.info(str);
				}
				//-----------end sending mail--------	
				
			}

			
			// 14-aug2016 if (prevHBid.getBidName() != null || (daysDiff <= 0)||
			// (daysDiff1 <= 0))
			if (prevHBid.getBidName() != null) {
				model.addAttribute("submitFormResult", retstr);

				// return new ModelAndView("usrbidpendingview", model);

			}
		} catch (Exception ex) {
			logger.info("processBidApply()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return new ModelAndView("applyBid", model);
	}

	@RequestMapping(value = "/exitBid", method = RequestMethod.POST)
	public @ResponseBody
	ModelAndView processBidExit(ModelMap model,
			@RequestParam("bidId") int bidId, HttpSession session) {
		try {

			HBid prevHBid = obsDao.getHBid(bidId);

			User user = (User) session.getAttribute("user");
			System.out
					.println("processBidExit()#userID is :" + user.getEmail());
			logger.info("processBidExit()#userID is :" + user.getEmail());
			HUser hUser = obsDao.getHUser(user.getEmail());

			HUserBid hUserBid = obsDao.getUsrWiseBid(hUser, prevHBid);
			System.out
					.println("processBidExit()#without session hBid.getBidId() :"
							+ bidId + " and prevHBid " + prevHBid);
			logger.info("processBidExit#without session hBid.getBidId() :"
					+ bidId + " and prevHBid " + prevHBid);
			String retstr = "Bid Exit Fail ..!";

			if (prevHBid.getBidName() == null
					|| prevHBid.getBidDescription() == null
					|| prevHBid.getBidOpenDate() == null
					|| prevHBid.getBidCloseDate() == null
					|| prevHBid.getBidPrice() == null) {
				retstr = "Please enter the all valid values  ..!";
			} else if (obsDao.checkBidExist(prevHBid.getBidName()) == Boolean.FALSE) {

				retstr = "Bid Name already Exits  ..! Go for processBidManagement";
				// prevHBid.setBidStatus("Exit");
				hUserBid.setUserbidStatus("Exit");
				if (obsDao.updateBid(prevHBid)
						&& obsDao.createUserBids(hUserBid)) {
					retstr = "Bid " + prevHBid.getBidName()
							+ "  exit successfully..!!";
					logger.info("processBidExit()#user " + prevHBid.getBidId()
							+ " bid status changed to Exit successfully");
				} else {
					retstr = prevHBid.getBidName()
							+ " Exit is fail.Please try later..!!";
				}
				logger.info(retstr);
			} else {
				System.out.println(retstr);
				logger.info(retstr);
			}
			if (prevHBid.getBidName() != null) {
				model.addAttribute("submitFormResult", retstr);
			}
		} catch (Exception ex) {
			logger.info("processBidExit()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return new ModelAndView("userAppliedBidHistory", model);
	}

	@RequestMapping(value = "/updateBidHistory", method = RequestMethod.POST)
	public String bidHistoryUpdation(Model model,
			@RequestParam("bidId") int bidId, HttpSession session) {
		System.out
				.println("comes from appliedBidHistry menu#bidHistoryUpdation()#BID Id is :"
						+ bidId);
		logger.info("comes from appliedBidHistry menu#bidHistoryUpdation()#BID Id is :"
				+ bidId);

		String userbidPrice = "", userBidCloseDate = "";
		HBid prevHBid = obsDao.getHBid(bidId);

		// -------------------------------
		User user = (User) session.getAttribute("user");
		System.out
				.println("bidHistoryUpdation()#userID is :" + user.getEmail());
		logger.info("bidHistoryUpdation()#userID is :" + user.getEmail());
		HUser hUser = obsDao.getHUser(user.getEmail());
		HUserBid hUserBid = obsDao.getUsrWiseBid(hUser, prevHBid);

		// ---------------------------
		model.addAttribute("bidId", bidId);
		// String str=hUserBid.getUserBidCloseDate();
		model.addAttribute("userbidPrice", hUserBid.getUserbidPrice());
		model.addAttribute("userBidComment", hUserBid.getUserBidComment());
		model.addAttribute("userBidAttachmentName", hUserBid.getUserBidAttachmentName());
		// model.addAttribute("userBidCloseDate",
		// hUserBid.getUserBidCloseDate().toString());
		logger.info("bidHistoryUpdation()#userbidPrice :"
				+ hUserBid.getUserbidPrice() + ", userBidComment"
				+ hUserBid.getUserBidComment());

		model.addAttribute("hBid", prevHBid);
		// model.addAttribute("hBid", prevHBid);
		return "updateBidHistory";
	}

	@RequestMapping(value = "/updateBidHistorySuccess", method = RequestMethod.POST)
	public @ResponseBody
	ModelAndView processBidHistoryUpdate(ModelMap model, HttpSession session,
			@RequestParam("bidId") int bidId,
			@RequestParam("userbidPrice") Double userbidPrice,
			@RequestParam("userBidComment") String userBidComment,
			@ModelAttribute("uploadForm") UmfFileUpload uploadFrm,
			BindingResult result) {
		try {

			logger.info("comes from appliedBidHistry menu#processBidHistoryUpdate()#userbidPrice :"
					+ userbidPrice
					+ ",userBidComment: "
					+ userBidComment
					+ "without session hBid.getBidId() :" + bidId);
			HBid prevHBid = obsDao.getHBid(bidId);

			User user = (User) session.getAttribute("user");
			System.out.println("processBidHistoryUpdate()#userID is :"
					+ user.getEmail());
			logger.info("processBidHistoryUpdate()#userID is :"
					+ user.getEmail());
			HUser hUser = obsDao.getHUser(user.getEmail());

			HUserBid hUserBid = obsDao.getUsrWiseBid(hUser, prevHBid);

			System.out
					.println("processBidHistoryUpdate()#without session hBid.getBidId() :"
							+ bidId
							+ " and prevHBid "
							+ prevHBid
							+ ",hUserBid :" + hUserBid);
			logger.info("processBidHistoryUpdate()#without session hBid.getBidId() :"
					+ bidId
					+ " and prevHBid "
					+ prevHBid
					+ ",hUserBid :"
					+ hUserBid);
			String retstr = "Bid History Updation Fail ..!";

			logger.info("comes from appliedBidHistry menu#processBidHistoryUpdate()#userbidPrice :"
					+ userbidPrice
					+ ",userBidComment: "
					+ userBidComment
					+ "without session hBid.getBidId() :" + bidId);

			if (prevHBid.getBidName() == null
					|| prevHBid.getBidDescription() == null
					|| prevHBid.getBidOpenDate() == null
					|| prevHBid.getBidCloseDate() == null
					|| prevHBid.getBidPrice() == null) {
				retstr = "Please enter the all valid values  ..!";
			} else if (obsDao.checkBidExist(prevHBid.getBidName()) == Boolean.FALSE) {
				retstr = "Bid Name already Exits  ..! Go for processBidHistoryManagement";
				try {
					if (prevHBid != null && hUserBid != null) {

						hUserBid.setUserbidPrice(userbidPrice);
						hUserBid.setUserBidComment(userBidComment.trim());
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.toString());
				}
				/*
				 * prevHBid.setBidName(hBid.getBidName());
				 * prevHBid.setBidDescription(hBid.getBidDescription());
				 * prevHBid.setBidOpenDate(hBid.getBidOpenDate());
				 * prevHBid.setBidCloseDate(hBid.getBidCloseDate());
				 * prevHBid.setBidPrice(hBid.getBidPrice());
				 * hUserBid.setUserbidPrice(userbidPrice);
				 * hUserBid.setUserBidComment(userBidComment);
				 */
				// **********************13-Aug2016 FILE
				// UPLOAD*******************************
				// ----------------[ FileUpload ]-------------
				// String saveDirectory = "D:/home/obs/";
				String saveDirectory = iobs.uploadFilePath();
				obsUtility.makedir(saveDirectory);
				Boolean mkDir = obsUtility.makedir(saveDirectory + "/"
						+ prevHBid.getBidName() + "/" + obsUtility.getMonth(1)
						+ "/");
				// obsUtility(hbid.getBidId())
				logger.info("processBidHistoryUpdate()#mkDir --->:" + mkDir
						+ ", prev BidName :" + prevHBid.getBidName()
						+ ",prev BidId :" + prevHBid.getBidId());
				if (mkDir) {
					saveDirectory = saveDirectory + "/" + prevHBid.getBidName()
							+ "/" + obsUtility.getMonth(1) + "/";
				} else {
					logger.info("processBidHistoryUpdate()#path does not created saveDirectory :"
							+ saveDirectory);
				}
				List<MultipartFile> umfFiles = uploadFrm.getUmfFiles();
				List<String> fileNames = new ArrayList<String>();
				System.out.println("[ processBidHistoryUpdate()# Files :"
						+ umfFiles + ",fileNames :" + fileNames + " ]"
						+ " and uploadFrm: " + uploadFrm);
				logger.info("[ processBidHistoryUpdate()# Files :" + umfFiles
						+ ",fileNames :" + fileNames + " ]"
						+ " and uploadFrm: " + uploadFrm);

				if (null != umfFiles && umfFiles.size() > 0) {
					for (MultipartFile multipartFile : umfFiles) {

						String fileName = multipartFile.getOriginalFilename();

						logger.info("processBidHistoryUpdate()#--1-->fileName :"
								+ fileName);
						if (!fileName.equals("")) {

							if (!"".equalsIgnoreCase(fileName)) {
								// InputStream inputStream = null;
								// inputStream=multipartFile.getInputStream();
								byte[] aFileBytes = multipartFile.getBytes();
								// Handle file content -
								// multipartFile.getInputStream()
								multipartFile.transferTo(new File(saveDirectory
										+ fileName));
								fileNames.add(fileName);
								logger.info("processBidHistoryUpdate()#--2-->fileName :"
										+ fileName);
								// ------------------ReadFile-----------
								String line = "";
								File f1 = new File(saveDirectory + fileName);
								String ext = FilenameUtils
										.getExtension(saveDirectory + fileName);
								System.out
										.println("processBidHistoryUpdate()#File extension is :"
												+ ext
												+ " ,fileName :"
												+ fileName);
								logger.info("processBidHistoryUpdate()#File extension is :"
										+ ext + " ,fileName :" + fileName);
								if (ext.equals("jpg") || ext.equals("png")
										|| ext.equals("pdf")||ext.equals("docx")||ext.equals("doc")||ext.equals("jpeg")||ext.equals("txt")||ext.equals("xls")||ext.equals("xlsx")) {
									if (f1.exists()) {

										logger.info("processBidHistoryUpdate()#Uploaded the Message file:"
												+ saveDirectory + fileName);
										logger.info("processBidHistoryUpdate()#Uploaded file aFileBytes :"
												+ aFileBytes);
										hUserBid.setUserBidAttachmentName(fileName);
										hUserBid.setUserAttachmentData(aFileBytes);
										logger.info("processBidHistoryUpdate()# userBidAttachmentName :"
												+ fileName
												+ " prev BidName :"
												+ prevHBid.getBidName()
												+ ",prev BidId :"
												+ prevHBid.getBidId());

										if (obsDao.updateBid(prevHBid)
												&& obsDao
														.createUserBids(hUserBid)) {
											retstr = "Bid : "
													+ prevHBid.getBidName()
													+ " applied successfully..!!";
											logger.info("processBidHistoryUpdate()#user "
													+ prevHBid.getBidId()
													+ " bid status changed to apply successfully # userBidAttachmentName :"
													+ fileName
													+ " prev BidName :"
													+ prevHBid.getBidName()
													+ ",prev BidId :"
													+ prevHBid.getBidId());
										} else {
											retstr = prevHBid.getBidName()
													+ " Apply is fail.Please try later..!!";
										}

										logger.info(retstr);

									}// End if (f1.exists())
								} else {

									logger.info("processBidHistoryUpdate()#Please upload valid jpg,png File format ,This is custom ERROR message");
									throw new CustomGenericException("E888",
											"Please upload valid csv,txt  File format ,This is custom ERROR message");
								}

								// -----------------End ReadFile--------
							}
						} else {

							hUserBid.setUserBidAttachmentName(null);
							hUserBid.setUserAttachmentData(null);
							if (obsDao.updateBid(prevHBid)
									&& obsDao.createUserBids(hUserBid)) {
								retstr = "Bid : " + prevHBid.getBidName()
										+ " applied successfully..!!";
								logger.info("processBidHistoryUpdate()#user "
										+ prevHBid.getBidId()
										+ " bid status changed to apply successfully without userBidAttachmentName");
							} else {
								retstr = prevHBid.getBidName()
										+ " Apply is fail.Please try later..!!";
							}

							logger.info(retstr);
						}

					}// End of loop
				}

				// ----------------[ End of file Upload ]----------
				// *******************13-Aug2016 FILE
				// UPLOAD**********************************
				/*
				 * if (obsDao.updateBid(prevHBid) &&
				 * obsDao.createUserBids(hUserBid)) {
				 * 
				 * retstr = prevHBid.getBidName() + " updated successfully";
				 * logger.info("processBidHistoryUpdate()#user " +
				 * prevHBid.getBidId() + " updated successfully"); } else {
				 * retstr = prevHBid.getBidName() +
				 * " updation is fail.Please try later..!!"; }
				 * logger.info(retstr);
				 */
			} else {
				System.out.println(retstr);
				logger.info(retstr);
			}
			if (prevHBid.getBidName() != null) {
				model.addAttribute("submitFormResult", retstr);
			}
		} catch (Exception ex) {
			logger.info("processBidHistoryUpdate()#This is custom ERROR message.Please try later..!! ,Exception :"
					+ ex);
			throw new CustomGenericException("E888",
					"This is custom ERROR message.Please try later..!!");
		}
		return new ModelAndView("updateBidHistory", model);
	}
	@RequestMapping(value = "/downloadUserBidPDF")
	public void downloadUserBidPDF(HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam("reportId") int reportId,
			@RequestParam("userId") String userId,
			@ModelAttribute("bidListt") HBid hBid			
			)
			throws IOException {
		
		//logger.info("All Values are : reportId " + reportId + ", userId:" + userId+" and list size is"+hBidForm.getBidLists());						
		
/*		HUser hUser = obsDao.getHUser(userId);

		List<HBid> bidListOnBasisOfUserId = obsDao
		       .getBidListOnBasisOfUserId(hUser);

		Map<String, Double> userbidPriceMap = obsDao
		       .getUserbidPriceListOnBasisOfBidId(bidListOnBasisOfUserId,
				     hUser);
		Map<String, String> userbidCommentMap = obsDao
		       .getUserbidCommentListOnBasisOfBidId(bidListOnBasisOfUserId,
				     hUser);
		Map<String, String> userBidAttachmentMap = obsDao
		       .getUserbidAttachmentListOnBasisOfBidId(
				     bidListOnBasisOfUserId, hUser);
*/
		
		/*final ServletContext servletContext = request.getSession()
				.getServletContext();
		final File tempDirectory = (File) servletContext
				.getAttribute("javax.servlet.context.tempdir");
		final String temperotyFilePath = tempDirectory.getAbsolutePath();
		String fileName = "";

		if (reportId == 3) {
			fileName = "UserBidDetails.pdf";
		}

		response.setContentType("application/pdf");
		response.setHeader("Content-disposition", "attachment; filename="
				+ fileName);
		try {
			DownloadPdfUtility.createUserBidPDF(temperotyFilePath + "\\"
					+ fileName, hBidList, reportId, userId, bidStatusMap,
					userBidPriceMap,userBidAttachmentMap);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			baos = convertPDFToByteArrayOutputStream(temperotyFilePath + "\\"
					+ fileName);
			OutputStream os = response.getOutputStream();
			baos.writeTo(os);
			os.flush();
		} catch (Exception e1) {
			e1.printStackTrace();
		}*/

	}

	@RequestMapping(value = "/downloadPDF")
	public void downloadPDF(HttpServletRequest request,
			HttpServletResponse response, @RequestParam("reportId") int reportId)
			throws IOException {

		final ServletContext servletContext = request.getSession()
				.getServletContext();
		final File tempDirectory = (File) servletContext
				.getAttribute("javax.servlet.context.tempdir");
		final String temperotyFilePath = tempDirectory.getAbsolutePath();
		String fileName = "";
		List<HBid> hBidDetails = null;
		if (reportId == 1) {
			fileName = "AllBidDetails.pdf";
			hBidDetails = obsDao.getAllBids();
		} else if (reportId == 2) {
			fileName = "OpenBidDetails.pdf";
			hBidDetails = obsDao.getAllOpenBids();
		}

		response.setContentType("application/pdf");
		response.setHeader("Content-disposition", "attachment; filename="
				+ fileName);
		try {
			DownloadPdfUtility.createPDF(temperotyFilePath + "\\" + fileName,
					hBidDetails, reportId);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			baos = convertPDFToByteArrayOutputStream(temperotyFilePath + "\\"
					+ fileName);
			OutputStream os = response.getOutputStream();
			baos.writeTo(os);
			os.flush();
		} catch (Exception e1) {
			e1.printStackTrace();
		}

	}

	private ByteArrayOutputStream convertPDFToByteArrayOutputStream(
			String fileName) {

		InputStream inputStream = null;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			inputStream = new FileInputStream(fileName);
			byte[] buffer = new byte[1024];
			baos = new ByteArrayOutputStream();

			int bytesRead;
			while ((bytesRead = inputStream.read(buffer)) != -1) {
				baos.write(buffer, 0, bytesRead);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return baos;
	}
	// ------------End Anuwork--------
}
