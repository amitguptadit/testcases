/*
 * @author amit.gupta2
 *
 */
package com.vtl.obs.dao;

import com.vtl.obs.beans.User;

public interface UserDao {

	public boolean isValidUser(User user);

}
