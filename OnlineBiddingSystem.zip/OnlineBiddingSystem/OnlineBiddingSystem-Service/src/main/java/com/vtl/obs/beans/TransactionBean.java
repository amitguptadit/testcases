package com.vtl.obs.beans;

import java.util.Date;

public class TransactionBean {
	String msisdn;
	String fromdatepicker;
	String serviceType;
	String todatepicker;
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getFromdatepicker() {
		return fromdatepicker;
	}
	public void setFromdatepicker(String fromdatepicker) {
		this.fromdatepicker = fromdatepicker;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getTodatepicker() {
		return todatepicker;
	}
	public void setTodatepicker(String todatepicker) {
		this.todatepicker = todatepicker;
	}




}