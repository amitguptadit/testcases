package com.vtl.obs.beans;

public class TransactionResultBean {
	int transId;
	String time;
	String msisdn;
	String callCharge;
	String serviceType;
	String serviceName;
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getCallCharge() {
		return callCharge;
	}
	public void setCallCharge(String callCharge) {
		this.callCharge = callCharge;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}


}
