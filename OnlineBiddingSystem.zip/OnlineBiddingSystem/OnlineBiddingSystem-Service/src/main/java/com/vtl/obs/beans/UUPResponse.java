/*
 @mit gupta
 */
package com.vtl.obs.beans;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("InventoryProfile")
public class UUPResponse {

	@XStreamAlias("MSISDN")
	private String msisdn;

	@XStreamAlias("CIRCLE")
	private String circle;

	@XStreamAlias("IMSI")
	private String imsi;

	@XStreamAlias("INIdentifier")
	private String inIdentifier;

	@XStreamAlias("ResultCode")
	private String resultCode;

	@XStreamAlias("ResultDescription")
	private String resultDescription;

	@Override
	public String toString() {
		return "UUPResponse [ msisdn=" + msisdn + ", imsi=" + imsi
				+ ", circle=" + circle + ", inIdentifier=" + inIdentifier
				+ ", resultCode=" + resultCode + ", resultDescription="
				+ resultDescription + "]";
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getCircle() {
		return circle;
	}

	public void setCircle(String circle) {
		this.circle = circle;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public String getInIdentifier() {
		return inIdentifier;
	}

	public void setInIdentifier(String inIdentifier) {
		this.inIdentifier = inIdentifier;
	}

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public String getResultDescription() {
		return resultDescription;
	}

	public void setResultDescription(String resultDescription) {
		this.resultDescription = resultDescription;
	}

}
