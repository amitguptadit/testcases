package com.vtl.obs.beans;

import java.util.HashMap;

public class ReloadValidation
{

	private HashMap<String,Integer> validRequestMap=new HashMap<String, Integer>();

	public HashMap<String, Integer> getValidRequestMap() {
		return validRequestMap;
	}

	public void setValidRequestMap(HashMap<String, Integer> validRequestMap) {
		this.validRequestMap = validRequestMap;
	}


}
