package com.vtl.obs.services;


public interface IOBS
{
	public String sendMessage(String msisdn ,String msgContent);
	
	public String uploadFilePath();
	public String getVendorPassword();
	public String getSmsServiceURL();
	
}
