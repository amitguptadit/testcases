package com.vtl.obs.beans;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class UmfFileUpload {
	private List<MultipartFile> umfFiles;

	public List<MultipartFile> getUmfFiles() {
		return umfFiles;
	}
	public void setUmfFiles(List<MultipartFile> umfFiles) {
		this.umfFiles = umfFiles;
	}

}
