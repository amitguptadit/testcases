package com.iag.application.error;

public class MessageConstants {
	
	 public static final String PASSENGER_ERROR = "passenger.error.";
	

}
