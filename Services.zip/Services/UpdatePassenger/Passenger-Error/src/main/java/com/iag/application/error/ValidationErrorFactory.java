package com.iag.application.error;

import org.apache.commons.lang3.StringUtils;

import com.iag.application.exception.ServiceException;
import com.iag.application.exception.ValidationServiceException;

/**
 * Transformer to transform Validation exception to validation error. This class is purposefully made package private as
 * its scope is within the package. Client using the error framework should not be aware of this low level
 * implementation.
 * @author n438106
 */
final class ValidationErrorFactory implements AbstractErrorFactory {
  //private static final String DEVELOPER_LINK_KEY = "msg-message-business-developer_link";
  private static final String BUSINESS_MESSAGE_KEY = ".business_message";
  private static final String DEVELOPER_LINK_KEY = ".developer_link";
  
  
  

  @Override
  public ServiceError createError(final ServiceException exception, final ContentProvider contentProvider,
      final String namespace) {
    ValidationServiceException validationServiceException = (ValidationServiceException) exception;
    ValidationError validationError =
        createValidationError(exception, contentProvider, namespace);
    if (validationServiceException.getValidationExceptions() != null) {
      for (ValidationServiceException childValidationServiceException : validationServiceException
          .getValidationExceptions()) {
        ValidationError childValidationError =
            createValidationError(childValidationServiceException, contentProvider, namespace);
        validationError.addValidationError(childValidationError);
      }
    }
    return validationError;
  }

  private ValidationError createValidationError(final ServiceException exception,
      final ContentProvider contentProvider,
      final String namespace) {
    ValidationServiceException validationServiceException = (ValidationServiceException) exception;
    ValidationError validationError =
        new ValidationError(validationServiceException.getCode());
    validationError.setPath(validationServiceException.getPath());
    validationError.setBusinessMessage(contentProvider.getContent(MessageConstants.PASSENGER_ERROR
        + StringUtils.trimToEmpty(namespace) + validationServiceException.getCode() + BUSINESS_MESSAGE_KEY));
    validationError.setDeveloperLink(contentProvider.getContent(MessageConstants.PASSENGER_ERROR+validationServiceException.getCode()+DEVELOPER_LINK_KEY));
    validationError.setDeveloperMessage(validationServiceException.getDeveloperMessage());
    return validationError;
  }

}
