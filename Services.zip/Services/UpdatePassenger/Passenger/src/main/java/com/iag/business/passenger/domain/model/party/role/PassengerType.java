package com.iag.business.passenger.domain.model.party.role;

public enum PassengerType {
    INFANT,
    CHILD,
    ADULT
}