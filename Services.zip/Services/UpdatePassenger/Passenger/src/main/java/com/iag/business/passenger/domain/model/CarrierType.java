package com.iag.business.passenger.domain.model;

/**
 * Enum class for storing types of carrier. 
 */

public enum CarrierType {

    OPERATING,
    MARKETING
    
}