package com.iag.business.passenger.domain.model.adapters;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.joda.time.ReadablePartial;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

public class JodaLocalDateTimeAdapter extends XmlAdapter<String, LocalDateTime> {

	  /*
	   * (non-Javadoc)
	   * @see javax.xml.bind.annotation.adapters.XmlAdapter#unmarshal(java.lang.Object)
	   */
	  @Override
	  public LocalDateTime unmarshal(final String date) {
	    if (date == null) {
	      return null;
	    }
	    DateTime dateTime = ISODateTimeFormat.dateParser().parseDateTime(date);
	    return new LocalDateTime(dateTime.getYear(), dateTime.getMonthOfYear(), dateTime.getDayOfMonth(), dateTime.getHourOfDay(), dateTime.getMinuteOfHour(), dateTime.getSecondOfMinute());
	  }

	  /*
	   * (non-Javadoc)
	   * @see javax.xml.bind.annotation.adapters.XmlAdapter#marshal(java.lang.Object)
	   */
	  @Override
		public String marshal(LocalDateTime localDateTime) throws Exception {
			return print(localDateTime, ISODateTimeFormat.dateTime());
		}

	 

	  private static String print(final ReadablePartial readablePartial, final DateTimeFormatter dateTimeFormatter) {
	    if (readablePartial == null) {
	      return null;
	    }
	    return dateTimeFormatter.print(readablePartial);
	  }

		}