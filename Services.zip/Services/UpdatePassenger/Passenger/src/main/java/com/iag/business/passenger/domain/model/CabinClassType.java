package com.iag.business.passenger.domain.model;

public enum CabinClassType {
	
	ECONOMY,
	PREMIUM_ECONOMY,
	BUSINESS
}