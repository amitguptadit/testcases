package com.iag.business.passenger.proxy.config.domain;

import java.util.List;

public class Configuration {
	private String resource;
	private String identifier;
	private String version;
	private String effectiveDate;
	private List<ConfigurationNamespace> configurationNamespaces;

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public List<ConfigurationNamespace> getConfigurationNamespaces() {
		return configurationNamespaces;
	}

	public void setConfigurationNamespaces(List<ConfigurationNamespace> configurationNamespaces) {
		this.configurationNamespaces = configurationNamespaces;
	}

}
