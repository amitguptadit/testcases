package com.iag.business.passenger.validation;

import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.error.MessageConstants;
import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.exception.ValidationServiceExceptionGenerator;


/**
 * BookingIdentifier Validation is used for validating booking-identifier.
 *
 */
@Component
public class BookingIdentifierValidation {
	private static final Logger logger = LoggerFactory.getLogger(BookingIdentifierValidation.class);

	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	/**
	 * @param validationServiceExceptionGenerator
	 */
	@Autowired
	public BookingIdentifierValidation(final ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * This method is used to validate bookingIdentifier
	 * 
	 * @param bookingIdentifier
	 * @return
	 */
	public ValidationServiceException validate(final String bookingIdentifier) {
		logger.info("start method:validate(), Booking-Identifier: {}", bookingIdentifier);
		ValidationServiceException bookingValidationServiceException = null;
		 Pattern bookingIdentifierMatcher = Pattern.compile(PassengerServiceConstants.BOOKINGIDENTIFER);
			if (!bookingIdentifierMatcher.matcher(bookingIdentifier).matches()) {
				bookingValidationServiceException = validationServiceExceptionGenerator.createValidationError(PassengerErrorCode.DATA_INVALID.name(),
				PassengerServiceConstants.BOOKINGIDENTIFER_PATH, MessageConstants.PASSENGER_ERROR
						+ PassengerErrorCode.DATA_INVALID.name() + PassengerServiceConstants.DEVMSG_BOOKINGIDENTIFER);
			}
		logger.info("end method:validate()");
		return bookingValidationServiceException;
		
	}

	
}
