
package com.iag.business.passenger.domain.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.joda.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.iag.business.passenger.domain.model.adapters.JodaLocalDateTimeAdapter;
import com.iag.business.passenger.domain.model.adapters.JsonJodaDateTimeDeSerializer;
import com.iag.business.passenger.domain.model.adapters.JsonJodaDateTimeSerializer;
import com.iag.business.passenger.domain.model.address.PostalAddress;
import com.iag.business.passenger.domain.model.party.role.PassengerStatus;
import com.iag.business.passenger.domain.model.utility.ToStringBuilder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "identifier",
    "carriers",
    "origin",
    "destination",
    "scheduledDepartureLocalDatetime",
    "scheduledArrivalLocalDatetime",
    "seat",
    "passengerStatus",
    "bookingClass",
    "cabinCode",
    "destinationAddress",
    "status",
    "passengerStatus",
    "eligibilities"
})
public class ItineraryItem {

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    private String identifier;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("carriers")
    private List<Carrier> carriers = new ArrayList<Carrier>();
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("origin")
    private Origin origin;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("destination")
    private Destination destination;
    /**
     * Scheduled departure local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.
     * (Required)
     * 
     */
    @XmlJavaTypeAdapter(JodaLocalDateTimeAdapter.class)
    @JsonSerialize(using = JsonJodaDateTimeSerializer.class)
    @JsonDeserialize(using = JsonJodaDateTimeDeSerializer.class)
    @JsonProperty("scheduledDepartureLocalDatetime")
    @JsonPropertyDescription("Scheduled departure local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.")
    private LocalDateTime scheduledDepartureLocalDatetime;
    /**
     * Scheduled arrival local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.
     * (Required)
     * 
     */
    @XmlJavaTypeAdapter(JodaLocalDateTimeAdapter.class)
    @JsonSerialize(using = JsonJodaDateTimeSerializer.class)
    @JsonDeserialize(using = JsonJodaDateTimeDeSerializer.class)
    @JsonProperty("scheduledArrivalLocalDatetime")
    @JsonPropertyDescription("Scheduled arrival local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.")
    private LocalDateTime scheduledArrivalLocalDatetime;
    @JsonProperty("seat")
    private Seat seat;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("passengerStatus")
    private PassengerStatus passengerStatus;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("bookingClass")
    private String bookingClass;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("cabinCode")
    private String cabinCode;
    /**
     * The postal address of the passenger.
     * (Required)
     * 
     */
    @JsonProperty("destinationAddress")
    @JsonPropertyDescription("The postal address of the passenger.")
    private PostalAddress destinationAddress;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("status")
    private ItineraryItemStatus status;
    @JsonProperty("eligibilities")
    private List<Eligibility> eligibilities = null;
    
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    public String getIdentifier() {
        return identifier;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

   
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("carriers")
    public List<Carrier> getCarriers() {
        return carriers;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("carriers")
    public void setCarriers(List<Carrier> carriers) {
        this.carriers = carriers;
    }

   
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("origin")
    public Origin getOrigin() {
        return origin;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("origin")
    public void setOrigin(Origin origin) {
        this.origin = origin;
    }

   
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("destination")
    public Destination getDestination() {
        return destination;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("destination")
    public void setDestination(Destination destination) {
        this.destination = destination;
    }

   
    /**
     * Scheduled departure local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.
     * (Required)
     * 
     */
    @JsonProperty("scheduledDepartureLocalDatetime")
    public LocalDateTime getScheduledDepartureLocalDatetime() {
        return scheduledDepartureLocalDatetime;
    }

    /**
     * Scheduled departure local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.
     * (Required)
     * 
     */
    @JsonProperty("scheduledDepartureLocalDatetime")
    public void setScheduledDepartureLocalDatetime(LocalDateTime scheduledDepartureLocalDatetime) {
        this.scheduledDepartureLocalDatetime = scheduledDepartureLocalDatetime;
    }

   
    /**
     * Scheduled arrival local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.
     * (Required)
     * 
     */
    @JsonProperty("scheduledArrivalLocalDatetime")
    public LocalDateTime getScheduledArrivalLocalDatetime() {
        return scheduledArrivalLocalDatetime;
    }

    /**
     * Scheduled arrival local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.
     * (Required)
     * 
     */
    @JsonProperty("scheduledArrivalLocalDatetime")
    public void setScheduledArrivalLocalDatetime(LocalDateTime scheduledArrivalLocalDatetime) {
        this.scheduledArrivalLocalDatetime = scheduledArrivalLocalDatetime;
    }

   
    @JsonProperty("seat")
    public Seat getSeat() {
        return seat;
    }

    @JsonProperty("seat")
    public void setSeat(Seat seat) {
        this.seat = seat;
    }

   
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("passengerStatus")
    public PassengerStatus getPassengerStatus() {
        return passengerStatus;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("passengerStatus")
    public void setPassengerStatus(PassengerStatus passengerStatus) {
        this.passengerStatus = passengerStatus;
    }

  
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("bookingClass")
    public String getBookingClass() {
        return bookingClass;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("bookingClass")
    public void setBookingClass(String bookingClass) {
        this.bookingClass = bookingClass;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("cabinCode")
    public String getCabinCode() {
        return cabinCode;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("cabinCode")
    public void setCabinCode(String cabinCode) {
        this.cabinCode = cabinCode;
    }

    /**
     * The postal address of the passenger.
     * (Required)
     * 
     */
    @JsonProperty("destinationAddress")
    public PostalAddress getDestinationAddress() {
        return destinationAddress;
    }

    /**
     * The postal address of the passenger.
     * (Required)
     * 
     */
    @JsonProperty("destinationAddress")
    public void setDestinationAddress(PostalAddress destinationAddress) {
        this.destinationAddress = destinationAddress;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("status")
    public ItineraryItemStatus getStatus() {
        return status;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("status")
    public void setStatus(ItineraryItemStatus status) {
        this.status = status;
    }

   
    @JsonProperty("eligibilities")
    public List<Eligibility> getEligibilities() {
        return eligibilities;
    }

    @JsonProperty("eligibilities")
    public void setEligibilities(List<Eligibility> eligibilities) {
        this.eligibilities = eligibilities;
    }

    
    @Override
    public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {
      return ToStringBuilder.generateToString(this);
    }


}
