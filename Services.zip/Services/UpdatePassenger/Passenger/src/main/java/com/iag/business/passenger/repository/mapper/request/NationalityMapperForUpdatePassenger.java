package com.iag.business.passenger.repository.mapper.request;

import org.springframework.stereotype.Component;

import com.amadeus.xml.ccpruq_16_6_1a.NationalityDetailsTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.NationalityTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.StatusDetailsType;
import com.amadeus.xml.ccpruq_16_6_1a.StatusType148330S;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.party.role.Passenger;
@Component
public class NationalityMapperForUpdatePassenger {

	public StatusType148330S buildCprGroupDeleteIndicatorsForNationality() {
		StatusDetailsType detailsTyp = new StatusDetailsType();
		StatusType148330S statusType148330S = new StatusType148330S();
		detailsTyp.setIndicator(PassengerServiceConstants.NATIONALITY_INDICATOR);
		detailsTyp.setAction(PassengerServiceConstants.NATIONALITY_ACTION);
		statusType148330S.setStatusInformation(detailsTyp);
		return statusType148330S;
	}
	public NationalityTypeU buildCountry(Passenger passenger) {
		NationalityTypeU nationalityTypeU = new NationalityTypeU();
		NationalityDetailsTypeU nationalityDetailsTypeU = new NationalityDetailsTypeU();
		nationalityTypeU.setCodeQualifier(PassengerServiceConstants.CODE_QUALIFIER);

		nationalityDetailsTypeU.setNationalityCode(passenger.getPerson().getNationality().getType());
		nationalityTypeU.setNationalityDetails(nationalityDetailsTypeU);
		return nationalityTypeU;
	}

}
