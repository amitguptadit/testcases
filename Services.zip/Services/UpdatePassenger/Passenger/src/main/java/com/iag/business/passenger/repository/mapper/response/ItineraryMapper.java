package com.iag.business.passenger.repository.mapper.response;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amadeus.xml.ccprrr_17_1_1a.CodedAttributeInformationType208434C;
import com.amadeus.xml.ccprrr_17_1_1a.CompanyRoleIdentificationType;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel.AddressDetailsGroup;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel.CandidateETickets;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel.LegLevel;
import com.amadeus.xml.ccprrr_17_1_1a.FlightDetailsResponseType;
import com.amadeus.xml.ccprrr_17_1_1a.ItemReferencesAndVersionsType146132S;
import com.amadeus.xml.ccprrr_17_1_1a.SpecialRequirementsDataDetailsType;
import com.amadeus.xml.ccprrr_17_1_1a.SpecialRequirementsDetailsType198190S;
import com.amadeus.xml.ccprrr_17_1_1a.StatusDetailsType;
import com.amadeus.xml.ccprrr_17_1_1a.StatusDetailsType233068C;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.TerminalLocationType116626S;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.CabinClassType;
import com.iag.business.passenger.domain.model.Carrier;
import com.iag.business.passenger.domain.model.CarrierType;
import com.iag.business.passenger.domain.model.Destination;
import com.iag.business.passenger.domain.model.Eligibility;
import com.iag.business.passenger.domain.model.Eticket;
import com.iag.business.passenger.domain.model.Gate;
import com.iag.business.passenger.domain.model.Itinerary;
import com.iag.business.passenger.domain.model.ItineraryItem;
import com.iag.business.passenger.domain.model.ItineraryItemStatus;
import com.iag.business.passenger.domain.model.Origin;
import com.iag.business.passenger.domain.model.Seat;
import com.iag.business.passenger.domain.model.address.PostalAddress;
import com.iag.business.passenger.domain.model.address.PostalAddress.PostalAddressBuilder;
import com.iag.business.passenger.domain.model.party.role.PassengerStatus;
import com.iag.business.passenger.proxy.config.ServiceProxy;

/**
 * This class is used to map Itinerary of Passenger form amadeus Response to domain object.
 *
 */
/**
 * @author n485121
 *
 */
@Component
public class ItineraryMapper {

	

	@Autowired
	private ServiceProxy configurationInfrastructureServiceProxy;

	private static final Logger logger = LoggerFactory.getLogger(ItineraryMapper.class);

	public Itinerary buildItineraryItems(List<ProductLevel> productLevelList) {
		logger.info("method start: buildItineraryItems(), productLevelList: {}", productLevelList.size());
		String eTicket = StringUtils.EMPTY;
		String originIdentifier = StringUtils.EMPTY;
		String originGateNumber = StringUtils.EMPTY;
		String originTerminal = StringUtils.EMPTY;
		String destinationIdentifier = StringUtils.EMPTY;
		String destinationTerminal = StringUtils.EMPTY;
		Itinerary itinerary = null;
		PassengerStatus passengerStatus = null;
		ItineraryItemStatus flightStatus = null;
		ItineraryItem itineraryItem = null;
		Seat seat = null;
		List<ItineraryItem> itineraryItems = new ArrayList<ItineraryItem>();
		for (ProductLevel productLevel : productLevelList) {
			itineraryItem = new ItineraryItem();
			List<Carrier> carriers = new ArrayList<>();
			List<CandidateETickets> candidateETickets = productLevel.getCandidateETickets();
			for (CandidateETickets candidateETicket : candidateETickets) {
				eTicket = candidateETicket.getTicketInfo().getDocumentDetails().getNumber();///
			}
			
			List<ItemReferencesAndVersionsType146132S> productIdentifiers = productLevel.getProductIdentifiers();
			for (ItemReferencesAndVersionsType146132S itemReferencesAndVersionsType : productIdentifiers) {
				itineraryItem.setIdentifier(itemReferencesAndVersionsType.getIdSection().getPrimeId());/// identifier
			}
			// Operating Carrier
			if (productLevel.getOperatingFlightDetails() != null) {
				populateOperatingCarrierDetails(productLevel.getOperatingFlightDetails(), carriers);
				originIdentifier = productLevel.getOperatingFlightDetails().getBoardPoint();
				destinationIdentifier = productLevel.getOperatingFlightDetails().getOffPoint();
			}
			// Marketing Carrier
			if (productLevel.getMarketingFlightInfo() != null
					&& productLevel.getMarketingFlightInfo().getCodeshareDetails() != null) {
				populateMarketingCarrierDetails(productLevel.getMarketingFlightInfo().getCodeshareDetails(), carriers);
			}

			List<TerminalLocationType116626S> departureGate = productLevel.getDepartureGate();
			for (TerminalLocationType116626S terminalLocationType : departureGate) {
				if (null != terminalLocationType.getFacilityDetails())
					originGateNumber = terminalLocationType.getFacilityDetails().getIdentifier();///
			}

			List<LegLevel> legLevelList = productLevel.getLegLevel();
			for (LegLevel legLevel : legLevelList) {
				if (legLevel.getAdditionalProductDetails() != null) {
					if (StringUtils.isNotEmpty(
									legLevel.getAdditionalProductDetails().getDepartureStationInfo().getTerminal())) {
						originTerminal = legLevel.getAdditionalProductDetails().getDepartureStationInfo().getTerminal();///
					}
					if (StringUtils.isNotEmpty(legLevel.getAdditionalProductDetails().getArrivalStationInfo().getTerminal())) {
						destinationTerminal = legLevel.getAdditionalProductDetails().getArrivalStationInfo()
								.getTerminal();///
					}
				}
				itineraryItem = getScheduleDepartureAndArrivalTime(legLevel.getLegTimes(), itineraryItem);

				for (SpecialRequirementsDetailsType198190S SpecialRequirementsDetails : legLevel.getSeatInfo()) {
					List<SpecialRequirementsDataDetailsType> seatDetails = SpecialRequirementsDetails.getSeatDetails();
					for (SpecialRequirementsDataDetailsType specialRequirementsDataDetailsType : seatDetails) {
						seat = new Seat();
						seat.setNumber(specialRequirementsDataDetailsType.getSeatNumber());///
						itineraryItem.setSeat(seat);
					}
				}
				itineraryItem.setPassengerStatus(populatePassengerStatus(passengerStatus, productLevel, legLevel));
			}

			if (null != productLevel.getBookedCabinCode().getCabinDetails()) {
				itineraryItem.setBookingClass(productLevel.getBookedCabinCode().getCabinDetails().getBookingClass());

				String cabinClass = productLevel.getBookedCabinCode().getCabinDetails().getClassDesignator();

				populateCabinClass(cabinClass, itineraryItem);

			}
			itineraryItem.setStatus(getFlightStatus(flightStatus, productLevel));

			if (!CollectionUtils.isEmpty(productLevel.getAddressDetailsGroup())) {
				itineraryItem.setDestinationAddress(populateDestinationAddress(productLevel.getAddressDetailsGroup()));
			}
			
			if (productLevel.getRegProductStatus() != null) {
				populateEligibilities(productLevel.getRegProductStatus().getStatusInformation(), itineraryItem);
			}
				
			Origin origin = new Origin();
			origin.setIdentifier(originIdentifier);
			origin.setTerminal(originTerminal);
			if (StringUtils.isNotEmpty(originGateNumber)) {
				Gate gate = new Gate();
				gate.setNumber(originGateNumber);
				origin.setGate(gate);
			}
			Destination destination = new Destination();
			destination.setIdentifier(destinationIdentifier);
			destination.setTerminal(destinationTerminal);

			itineraryItem.setCarriers(carriers);
			itineraryItem.setOrigin(origin);
			itineraryItem.setDestination(destination);
			
			itineraryItems.add(itineraryItem);
		}
		itinerary = new Itinerary();
		Eticket eticket = new Eticket();
		eticket.setIdentifier(eTicket);
		itinerary.setEticket(eticket);
		itinerary.setItineraryItems(itineraryItems);
		return itinerary;
	}
	
	
	private void populateEligibilities(List<StatusDetailsType> statusInformationList, ItineraryItem itineraryItem){
		List<Eligibility> eligibilitiesList = new ArrayList<>();
		for (StatusDetailsType statusDetailsType : statusInformationList) {
			String indicator = statusDetailsType.getIndicator();
			String action = statusDetailsType.getAction();
			if (StringUtils.isNotEmpty(indicator) && StringUtils.isNotEmpty(action)) {
				Eligibility eligibility = new Eligibility();
				String actionDescription = configurationInfrastructureServiceProxy.retrieveConfiguration(
						PassengerServiceConstants.PASSENGER_ELIGIBILITIES_NAMESPACE, indicator + PassengerServiceConstants.UNDERSCORE + action);
				eligibility.setCode(indicator);
				if(actionDescription != null){
				  eligibility.setDescription(actionDescription);
				}else{
					eligibility.setDescription(action);
				}
				eligibilitiesList.add(eligibility);
			}
		}
		itineraryItem.setEligibilities(eligibilitiesList);
	}
		
	
	private void populateCabinClass(String cabinClass, ItineraryItem itineraryItem) {
		if (listContain(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE, PassengerServiceConstants.PASSENGER_CABIN_CLASS_ECONOMY),
				cabinClass)) {
			itineraryItem.setCabinCode(CabinClassType.ECONOMY.name());
		} else if (listContain(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerServiceConstants.PASSENGER_CABIN_CLASS_PREMIUM_ECONOMY), cabinClass)) {
			itineraryItem.setCabinCode(CabinClassType.PREMIUM_ECONOMY.name());
		} else if (listContain(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE, PassengerServiceConstants.PASSENGER_CABIN_CLASS_BUSINESS),
				cabinClass)) {
			itineraryItem.setCabinCode(CabinClassType.BUSINESS.name());
		}

	}

	private boolean listContain(String cabinClassList, String cabinCode) {
		boolean hasContain = false;
		if (cabinClassList != null) {
			List<String> stringList = Arrays.asList(cabinClassList.split("\\s*,\\s*"));
			if (stringList.contains(cabinCode)) {
				hasContain = true;
			}
		}
		return hasContain;
	}

	/**
	 * This method is used to populate Destination Address
	 * 
	 * @param addressDetailsGroupList
	 * @return
	 */
	private PostalAddress populateDestinationAddress(List<AddressDetailsGroup> addressDetailsGroupList) {
		String countryCode = null;
		String[] addressLines = {};
		String cityCode = null;
		String postalCode = null;
		PostalAddress postalAddress = null;
		for (AddressDetailsGroup addressDetailsGroup : addressDetailsGroupList) {
			if (addressDetailsGroup.getAddressQualifier().getLocationType()
					.equals(PassengerServiceConstants.ADDRESS_QUALIFIER)) {
				addressLines = addressDetailsGroup.getAddressDetails().getTravelerAddress().getStreet().split(" ");
				cityCode = addressDetailsGroup.getAddressDetails().getTravelerCity();
				postalCode = addressDetailsGroup.getAddressDetails().getTravelerPostcode();
				countryCode = addressDetailsGroup.getAddressDetails().getTravelerCountryCode();
				PostalAddress.PostalAddressBuilder postalAddressBuilder = new PostalAddressBuilder(addressLines,
						countryCode);
				postalAddressBuilder.setPostalCode(postalCode);
				postalAddressBuilder.setCity(cityCode);
				postalAddress = postalAddressBuilder.build();
			}

		}
		return postalAddress;

	}

	/**
	 * This method is used to populate Schedule Departure And Arrival Time
	 * 
	 * @param legTimes
	 * @param itineraryItem
	 * @return
	 */
	private ItineraryItem getScheduleDepartureAndArrivalTime(List<StructuredDateTimeInformationType> legTimes,
			ItineraryItem itineraryItem) {
		for (StructuredDateTimeInformationType structuredDateTimeInformationType : legTimes) {
			if (structuredDateTimeInformationType.getDateTime() != null) {
				if (structuredDateTimeInformationType.getBusinessSemantic()
						.equals(PassengerServiceConstants.FLIGHT_LEG_DEPARTURE_STD)) {
					LocalDateTime scheduledDepartureLocalDatetime = new LocalDateTime(
							Integer.parseInt(structuredDateTimeInformationType.getDateTime().getYear()),
							Integer.parseInt(structuredDateTimeInformationType.getDateTime().getMonth()),
							Integer.parseInt(structuredDateTimeInformationType.getDateTime().getDay()),
							Integer.parseInt(structuredDateTimeInformationType.getDateTime().getHour()),
							Integer.parseInt(structuredDateTimeInformationType.getDateTime().getMinutes()),
							structuredDateTimeInformationType.getDateTime().getSeconds().intValue());
					itineraryItem.setScheduledDepartureLocalDatetime(scheduledDepartureLocalDatetime);

				}
				if (structuredDateTimeInformationType.getBusinessSemantic()
						.equals(PassengerServiceConstants.FLIGHT_LEG_ARRIVAL_STA)) {
					LocalDateTime scheduledArrivalLocalDatetime = new LocalDateTime(
							Integer.parseInt(structuredDateTimeInformationType.getDateTime().getYear()),
							Integer.parseInt(structuredDateTimeInformationType.getDateTime().getMonth()),
							Integer.parseInt(structuredDateTimeInformationType.getDateTime().getDay()),
							Integer.parseInt(structuredDateTimeInformationType.getDateTime().getHour()),
							Integer.parseInt(structuredDateTimeInformationType.getDateTime().getMinutes()),
							structuredDateTimeInformationType.getDateTime().getSeconds().intValue());
					itineraryItem.setScheduledArrivalLocalDatetime(scheduledArrivalLocalDatetime);
				}
			}
		}
		return itineraryItem;
	}

	/**
	 * Method is used to populate flight status
	 * 
	 * @param flightStatus
	 * @param productLevel
	 * @return
	 */
	private ItineraryItemStatus getFlightStatus(ItineraryItemStatus flightStatus, ProductLevel productLevel) {
		if (StringUtils.isNotEmpty(productLevel.getBookingStatusDetails().getStatusCode())) {
			String statusCode = productLevel.getBookingStatusDetails().getStatusCode();
			if (PassengerServiceConstants.FLIGHT_SEGMENT_STATUS.contains(statusCode))
				flightStatus = ItineraryItemStatus.CONFIRMED;
			else
				flightStatus = ItineraryItemStatus.UNCONFIRMED;
		}
		return flightStatus;
	}

	/**
	 * Method is used to populate Passenger Status
	 * 
	 * @param passengerStatus
	 * @param productLevel
	 * @param legLevel
	 * @return
	 */
	private PassengerStatus populatePassengerStatus(PassengerStatus passengerStatus, ProductLevel productLevel,
			LegLevel legLevel) {
		List<CodedAttributeInformationType208434C> attributeDetailsList = productLevel.getProductLevelIndicators()
				.getAttributeDetails();
		for (CodedAttributeInformationType208434C codedAttributeInformationType : attributeDetailsList) {
			if (codedAttributeInformationType.getAttributeType().equals(PassengerServiceConstants.PPI)) {
				for (StatusDetailsType233068C statusDetailsType : legLevel.getLegLevelIndicator()
						.getStatusInformation()) {
					String indicator = statusDetailsType.getIndicator();
					if (indicator.equals(PassengerServiceConstants.CAC))
						passengerStatus = PassengerStatus.CHECKEDIN;
					else if (indicator.equals(PassengerServiceConstants.CNC))
						passengerStatus = PassengerStatus.NOTCHECKEDIN;
					else if (indicator.equals(PassengerServiceConstants.CST))
						passengerStatus = PassengerStatus.STANDBY;
				}
			}
		}
		return passengerStatus;
	}

	/**
	 * @param flightDetailsResponseType
	 * @param carriers
	 */
	private void populateOperatingCarrierDetails(FlightDetailsResponseType flightDetailsResponseType,
			List<Carrier> carriers) {
		if (StringUtils.isNotEmpty(flightDetailsResponseType.getCarrierDetails().getMarketingCarrier())) {
			Carrier operatingCarrier = new Carrier();
			operatingCarrier.setCode(flightDetailsResponseType.getCarrierDetails().getMarketingCarrier());///
			operatingCarrier.setType(CarrierType.OPERATING);
			if (flightDetailsResponseType.getFlightDetails() != null) {
				operatingCarrier.setFlightNumber(flightDetailsResponseType.getFlightDetails().getFlightNumber());/// flightno
				operatingCarrier
						.setOperationalSuffix(flightDetailsResponseType.getFlightDetails().getOperationalSuffix());/// suffix
			}
			carriers.add(operatingCarrier);
		}
	}

	/**
	 * @param companyRoleIdentificationType
	 * @param carriers
	 */
	private void populateMarketingCarrierDetails(CompanyRoleIdentificationType companyRoleIdentificationType,
			List<Carrier> carriers) {
		Carrier marketingCarrier = new Carrier();
		marketingCarrier.setCode(companyRoleIdentificationType.getAirlineDesignator());/// code
		marketingCarrier.setType(CarrierType.MARKETING);
		marketingCarrier.setFlightNumber(companyRoleIdentificationType.getFlightNumber());/// flightno
		marketingCarrier.setOperationalSuffix(companyRoleIdentificationType.getOperationalSuffix());// suffix
		carriers.add(marketingCarrier);
	}

}		
