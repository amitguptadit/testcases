package com.iag.business.passenger.repository.mapper.request;

import java.util.List;

import org.springframework.stereotype.Component;

import com.amadeus.xml.ccpruq_16_6_1a.CountrySubEntityDetailsBatchTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR.CustomerEdit.Edits.AddressDetailsGroup;
import com.amadeus.xml.ccpruq_16_6_1a.NameAndAddressBatchTypeU8146S;
import com.amadeus.xml.ccpruq_16_6_1a.PlaceLocationIdentificationTypeU8493S;
import com.amadeus.xml.ccpruq_16_6_1a.StatusDetailsType;
import com.amadeus.xml.ccpruq_16_6_1a.StatusType148330S;
import com.amadeus.xml.ccpruq_16_6_1a.StreetTypeU;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.ItineraryItem;
import com.iag.business.passenger.domain.model.party.role.Passenger;

@Component
public class HomeAndDestinationAddressMapperForUpdatePassenger {
	@SuppressWarnings("rawtypes")
	public AddressDetailsGroup buildHomeAndDestinationAddress(Passenger passenger) {
		AddressDetailsGroup addressDetailsGroup = new AddressDetailsGroup();
		NameAndAddressBatchTypeU8146S nameAndAddressBatchTypeU8146S = new NameAndAddressBatchTypeU8146S();
		nameAndAddressBatchTypeU8146S.setTraveler(PassengerServiceConstants.TRAVELER);
		List<ItineraryItem> itineraryItemList = passenger.getItinerary().getItineraryItems();
		for (ItineraryItem itineraryItem : itineraryItemList) {
			StreetTypeU streetTypeU = new StreetTypeU();
			String[] addressLineList = itineraryItem.getDestinationAddress().getAddressLines();
			String destinationAddressLine = null;
			for (String addressLine : addressLineList) {
				destinationAddressLine = addressLine;
				streetTypeU.setStreet(destinationAddressLine);
			}
			nameAndAddressBatchTypeU8146S.setTravelerAddress(streetTypeU);
			CountrySubEntityDetailsBatchTypeU countrySubEntityDetailsBatchTypeU = new CountrySubEntityDetailsBatchTypeU();
			nameAndAddressBatchTypeU8146S.setTravelerCountry(countrySubEntityDetailsBatchTypeU);
			if (itineraryItem.getDestinationAddress() != null) {
				nameAndAddressBatchTypeU8146S.setTravelerCity(itineraryItem.getDestinationAddress().getCity());
				nameAndAddressBatchTypeU8146S
						.setTravelerCountryCode(itineraryItem.getDestinationAddress().getCountry());
				nameAndAddressBatchTypeU8146S.setTravelerPostcode(itineraryItem.getDestinationAddress().getPostCode());
				if (itineraryItem.getDestinationAddress().getState() != null) {
					countrySubEntityDetailsBatchTypeU
							.setCountrySubEntityName(itineraryItem.getDestinationAddress().getState());
				}
			}
			addressDetailsGroup.setAddressDetails(nameAndAddressBatchTypeU8146S);
		}
		PlaceLocationIdentificationTypeU8493S placeLocationIdentificationTypeU8493S = new PlaceLocationIdentificationTypeU8493S();
		placeLocationIdentificationTypeU8493S.setLocationType(PassengerServiceConstants.ADDRESS_LOCATION_TYPE);

		addressDetailsGroup.setAddressType(placeLocationIdentificationTypeU8493S);
		return addressDetailsGroup;
	}

	public StatusType148330S buildCprGroupDeleteIndicatorsHomeAndDestinationAddress() {
		StatusDetailsType detailsTyp = new StatusDetailsType();
		StatusType148330S statusType148330S = new StatusType148330S();
		detailsTyp.setIndicator(PassengerServiceConstants.HOME_DESTINATION_INDICATOR);
		detailsTyp.setAction(PassengerServiceConstants.HOME_DESTINATION_ACTION);
		statusType148330S.setStatusInformation(detailsTyp);
		return statusType148330S;
	}
}
