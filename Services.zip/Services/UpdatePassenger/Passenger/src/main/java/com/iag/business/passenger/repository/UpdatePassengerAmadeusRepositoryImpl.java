package com.iag.business.passenger.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.repository.mapper.request.UpdatePassengerAmadeusRequestMapper;
import com.iag.business.passenger.session.AmadeusSession;
/**
 * This class implements methods defined in interface UpdatePassengerAmadeusRepository.
 */
@Component
public class UpdatePassengerAmadeusRepositoryImpl extends AmadeusWebServiceGatewayForUpdatePassenger implements UpdatePassengerAmadeusRepository {
	@Autowired
	UpdatePassengerAmadeusRequestMapper updatepassengerRequestMapper;
	private static final Logger logger = LoggerFactory.getLogger(UpdatePassengerAmadeusRepositoryImpl.class);
	/**
	 * This method is responsible to update Passenger information
	 * 
	 * @param BookingIdentifier
	 * @param Passenger
	 * @param session
	 */
	@Override
	public void updatePassenger(String bookingIdentifier, Passenger passenger,
			AmadeusSession session) {
		logger.info("method start in repository : updatePassenger()");
		DCSCPREditCPR dCSCPREditCPRRequest=updatepassengerRequestMapper.createRequestBodyForUpdatePassenge(bookingIdentifier,
				passenger);
		Object object=getWebServiceResponseForUpdatePassenger(dCSCPREditCPRRequest, PassengerServiceConstants.UPDATE_SOAP_URL,session);
		System.out.println("Response TEST :"+object);
		logger.info("method end in repository : updatePassenger()");
	}
}
