package com.iag.business.passenger.repository.mapper.response;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel;
import com.amadeus.xml.ccprrr_17_1_1a.ItemReferencesAndVersionsType146132S;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.Itinerary;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.party.role.AssociatedPassenger;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.domain.model.party.role.Passenger.PassengerBuilder;
import com.iag.business.passenger.domain.model.party.role.PassengerType;

/**
 * This class is used to map Passenger from Amadeus Response to Domain object.
 *
 */
@Component
public class PassengerResponseMapper {
	
	private static final Logger logger = LoggerFactory.getLogger(PassengerResponseMapper.class);

	private final EmergencyContactMapper emergencyContactMapper;

	private final PersonMapper personMapper;

	private final ItineraryMapper itineraryMapper;

	@Autowired
	public PassengerResponseMapper(final EmergencyContactMapper emergencyContactMapper, final PersonMapper personMapper,
			final ItineraryMapper itineraryMapper) {
		this.emergencyContactMapper = emergencyContactMapper;
		this.personMapper = personMapper;
		this.itineraryMapper = itineraryMapper;
	}

	/**
	 * getPassengerAmadeusResponse is used to populate Passenger domain model.
	 * @param responseBody
	 * @return
	 */
	public Passenger<String> getPassengerAmadeusResponse(DCSIDCCPRIdentificationReply passengerAmadeusReply) {
		logger.info("method start: getPassengerAmadeusResponse(), PassengerAmadeusResponse: {}", passengerAmadeusReply);
		String identifier = StringUtils.EMPTY;
		PassengerType passengerType = null;
		Person<String> person = null;
		EmergencyContact<String> emergencyContactDomain = null;
		Itinerary itinerary = null;
		Passenger<String> passenger = null;
		if (passengerAmadeusReply != null) {
			List<CustomerLevel> customerLevelList = passengerAmadeusReply.getCustomerLevel();
			if(!CollectionUtils.isEmpty(customerLevelList)){
			   CustomerLevel customerLevel = customerLevelList.get(0);
		    	identifier = customerLevel.getUniqueCustomerId().getIdSection().getPrimeId();

				if (customerLevel.getCustomerDetails().getPaxDetails() != null) {
					passengerType = getPassengerType(customerLevel.getCustomerDetails().getPaxDetails().getType(),passengerType);
				}
				person = personMapper.buildPerson(customerLevel);
				itinerary = itineraryMapper.buildItineraryItems(customerLevel.getProductLevel());

				Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(passengerType,
						person, itinerary);
				if (!CollectionUtils.isEmpty(customerLevel.getCustomerLevelEmergencyContact())) {
					emergencyContactDomain = emergencyContactMapper.buildEmergencyContact(
							customerLevel.getCustomerLevelEmergencyContact(), emergencyContactDomain);
					passengerBuilder.setEmergencyContact(emergencyContactDomain);
				}
				if (PassengerType.INFANT.equals(passengerType)) {
					AssociatedPassenger<String> associatedPassenger = new AssociatedPassenger<>();
					associatedPassenger.setIdentifier(getAssociatedPassenger(customerLevel));
					passengerBuilder.setAssociatedPassenger(associatedPassenger);
				}

				passenger = passengerBuilder.build();
				passenger.setIdentifier(identifier);
		}
	  }
		logger.info("method end: getPassengerAmadeusResponse(), PassengerDomain: {}", passenger);
		return passenger;

  }

	private String getAssociatedPassenger(CustomerLevel customerLevel) {
		String associatedPassengerIdentifier = null;
		for (ProductLevel productLevel : customerLevel.getProductLevel()) {
			List<ItemReferencesAndVersionsType146132S> productIdentifiers = productLevel
					.getProductIdentifiers();
			for (ItemReferencesAndVersionsType146132S itemReferencesAndVersionsType : productIdentifiers) {
				if (itemReferencesAndVersionsType.getIdSection().getReferenceQualifier()
						.equals(PassengerServiceConstants.ASSOCIATED_PASSENGER_QUALIFIER))
					associatedPassengerIdentifier = itemReferencesAndVersionsType.getIdSection().getPrimeId(); /// associated
			}
		}
		return associatedPassengerIdentifier;
	}

	/**
	 * getPassengerGenderType() used to get GenderType of passenger
	 * @param type
	 * @return
	 */
	private PassengerType getPassengerType(String type,PassengerType passengerType) {
		if (PassengerServiceConstants.ADULT.equals(type)) {
			passengerType = PassengerType.ADULT;
		} else if (PassengerServiceConstants.CHILD.equals(type)) {
			passengerType = PassengerType.CHILD;
		} else if (PassengerServiceConstants.INFANT.equals(type)) {
			passengerType = PassengerType.INFANT;

		}
		return passengerType;
	}

}
