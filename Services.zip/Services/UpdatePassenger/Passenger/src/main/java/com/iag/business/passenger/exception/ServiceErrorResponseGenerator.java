package com.iag.business.passenger.exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.error.ContentProvider;
import com.iag.application.error.ErrorFactory;
import com.iag.application.error.ServiceError;
import com.iag.application.exception.ServiceException;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;


/**
 * Class to generate Response Error .
 * 
 */
@Component
public class ServiceErrorResponseGenerator {

	private final com.iag.application.error.ContentProvider defaultContentProvider;

	private final ErrorFactory errorFactory;
	

	@Autowired
	public ServiceErrorResponseGenerator(final ContentProvider defaultContentProvider) {
		this.defaultContentProvider = defaultContentProvider;
		this.errorFactory = new ErrorFactory();

	}

	/**
	 * Method to generate ServiceError from serviceException.
	 * 
	 * @param serviceException
	 * @return
	 */
	public ServiceError createServiceError(final ServiceException serviceException) {
		return errorFactory.createError(serviceException, defaultContentProvider);
	}

	/**
	 * Method to retrieve http status code for an service exception.
	 * 
	 * @param serviceException
	 * @return
	 */
	public String getStatusCode(final ServiceException serviceException) {
		if (serviceException.getCode().equalsIgnoreCase(PassengerErrorCode.SYSTEM_UNAVAILABLE.name())) {
			serviceException.setOptionalNamespace(PassengerServiceConstants.NAMESPACE);
		}
		return errorFactory.getStatusCode(serviceException, defaultContentProvider);
	}

}
