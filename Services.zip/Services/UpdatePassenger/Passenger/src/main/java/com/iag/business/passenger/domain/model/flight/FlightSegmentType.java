package com.iag.business.passenger.domain.model.flight;

public enum FlightSegmentType {

    INBOUND,
    OUTBOUND,
    ONWARD,
    RETURN
}
