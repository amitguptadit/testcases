package com.iag.business.passenger.domain.model.utility;

import java.lang.reflect.Field;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


/**
 * Custom toString style. Will produce a style like BrandProfile{brand='AM', tier='tier', channel=WEB}.
 */
public final class ToStringBuilder {

  /**
   * Common string used to represent null values.
   */
  public static final String NULL = "NULL";

  @SuppressWarnings("serial")
  private static final class Style extends ToStringStyle {
    /**
     * Set the default properties. Private as there is no reason for anyone else
     * to construct one.
     */
    private Style() {
      setNullText(NULL);
      setUseIdentityHashCode(false);
      setUseShortClassName(true);
      setContentStart("{");
      setContentEnd("}");
      setFieldSeparator(", ");
      setArraySeparator(", ");
      setArrayStart("[");
      setArrayEnd("]");
    }
  }
  
  
  private static final class Reflection extends ReflectionToStringBuilder {
    private static final ToStringStyle TO_STRING_STYLE = new Style();

    private Reflection(final Object object) {
      super(object, TO_STRING_STYLE);
    }

    @Override
    protected boolean accept(final Field field) {
      return !field.isAnnotationPresent(NoToString.class) && super.accept(field);
    }
  }

  private ToStringBuilder() {
    // No construction allowed
  }

  /**
   * Generate the toString representation of an object,
   * ignoring certain fields marked with {@link NoToString @NoToString}.
   * @param o Object to turn into a string.
   * @return String representing the object (with some fields excluded).
   */
  public static String generateToString(final Object o) {
    return new Reflection(o).toString();
  }

}
