package com.iag.business.passenger.repository.mapper.response;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel.NationalityGroup;
import com.amadeus.xml.ccprrr_17_1_1a.NationalityTypeU8495S;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeInformationType13618S;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeType18902C;
import com.amadeus.xml.ccprrr_17_1_1a.TravellerDetailsType279779C;
import com.amadeus.xml.ccprrr_17_1_1a.TravellerSurnameInformationType279780C;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.location.LocationType;
import com.iag.business.passenger.domain.model.party.Gender;
import com.iag.business.passenger.domain.model.party.Nationality;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.party.Person.PersonBuilder;
import com.iag.business.passenger.domain.model.party.PersonName;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifier;

/**
 * This class is used to map Person from Amadeus response to domain model object.
 *
 */
@Component
public class PersonMapper {

	private static final Logger logger = LoggerFactory.getLogger(PersonMapper.class);

	private final PersonNameMapper personNameMapper;

	private final RegisteredIdentifiersMapper registeredIdentifiersMapper;

	@Autowired
	public PersonMapper(final PersonNameMapper personNameMapper,
			final RegisteredIdentifiersMapper registeredIdentifiersMapper) {
		this.personNameMapper = personNameMapper;
		this.registeredIdentifiersMapper = registeredIdentifiersMapper;
	}

	public Person<String> buildPerson(CustomerLevel customerLevel) {
		logger.info("method start: buildPerson(), customerLevel: {}", customerLevel.toString());
		String givenName = null;
		String title = null;
		String surname = null;
		String gender = null;
		PersonName personName = null;
		if (customerLevel.getCustomerDetails() != null) {
			TravellerSurnameInformationType279780C travellerSurnameInformation = customerLevel.getCustomerDetails()
					.getPaxDetails();
			List<TravellerDetailsType279779C> travellerDetailsTypeList = customerLevel.getCustomerDetails()
					.getOtherPaxDetails();
			givenName = travellerDetailsTypeList.get(0).getGivenName();
			title = travellerDetailsTypeList.get(0).getTitle();
			surname = travellerSurnameInformation.getSurname();
			personName = personNameMapper.buildPersonName(givenName,surname,title);			
			gender = travellerSurnameInformation.getGender();///
		}

		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(personName);

		if (StringUtils.isNotEmpty(gender)) {
			personGenderType(gender, personBuilder);
		}

		if (null != customerLevel.getDateOfBirth()) {
			StructuredDateTimeInformationType13618S dateOfBirth = customerLevel.getDateOfBirth();
			// timeMode = dateOfBirth.getTimeMode();
			StructuredDateTimeType18902C dateTime = dateOfBirth.getDateTime();
			LocalDate localDate = new LocalDate(Integer.parseInt(dateTime.getYear()),
					Integer.parseInt(dateTime.getMonth()), Integer.parseInt(dateTime.getDay()));
			personBuilder.setDateOfBirth(localDate);
		}

		populatePersonNationality(customerLevel.getProductLevel(), personBuilder);
		// Registered Identifiers
		if (!CollectionUtils.isEmpty(customerLevel.getCustomerLevelRegDocs())) {
			List<RegisteredIdentifier<?>> registeredIdentifierList = registeredIdentifiersMapper
					.buildRegisteredIdentifiers(customerLevel.getCustomerLevelRegDocs());
			personBuilder.setRegisteredIdentifier(registeredIdentifierList);
		}
		Person<String> person = personBuilder.build();
		return person;
	}

	/**
	 * personGenderType() is used to retrieve Gender
	 * 
	 * @param gender
	 * @param personBuilder
	 */
	private void personGenderType(String gender, Person.PersonBuilder<String> personBuilder) {
		if (gender.equals(PassengerServiceConstants.MALE))
			personBuilder.setGender(Gender.MALE);
		else if (gender.equals(PassengerServiceConstants.FEMALE))
			personBuilder.setGender(Gender.FEMALE);
	}

	/**
	 * populatePersonNationality():method to populate Nationality of Person
	 * 
	 * @param productLevelList
	 * @return
	 */
	private void populatePersonNationality(List<ProductLevel> productLevelList,
			Person.PersonBuilder<String> personBuilder) {
		for (ProductLevel ProductLevel : productLevelList) {
			if (null != ProductLevel.getNationalityGroup()) {
				Nationality nationality = new Nationality();
				NationalityGroup nationalityGroup = ProductLevel.getNationalityGroup();
				NationalityTypeU8495S nationalityType = nationalityGroup.getNationality();
				nationality.setType(LocationType.COUNTRY.name());///
				nationality.setIdentifier(nationalityType.getNationalityDetails().getNationalityCode());
				personBuilder.setNationality(nationality);
			}
		}

	}

}
