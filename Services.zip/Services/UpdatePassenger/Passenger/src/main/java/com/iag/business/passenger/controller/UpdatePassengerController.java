package com.iag.business.passenger.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.service.UpdatePassengerService;
import com.iag.business.passenger.session.AmadeusSession;
import com.iag.business.passenger.validation.UpdatePassengerValidator;

/**
 * UpdatePassengerController provides interface for passenger related update
 * operations like title, name, country of residence.
 */
@RestController
public class UpdatePassengerController {
	private static final Logger logger = LoggerFactory.getLogger(UpdatePassengerController.class);

	private UpdatePassengerService updatePassengerService;

	private UpdatePassengerValidator updatePassengerValidator;

	private AmadeusSession amadeusSession;

	@Autowired
	public UpdatePassengerController(UpdatePassengerService updatePassengerService, UpdatePassengerValidator updatePassengerValidator,
			AmadeusSession amadeusSession) {
		this.updatePassengerService = updatePassengerService;
		this.updatePassengerValidator = updatePassengerValidator;
		this.amadeusSession = amadeusSession;
	}

	/**
	 * This method is responsible to post a Passenger updated information and
	 * post on the basis of booking and Passenger information.
	 * 
	 * @param PassengerId
	 * @param BookingIdentifier
	 * @param Passenger
	 * @param requestHeaderMap
	 */
	// TODO : populate session object with Header map values
	
	@PostMapping(value = "/bookings/{" + PassengerServiceConstants.BOOKING_IDENTIFIER + "}" + "/passengers" + "/{"
			+ PassengerServiceConstants.PASSENGER_IDENTIFIER + "}",consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updatePassenger(@PathVariable(value = "booking-identifier") String bookingIdentifier,
			@PathVariable(value = "passenger-identifier") String passengerIdentifier, @RequestBody Passenger<String> passenger,
			@RequestHeader final Map<String, String> headerValueMap) throws Exception {
		logger.info("method start: updatePassenger(), Booking-Identifier: {}, Passenger_Identifier: {}",
				bookingIdentifier, passengerIdentifier);
		updatePassengerValidator.validate(bookingIdentifier, passengerIdentifier, passenger,headerValueMap);
		passenger.setIdentifier(passengerIdentifier);
		amadeusSession = populateHeader(headerValueMap);	
		updatePassengerService.updatePassenger(bookingIdentifier, passenger, amadeusSession);
		logger.info("method End: updatePassenger()");
		return new ResponseEntity<>(HttpStatus.OK);

	}

	/**
	 * populateHeader method used to populate amadeaus session from header
	 * 
	 * @param headerValueMap
	 * @return
	 */
	private AmadeusSession populateHeader(final Map<String, String> headerValueMap) {
		amadeusSession.setSessionId(headerValueMap.get(PassengerServiceConstants.SESSIONID));
		amadeusSession.setSequenceNumber(headerValueMap.get(PassengerServiceConstants.SEQUENCENUMBER));
		amadeusSession.setSecurityToken(headerValueMap.get(PassengerServiceConstants.SECURITY_TOKEN));		
		amadeusSession.setLocation(headerValueMap.get(PassengerServiceConstants.LOCATION));
		amadeusSession.setChannel(headerValueMap.get(PassengerServiceConstants.CHANNEL));
		amadeusSession.setScope(headerValueMap.get(PassengerServiceConstants.SCOPE));		
	return amadeusSession;
	}
}
