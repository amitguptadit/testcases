package com.iag.business.passenger.validation;

import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.error.MessageConstants;
import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.exception.ValidationServiceExceptionGenerator;

/**
 * BookingIdentifier Validation is used for validating booking-identifier
 *
 */

@Component
public class PassengerIdentifierValidation {
	private static final Logger logger = LoggerFactory.getLogger(PassengerIdentifierValidation.class);
	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	/**
	 * @param validationServiceExceptionGenerator
	 */
	@Autowired
	public PassengerIdentifierValidation(
			final ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * @param validationServiceExceptionList
	 * @param passengerIdentifier
	 * @return
	 */
	public ValidationServiceException validate(final String passengerIdentifier) {
		logger.info("start method:validate(), passenger-identifier: {}", passengerIdentifier);
		ValidationServiceException passengerValidationServiceException = null;
		Pattern bookingIdentifierMatcher = Pattern.compile(PassengerServiceConstants.PASSENGERIDENTIFIER);
		if (!bookingIdentifierMatcher.matcher(passengerIdentifier).matches()) {
			passengerValidationServiceException = validationServiceExceptionGenerator.createValidationError(
					PassengerErrorCode.DATA_INVALID.name(), PassengerServiceConstants.PASSENGERIDENTIFIER_PATH,
					MessageConstants.PASSENGER_ERROR + PassengerErrorCode.DATA_INVALID.name()
							+ PassengerServiceConstants.DEVMSG_PASSENGERIDENTIFER);
		}
		logger.info("end method:validate()");
		return passengerValidationServiceException;
	}

	
}
