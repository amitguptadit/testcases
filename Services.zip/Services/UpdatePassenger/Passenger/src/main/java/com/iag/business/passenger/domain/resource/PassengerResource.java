package com.iag.business.passenger.domain.resource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.ResourceSupport;
import org.springframework.util.Assert;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonUnwrapped;

public class PassengerResource<Passenger> extends ResourceSupport {

	private List<Link> links = new ArrayList<>();

	private  Passenger passenger;

	/**
	 * Creates an empty {@link Resource}.
	 */
	protected PassengerResource() {
		this.passenger = null;
	}

	@JsonProperty("_links")
	public List<Link> getLinks() {
		return links;
	}

	/**
	 * Creates a new {@link Resource} with the given content and {@link Link}s
	 * (optional).
	 * 
	 * @param content
	 *            must not be {@literal null}.
	 * @param links
	 *            the links to add to the {@link Resource}.
	 */
	public PassengerResource(Passenger passenger, Link... links) {
		this(passenger, Arrays.asList(links));
	}

	/**
	 * Creates a new {@link Resource} with the given content and {@link Link}s.
	 * 
	 * @param content
	 *            must not be {@literal null}.
	 * @param links
	 *            the links to add to the {@link Resource}.
	 */
	public PassengerResource(Passenger passenger, Iterable<Link> links) {
		Assert.notNull(passenger, "Content must not be null!");
		Assert.isTrue(!(passenger instanceof Collection), "Content must not be a collection! Use Resources instead!");
		this.passenger = passenger;
		this.add(links);
	}

	/**
	 * Adds the given link to the resource.
	 * 
	 * @param link
	 */
	public void add(Link link) {
		Assert.notNull(link, "Link must not be null!");
		this.links.add(link);
	}

	/**
	 * Returns the underlying entity.
	 * 
	 * @return the content
	 */
	@JsonUnwrapped
	public Passenger getPassenger() {
		return passenger;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.hateoas.ResourceSupport#toString()
	 */
	@Override
	public String toString() {
		return String.format("Resource { content: %s, %s }", getPassenger(), super.toString());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.hateoas.ResourceSupport#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {

		if (this == obj) {
			return true;
		}

		if (obj == null || !obj.getClass().equals(getClass())) {
			return false;
		}
		PassengerResource<?> that = (PassengerResource<?>) obj;

		boolean contentEqual = this.passenger == null ? that.passenger == null : this.passenger.equals(that.passenger);
		return contentEqual ? super.equals(obj) : false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.hateoas.ResourceSupport#hashCode()
	 */
	@Override
	public int hashCode() {
		int result = super.hashCode();
		result += passenger == null ? 0 : 17 * passenger.hashCode();
		return result;
	}

}
