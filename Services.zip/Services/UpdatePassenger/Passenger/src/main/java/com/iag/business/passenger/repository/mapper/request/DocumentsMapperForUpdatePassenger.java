package com.iag.business.passenger.repository.mapper.request;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.LocalDate;
import org.springframework.stereotype.Component;

import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR.CustomerEdit.Edits.Documents;
import com.amadeus.xml.ccpruq_16_6_1a.DateTimePeriodDetailsBatchTypeU168602C;
import com.amadeus.xml.ccpruq_16_6_1a.DateTimePeriodTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.DocumentMessageDetailsTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.DocumentMessageNameTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.DocumentMessageTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.LocationIdentificationBatchType202912C;
import com.amadeus.xml.ccpruq_16_6_1a.NameAndAddressBatchTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.PartyNameBatchTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.PlaceLocationIdentificationType139972S;
import com.amadeus.xml.ccpruq_16_6_1a.RelatedLocationOneIdentificationType;
import com.amadeus.xml.ccpruq_16_6_1a.StatusDetailsType;
import com.amadeus.xml.ccpruq_16_6_1a.StatusType148330S;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.location.Location;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifier;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifierType;
import com.iag.business.passenger.domain.model.party.role.Passenger;

@Component
public class DocumentsMapperForUpdatePassenger {
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Documents buildDocuments(Passenger passenger) {
	
		Location<String> location = new Location<>();
		LocalDate expiryDate = null;
		String token = null;
		RegisteredIdentifierType type = null;
		List<RegisteredIdentifier> registeredIdentifierList = passenger.getPerson().getRegisteredIdentifiers();
		for (RegisteredIdentifier registeredIdentifier : registeredIdentifierList) {
			expiryDate = registeredIdentifier.getExpiryDate();
			location = registeredIdentifier.getPlaceOfIssue();
			token = registeredIdentifier.getToken();
			type = registeredIdentifier.getType();
		}
		RegisteredIdentifier<String> registeredIdentifier = new RegisteredIdentifier<>(token, null, type, location,
				expiryDate, passenger.getPerson());
		Documents documents = new Documents();
		DocumentMessageTypeU documentMessageTypeU = new DocumentMessageTypeU();
		DocumentMessageNameTypeU documentMessageNameTypeU = new DocumentMessageNameTypeU();
		documentMessageNameTypeU.setDocumentCode("DEC");
		documentMessageTypeU.setIssueDetails(documentMessageNameTypeU);

		DateTimePeriodTypeU dateTimePeriodTypeU = new DateTimePeriodTypeU();
		List<DateTimePeriodDetailsBatchTypeU168602C> dateTimePeriodDetailsBatchTypeU168602CList = new ArrayList<>();
		DateTimePeriodDetailsBatchTypeU168602C dateTimePeriodDetailsBatchTypeU168602C = new DateTimePeriodDetailsBatchTypeU168602C();
		dateTimePeriodDetailsBatchTypeU168602C.setDateTimeQualifier(PassengerServiceConstants.DATETIME_QUALIFIER);
		dateTimePeriodDetailsBatchTypeU168602C.setDateTimeDetails(registeredIdentifier.getExpiryDate().toString());
		dateTimePeriodDetailsBatchTypeU168602C.setFormat(PassengerServiceConstants.DATETIMEDESCRIPTION_FORMAT);
		dateTimePeriodDetailsBatchTypeU168602CList.add(dateTimePeriodDetailsBatchTypeU168602C);
		dateTimePeriodTypeU.setDateTimeDescription(dateTimePeriodDetailsBatchTypeU168602CList);

		PlaceLocationIdentificationType139972S placeLocationIdentificationType139972S = new PlaceLocationIdentificationType139972S();
		placeLocationIdentificationType139972S.setLocationType(PassengerServiceConstants.LOCATION_TYPE);
		LocationIdentificationBatchType202912C locationIdentificationBatchType202912C = new LocationIdentificationBatchType202912C();
		locationIdentificationBatchType202912C.setCode("DEC");
		locationIdentificationBatchType202912C.setQualifier(PassengerServiceConstants.LOCATION_QUALIFIER);
		placeLocationIdentificationType139972S.setLocationDescription(locationIdentificationBatchType202912C);
		RelatedLocationOneIdentificationType relatedLocationOneIdentificationType = new RelatedLocationOneIdentificationType();
		relatedLocationOneIdentificationType.setCode(registeredIdentifier.getPlaceOfIssue().getLocationIdentifier());
		relatedLocationOneIdentificationType.setQualifier(PassengerServiceConstants.LOCATION_DETAILS_QUALIFIER);
		placeLocationIdentificationType139972S.setFirstLocationDetails(relatedLocationOneIdentificationType);

		NameAndAddressBatchTypeU nameAndAddressBatchTypeU = new NameAndAddressBatchTypeU();
		nameAndAddressBatchTypeU.setTraveler(PassengerServiceConstants.TRAVELER);
		nameAndAddressBatchTypeU.setTravelerCountryCode(registeredIdentifier.getPlaceOfIssue().getName());
		PartyNameBatchTypeU partyNameBatchTypeU = new PartyNameBatchTypeU();
		partyNameBatchTypeU.setLastName(registeredIdentifier.getPerson().getPersonName().getFamilyName());
		partyNameBatchTypeU.setGivenNames(registeredIdentifier.getPerson().getPersonName().getFirstName());
		nameAndAddressBatchTypeU.setTravelerName(partyNameBatchTypeU);
		DocumentMessageDetailsTypeU documentMessageDetailsTypeU = new DocumentMessageDetailsTypeU();
		documentMessageDetailsTypeU.setTravelerDocumentId(registeredIdentifier.getToken());
		documentMessageTypeU.setTravelerDocumentDetails(documentMessageDetailsTypeU);
		documents.setTravelerDocument(documentMessageTypeU);
		documents.setDocumentExpiration(dateTimePeriodTypeU);
		documents.setDocumentIssuingCountry(placeLocationIdentificationType139972S);
		documents.setTravelerNameAndAddress(nameAndAddressBatchTypeU);	
		return documents;
	}
	public StatusType148330S buildCprGroupDeleteIndicatorsForDocument() {
		StatusType148330S statusType148330S = new StatusType148330S();
		StatusDetailsType statusDetailsType = new StatusDetailsType();
		statusDetailsType.setIndicator(PassengerServiceConstants.INDICATOR);
		statusDetailsType.setAction(PassengerServiceConstants.ACTION);
		statusType148330S.setStatusInformation(statusDetailsType);
		return statusType148330S;
	}
}
