package com.iag.business.passenger.domain.model.flight;

public enum FlightSegmentStatus {
    CONFIRMED,
    UNCONFIRMED,
    DELAYED;
}
