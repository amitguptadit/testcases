package com.iag.business.passenger;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.URIException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.transport.http.CommonsHttpMessageSender;

import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.proxy.config.ServiceProxy;
import com.iag.business.passenger.repository.AmadeusHeaderClientInterceptor;

@Configuration
public class AmedeusConnectorConfig {

    

	private static final Logger LOG = LoggerFactory.getLogger(AmedeusConnectorConfig.class);

	@Autowired
	private  ServiceProxy configurationInfrastructureServiceProxy;
     
	@Bean
	AmadeusHeaderClientInterceptor amadeusHeaderClientInterceptor() {
		return new AmadeusHeaderClientInterceptor();
	}

	@SuppressWarnings("deprecation")
	@Bean
	public CommonsHttpMessageSender httpSender() throws URIException {
		CommonsHttpMessageSender commonsHttpMessageSender = new CommonsHttpMessageSender();
		Map<String, String> maxConnectionsPerHost = new HashMap<String, String>();
        maxConnectionsPerHost.put(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.HTTP_SENDER_WILDCARD_HOSTS.name()),
        		configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.HTTP_SENDER_MAX_HOSTS.name()));
		commonsHttpMessageSender.setAcceptGzipEncoding(true);
        commonsHttpMessageSender.setReadTimeout(Integer.parseInt(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.HTTP_SENDER_READ_TIME_OUT.name())));
        commonsHttpMessageSender.setConnectionTimeout(Integer.parseInt(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.HTTP_SENDER_CONNECTOR_TIME_OUT.name())));
		commonsHttpMessageSender.setMaxConnectionsPerHost(maxConnectionsPerHost);
		return commonsHttpMessageSender;
	}
    
	@Bean
	public WebServiceTemplate amadeusWebServiceTemplate(Jaxb2Marshaller amadeusMarshaller,
			Jaxb2Marshaller amadeusUnMarshaller, CommonsHttpMessageSender httpSender) {

		CommonsHttpMessageSender[] httsenders = { httpSender };
		WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
		webServiceTemplate.setMarshaller(amadeusMarshaller);
		webServiceTemplate.setUnmarshaller(amadeusUnMarshaller);
		webServiceTemplate.setMessageSenders(httsenders);
        webServiceTemplate.setDefaultUri(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.PASSENGER_DEFAULT_URL.name()));
        
		return webServiceTemplate;

	}

	@Bean
	public Jaxb2Marshaller amadeusMarshaller() {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		LOG.info("amadeusMarshaller method invoking {}",configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.PASSENGER_MARSHALLER.name()));
        jaxb2Marshaller.setContextPaths(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.PASSENGER_MARSHALLER.name()));
		Map<String, Boolean> marshallerProperties = new HashMap<String, Boolean>();
		marshallerProperties.put(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		return jaxb2Marshaller;
	}

	@Bean 
	public Jaxb2Marshaller amadeusUnMarshaller() {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		LOG.info("amadeusUnMarshaller method invoking {}");
         jaxb2Marshaller.setContextPaths(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.PASSENGER_UNMARSHALLER.name()));
		Map<String, Boolean> marshallerProperties = new HashMap<String, Boolean>();
		marshallerProperties.put(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);

		return jaxb2Marshaller;
	}
	
	@Bean
	public WebServiceTemplate amadeusWebServiceTemplateForUpdatePassenger(Jaxb2Marshaller amadeusMarshallerForUpdatePassenger,
			Jaxb2Marshaller amadeusUnMarshallerForUpdatePassenger, CommonsHttpMessageSender httpSender) {
		ClientInterceptor[] clientInterceptors = { amadeusHeaderClientInterceptor() };

		CommonsHttpMessageSender[] httsenders = { httpSender };
		WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
		webServiceTemplate.setMarshaller(amadeusMarshallerForUpdatePassenger);
		webServiceTemplate.setInterceptors(clientInterceptors);
		webServiceTemplate.setUnmarshaller(amadeusUnMarshallerForUpdatePassenger);
		webServiceTemplate.setMessageSenders(httsenders);
        webServiceTemplate.setDefaultUri(PassengerServiceConstants.DEFAULT_URL);
        
		return webServiceTemplate;

	}

	@Bean
	public Jaxb2Marshaller amadeusMarshallerForUpdatePassenger() {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		LOG.info("updateAmadeusMarshaller method invoking");
        jaxb2Marshaller.setContextPaths(PassengerServiceConstants.UPDATE_PASSENGER_MARSHALLER);
		Map<String, Boolean> marshallerProperties = new HashMap<String, Boolean>();
		marshallerProperties.put(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		return jaxb2Marshaller;
	}

	@Bean 
	public Jaxb2Marshaller amadeusUnMarshallerForUpdatePassenger() {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		LOG.info("updateAmadeusUnMarshaller method invoking");
        jaxb2Marshaller.setContextPaths(PassengerServiceConstants.UPDATE_PASSENGER_UNMARSHALLER);
		Map<String, Boolean> marshallerProperties = new HashMap<String, Boolean>();
		marshallerProperties.put(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);

		return jaxb2Marshaller;
	}

}
