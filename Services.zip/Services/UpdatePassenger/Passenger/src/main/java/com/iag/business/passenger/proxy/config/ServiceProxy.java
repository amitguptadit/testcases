package com.iag.business.passenger.proxy.config;

/**
 * Interface to define contract for service call over http.
 */
public interface ServiceProxy { 

 String retrieveConfiguration(String configurationName, String key);
}
