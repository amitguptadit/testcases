package com.iag.business.passenger.repository.mapper.request;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR;
import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR.CustomerEdit;
import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR.CustomerEdit.Edits;
import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR.CustomerEdit.Edits.EmergencyContact;
import com.amadeus.xml.ccpruq_16_6_1a.FlightDetailsResponseType;
import com.amadeus.xml.ccpruq_16_6_1a.ItemReferencesAndVersionsType93421S;
import com.amadeus.xml.ccpruq_16_6_1a.NationalityDetailsTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.NationalityTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.OutboundCarrierDetailsTypeI;
import com.amadeus.xml.ccpruq_16_6_1a.OutboundFlightNumberDetailstypeI3083C;
import com.amadeus.xml.ccpruq_16_6_1a.StatusDetailsType;
import com.amadeus.xml.ccpruq_16_6_1a.StatusType148330S;
import com.amadeus.xml.ccpruq_16_6_1a.TravellerDetailsTypeI;
import com.amadeus.xml.ccpruq_16_6_1a.TravellerInformationTypeI;
import com.amadeus.xml.ccpruq_16_6_1a.TravellerSurnameInformationTypeI;
import com.amadeus.xml.ccpruq_16_6_1a.UniqueIdDescriptionType;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.Carrier;
import com.iag.business.passenger.domain.model.ItineraryItem;
import com.iag.business.passenger.domain.model.party.role.Passenger;

/**
 * This class is used for map the AmadeusRequest.
 */
@Component
public class UpdatePassengerAmadeusRequestMapper {
	@Autowired
	NationalityMapperForUpdatePassenger nationalityMapperForUpdatePassenger;
	@Autowired
	HomeAndDestinationAddressMapperForUpdatePassenger homeAndDestinationAddressMapperForUpdatePassenger;
	@Autowired
	DocumentsMapperForUpdatePassenger documentsMapperForUpdatePassenger;
	@Autowired
	EmergencyContactMapperForUpdatePassenger emergencyContactMapperForUpdatePassenger;
	private static final Logger logger = LoggerFactory.getLogger(UpdatePassengerAmadeusRequestMapper.class);

	/**
	 * Method is used to create the AmadeusRequest request to get the
	 * EditCPRRequest information.
	 * 
	 * @param bookingIdentifier
	 * @param passengerIdentifier
	 * @param passenger
	 * @param session
	 */
	@SuppressWarnings("rawtypes")
	public DCSCPREditCPR createRequestBodyForUpdatePassenge(String bookingIdentifier, Passenger passenger) {
		logger.info("method start: createRequestBodyForUpdatePassenge()");
		DCSCPREditCPR dCSCPREditCPRRequest = new DCSCPREditCPR();
		dCSCPREditCPRRequest
				.setCustomerEdit(buildCommonCustomerDetails(passenger, bookingIdentifier, passenger.getIdentifier()));
		logger.info("method end: createRequestBodyForUpdatePassenge()");
		return dCSCPREditCPRRequest;
	}

	@SuppressWarnings("rawtypes")
	private List<CustomerEdit> buildCommonCustomerDetails(Passenger passenger, String bookingIdentifier,
			String passengerIdentifier) {
		List<CustomerEdit> customerEditList = new ArrayList<>();
		CustomerEdit customerEdit = new CustomerEdit();
		TravellerSurnameInformationTypeI travellerSurnameInformationTypeI = new TravellerSurnameInformationTypeI();
		TravellerInformationTypeI travellerInformationTypeI = new TravellerInformationTypeI();
		ItemReferencesAndVersionsType93421S itemReferencesAndVersionsType93421S = new ItemReferencesAndVersionsType93421S();
		UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
		// map surname -> familyName
		travellerSurnameInformationTypeI.setSurname(passenger.getPerson().getPersonName().getFamilyName());
		travellerSurnameInformationTypeI.setType(buildPassengerGenderType(passenger.getType().name()));
		travellerInformationTypeI.setPaxDetails(travellerSurnameInformationTypeI);
		List<TravellerDetailsTypeI> travellerDetailsTypeIList = new ArrayList<>();
		TravellerDetailsTypeI travellerDetailsTypeI = new TravellerDetailsTypeI();

		travellerDetailsTypeI.setGivenName(passenger.getPerson().getPersonName().getFirstName());
		travellerDetailsTypeIList.add(travellerDetailsTypeI);

		travellerInformationTypeI.setOtherPaxDetails(travellerDetailsTypeIList);

		uniqueIdDescriptionType.setReferenceQualifier(PassengerServiceConstants.REFERENCE_QUALIFIER);
		uniqueIdDescriptionType.setPrimeId(passengerIdentifier);
		itemReferencesAndVersionsType93421S.setIdSection(uniqueIdDescriptionType);

		customerEdit.setCustomerDetails(travellerInformationTypeI);
		customerEdit.setUniqueCustomerId(itemReferencesAndVersionsType93421S);
		customerEdit.setEdits(buildCommonEditsForCustomerDetails(passenger, bookingIdentifier));
		// customerEdit.setEdits(homeAndDestinationAddressMapperForUpdatePassenger.buildHomeAndDestinationAddress(passenger));
		// customerEdit.setEdits(documentsMapperForUpdatePassenger.buildDocuments(passenger));
		// customerEdit.setEdits(emergencyContactMapperForUpdatePassenger.buildEmergencyContact(passenger));
		travellerSurnameInformationTypeI.setSurname(passenger.getPerson().getPersonName().getFamilyName());
		travellerSurnameInformationTypeI.setType(buildPassengerGenderType(passenger.getType().name()));

		travellerInformationTypeI.setPaxDetails(travellerSurnameInformationTypeI);

		travellerDetailsTypeI.setGivenName(passenger.getPerson().getPersonName().getFirstName());
		travellerDetailsTypeIList.add(travellerDetailsTypeI);
		travellerInformationTypeI.setOtherPaxDetails(travellerDetailsTypeIList);
		uniqueIdDescriptionType.setReferenceQualifier(PassengerServiceConstants.REFERENCE_QUALIFIER);
		uniqueIdDescriptionType.setPrimeId(passengerIdentifier);
		itemReferencesAndVersionsType93421S.setIdSection(uniqueIdDescriptionType);
		// customerEdit.setEdits(getOperatingFlightDetails(passenger,bookingIdentifier));
		customerEdit.setUniqueCustomerId(itemReferencesAndVersionsType93421S);
		customerEdit.setCustomerDetails(travellerInformationTypeI);
		// customerEdit.setEdits(buildOperatingFlightDetails(passenger,
		// bookingIdentifier));
		customerEditList.add(customerEdit);
		return customerEditList;

	}

	private String buildPassengerGenderType(String type) {
		String passengerType = null;
		if (type.equals("ADULT")) {
			passengerType = PassengerServiceConstants.ADULT;
		} else if (type.equals("CHILD")) {
			passengerType = PassengerServiceConstants.CHILD;
		} else if (type.equals("INFANT")) {
			passengerType = PassengerServiceConstants.INFANT;

		}
		return passengerType;
	}

	@SuppressWarnings("rawtypes")
	private List<Edits> buildCommonEditsForCustomerDetails(Passenger passenger, String bookingIdentifier) {
		List<Edits> editList = new ArrayList<>();
		Edits edits = new Edits();
		FlightDetailsResponseType flightDetailsResponseType = new FlightDetailsResponseType();
		List<ItineraryItem> itineraryItemList = passenger.getItinerary().getItineraryItems();
		UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
		OutboundCarrierDetailsTypeI outboundCarrierDetailsTypeI = new OutboundCarrierDetailsTypeI();
		OutboundFlightNumberDetailstypeI3083C outboundFlightNumberDetailstypeI3083C = new OutboundFlightNumberDetailstypeI3083C();
		List<Carrier> CarrierList = null;

		String flightNumber = null;
		for (ItineraryItem itineraryItem : itineraryItemList) {
			CarrierList = itineraryItem.getCarriers();
			for (Carrier carrier : CarrierList) {

				flightNumber = carrier.getFlightNumber();

				outboundCarrierDetailsTypeI.setMarketingCarrier(carrier.getCode());
				outboundFlightNumberDetailstypeI3083C.setFlightNumber(flightNumber);
			}
			// outboundFlightNumberDetailstypeI3083C.set
			flightDetailsResponseType.setDepartureDate(new BigInteger(
					itineraryItem.getScheduledDepartureLocalDatetime().toString().split("T")[0].replace("-", "")));
			flightDetailsResponseType.setBoardPoint(itineraryItem.getOrigin().getIdentifier());
			flightDetailsResponseType.setOffPoint(itineraryItem.getDestination().getIdentifier());
			uniqueIdDescriptionType.setPrimeId(itineraryItem.getIdentifier());
			flightDetailsResponseType.setCarrierDetails(outboundCarrierDetailsTypeI);
			flightDetailsResponseType.setFlightDetails(outboundFlightNumberDetailstypeI3083C);
			edits.setOperatingFlightDetails(flightDetailsResponseType);
			// To enable for Nationality
			//edits.setCprGroupDeleteIndicators(nationalityMapperForUpdatePassenger.buildCprGroupDeleteIndicatorsForNationality());
			//edits.setCountry(nationalityMapperForUpdatePassenger.buildCountry(passenger));
			//edits.setAddressDetailsGroup(homeAndDestinationAddressMapperForUpdatePassenger.buildHomeAndDestinationAddress(passenger));
			//edits.setCprGroupDeleteIndicators(homeAndDestinationAddressMapperForUpdatePassenger.buildCprGroupDeleteIndicatorsHomeAndDestinationAddress());
			//edits.setEmergencyContact(emergencyContactMapperForUpdatePassenger.buildEmergencyContact(passenger));
			//edits.setCprGroupDeleteIndicators(emergencyContactMapperForUpdatePassenger.buildCprGroupDeleteIndicatorsForEmergencyContact());
			edits.setDocuments(documentsMapperForUpdatePassenger.buildDocuments(passenger));
			edits.setCprGroupDeleteIndicators(documentsMapperForUpdatePassenger.buildCprGroupDeleteIndicatorsForDocument());
			editList.add(edits);

		}
		ItemReferencesAndVersionsType93421S itemReferencesAndVersionsType93421S = new ItemReferencesAndVersionsType93421S();

		uniqueIdDescriptionType.setReferenceQualifier(PassengerServiceConstants.REFERENCE_IDENTIFIER);

		itemReferencesAndVersionsType93421S.setIdSection(uniqueIdDescriptionType);

		edits.setUniqueProductId(itemReferencesAndVersionsType93421S);
		editList.add(edits);
		return editList;

	}
}
