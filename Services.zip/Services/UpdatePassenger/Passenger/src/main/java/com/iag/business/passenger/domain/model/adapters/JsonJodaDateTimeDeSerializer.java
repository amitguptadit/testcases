package com.iag.business.passenger.domain.model.adapters;

import java.io.IOException;

import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.joda.time.format.ISODateTimeFormat;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class JsonJodaDateTimeDeSerializer extends JsonDeserializer<LocalDateTime> {

	  /**
	   * It converts date in String format to {@link LocalDate}.
	   */
	  @Override
	  public LocalDateTime deserialize(final JsonParser jsonparser, final DeserializationContext deserializationcontext)
	      throws IOException {
	    DateTime dateTime = ISODateTimeFormat.dateTimeParser().parseDateTime(jsonparser.getText());
	    return new LocalDateTime(dateTime.getYear(), dateTime.getMonthOfYear(), dateTime.getDayOfMonth(), 
	    		dateTime.getHourOfDay(), dateTime.getMinuteOfHour(), dateTime.getSecondOfMinute());
	    }
	}
