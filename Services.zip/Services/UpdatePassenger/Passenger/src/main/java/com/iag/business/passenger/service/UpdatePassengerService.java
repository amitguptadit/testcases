package com.iag.business.passenger.service;

import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.session.AmadeusSession;

public interface UpdatePassengerService {
	@SuppressWarnings("rawtypes")
	public void updatePassenger(String bookingIdentifier, Passenger passenger,
			AmadeusSession session);
}
