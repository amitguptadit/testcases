package com.iag.business.passenger.repository;


import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.session.AmadeusSession;

public interface UpdatePassengerAmadeusRepository {
	@SuppressWarnings("rawtypes")
	public void updatePassenger(String bookingIdentifier, Passenger passenger,
			AmadeusSession session);
}
