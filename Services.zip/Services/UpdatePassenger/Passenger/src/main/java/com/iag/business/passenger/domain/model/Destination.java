
package com.iag.business.passenger.domain.model;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iag.business.passenger.domain.model.utility.ToStringBuilder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "identifier",
    "terminal",
    "gate"
})
public class Destination {

    /**
     * An IATA airport code, also known as an IATA location identifier, IATA station code or simply a location identifier, is a three-letter code designating many airports around the world, defined by the International Air Transport Association (IATA). The characters prominently displayed on baggage tags attached at airport check-in desks are an example of a way these codes are used.
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    @JsonPropertyDescription("An IATA airport code, also known as an IATA location identifier, IATA station code or simply a location identifier, is a three-letter code designating many airports around the world, defined by the International Air Transport Association (IATA). The characters prominently displayed on baggage tags attached at airport check-in desks are an example of a way these codes are used.")
    private String identifier;
    /**
     * An airport terminal is a building at an airport where passengers transfer between ground transportation and the facilities that allow them to board and disembark from aircraft. Within the terminal, passengers purchase tickets, transfer their luggage, and go through security.
     * 
     */
    @JsonProperty("terminal")
    @JsonPropertyDescription("An airport terminal is a building at an airport where passengers transfer between ground transportation and the facilities that allow them to board and disembark from aircraft. Within the terminal, passengers purchase tickets, transfer their luggage, and go through security.")
    private String terminal;
    /**
     * A gate, is an area of an airport that provides a waiting area for passengers before boarding their flight.
     * 
     */
    @JsonProperty("gate")
    @JsonPropertyDescription("A gate, is an area of an airport that provides a waiting area for passengers before boarding their flight.")
    private Gate gate;
   
    /**
     * An IATA airport code, also known as an IATA location identifier, IATA station code or simply a location identifier, is a three-letter code designating many airports around the world, defined by the International Air Transport Association (IATA). The characters prominently displayed on baggage tags attached at airport check-in desks are an example of a way these codes are used.
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    public String getIdentifier() {
        return identifier;
    }

    /**
     * An IATA airport code, also known as an IATA location identifier, IATA station code or simply a location identifier, is a three-letter code designating many airports around the world, defined by the International Air Transport Association (IATA). The characters prominently displayed on baggage tags attached at airport check-in desks are an example of a way these codes are used.
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

  
    /**
     * An airport terminal is a building at an airport where passengers transfer between ground transportation and the facilities that allow them to board and disembark from aircraft. Within the terminal, passengers purchase tickets, transfer their luggage, and go through security.
     * 
     */
    @JsonProperty("terminal")
    public String getTerminal() {
        return terminal;
    }

    /**
     * An airport terminal is a building at an airport where passengers transfer between ground transportation and the facilities that allow them to board and disembark from aircraft. Within the terminal, passengers purchase tickets, transfer their luggage, and go through security.
     * 
     */
    @JsonProperty("terminal")
    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    
    /**
     * A gate, is an area of an airport that provides a waiting area for passengers before boarding their flight.
     * 
     */
    @JsonProperty("gate")
    public Gate getGate() {
        return gate;
    }

    /**
     * A gate, is an area of an airport that provides a waiting area for passengers before boarding their flight.
     * 
     */
    @JsonProperty("gate")
    public void setGate(Gate gate) {
        this.gate = gate;
    }

    @Override
    public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {
      return ToStringBuilder.generateToString(this);
    }


    
}
