package com.iag.business.passenger.validation;

import java.io.IOException;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.error.MessageConstants;
import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifier;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.exception.ValidationServiceExceptionGenerator;


/**
 * Passenger Validation is used for validating passenger.
 *
 */
@Component
public class PassengerFieldsValidation {
	private static final Logger logger = LoggerFactory.getLogger(BookingIdentifierValidation.class);

	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	/**
	 * @param validationServiceExceptionGenerator
	 */
	@Autowired
	public PassengerFieldsValidation(final ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * This method is used to validate passenger
	 * 
	 * @param passenger
	 * @return
	 * @throws JSONException 
	 * @throws IOException 
	 */
	public ValidationServiceException validate(final Passenger<String> passenger){
		//System.out.println("size : "+passenger.toString().length());
		
		logger.info("start method:validate(), Booking-Identifier: {}", passenger);
		logger.info("Start of method validate ||" + passenger);
	
		ValidationServiceException updatePassengerValidationServiceException = null;
		if(passenger == null){
			updatePassengerValidationServiceException = createValidationError(
					PassengerErrorCode.MANDATORY_DATA_MISSING.name());
			return updatePassengerValidationServiceException;
		}
		if (null != passenger.getEmergencyContact()  || null != passenger.getPerson() || null !=  passenger.getItinerary()) {
			if(passenger.getPerson() != null){
				Person<String> person = passenger.getPerson();
				if (person.getRegisteredIdentifiers() != null || person.getNationality() != null) {
					List<RegisteredIdentifier<?>> registeredIdentifiers = person.getRegisteredIdentifiers();
					if (!(CollectionUtils.isEmpty(registeredIdentifiers))) {
						for (RegisteredIdentifier<?> registeredIdentifier : registeredIdentifiers) {
							if (StringUtils.isEmpty(registeredIdentifier.getToken()) || registeredIdentifier.getExpiryDate() == null
									                                                     || registeredIdentifier.getPlaceOfIssue() == null) {
								return updatePassengerValidationServiceException = createValidationError(
										PassengerErrorCode.MANDATORY_DATA_MISSING.name());

							}
						} 
					}
				}//registeredIdentifier+Nationality
				else{
					return updatePassengerValidationServiceException = createValidationError(
 							PassengerErrorCode.MANDATORY_DATA_MISSING.name()); 
				}		
			}//person
			
		}
		else{
			return updatePassengerValidationServiceException = createValidationError(
					PassengerErrorCode.MANDATORY_DATA_MISSING.name());
		}
		
		
		return updatePassengerValidationServiceException;
	}
	private ValidationServiceException createValidationError(String errorCode) {
		return validationServiceExceptionGenerator.createValidationError(errorCode,
				PassengerServiceConstants.PASSENGER_PATH,
				MessageConstants.PASSENGER_ERROR + errorCode + PassengerServiceConstants.DEVMSG_HEADERVALUE);

	}
	
	
}
