package com.iag.business.passenger.service;

import java.util.List;

import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.session.AmadeusSession;

public interface PassengerService {
	
	public Passenger getPassenger(String bookingIdentifier, String passengerIdentifier,AmadeusSession session);
}
