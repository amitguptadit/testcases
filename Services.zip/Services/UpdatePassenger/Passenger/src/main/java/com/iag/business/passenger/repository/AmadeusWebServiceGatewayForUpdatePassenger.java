package com.iag.business.passenger.repository;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.support.MarshallingUtils;

import com.amadeus.xml.ccprur_16_6_1a.DCSCPREditCPRReply;
import com.amadeus.xml.ccprur_16_6_1a.ErrorGroupType;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.proxy.config.ServiceProxy;
import com.iag.business.passenger.repository.mapper.request.PassengersRequiestHeaderMapper;
import com.iag.business.passenger.session.AmadeusSession;

@Component
public class AmadeusWebServiceGatewayForUpdatePassenger {

	private static final Logger LOG = LoggerFactory.getLogger(AmadeusWebServiceGatewayForUpdatePassenger.class);
	//@Autowired
	//private ApplicationServiceExceptionGenerator applicationServiceExceptionGenerator;
	@Autowired
	Jaxb2Marshaller amadeusMarshallerForUpdatePassenger;
	@Autowired
	Jaxb2Marshaller amadeusUnMarshallerForUpdatePassenger;
	@Autowired
	private WebServiceTemplate amadeusWebServiceTemplateForUpdatePassenger;
	@Autowired
	private ServiceProxy configurationInfrastructureServiceProxy;

	public Object getWebServiceResponseForUpdatePassenger(final Object requestObject, final String soapActionUri,
			AmadeusSession session) {
		Object response = null;
		try {
			LOG.info("getWebServiceResponseForPassengers session Object {}", session.toString());
			response = getAmadeusWebServiceResponseForUpdatePassenger(requestObject, soapActionUri, session);
			System.out.println("Final response test "+response);
		} catch (Exception exception) {
			throwWebServiceException(exception);
		}
		
	    hasError(response); 
		return response;
	}

	private Object getAmadeusWebServiceResponseForUpdatePassenger(final Object requestObject, final String soapActionUri,
			AmadeusSession session) {
		return amadeusWebServiceTemplateForUpdatePassenger.sendAndReceive(new WebServiceMessageCallback() {
			public void doWithMessage(WebServiceMessage message) throws IOException {
				SaajSoapMessage soapMessage = (SaajSoapMessage) message;
				soapMessage.setSoapAction(soapActionUri);
				PassengersRequiestHeaderMapper ame = new PassengersRequiestHeaderMapper();
				ame.mapHeaders(soapMessage, session);
				MarshallingUtils.marshal(amadeusMarshallerForUpdatePassenger, requestObject, soapMessage);
			}
		}, new WebServiceMessageExtractor<Object>() {
			public Object extractData(WebServiceMessage message) throws IOException {
				Object responseBody = MarshallingUtils.unmarshal(amadeusUnMarshallerForUpdatePassenger, message);
				return responseBody;

			}
		});
	}

	/**
	 * This private method is responsible to handle the webServiceException if
	 * any in response from AmadeusWebSerfvice. It should throw the exception
	 * based on the nature.
	 * 
	 * @param wsie
	 *            WebServiceIOException
	 */

	private void throwWebServiceException(final Exception exception) {
		LOG.error("AmadeusWebServiceGateway throwWebServiceException {} ", exception);
		throw new ApplicationServiceException(PassengerErrorCode.SYSTEM_UNAVAILABLE.name());

	}

	private void hasError(final Object response) {
		String errorCode = StringUtils.EMPTY;
		final List<ErrorGroupType> errorSection = ((DCSCPREditCPRReply) response).getErrors();
		if (errorSection != null) {
			for (ErrorGroupType error : errorSection) {
				errorCode = error.getErrorOrWarningCodeDetails().getErrorDetails().getErrorCode();
				String errorCategory = error.getErrorOrWarningCodeDetails().getErrorDetails().getErrorCategory();
				LOG.error("AmadeusWebServiceGateway ResponseErrorCode {} ,errorCategory {} ", errorCode, errorCategory);
				String configerrorCategory = configurationInfrastructureServiceProxy.retrieveConfiguration(
						PassengerServiceConstants.AMADEUS_NAMESPACE,
						PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name());
				if (listContain(configerrorCategory,errorCategory)) {
					getErrorType(errorCode, errorCategory);
				}
			}
		}

	}

	private void getErrorType(String errorCode, String errorCategory) {
		String configvalue = StringUtils.EMPTY;
		configvalue = configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name());
		if (listContain(configvalue,errorCode)) {
			LOG.error("AmadeusWebServiceGateway getErrorType {} ,SYSTEM_UNAVAILABLE ", configvalue);
			throw new ApplicationServiceException(PassengerErrorCode.SYSTEM_UNAVAILABLE.name());
		}
		configvalue = configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_NOT_FOUND_CODE_STATUS_LIST.name());
		if (listContain(configvalue,errorCode)) {
			LOG.error("AmadeusWebServiceGateway getErrorType {} ,PASSENGER_NOT_FOUND ", configvalue);
			throw new ApplicationServiceException(PassengerErrorCode.PASSENGER_NOT_FOUND.name());

		}
		configvalue = configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_WARNING_CODE_STATUS_LIST.name());
		if (!listContain(configvalue,errorCode)) {
			LOG.error("AmadeusWebServiceGateway getErrorType {} ,SYSTEM_UNAVAILABLE -2 ", configvalue);
			throw new ApplicationServiceException(PassengerErrorCode.SYSTEM_UNAVAILABLE.name());

		}
	}
	 private boolean listContain(String errorStausList,String errorCode){
		 boolean hasContain = false;
		 List<String> stringList = Arrays.asList(errorStausList.split("\\s*,\\s*"));
         if(stringList.contains(errorCode)){
        	 hasContain=true;
         }
        
		return hasContain;
	 }
}
