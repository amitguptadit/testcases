
package com.iag.business.passenger.domain.model.party.role;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iag.business.passenger.domain.model.DangerousGoods;
import com.iag.business.passenger.domain.model.Itinerary;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.utility.ToStringBuilder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"identifier",
	"passenger-identifier",
    "associatedPassenger",
    "type",
    "emergencyContact",
    "person",
    "dangerousGoods",
    "itinerary",    
})
public class Passenger<K> extends PartyRole<K> implements Serializable {

	/**
	 * The passenger's unique identifier in the booking. (Required)
	 * 
	 *//*
		 * @JsonProperty("identifier")
		 * 
		 * @JsonPropertyDescription(
		 * "The passenger's unique identifier in the booking.") private String
		 * identifier;
		 */
	
	/**
	 * Passenger Identifier
	 * <p>
	 * 
	 * 
	 */
	@JsonProperty("passenger-identifier")
	private String passengerIdentifier;
	
	/**
	 * Associated Passenger
	 * <p>
	 * 
	 * 
	 */
	@JsonProperty("associatedPassenger")
	private AssociatedPassenger<K> associatedPassenger;
	/**
	 * The type of the passenger. Could be any of the following values - INFANT,
	 * CHILD,ADULT (Required)
	 * 
	 */
	@JsonProperty("type")
	@JsonPropertyDescription("The type of the passenger. Could be any of the following values - INFANT, CHILD,ADULT")
	private PassengerType type;
	/**
	 * Emergency contact details for the passenger
	 * 
	 */
	@JsonProperty("emergencyContact")
	@JsonPropertyDescription("Emergency contact details for the passenger")
	private EmergencyContact<K> emergencyContact;
	/**
	 * Passenger's personal details. (Required)
	 * 
	 */
	@JsonProperty("person")
	@JsonPropertyDescription("Passenger's personal details.")
	private Person<K> person;
	
	/**
	 * Passenger's personal details. (Required)
	 * 
	 */
	@JsonProperty("dangerousGoods")
	@JsonPropertyDescription("Dangerous goods details.")
	private DangerousGoods dangerousGoods;
	
	
	
	/**
	 * A collection of itinerary items , passenger wants to check-in for .
	 * (Required)
	 * 
	 */
	@JsonProperty("itinerary")
	@JsonPropertyDescription("A collection of  itinerary items , passenger wants to check-in for .")
	private Itinerary itinerary;

	private Passenger(PassengerBuilder<K> passengerBuilder) {
		this();
		this.associatedPassenger = passengerBuilder.associatedPassenger;
		this.emergencyContact = passengerBuilder.emergencyContact;
		this.itinerary = passengerBuilder.itinerary;
		this.person = passengerBuilder.person;
		this.type = passengerBuilder.type;
		this.dangerousGoods = passengerBuilder.dangerousGoods;
		this.passengerIdentifier = passengerBuilder.passengerIdentifier;
	}

	private Passenger() {
	}
	
	

	/**
	 * A collection of itinerary items , passenger wants to check-in for .
	 * (Required)
	 * 
	 */
	@JsonProperty("itinerary")
	public Itinerary getItinerary() {
		return itinerary;
	}
	
	/**
	 * A collection of itinerary items , passenger wants to check-in for .
	 * (Required)
	 * 
	 */
	@JsonProperty("dangerousGoods")
	public DangerousGoods getDangerousGoods() {
		return dangerousGoods;
	}

	/**
	 * Passenger's personal details. (Required)
	 * 
	 */
	@JsonProperty("person")
	public Person<K> getPerson() {
		return person;
	}

	/**
	 * Emergency contact details for the passenger
	 * 
	 */
	@JsonProperty("emergencyContact")
	public EmergencyContact<K> getEmergencyContact() {
		return emergencyContact;
	}

	/**
	 * The type of the passenger. Could be any of the following values - INFANT,
	 * CHILD,ADULT (Required)
	 * 
	 */
	@JsonProperty("type")
	public PassengerType getType() {
		return type;
	}

	/**
	 * Associated Passenger
	 * <p>
	 * 
	 * 
	 */
	@JsonProperty("associatedPassenger")
	public AssociatedPassenger<K> getAssociatedPassenger() {
		return associatedPassenger;
	}

	/**
	 * The passenger's unique identifier in the booking. (Required)
	 * 
	 */
	/*
	 * @JsonProperty("identifier") public String getIdentifier() { return
	 * identifier; }
	 * 
	 *//**
		 * The passenger's unique identifier in the booking. (Required)
		 * 
		 *//*
		 * @JsonProperty("identifier") public void setIdentifier(String
		 * identifier) { this.identifier = identifier; }
		 */

	public static class PassengerBuilder<K> {

		private AssociatedPassenger<K> associatedPassenger;
		private PassengerType type;
		private EmergencyContact<K> emergencyContact;
		private Person<K> person;
		private Itinerary itinerary;
		private DangerousGoods dangerousGoods;
		private String passengerIdentifier;

		public PassengerBuilder(final PassengerType type, final Person<K> person, final Itinerary itinerary) {
			this.type = type;
			this.person = person;
			this.itinerary = itinerary;
		}
		
		/**
		 * Associated Passenger
		 * <p>
		 * 
		 * @return
		 * 
		 * 
		 */
		@JsonProperty("passenger-identifier")
		public PassengerBuilder<K> setPassengerIdentifier(String passengerIdentifier) {
			this.passengerIdentifier = passengerIdentifier;
			return this;
		}


		/**
		 * Associated Passenger
		 * <p>
		 * 
		 * @return
		 * 
		 * 
		 */
		@JsonProperty("associatedPassenger")
		public PassengerBuilder<K> setAssociatedPassenger(AssociatedPassenger<K> associatedPassenger) {
			this.associatedPassenger = associatedPassenger;
			return this;
		}

		/**
		 * Emergency contact details for the passenger
		 * 
		 * @return
		 * 
		 */
		@JsonProperty("emergencyContact")
		public PassengerBuilder<K> setEmergencyContact(EmergencyContact<K> emergencyContact) {
			this.emergencyContact = emergencyContact;
			return this;
		}
		
		/**
		 * Dangerous goods details for the passenger
		 * 
		 * @return
		 * 
		 */
		@JsonProperty("dangerousGoods")
		public PassengerBuilder<K> setDangerousGoods(DangerousGoods dangerousGoods) {
			this.dangerousGoods = dangerousGoods;
			return this;
		}

		/**
		 * Method finally returns the built instance.
		 * 
		 * @return
		 */
		public Passenger<K> build() {
			return new Passenger<K>(this);
		}

	}

    @Override
    public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {
      return ToStringBuilder.generateToString(this);
    }


}
