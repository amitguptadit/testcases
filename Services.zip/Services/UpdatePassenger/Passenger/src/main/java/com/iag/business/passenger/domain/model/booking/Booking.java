
package com.iag.business.passenger.domain.model.booking;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iag.business.passenger.domain.model.flight.FlightSegment;
import com.iag.business.passenger.domain.model.utility.ToStringBuilder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "identifier",
    "flightSegments"
})
public class Booking {

    /**
     * Booking Identifier
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    @JsonPropertyDescription("Booking Identifier")
    private String identifier;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("flightSegments")
    private List<FlightSegment> flightSegments = new ArrayList<FlightSegment>();
    public Booking(BookingBuilder bookingBuilder) {
		this.identifier = bookingBuilder.identifier;
		this.flightSegments = bookingBuilder.flightSegments;
	}

	/**
     * Collection of links. It will have a self link and link to all passengers in the booking
     * (Required)
     * 
     */

    /**
     * Booking Identifier
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    public String getIdentifier() {
        return identifier;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("flightSegments")
    public List<FlightSegment> getFlightSegments() {
        return flightSegments;
    }

 
    
    
    public static class BookingBuilder {
    	
    	/**
         * Booking Identifier
         * (Required)
         * 
         */
        @JsonProperty("identifier")
        @JsonPropertyDescription("Booking Identifier")
        private String identifier;
        /**
         * 
         * (Required)
         * 
         */
        @JsonProperty("flightSegments")
        private List<FlightSegment> flightSegments = new ArrayList<FlightSegment>();

        /**
         * Builder constructor only receives the required attributes.
         * @param identifier
         * @param flightSegments
         */
        public BookingBuilder(final String identifier, final List<FlightSegment> flightSegments) {
          this.identifier = identifier;
          this.flightSegments = flightSegments;
        }
        
        /**
         * Method finally returns the built instance.
         * @return
         */
        public Booking build() {
          return new Booking(this);
        }

    }

    @Override
    public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {
      return ToStringBuilder.generateToString(this);
    }

}
