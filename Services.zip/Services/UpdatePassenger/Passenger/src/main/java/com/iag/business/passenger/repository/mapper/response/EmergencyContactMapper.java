package com.iag.business.passenger.repository.mapper.response;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.CustomerLevelEmergencyContact;
import com.amadeus.xml.ccprrr_17_1_1a.PassengerApiInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.StatusDetailsType;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.address.TelecomAddress;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.party.Person.PersonBuilder;
import com.iag.business.passenger.domain.model.party.PersonName;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact.EmergencyContactBuilder;

/**
 * This class is used to map emergency contact of passenger from amadeus response to domain model object.
 *
 */
@Component
public class EmergencyContactMapper {
	
	private static final Logger logger = LoggerFactory.getLogger(EmergencyContactMapper.class);	
	
	private final PersonNameMapper personNameMapper;
	
	@Autowired
	public EmergencyContactMapper(final PersonNameMapper personNameMapper) {
		this.personNameMapper = personNameMapper;
	}
	
	public EmergencyContact<String> buildEmergencyContact(
			List<CustomerLevelEmergencyContact> customerLevelEmergencyContactList,
			EmergencyContact<String> emergencyContact) {
		logger.info("method start: buildEmergencyContact(), EmergencyContactList: {}", customerLevelEmergencyContactList.size());
		Boolean isDeclined = false;
		String phoneNumber = null;
		PersonName personName = null;
		if (!CollectionUtils.isEmpty(customerLevelEmergencyContactList)) {
			for (CustomerLevelEmergencyContact customerLevelEmergencyContact : customerLevelEmergencyContactList) {
				final List<StatusDetailsType> statusInformation = customerLevelEmergencyContact.getRegDocIndicators().getStatusInformation();
				isDeclined = populateIsDeclined(isDeclined, statusInformation);
				PassengerApiInformationType passengerApiInformationType = customerLevelEmergencyContact
						.getTravelerAndDocumentInfo();
				phoneNumber = passengerApiInformationType.getContactDetails().getPhoneNumber();
				personName = personNameMapper.buildPersonName(passengerApiInformationType.getContactDetails().getFirstName(), passengerApiInformationType.getContactDetails().getSurname(), null);
			}
			Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(personName);
			TelecomAddress telecomAddress = new TelecomAddress(phoneNumber);
			List<TelecomAddress> telecomAddresses = new ArrayList<>();
			telecomAddresses.add(telecomAddress);
			personBuilder.setTelecomAddresses(telecomAddresses);

			Person<String> person = personBuilder.build();
			EmergencyContact.EmergencyContactBuilder<String> emergencyBuilder = new EmergencyContactBuilder<String>(isDeclined);
			emergencyBuilder.setPerson(person);
			emergencyContact = emergencyBuilder.build();

		}
		return emergencyContact;
	}

	/**
	 * populateIsDeclined() for emergency contact
	 * @param isDeclined
	 * @param statusInformation
	 * @return
	 */
	private Boolean populateIsDeclined(Boolean isDeclined, final List<StatusDetailsType> statusInformation) {
		for (StatusDetailsType StatusDetailsType : statusInformation) {
			if (StatusDetailsType.getIndicator().equals(PassengerServiceConstants.DCL)) {
				if (StatusDetailsType.getAction().equals(PassengerServiceConstants.NOT_DECLINED)) {
					isDeclined = false;
				} else if (StatusDetailsType.getAction().equals(PassengerServiceConstants.DECLINED)) {
					isDeclined = true;
				}
			}

		}
		return isDeclined;
	}

}
