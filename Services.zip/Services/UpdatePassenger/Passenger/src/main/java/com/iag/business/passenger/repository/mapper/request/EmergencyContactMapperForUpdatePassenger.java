package com.iag.business.passenger.repository.mapper.request;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR.CustomerEdit.Edits;
import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR.CustomerEdit.Edits.EmergencyContact;
import com.amadeus.xml.ccpruq_16_6_1a.PassengerApiInformationType93959S;
import com.amadeus.xml.ccpruq_16_6_1a.PassengerContactDataTypeI;
import com.amadeus.xml.ccpruq_16_6_1a.StatusDetailsType;
import com.amadeus.xml.ccpruq_16_6_1a.StatusDetailsTypeI;
import com.amadeus.xml.ccpruq_16_6_1a.StatusType148330S;
import com.amadeus.xml.ccpruq_16_6_1a.StatusTypeI114400S;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.address.TelecomAddress;
import com.iag.business.passenger.domain.model.location.Location;
import com.iag.business.passenger.domain.model.location.LocationType;
import com.iag.business.passenger.domain.model.party.role.Passenger;

import ch.qos.logback.core.net.SyslogOutputStream;
@Component
public class EmergencyContactMapperForUpdatePassenger {
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public EmergencyContact buildEmergencyContact(Passenger passenger) {
		EmergencyContact emergencyContact = new EmergencyContact();		
	
		
		
		StatusTypeI114400S statusTypeI114400S = new StatusTypeI114400S();
		StatusDetailsTypeI statusDetailsTypeI=new StatusDetailsTypeI();
		statusDetailsTypeI.setAction("0");		
		statusDetailsTypeI.setIndicator(PassengerServiceConstants.EMERGENCY_STATUS_CONTACT_INDICATOR); 	
		statusTypeI114400S.setStatusDetails(statusDetailsTypeI);
		emergencyContact.setDeclineIndicator(statusTypeI114400S);
		
		PassengerApiInformationType93959S passengerApiInformationType93959S = new PassengerApiInformationType93959S();
		PassengerContactDataTypeI passengerContactDataTypeI = new PassengerContactDataTypeI();
		passengerContactDataTypeI.setSurname(passenger.getEmergencyContact().getPerson().getPersonName().getFamilyName());
		List<TelecomAddress> telecomAddressList = passenger.getEmergencyContact().getPerson().getTelecomAddresses();
		for (TelecomAddress telecomAddress : telecomAddressList) {
			passengerContactDataTypeI.setPhoneNumber(telecomAddress.getNumber());
		}		
		passengerContactDataTypeI.setComment(passenger.getEmergencyContact().getPerson().getPersonName().getFirstName());
		// to ask getLocationIdentifier OR getIdentifier
		if(passenger.getEmergencyContact().getPerson().getCountryOfResidence()!=null)
		passengerContactDataTypeI.setCountryOfResidence(passenger.getEmergencyContact().getPerson().getCountryOfResidence().getLocationIdentifier());
		passengerApiInformationType93959S.setContactDetails(passengerContactDataTypeI);
		emergencyContact.setRegDocEmergContDetails(passengerApiInformationType93959S);
		return emergencyContact;
		
	}
	public StatusType148330S buildCprGroupDeleteIndicatorsForEmergencyContact() {
		StatusType148330S statusType148330S = new StatusType148330S();
		StatusDetailsType statusDetailsType = new StatusDetailsType();
		statusDetailsType.setAction(PassengerServiceConstants.EMERGENCY_CONTACT_ACTION);
		statusDetailsType.setIndicator(PassengerServiceConstants.EMERGENCY_CONTACT_INDICATOR);
		statusType148330S.setStatusInformation(statusDetailsType);
		return statusType148330S;
	}
}
