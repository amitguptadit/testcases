package com.iag.business.passenger.domain.model.adapters;

import java.io.IOException;

import org.joda.time.LocalDate;
import org.joda.time.format.ISODateTimeFormat;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

/**
 * JsonJodaDateSerializer used to serialize the joda LocalDate into ISODateTimeFormat.
 * by default jackson is not giving the correct format of joda date time,it is giving long value.
 * It converts joda LocalDate object into json.
 */
public class JsonJodaDateSerializer extends JsonSerializer<LocalDate> {

  /**
   * This converts LocalDate into Json String.
   */
  @Override
  public void serialize(final LocalDate date, final JsonGenerator jsonGenerator, final SerializerProvider provider)
      throws IOException {

    jsonGenerator.writeString(ISODateTimeFormat.date().print(date));
  }

}
