package com.iag.business.passenger.repository;


import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.session.AmadeusSession;



/**
 * This class is responsible to call AmadeusMock service.
 */
public interface PassengerRepository {
	
	public Passenger getPassenger(String bookingIdentifier, String passengerIdentifier, AmadeusSession session) ;
}
