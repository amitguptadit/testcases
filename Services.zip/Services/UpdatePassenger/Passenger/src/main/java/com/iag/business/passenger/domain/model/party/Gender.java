package com.iag.business.passenger.domain.model.party;

/**
 * Enum class for storing Gender types. <li>{@link #MALE}</li> <li>{@link #FEMALE}</li> <li>{@link #NOT_SPECIFIED}</li>
 * <li>{@link #NOT_KNOWN}</li>
 */
public enum Gender {
  MALE, FEMALE, NOT_SPECIFIED, NOT_KNOWN
}
