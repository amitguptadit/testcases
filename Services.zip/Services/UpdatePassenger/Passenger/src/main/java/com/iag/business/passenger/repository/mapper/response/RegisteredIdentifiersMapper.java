package com.iag.business.passenger.repository.mapper.response;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.CustomerLevelRegDocs;
import com.amadeus.xml.ccprrr_17_1_1a.DateTimePeriodType;
import com.amadeus.xml.ccprrr_17_1_1a.PlaceLocationIdentificationTypeU93016S;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.location.Location;
import com.iag.business.passenger.domain.model.location.LocationType;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.party.Person.PersonBuilder;
import com.iag.business.passenger.domain.model.party.PersonName;
import com.iag.business.passenger.domain.model.party.PersonName.PersonNameBuilder;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifier;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifierType;

/**
 * This class is used to map registeredIdentifier of passenger from amadeus response to domain model object.
 *
 */
@Component
public class RegisteredIdentifiersMapper {
	
	
	private static final Logger logger = LoggerFactory.getLogger(RegisteredIdentifiersMapper.class);
	
	public List<RegisteredIdentifier<?>> buildRegisteredIdentifiers(
			List<CustomerLevelRegDocs> customerLevelRegDocList) {
	  logger.info("method start: buildRegisteredIdentifiers(), customerLevelRegDocList: {}", customerLevelRegDocList.size());
		String type = null;
		String firstName = null;
		String surname = null;
		String dateTimeDetails = null;
		String locationCode = null;
		String locationType = null;
		LocationType countryType = null;
		String token = null;
		LocalDate expiryDate = null;	
		Person<String> person = null;
		List<RegisteredIdentifier<?>> registeredIdentifiers = new ArrayList<>();

		for (CustomerLevelRegDocs customerLevelRegDocs : customerLevelRegDocList) {
			if (customerLevelRegDocs.getTravelerAndDocumentInfo().getDocumentIdentification() != null) {
				type = customerLevelRegDocs.getTravelerAndDocumentInfo().getDocumentIdentification().getType();///
				token = customerLevelRegDocs.getTravelerAndDocumentInfo().getDocumentIdentification().getNumber();
			}
			List<PlaceLocationIdentificationTypeU93016S> documentIssuingCountryList = customerLevelRegDocs
					.getDocumentIssuingCountry();
			for (PlaceLocationIdentificationTypeU93016S placeLocationIdentificationTypeU93016S : documentIssuingCountryList) {
				locationType = placeLocationIdentificationTypeU93016S.getLocationType();
				if (locationType.equals(PassengerServiceConstants.COUNTRY_CODE)) {
					countryType = LocationType.COUNTRY;
					locationCode = placeLocationIdentificationTypeU93016S.getLocationDescription().getCode();
				}
			}

			List<DateTimePeriodType> documentDate = customerLevelRegDocs.getDocumentDate();
			for (DateTimePeriodType DateTimePeriodType : documentDate) {
				if (DateTimePeriodType.getDateTimeDescription() != null
						&& DateTimePeriodType.getDateTimeDescription().getDateTimeQualifier()
								.equals(PassengerServiceConstants.DATE_TIME_QUALIFIER)
						&& DateTimePeriodType.getDateTimeDescription().getFormat()
								.equals(PassengerServiceConstants.DATE_FORMAT)) {
					dateTimeDetails = DateTimePeriodType.getDateTimeDescription().getDateTimeDetails();///
					DateTimeFormatter formatter = DateTimeFormat.forPattern(PassengerServiceConstants.EXPIRY_DATE_FORMAT);				 
					expiryDate = LocalDate.parse(dateTimeDetails,formatter);						
				}
			}

			if (customerLevelRegDocs.getTravelerAndDocumentInfo().getContactDetails() != null) {
				firstName = customerLevelRegDocs.getTravelerAndDocumentInfo().getContactDetails().getFirstName();
				surname = customerLevelRegDocs.getTravelerAndDocumentInfo().getContactDetails().getSurname();
				PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder(firstName, surname);
				PersonName personName = personNameBuilder.build();
				Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(personName);
				person = personBuilder.build();
			}
			
			Location<String> location = new Location<>();
			location.setLocationIdentifier(locationCode);
			location.setType(countryType);

			RegisteredIdentifier<String> registeredIdentifier = new RegisteredIdentifier<>(token, null,
					getRegisteredIdentifierType(type), location, expiryDate, person);
			registeredIdentifiers.add(registeredIdentifier);
		}
	
		return registeredIdentifiers;

	}

	/**
	 * getRegisteredIdentifierType(): get type of registered identifier.
	 * @param type
	 * @return
	 */
	private RegisteredIdentifierType getRegisteredIdentifierType(String type) {
		RegisteredIdentifierType registeredIdentifierType = null;
		if (type.equals(PassengerServiceConstants.PASSPORT)) {
			registeredIdentifierType = RegisteredIdentifierType.PASSPORT;
		} else if (type.equals(PassengerServiceConstants.IDENTITY_CARD)) {
			registeredIdentifierType = RegisteredIdentifierType.NATIONAL_IDENTITY_CARD;
		} else if (type.equals(PassengerServiceConstants.DRIVING_LICENCE)) {
			registeredIdentifierType = RegisteredIdentifierType.DRIVING_LICENCE;
		} else if (type.equals(PassengerServiceConstants.VISA)) {
			registeredIdentifierType = RegisteredIdentifierType.VISA;
		}
		return registeredIdentifierType;
	}

}
