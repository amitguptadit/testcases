package com.iag.business.passenger.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amadeus.xml.ccprrq_17_1_1a.DCSIDCCPRIdentification;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.proxy.config.ServiceProxy;
import com.iag.business.passenger.repository.mapper.request.PassengerRequestMapper;
import com.iag.business.passenger.repository.mapper.response.PassengerResponseMapper;
import com.iag.business.passenger.session.AmadeusSession;

@Repository
public class PassengerRepositoryImpl implements PassengerRepository {
	private static final Logger logger = LoggerFactory.getLogger(PassengerRepositoryImpl.class);

	@Autowired
	PassengerRequestMapper passengerRequestMapper;

	@Autowired
	PassengerResponseMapper passengerResponseMapper;

	@Autowired
	AmadeusWebServiceGateway amadeusWebServiceGateway;

	@Autowired
	private ServiceProxy configurationInfrastructureServiceProxy;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.iag.business.passenger.repository.PassengerRepository#getPassenger(
	 * java.lang.String, java.lang.String,
	 * com.iag.business.passenger.session.AmadeusSession)
	 */
	@Override
	public Passenger<String> getPassenger(String bookingIdentifier, String passengerIdentifier,
			AmadeusSession session) {
		logger.info("method start: getPassenger(), Booking-Identifier: {}, Passenger-Identifier: {}", bookingIdentifier,
				passengerIdentifier);
		DCSIDCCPRIdentification req = passengerRequestMapper.createRequestBodyForPassenger(bookingIdentifier,
				passengerIdentifier);
		DCSIDCCPRIdentificationReply response = (DCSIDCCPRIdentificationReply) amadeusWebServiceGateway
				.getWebServiceResponseForPassengers(req,
						configurationInfrastructureServiceProxy.retrieveConfiguration(
								PassengerServiceConstants.AMADEUS_NAMESPACE,
								PassengerErrorCode.PASSENGER_SOAP_URL.name()),
						session);
		return passengerResponseMapper.getPassengerAmadeusResponse(response);
	}

}
