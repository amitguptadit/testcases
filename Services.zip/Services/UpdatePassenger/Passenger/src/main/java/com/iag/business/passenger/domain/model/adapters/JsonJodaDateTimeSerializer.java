package com.iag.business.passenger.domain.model.adapters;

import java.io.IOException;

import org.joda.time.LocalDateTime;
import org.joda.time.format.ISODateTimeFormat;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class JsonJodaDateTimeSerializer extends JsonSerializer<LocalDateTime> {

	  /**
	   * This converts LocalDate into Json String.
	   */
	  @Override
	  public void serialize(final LocalDateTime date, final JsonGenerator jsonGenerator, final SerializerProvider provider)
	      throws IOException {
	    jsonGenerator.writeString(ISODateTimeFormat.dateTime().print(date));
	  }

	}

