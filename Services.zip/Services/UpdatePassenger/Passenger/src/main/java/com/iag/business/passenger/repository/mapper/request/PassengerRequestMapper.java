package com.iag.business.passenger.repository.mapper.request;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amadeus.xml.ccprrq_17_1_1a.DCSIDCCPRIdentification;
import com.amadeus.xml.ccprrq_17_1_1a.DCSIDCCPRIdentification.SetOfCriteria;
import com.amadeus.xml.ccprrq_17_1_1a.FlightDetailsQueryType;
import com.amadeus.xml.ccprrq_17_1_1a.ItemReferencesAndVersionsType;
import com.amadeus.xml.ccprrq_17_1_1a.ReservationControlInformationDetailsType;
import com.amadeus.xml.ccprrq_17_1_1a.ReservationControlInformationType;
import com.amadeus.xml.ccprrq_17_1_1a.UniqueIdDescriptionType;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.proxy.config.ServiceProxy;
@Component
public class PassengerRequestMapper {
	private static final Logger LOG = LoggerFactory.getLogger(PassengerRequestMapper.class);
	@Autowired
	private  ServiceProxy configurationInfrastructureServiceProxy;

	/**
	 * Amadeus Request-Body  Mapper For Passenger  
	 * @param bookingIdentifier
	 * @param passengerIdentifier
	 * @return DCSIDCCPRIdentification
	 */

	public DCSIDCCPRIdentification createRequestBodyForPassenger(String bookingIdentifier, String passengerIdentifier)
	{

		LOG.info("PassengerRequestMapper pnr {},passengerIdentifier {} ", bookingIdentifier,passengerIdentifier);
		DCSIDCCPRIdentification dCSIDC_CPRIdentification = new DCSIDCCPRIdentification();
		
		SetOfCriteria setOfCriteria = new SetOfCriteria();
		List<ItemReferencesAndVersionsType> itemReferencesAndVersionsList = new ArrayList<>();

		ItemReferencesAndVersionsType itemReferencesAndVersionsType = new ItemReferencesAndVersionsType();
		UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
		uniqueIdDescriptionType.setReferenceQualifier(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.PASSENGER_REFERENCE_QUALIFIER.name()));
		uniqueIdDescriptionType.setPrimeId(passengerIdentifier);

		itemReferencesAndVersionsType.setIdSection(uniqueIdDescriptionType);
		itemReferencesAndVersionsList.add(itemReferencesAndVersionsType);
		setOfCriteria.setUniqueIdentifier(itemReferencesAndVersionsList);

		ReservationControlInformationType controlInformationType = new ReservationControlInformationType();
		ReservationControlInformationDetailsType controlInformationDetails = new ReservationControlInformationDetailsType();
		controlInformationDetails.setControlNumber(bookingIdentifier);
		controlInformationType.setReservation(controlInformationDetails);
		setOfCriteria.setRecordLocator(controlInformationType);

		FlightDetailsQueryType flight = new FlightDetailsQueryType();
		setOfCriteria.setTravelCriteria(flight);
		List<SetOfCriteria> ListCritera = new ArrayList<>();
		ListCritera.add(setOfCriteria);
		dCSIDC_CPRIdentification.setSetOfCriteria(ListCritera);
		LOG.info("PassengerRequestMapper RequestBody {}",dCSIDC_CPRIdentification.toString());
		return dCSIDC_CPRIdentification;
	}
	
}
