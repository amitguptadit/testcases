package com.iag.business.passenger.domain.model.party;

import java.io.Serializable;

import javax.validation.Valid;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.iag.business.passenger.domain.model.utility.ToStringBuilder;


/**
 * Party class provides a prototype for types of customers. Such as Person, Organization
 * @param <K> id for the Party.
 * @param addresses : list of all types of addresses such as EmailAddress,PostalAddress, TelecomAddress etc.
 * @param preferences : list of all sort of preferences for this party.
 */
@SuppressWarnings("serial")
//@XmlSeeAlso({ Person.class, Organisation.class })
/*@JsonTypeInfo(use = JsonTypeInfo.Id.NAME,
    include = JsonTypeInfo.As.PROPERTY,
    property = "type")*/
@JsonSubTypes({
    @JsonSubTypes.Type(value = Person.class, name = "person")    
})
@JsonInclude(Include.NON_EMPTY)
public abstract class Party<K> implements Serializable {
  @Valid
  //private List<Address> addresses;
  private K id;
 // private Collection<Preference> preferences;

  /**
   * @return addresses as list of <code>Address</code>.
   */
 /* public List<Address> getAddresses() {
    return addresses;
  }*/

  /**
   * @return id as K.
   */
  public K getId() {
    return id;
  }

  /**
   * @param addresses as list of <code>Address</code>.
   */
  /*public void setAddresses(final List<Address> addresses) {
    this.addresses = addresses;
  }*/

  /**
   * @param id as K.
   */
  public void setId(final K id) {
    this.id = id;
  }

  /**
   * @return preferences as <code>Collection</code>
   */
  /*public Collection<Preference> getPreferences() {
    return preferences;
  }*/

  /**
   * @param preferences
   */
  /*public void setPreferences(final Collection<Preference> preferences) {
    this.preferences = preferences;
  }*/

  @Override
  public int hashCode() {
    return HashCodeBuilder.reflectionHashCode(this);
  }

  @Override
  public boolean equals(final Object obj) {
    return EqualsBuilder.reflectionEquals(this, obj);
  }

  @Override
  public String toString() {
    return ToStringBuilder.generateToString(this);
  }
}
