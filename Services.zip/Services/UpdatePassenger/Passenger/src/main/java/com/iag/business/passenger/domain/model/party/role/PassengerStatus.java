package com.iag.business.passenger.domain.model.party.role;

public enum PassengerStatus {

    CHECKEDIN,
    NOTCHECKEDIN,
    STANDBY
    
}
