package com.iag.business.passenger.domain.model.location;

public enum LocationType {
  COUNTRY,STATE,COUNTY,CITY,AIRPORT,STATION
}
