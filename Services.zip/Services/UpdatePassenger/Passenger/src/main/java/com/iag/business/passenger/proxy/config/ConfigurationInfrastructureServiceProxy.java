package com.iag.business.passenger.proxy.config;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.iag.application.exception.ApplicationServiceException;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.proxy.config.domain.Configuration;
import com.iag.business.passenger.proxy.config.domain.ConfigurationNamespace;


/**
 * 
 * This is proxy class to invoke configuration infrastructure service.
 * 
 */
@Component
public class ConfigurationInfrastructureServiceProxy implements ServiceProxy {

	private static final Logger logger = LoggerFactory.getLogger(ConfigurationInfrastructureServiceProxy.class);
	
	private final Map<String, String> serviceConfigMap = new HashMap<>();
	private final Map<String, Map<String, String>> configNamespacesMap = new ConcurrentHashMap<>();
	private final String configPath;
	private final RestTemplate restTemplate;

	@Autowired
	public ConfigurationInfrastructureServiceProxy(@Value("${config.url}") final String configPath,
			final RestTemplate restTemplate) {
		this.configPath = configPath;
		this.restTemplate = restTemplate;
	  }

	@Override
	public String retrieveConfiguration(String configurationName, String key) {
		logger.info("start method:retrieveConfiguration(), key: {}", key);
		if (!configNamespacesMap.isEmpty()){
			return configNamespacesMap.get(configurationName).get(key);
		}
		else {
			ResponseEntity<Configuration> configurationResponse;
			configurationResponse = restTemplate.exchange(configPath, HttpMethod.GET, null, Configuration.class);
			if (configurationResponse == null || !configurationResponse.getStatusCode().is2xxSuccessful()) {
				logger.error("response status is invalid.");
				throw new ApplicationServiceException(PassengerErrorCode.SYSTEM_UNAVAILABLE.name());
			}
			retrievePassengerConfiguration(configurationResponse.getBody());
			return configNamespacesMap.get(configurationName).get(key);
		}

	}
	
	/**
	 * @param configuration
	 * @return
	 */
	private void retrievePassengerConfiguration(Configuration configuration) {
		List<ConfigurationNamespace> configurationList = configuration.getConfigurationNamespaces();
		for (ConfigurationNamespace configurationNamespaces : configurationList) {			
			configurationNamespaces.getConfigurationItems().forEach(configurationItem -> {
				serviceConfigMap.put(configurationItem.getIdentifier(), configurationItem.getValue());
			});			
			configNamespacesMap.put(configurationNamespaces.getName(), serviceConfigMap);
			Collections.unmodifiableMap(configNamespacesMap);
		}
	}

	
	
}
