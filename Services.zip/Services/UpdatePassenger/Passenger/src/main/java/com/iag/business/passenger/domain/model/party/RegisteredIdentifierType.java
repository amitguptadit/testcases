package com.iag.business.passenger.domain.model.party;

/**
 * Enum class for storing types of identifiers. <li>{@link #PASSPORT}</li> <li>{@link #IDENTITY_CARD}</li> <li>
 * {@link #DRIVING_LICENCE}</li> <li>{@link #NATIONAL_INSURANCE_CARD}</li>
 */
public enum RegisteredIdentifierType {
  PASSPORT, NATIONAL_IDENTITY_CARD, DRIVING_LICENCE, NATIONAL_INSURANCE_CARD, VISA

}
