package com.iag.business.passenger.repository;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapMessage;

/**
 * AmadeusHeaderClientInterceptor class is responsible for generating SOAP
 * request header. remove this class once Amadeus resp.come properly 
 */
public class AmadeusHeaderClientInterceptor implements ClientInterceptor {

	private static final Logger LOG = LoggerFactory.getLogger(AmadeusHeaderClientInterceptor.class);
	private static final String SESSION_SPACE_URI = "http://xml.amadeus.com/ws/2009/01/WBS_Session-2.0.xsd";

	// @Value("${amadeus.connector.web.service.default.url}")
	// private String
	// amadeusConnectorWebServiceDefaultURI="https://nodeA1.test.webservices.amadeus.com/1ASIWAVIBA";

	@Override
	public boolean handleFault(final MessageContext messageContext) {
		//logRequestResponse("AmadeusHeaderClientInterceptor fault", messageContext);
		return true;
	}

	/**
	 * This method is to intercept the webservice request and create a soap header
	 * into it.
	 */
	@Override
	public boolean handleRequest(final MessageContext messageContext) {
		SoapMessage soapMessage = (SoapMessage) messageContext.getRequest();

		try {
			///createSoapHeaderInfo(soapMessage);
			System.out.println("creating the soap header");
			System.out.println("### SOAP REQUEST ###");
			try {
				ByteArrayOutputStream buffer = new ByteArrayOutputStream();
				messageContext.getRequest().writeTo(buffer);
				String payload = buffer.toString(java.nio.charset.StandardCharsets.UTF_8.name());
				System.out.println((payload));
			} catch (IOException e) {
				throw new WebServiceClientException("Can not write the SOAP request into the out stream", e) {
					private static final long serialVersionUID = -7118480620416458069L;
				};
			}

		} catch (Exception e) {
			System.out.println(
					"Error while creating the soap header in handleRequest() in AmadeusHeaderClientInterceptor");
			LOG.error("Error while creating the soap header in handleRequest() in AmadeusHeaderClientInterceptor : {}",
					e);
			return false;
		}

		// AmadeusLogging amadeusLogging = AmadeusWSContext.get();
		// if (amadeusLogging == null) {
		// amadeusLogging = new AmadeusLogging();
		// }
		// amadeusLogging.setAmadeusWSStartTime(System.currentTimeMillis());
		// AmadeusWSContext.set(amadeusLogging);
		return true;
	}
	// @Override
	// public boolean handleResponse(final MessageContext messageContext) {
	// if (AmadeusWSContext.get() != null) {
	// AmadeusWSContext.get().setAmadeusInteractionTime(System.currentTimeMillis()
	// - AmadeusWSContext.get().getAmadeusWSStartTime());
	// LOG.info("Amadeus Execution Time for the call:{}", System.currentTimeMillis()
	// - AmadeusWSContext.get().getAmadeusWSStartTime());
	// }
	// return true;
	// }



//	/**
//	 * This method is to get soap action which identifies the semantics implied by
//	 * this message.
//	 */
//	private String getSoapAction(final SoapMessage soapMessage) {
//		String quotes = "\"";
//		String soapAction = soapMessage.getSoapAction().trim();
//		if (soapAction.contains(quotes)) {
//			soapAction = soapAction.replaceAll(quotes, "");
//		}
//		return soapAction;
//	}
//
//	private String getAviosSessionID() {
//		String aviosSessionID = null;
//		aviosSessionID = "1234";
//		if (aviosSessionID.contains("!")) {
//			aviosSessionID = aviosSessionID.substring(0, aviosSessionID.indexOf('!'));
//		}
//		return aviosSessionID;
//	}

	public void afterCompletion(MessageContext arg0, Exception arg1) throws WebServiceClientException {

		System.out.println("completed");
		// No-op
	}

	@Override
	public boolean handleResponse(MessageContext messageContext) throws WebServiceClientException {
		try {
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();
			messageContext.getResponse().writeTo(buffer);
			String payload = buffer.toString(java.nio.charset.StandardCharsets.UTF_8.name());
			System.out.println((payload));
		} catch (IOException e) {
			throw new WebServiceClientException("Can not write the SOAP response into the out stream", e) {
				private static final long serialVersionUID = -7118480620416458069L;
			};
		}

		return true;
	}

}
