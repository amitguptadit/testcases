
package com.iag.business.passenger.domain.model.party;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iag.business.passenger.domain.model.utility.ToStringBuilder;



/**
 * The region/area where this identifier is valid.
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "type",
    "identifier"
})
public class AreaOfApplicability {

    /**
     * COUNTY, COUNTRY of the area/region.
     * (Required)
     * 
     */
    @JsonProperty("type")
    @JsonPropertyDescription("COUNTY, COUNTRY of the area/region.")
    private String type;
    /**
     * Identifier of the region/area.
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    @JsonPropertyDescription("Identifier of the region/area.")
    private String identifier;
    
    /**
     * COUNTY, COUNTRY of the area/region.
     * (Required)
     * 
     */
    @JsonProperty("type")
    public String getType() {
        return type;
    }

    /**
     * COUNTY, COUNTRY of the area/region.
     * (Required)
     * 
     */
    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }
 
    /**
     * Identifier of the region/area.
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    public String getIdentifier() {
        return identifier;
    }

    /**
     * Identifier of the region/area.
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    @Override
    public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {
      return ToStringBuilder.generateToString(this);
    }



}
