package com.iag.business.passenger.validation;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.exception.ValidationServiceExceptionGenerator;


/**
 * This is validator class which is used to collect different request validations.
 *
 */
@Component
public class UpdatePassengerValidator {
	private static final Logger logger = LoggerFactory.getLogger(UpdatePassengerValidator.class);
	private final BookingIdentifierValidation bookingIdentifierValidation;
	private final PassengerIdentifierValidation passengerIdentifierValidation;
	private final HeaderValidation headerValueMapValidation;
	private final PassengerFieldsValidation passengerFieldsValidation;
	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	/**
	 * @param bookingIdentifierValidation
	 * @param passengerIdentifierValidation
	 * @param passenger
	 * @param validationServiceExceptionGenerator
	 */
	@Autowired
	public UpdatePassengerValidator(final BookingIdentifierValidation bookingIdentifierValidation,
			PassengerIdentifierValidation passengerIdentifierValidation,PassengerFieldsValidation passengerFieldsValidation, HeaderValidation headerValueMapValidation,
			ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.bookingIdentifierValidation = bookingIdentifierValidation;
		this.passengerIdentifierValidation = passengerIdentifierValidation;
		this.passengerFieldsValidation = passengerFieldsValidation;
		this.headerValueMapValidation = headerValueMapValidation;
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * @param bookingIdentifier
	 * @param passengerIdentifier
	 * @param passenger 
	 * @param headerValueMap
	 * @throws IOException 
	 * @throws JSONException 
	 */
	public void validate(final String bookingIdentifier, final String passengerIdentifier,
			Passenger passenger, final Map<String, String> headerValueMap) {
		logger.info("start method:validate()");
		List<ValidationServiceException> validationServiceExceptionlist = Lists.newArrayList();
		validationServiceExceptionlist.add(bookingIdentifierValidation.validate(bookingIdentifier));
		validationServiceExceptionlist.add(passengerIdentifierValidation.validate(passengerIdentifier));
		validationServiceExceptionlist.add(headerValueMapValidation.validate(headerValueMap));
		validationServiceExceptionlist.add(passengerFieldsValidation.validate(passenger));
		validationServiceExceptionlist.removeAll(Collections.singleton(null));
		if (!validationServiceExceptionlist.isEmpty()) {
			logger.error("Request validation exception occured.");
			throw validationServiceExceptionGenerator
					.createServiceExceptionWithChildError(validationServiceExceptionlist);
		}
		logger.info("end method:validate()");

	}

}
