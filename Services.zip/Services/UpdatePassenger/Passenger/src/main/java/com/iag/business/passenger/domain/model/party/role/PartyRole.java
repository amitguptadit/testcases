package com.iag.business.passenger.domain.model.party.role;

import javax.validation.Valid;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.iag.business.passenger.domain.model.party.Party;
import com.iag.business.passenger.domain.model.utility.ToStringBuilder;



/**
 * {@link PartyRole} is a type of role which is taken on by a {@link Party}. For e.g. A Member is a role which is taken
 * by a Person. RedemptionSupplier is a role taken on by an Organisation etc.
 * @param <K> : Identifier for the PartyRole.
 * @param party : {@link Party} class provides a prototype for types of customers.
 * @param profiles : a list of profiles associated with this role.
 */
/*@JsonTypeInfo(use = JsonTypeInfo.Id.NAME,
    include = JsonTypeInfo.As.PROPERTY,
    property = "type")*/
@JsonSubTypes({
    @JsonSubTypes.Type(value = AssociatedPassenger.class, name = "associatedPassenger"),
    @JsonSubTypes.Type(value = EmergencyContact.class, name = "emergencyContact"),
    @JsonSubTypes.Type(value = Passenger.class, name = "passenger"),
})
@JsonInclude(Include.NON_EMPTY)
public abstract class PartyRole<K> {
  /*@JsonTypeInfo(use = JsonTypeInfo.Id.MINIMAL_CLASS,
      include = JsonTypeInfo.As.PROPERTY,
      property = "type")*/
  @JsonProperty("identifier")
  private String identifier;
  @Valid
  private Party<?> party;
  //private List<Profile<?>> profiles;

  public String getIdentifier() {
    return identifier;
  }

  public void setIdentifier(final String string) {
    this.identifier = string;
  }

  public Party<?> getParty() {
    return party;
  }

  public void setParty(final Party<?> party) {
    this.party = party;
  }

  /*public List<Profile<?>> getProfiles() {
    return profiles;
  }

  public void setProfiles(final List<Profile<?>> profiles) {
    this.profiles = profiles;
  }
*/
  @Override
  public int hashCode() {
    return HashCodeBuilder.reflectionHashCode(this);
  }

  @Override
  public boolean equals(final Object obj) {
    return EqualsBuilder.reflectionEquals(this, obj);
  }

  @Override
  public String toString() {
    return ToStringBuilder.generateToString(this);
  }
}
