package com.iag.business.passenger.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.domain.model.party.role.PassengerType;
import com.iag.business.passenger.domain.resource.PassengerResource;
import com.iag.business.passenger.service.PassengerService;
import com.iag.business.passenger.session.AmadeusSession;
import com.iag.business.passenger.validation.PassengerValidator;


/**
 *PassengerController provides interface for passenger related operations like passengerIdentifier,bookingIdentifier.
 */
@RestController
public class PassengerController {

	private static final Logger logger = LoggerFactory.getLogger(PassengerController.class);

	private PassengerService passengerService;

	private PassengerValidator passengerValidator;

	private AmadeusSession amadeusSession;

	@Autowired
	public PassengerController(PassengerService passengerService, PassengerValidator passengerValidator,
			AmadeusSession amadeusSession) {
		this.passengerService = passengerService;
		this.passengerValidator = passengerValidator;
		this.amadeusSession = amadeusSession;
	}

	/**
	 * This method is responsible to retrieve a Passenger information and
	 * details are retrieved on the basis of booking and Passenger information.
	 * 
	 * @param PassengerId
	 * @param BookingIdentifier
	 * @param requestHeaderMap
	 */
	@GetMapping(value = "/bookings/{" + PassengerServiceConstants.BOOKING_IDENTIFIER + "}" + "/passengers" + "/{"
			+ PassengerServiceConstants.PASSENGER_IDENTIFIER
			+ "}", produces = { PassengerServiceConstants.HAL_JSON_VALUE })
	public ResponseEntity<PassengerResource<Passenger>> getPassenger(
			@PathVariable(value = "booking-identifier") String bookingIdentifier,
			@PathVariable(value = "passenger-identifier") String passengerIdentifier,
			@RequestHeader final Map<String, String> headerValueMap) throws Exception {
		logger.info("method start: getPassenger(), Booking-Identifier: {}, Passenger-Identifier: {}", bookingIdentifier,
				passengerIdentifier);
		passengerValidator.validate(bookingIdentifier, passengerIdentifier, headerValueMap);
		amadeusSession = populateHeader(headerValueMap);
		Passenger<String> passenger = passengerService.getPassenger(bookingIdentifier, passengerIdentifier, amadeusSession);
		PassengerResource<Passenger> passengerResource = new PassengerResource<>(passenger);
		createHateoasLinks(bookingIdentifier, passengerIdentifier, headerValueMap, passengerResource);
		logger.info("method End: getPassenger()");
		return new ResponseEntity<>(passengerResource, HttpStatus.OK);
	}

	/**
	 * Method to create hateoas links.
	 * 
	 * @param bookingIdentifier
	 * @param passengerIdentifier
	 * @param headerValueMap
	 * @param passenger
	 * @throws Exception
	 */
	private void createHateoasLinks(String bookingIdentifier, String passengerIdentifier,
			final Map<String, String> headerValueMap, PassengerResource<Passenger> passengerResource) throws Exception {
		passengerResource.add(linkTo(methodOn(PassengerController.class).getPassenger(bookingIdentifier,
				passengerIdentifier, headerValueMap)).withSelfRel());
		passengerResource.add(linkTo(PassengerController.class).slash(PassengerServiceConstants.BOOKINGS)
				.slash(bookingIdentifier).withRel(PassengerServiceConstants.BOOKING));
		passengerResource.add(
				linkTo(PassengerController.class).slash(PassengerServiceConstants.BOOKINGS).slash(bookingIdentifier)
						.slash(PassengerServiceConstants.PASSENGERS).withRel(PassengerServiceConstants.ALL_PASSENGERS));
		if (passengerResource.getPassenger().getType().equals(PassengerType.INFANT))
			passengerResource.add(linkTo(methodOn(PassengerController.class).getPassenger(bookingIdentifier,
					passengerResource.getPassenger().getAssociatedPassenger().getIdentifier(), headerValueMap))
							.withRel(PassengerServiceConstants.ASSOCIATED_PASSENGER));
	}

	/**
	 * populateHeader method used to populate amadeaus session from header
	 * 
	 * @param headerValueMap
	 * @return
	 */
	private AmadeusSession populateHeader(final Map<String, String> headerValueMap) {
		amadeusSession.setSessionId(headerValueMap.get(PassengerServiceConstants.SESSIONID));
		amadeusSession.setSequenceNumber(headerValueMap.get(PassengerServiceConstants.SEQUENCENUMBER));
		amadeusSession.setSecurityToken(headerValueMap.get(PassengerServiceConstants.SECURITY_TOKEN));
		amadeusSession.setLocation(headerValueMap.get(PassengerServiceConstants.LOCATION));
		amadeusSession.setChannel(headerValueMap.get(PassengerServiceConstants.CHANNEL));
		amadeusSession.setScope(headerValueMap.get(PassengerServiceConstants.SCOPE));
		return amadeusSession;
	}

}

	