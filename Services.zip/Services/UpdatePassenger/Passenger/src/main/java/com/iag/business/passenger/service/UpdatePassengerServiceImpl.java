package com.iag.business.passenger.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.repository.UpdatePassengerAmadeusRepositoryImpl;
import com.iag.business.passenger.session.AmadeusSession;

/**
 * This class implements methods defined in interface UpdatePassengerService.
 */

@Service
public class UpdatePassengerServiceImpl implements UpdatePassengerService {
	private static final Logger logger = LoggerFactory.getLogger(UpdatePassengerServiceImpl.class);
	private UpdatePassengerAmadeusRepositoryImpl updatePassengerAmadeusRepository;

	@Autowired
	public UpdatePassengerServiceImpl(UpdatePassengerAmadeusRepositoryImpl updatePassengerAmadeusRepository) {
		this.updatePassengerAmadeusRepository = updatePassengerAmadeusRepository;
	}
	
	/**
	 * This method is responsible for update passenger related information
	 * 
	 * @see com.iag.business.passenger.service.UpdatePassengerService#updatePassenger(java.lang.String,
	 *      java.lang.String, com.iag.business.passenger.domain.Passenger,com.iag.business.passenger.domain.AmadeusSession)
	 */

	@Override
	public void updatePassenger(String bookingIdentifier, Passenger passenger,
			AmadeusSession session) {
		logger.info("method start: updatePassenger()");
		updatePassengerAmadeusRepository.updatePassenger(bookingIdentifier,passenger,session);
		logger.info("method end: updatePassenger()");
	}
}
