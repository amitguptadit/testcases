package com.iag.business.passenger.domain.model;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iag.business.passenger.domain.model.utility.ToStringBuilder;



/**
 *  DangerousGoods.
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "isPresented",
    "isConfirmed"
})
public class DangerousGoods {
	    /**
	     * 
	     * (Required)
	     * 
	     */
	    @JsonProperty("isPresented")
	    private Boolean isPresented;
	    
	    /**
	     * 
	     * (Required)
	     * 
	     */
	    @JsonProperty("isConfirmed")
	    private Boolean isConfirmed;
	    
	    
	    /**
	     * 
	     * (Required)
	     * 
	     */
	    @JsonProperty("isPresented")
	    public Boolean getIsPresented() {
	        return isPresented;
	    }

	    /**
	     * 
	     * (Required)
	     * 
	     */
	    @JsonProperty("isPresented")
	    public void setIsPresented(Boolean isPresented) {
	        this.isPresented = isPresented;
	    }

	    
	    /**
	     * 
	     * (Required)
	     * 
	     */
	    @JsonProperty("isConfirmed")
	    public Boolean getIsConfirmed() {
	        return isConfirmed;
	    }

	    /**
	     * 
	     * (Required)
	     * 
	     */
	    @JsonProperty("isConfirmed")
	    public void setIsConfirmed(Boolean isConfirmed) {
	        this.isConfirmed = isConfirmed;
	    }

	    
	    @Override
	    public int hashCode() {
	      return HashCodeBuilder.reflectionHashCode(this);
	    }

	    @Override
	    public boolean equals(final Object obj) {
	      return EqualsBuilder.reflectionEquals(this, obj);
	    }

	    @Override
	    public String toString() {
	      return ToStringBuilder.generateToString(this);
	    }



}
