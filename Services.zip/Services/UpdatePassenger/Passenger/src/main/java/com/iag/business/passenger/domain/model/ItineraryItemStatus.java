package com.iag.business.passenger.domain.model;

public enum ItineraryItemStatus {

    CONFIRMED,
    UNCONFIRMED,
    DELAYED


}