package com.iag.business.passenger.exception;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.proxy.config.ServiceProxy;


/**
 * Class to create ServiceException.
 */
@Component
public class ValidationServiceExceptionGenerator {

	@Autowired
	private ServiceProxy configurationInfrastructureServiceProxy;

	/**
	 * constructor method.
	 * 
	 * @param configurationInfrastructureServiceProxy
	 */

	@Autowired
	public ValidationServiceExceptionGenerator(final ServiceProxy configurationInfrastructureServiceProxy) {
		this.configurationInfrastructureServiceProxy = configurationInfrastructureServiceProxy;
	}

	/**
	 * This method is used to create validationServiceExceptionList.
	 * 
	 * @param serviceErrorCode
	 * @param path
	 * @param developerMessage
	 * @return
	 */
	public ValidationServiceException createValidationError(final String serviceErrorCode, final String path,
			final String developerMessage) {
		ValidationServiceException validationServiceException = new ValidationServiceException(serviceErrorCode);
		validationServiceException.setPath(path);
		validationServiceException.setDeveloperMessage(getMessageConfigurationValue(developerMessage));
		return validationServiceException;
	}
	

	/**
	 * Method to create ValidationServiceException with child errors.
	 * 
	 * @param validationServiceExceptionList
	 * @return
	 */
	public ValidationServiceException createServiceExceptionWithChildError(
			final List<ValidationServiceException> validationServiceExceptionList) {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name());
		for (ValidationServiceException childValidationServiceException : validationServiceExceptionList) {
			validationServiceException.addValidationException(childValidationServiceException);
		}
		return validationServiceException;
	}

	/**
	 * Method to create Service exception with path, error code and developer
	 * message.
	 * 
	 * @param errorCode
	 * @param errorPath
	 * @param developerMessage
	 * @return
	 */
	public ValidationServiceException createServiceException(final String errorCode, final String errorPath,
			final String developerMessage) {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name());
		validationServiceException
				.addValidationException(createValidationError(errorCode, errorPath, developerMessage));
		return validationServiceException;
	}
	
	

	/**
	 * Function to get the message based on the message key.
	 * 
	 * @param key
	 * @return
	 */
	public String getMessageConfigurationValue(final String key) {
		if (!StringUtils.EMPTY.equals(StringUtils.trimToEmpty(key))) {
			return configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.ERROR_NAMESPACE,key);
		}
		return StringUtils.EMPTY;
	}
}
