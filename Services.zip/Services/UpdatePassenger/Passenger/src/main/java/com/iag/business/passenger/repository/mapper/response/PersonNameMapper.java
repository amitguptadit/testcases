package com.iag.business.passenger.repository.mapper.response;

import org.springframework.stereotype.Component;

import com.iag.business.passenger.domain.model.party.PersonName;
import com.iag.business.passenger.domain.model.party.PersonName.PersonNameBuilder;
/**
 * This class is used to map personName of person.
 *
 */
@Component
public class PersonNameMapper {

	public PersonName buildPersonName(String firstName, String surName, String title) {
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder(firstName, surName);
		personNameBuilder.setTitle(title);
		PersonName personName = personNameBuilder.build();
		return personName;

	}

}
