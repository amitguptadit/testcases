package com.iag.business.passenger.constant;

public final class  PassengerServiceConstants {
	
	private PassengerServiceConstants(){}	
	
	public static final String BOOKING_IDENTIFIER = "booking-identifier";
	public static final String PASSENGER_IDENTIFIER = "passenger-identifier";	
	public static final String BOOKINGS = "bookings";
	public static final String BOOKING = "booking";
	public static final String PASSENGERS = "passengers";
	public static final String ALL_PASSENGERS = "AllPassengers";
	public static final String MESSAGE_CONFIGURATION_KEYWORD = "msg-";
	public static final String KEY_SEPARATOR_DOT = ".";
	public static final String KEY_SEPARATOR = "-";
	public static final String NAMESPACE = "passenger_";
	public static final String MOCK_RESPONSE= "mock_response";
	public static final String SLASH = "/";
	public static final String JSON = ".json";
	public static final String BOOKINGIDENTIFER = "[a-zA-Z0-9]{1,20}";
	public static final String BOOKINGIDENTIFER_PATH = "booking-identifier";
	public static final String DEVMSG_BOOKINGIDENTIFER = ".developer_message_bookingidentifier";	
	public static final String PASSENGERIDENTIFIER_PATH = "passenger-identifier";
	public static final String DEVMSG_PASSENGERIDENTIFER = ".developer_message_passengeridentifier";
	public static final String DEVMSG_HEADERVALUE = ".developer_message_headervalue";
	public static final String HEADERVALUE_PATH = "headervalue";
	public static final String PASSENGER_PATH = "passengervalue";
	public static final String PASSENGERIDENTIFIER = "[a-zA-Z0-9]{1,16}";
	public static final String CONFIG_CACHE = "errorConfiguration";
	public static final String HAL_JSON_VALUE = "application/hal+json";
	public static final String ASSOCIATED_PASSENGER = "AssociatedPassenger";
	public static final String SCOPE = "scope";
	public static final String CHANNEL = "channel";
	public static final String LOCATION = "location";
	public static final String SESSIONIDENTIFIER = "sessionidentifier";
    public static final String TOKENNUMBER = "tokennumber";
	public static final String GETPASSENGERS_MOCK_RESPONSE = "getpassengers_mock_response";
	public static final String SELECTION_DETAILS_INFORMATION_OPTION = "ILK";
	public static final String REFERENCE_QUALIFIER= "UCI";
	public static final String SOAP_URL= "http://webservices.amadeus.com/1ASIWIAGBA/CCPRRQ_17_1_1A";
	public static final int HTTP_SENDER_READ_TIME_OUT = 10000;
	public static final int HTTP_SENDER_CONNECTOR_TIME_OUT = 100000;
    public static final String HTTP_SENDER_MAX_HOSTS = "5";
    public static final String HTTP_SENDER_WILDCARD_HOSTS = "*";
	public static final String AMADEUS_GATEWAY_WEBURL = "amedeus.gateway.webUrl";
    public static final String AMADEUS_PASSENGER_MARSHALLER = "amedeus.gateway.passenger.marshaller";
    public static final String AMADEUS_PASSENGER_UNMARSHALLER = "amedeus.gateway.passenger.unMarshaller";
    public static final String AMADEUS_PASSENGERS_MARSHALLER = "amedeus.gateway.passengers.marshaller";
    public static final String AMADEUS_PASSENGERS_UNMARSHALLER = "amedeus.gateway.passengers.unMarshaller";
    public static final String UPDATE_SOAP_URL = "http://webservices.amadeus.com/1ASIWIAGBA/CCPRUQ_16_6_1A";
    public static final String PASSENGER_MARSHALLER = "com.amadeus.xml.ccprrq_17_1_1a";
	public static final String PASSENGER_UNMARSHALLER = "com.amadeus.xml.ccprrr_17_1_1a";
	public static final String UPDATE_PASSENGER_MARSHALLER = "com.amadeus.xml.ccpruq_16_6_1a";
	public static final String UPDATE_PASSENGER_UNMARSHALLER = "com.amadeus.xml.ccprur_16_6_1a";
	public static final String DEFAULT_URL = "https://BAaccess.test.webservices.1a.amadeus.com:52069";
	public static final String SESSIONID = "sessionid";
	public static final String SEQUENCENUMBER= "sequencenumber";
	public static final String SECURITY_TOKEN ="securitytoken";
	
	public static final String FLIGHT_SEGMENT_STATUS ="HK,TK,HL,SA,KK,KL,TL";
	
	public static final String ERROR_NAMESPACE = "Error";
	
	public static final String AMADEUS_NAMESPACE = "AmadeusConnectivity";
	
	public static final String PASSENGER_ELIGIBILITIES_NAMESPACE = "PassengerEligibilities";
	
	public static final String FLIGHT_LEG_ARRIVAL_STA = "STA";
	
	public static final String FLIGHT_LEG_DEPARTURE_STD = "STD";
	
	public static final String PPI = "PPI";
	
	public static final String CST = "CST";
	public static final String CNC = "CNC";
	public static final String CAC = "CAC";
	public static final String ADDRESS_QUALIFIER = "80";
	
	public static final String DECLINED = "1";
	public static final String NOT_DECLINED = "0";
	public static final String DCL = "DCL";
	public static final String FEMALE = "F";
	public static final String MALE = "M";
	public static final String COUNTRY_CODE = "91";  
	public static final String VISA = "V";
	public static final String DRIVING_LICENCE = "D";
	public static final String IDENTITY_CARD = "I";
	public static final String PASSPORT = "P";
	public static final String INFANT = "IN";
	public static final String CHILD = "C";
	public static final String ADULT = "A";
	public static final String ASSOCIATED_PASSENGER_QUALIFIER = "JID";
	public static final String DATE_FORMAT = "102";
	public static final String DATE_TIME_QUALIFIER = "192";
	public static final String PASSENGER_CABIN_CLASS_ECONOMY = "passenger_cabin_class_economy";
	public static final String PASSENGER_CABIN_CLASS_PREMIUM_ECONOMY = "passenger_cabin_class_premium_economy";
	public static final String PASSENGER_CABIN_CLASS_BUSINESS = "passenger_cabin_class_business";
	public static final String EXPIRY_DATE_FORMAT = "yyyyMMdd";
	public static final String UNDERSCORE = "_";
	
	//Added by Manoj
	public static final String REFERENCE_IDENTIFIER = "DID";
	public static final String DATETIME_QUALIFIER = "273";
	public static final String DATETIMEDESCRIPTION_FORMAT = "711";
	public static final String LOCATION_TYPE = "91";
	public static final String LOCATION_QUALIFIER = "162";
	public static final String LOCATION_DETAILS_QUALIFIER = "227";
	public static final String TRAVELER = "FL";
	public static final String INDICATOR = "DRD";
	public static final String ACTION = "0";
	public static final String NATIONALITY_INDICATOR = "NAT";
	public static final String NATIONALITY_ACTION = "0";
	public static final String CODE_QUALIFIER = "2";
	public static final String HOME_DESTINATION_ACTION = "UAD";
	public static final String HOME_DESTINATION_INDICATOR = "0";
	public static final String ADDRESS_LOCATION_TYPE = "80";
	public static final String EMERGENCY_CONTACT_ACTION = "0";
	public static final String EMERGENCY_CONTACT_INDICATOR = "DEC";
	public static final String EMERGENCY_STATUS_CONTACT_INDICATOR = "DCL";

}
