package com.iag.business.passenger.repository.mapper.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.amadeus.xml.ccprrr_17_1_1a.AdditionalProductDetailsTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.CabinClassDesignationType68442C;
import com.amadeus.xml.ccprrr_17_1_1a.CabinDetailsType40636S;
import com.amadeus.xml.ccprrr_17_1_1a.CodedAttributeInformationType208434C;
import com.amadeus.xml.ccprrr_17_1_1a.CodedAttributeType214203S;
import com.amadeus.xml.ccprrr_17_1_1a.CommercialAgreementsType;
import com.amadeus.xml.ccprrr_17_1_1a.CompanyRoleIdentificationType;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel.AddressDetailsGroup;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel.CandidateETickets;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel.LegLevel;
import com.amadeus.xml.ccprrr_17_1_1a.FacilityInformationType171568C;
import com.amadeus.xml.ccprrr_17_1_1a.FlightDetailsResponseType;
import com.amadeus.xml.ccprrr_17_1_1a.ItemReferencesAndVersionsType146132S;
import com.amadeus.xml.ccprrr_17_1_1a.NameAndAddressBatchType;
import com.amadeus.xml.ccprrr_17_1_1a.OutboundCarrierDetailsTypeI166697C;
import com.amadeus.xml.ccprrr_17_1_1a.OutboundFlightNumberDetailstypeI139968C;
import com.amadeus.xml.ccprrr_17_1_1a.PlaceLocationIdentificationType203606S;
import com.amadeus.xml.ccprrr_17_1_1a.RelatedProductInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.SpecialRequirementsDataDetailsType;
import com.amadeus.xml.ccprrr_17_1_1a.SpecialRequirementsDetailsType198190S;
import com.amadeus.xml.ccprrr_17_1_1a.StationInformationTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.StatusDetailsType;
import com.amadeus.xml.ccprrr_17_1_1a.StatusDetailsType233068C;
import com.amadeus.xml.ccprrr_17_1_1a.StatusType151539S;
import com.amadeus.xml.ccprrr_17_1_1a.StatusType208180S;
import com.amadeus.xml.ccprrr_17_1_1a.StreetType;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeType18904C;
import com.amadeus.xml.ccprrr_17_1_1a.TerminalLocationType116626S;
import com.amadeus.xml.ccprrr_17_1_1a.TicketNumberDetailsTypeI19962C;
import com.amadeus.xml.ccprrr_17_1_1a.TicketNumberTypeI8732S;
import com.amadeus.xml.ccprrr_17_1_1a.UniqueIdDescriptionType;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.Itinerary;
import com.iag.business.passenger.domain.model.ItineraryItemStatus;
import com.iag.business.passenger.domain.model.party.role.PassengerStatus;
import com.iag.business.passenger.proxy.config.ServiceProxy;


public class ItenaryMapperTest {
	
	ItineraryMapper itineraryMapper;
	
	@Mock
	private ServiceProxy configurationInfrastructureServiceProxy;


	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		itineraryMapper = new ItineraryMapper();
		ReflectionTestUtils.setField(itineraryMapper, "configurationInfrastructureServiceProxy",configurationInfrastructureServiceProxy);
	}

	@Test
	public void getPassengerWithItenaryDetails() {
		List<ProductLevel> productLevelList = populateItineraryItems();
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE, PassengerServiceConstants.PASSENGER_CABIN_CLASS_BUSINESS)).thenReturn("J,D,C,I,R,U");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.PASSENGER_ELIGIBILITIES_NAMESPACE, "ARQ_N")).thenReturn("Not Required");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.PASSENGER_ELIGIBILITIES_NAMESPACE, "APR_X")).thenReturn("Not needed");
		Itinerary itinerary = itineraryMapper.buildItineraryItems(productLevelList);
		assertNotNull(itinerary);
		assertEquals("2301CB2D000236BD",itinerary.getItineraryItems().iterator().next().getIdentifier());
		assertEquals("1258774395209",itinerary.getEticket().getIdentifier());
		assertEquals("BA",itinerary.getItineraryItems().iterator().next().getCarriers().iterator().next().getCode());
		assertEquals("OPERATING",itinerary.getItineraryItems().iterator().next().getCarriers().iterator().next().getType().name());
		assertEquals("117",itinerary.getItineraryItems().iterator().next().getCarriers().iterator().next().getFlightNumber());
		assertEquals("OP",itinerary.getItineraryItems().iterator().next().getCarriers().iterator().next().getOperationalSuffix());
		assertEquals("GATE2",itinerary.getItineraryItems().iterator().next().getOrigin().getGate().getNumber());
		assertEquals("T1",itinerary.getItineraryItems().iterator().next().getOrigin().getTerminal());
		assertEquals("LHR",itinerary.getItineraryItems().iterator().next().getOrigin().getIdentifier());
		assertNotNull(itinerary.getItineraryItems().iterator().next().getScheduledDepartureLocalDatetime());
		assertNotNull(itinerary.getItineraryItems().iterator().next().getScheduledArrivalLocalDatetime());
		assertEquals("R",itinerary.getItineraryItems().iterator().next().getBookingClass());
		assertEquals("27A",itinerary.getItineraryItems().iterator().next().getSeat().getNumber());
		assertEquals("CONFIRMED",itinerary.getItineraryItems().iterator().next().getStatus().name());
		assertEquals("CHECKEDIN",itinerary.getItineraryItems().iterator().next().getPassengerStatus().name());
		assertNotNull(itinerary.getItineraryItems().iterator().next().getDestinationAddress());
		assertNotNull(itinerary.getItineraryItems().iterator().next().getEligibilities());
		assertNotNull("ARQ",itinerary.getItineraryItems().iterator().next().getEligibilities().iterator().next().getCode());
		assertNotNull("Not Required",itinerary.getItineraryItems().iterator().next().getEligibilities().iterator().next().getDescription());
		assertNotNull("APR",itinerary.getItineraryItems().iterator().next().getEligibilities().iterator().next().getCode());
		assertNotNull("Not needed",itinerary.getItineraryItems().iterator().next().getEligibilities().iterator().next().getDescription());
	}

	@Test
	public void getPassengerWithPassengerStatusCheckedIn() {
		List<ProductLevel> productLevelList = populateItineraryItemsWithPassengerStatus(PassengerStatus.CHECKEDIN.name());
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE, PassengerServiceConstants.PASSENGER_CABIN_CLASS_BUSINESS)).thenReturn("J,D,C,I,R,U");
		Itinerary itinerary = itineraryMapper
				.buildItineraryItems(productLevelList);
		assertNotNull(itinerary);
		assertEquals("2301CB2D000236BD",itinerary.getItineraryItems().iterator().next().getIdentifier());
		assertEquals("CHECKEDIN",itinerary.getItineraryItems().iterator().next().getPassengerStatus().name());
	}
	@Test
	public void getPassengerWithPassengerStatusNotCheckedIn() {
		List<ProductLevel> productLevelList = populateItineraryItemsWithPassengerStatus(PassengerStatus.NOTCHECKEDIN.name());
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE, PassengerServiceConstants.PASSENGER_CABIN_CLASS_BUSINESS)).thenReturn("J,D,C,I,R,U");
		Itinerary itinerary = itineraryMapper
				.buildItineraryItems(productLevelList);
		assertNotNull(itinerary);
		assertEquals("2301CB2D000236BD",itinerary.getItineraryItems().iterator().next().getIdentifier());
		assertEquals("NOTCHECKEDIN",itinerary.getItineraryItems().iterator().next().getPassengerStatus().name());
	}
	@Test
	public void getPassengerWithPassengerStatusStandBy() {
		List<ProductLevel> productLevelList = populateItineraryItemsWithPassengerStatus(PassengerStatus.STANDBY.name());
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE, PassengerServiceConstants.PASSENGER_CABIN_CLASS_BUSINESS)).thenReturn("J,D,C,I,R,U");
		Itinerary itinerary = itineraryMapper
				.buildItineraryItems(productLevelList);
		assertNotNull(itinerary);
		assertEquals("2301CB2D000236BD",itinerary.getItineraryItems().iterator().next().getIdentifier());
		assertEquals("STANDBY",itinerary.getItineraryItems().iterator().next().getPassengerStatus().name());
	}
	
	@Test
	public void getPassengerWithPassengerStatusAsOther() {
		List<ProductLevel> productLevelList = populateItineraryItemsWithPassengerStatus("Other");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE, PassengerServiceConstants.PASSENGER_CABIN_CLASS_BUSINESS)).thenReturn("J,D,C,I,R,U");
		Itinerary itinerary = itineraryMapper
				.buildItineraryItems(productLevelList);
		assertNotNull(itinerary);
		assertEquals("2301CB2D000236BD",itinerary.getItineraryItems().iterator().next().getIdentifier());
		assertNull(itinerary.getItineraryItems().iterator().next().getPassengerStatus());
	}
	
	@Test
	public void getPassengerWithFlightStatusConfirmed() {
		List<ProductLevel> productLevelList = populateItineraryItemsWithFlightStatus(ItineraryItemStatus.CONFIRMED.name());
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE, PassengerServiceConstants.PASSENGER_CABIN_CLASS_BUSINESS)).thenReturn("J,D,C,I,R,U");
		Itinerary itinerary = itineraryMapper
				.buildItineraryItems(productLevelList);
		assertNotNull(itinerary);
		assertEquals("34546645656BA",itinerary.getItineraryItems().iterator().next().getIdentifier());
		assertEquals(ItineraryItemStatus.CONFIRMED.name(),itinerary.getItineraryItems().iterator().next().getStatus().name());
	}
	@Test
	public void getPassengerWithFlightStatusNotConfirmed() {
		List<ProductLevel> productLevelList = populateItineraryItemsWithFlightStatus(ItineraryItemStatus.UNCONFIRMED.name());
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE, PassengerServiceConstants.PASSENGER_CABIN_CLASS_BUSINESS)).thenReturn("J,D,C,I,R,U");
		Itinerary itinerary = itineraryMapper
				.buildItineraryItems(productLevelList);
		assertNotNull(itinerary);
		assertEquals("34546645656BA",itinerary.getItineraryItems().iterator().next().getIdentifier());
		assertEquals(ItineraryItemStatus.UNCONFIRMED.name(),itinerary.getItineraryItems().iterator().next().getStatus().name());
	}
	
	@Test
	public void getPassengerWithFlightStatusAsEmpty() {
		List<ProductLevel> productLevelList = populateItineraryItemsWithFlightStatus("Other");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE, PassengerServiceConstants.PASSENGER_CABIN_CLASS_BUSINESS)).thenReturn("J,D,C,I,R,U");
		Itinerary itinerary = itineraryMapper
				.buildItineraryItems(productLevelList);
		assertNotNull(itinerary);
		assertEquals("34546645656BA",itinerary.getItineraryItems().iterator().next().getIdentifier());
		assertNull(itinerary.getItineraryItems().iterator().next().getStatus());
	}
	
	@Test
	public void getPassengerWithCabinClassAsEconomy() {
		List<ProductLevel> productLevelList = populateItineraryItemsForCabinClass("Economy");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE, PassengerServiceConstants.PASSENGER_CABIN_CLASS_ECONOMY)).thenReturn("Y,O,Q,S,K,L,M,N,V,H,B");
		Itinerary itinerary = itineraryMapper
				.buildItineraryItems(productLevelList);
		assertNotNull(itinerary);
		assertEquals("ECONOMY",itinerary.getItineraryItems().iterator().next().getCabinCode());
	}
	
	@Test
	public void getPassengerWithCabinClassAsPremiumEconomy() {
		List<ProductLevel> productLevelList = populateItineraryItemsForCabinClass("Premium Economy");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerServiceConstants.PASSENGER_CABIN_CLASS_PREMIUM_ECONOMY)).thenReturn("W,E,T,P");
		Itinerary itinerary = itineraryMapper
				.buildItineraryItems(productLevelList);
		assertNotNull(itinerary);
		assertEquals("PREMIUM_ECONOMY",itinerary.getItineraryItems().iterator().next().getCabinCode());
	}
	
	@Test
	public void getPassengerWithCabinClassAsBusiness() {
		List<ProductLevel> productLevelList = populateItineraryItemsForCabinClass("Business");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE, PassengerServiceConstants.PASSENGER_CABIN_CLASS_BUSINESS)).thenReturn("J,D,C,I,R,U");
		Itinerary itinerary = itineraryMapper
				.buildItineraryItems(productLevelList);
		assertNotNull(itinerary);
		assertEquals("BUSINESS",itinerary.getItineraryItems().iterator().next().getCabinCode());
	}


	private List<ProductLevel> populateItineraryItems() {        
		List<ProductLevel> productLevelList = new ArrayList<>();
		ProductLevel productLevel = new ProductLevel();
		
		List<CandidateETickets> candidateETickets = new ArrayList<>();
		CandidateETickets candidateETicket = new CandidateETickets();	
		TicketNumberTypeI8732S ticketNumberType = new TicketNumberTypeI8732S();
		TicketNumberDetailsTypeI19962C ticketNumberDetailsType = new TicketNumberDetailsTypeI19962C();
		ticketNumberDetailsType.setNumber("1258774395209");
		ticketNumberType.setDocumentDetails(ticketNumberDetailsType);		
		candidateETicket.setTicketInfo(ticketNumberType);	
		candidateETickets.add(candidateETicket);
		productLevel.setCandidateETickets(candidateETickets);	
		
		List<ItemReferencesAndVersionsType146132S> productIdentifiers = new ArrayList<>();
		
		ItemReferencesAndVersionsType146132S itemReferencesAndVersionsType = new ItemReferencesAndVersionsType146132S();
		UniqueIdDescriptionType value = new UniqueIdDescriptionType();
		value.setPrimeId("2301CB2D000236BD");
		itemReferencesAndVersionsType.setIdSection(value);
		productIdentifiers.add(itemReferencesAndVersionsType);		
		productLevel.setProductIdentifiers(productIdentifiers);
		
		FlightDetailsResponseType operatingFlightDetails = new FlightDetailsResponseType();
		OutboundCarrierDetailsTypeI166697C outboundCarrierDetailsTypeI166697C = new OutboundCarrierDetailsTypeI166697C();
		outboundCarrierDetailsTypeI166697C.setMarketingCarrier("BA");
        
		OutboundFlightNumberDetailstypeI139968C outboundFlightNumberDetailstypeI = new OutboundFlightNumberDetailstypeI139968C();
		outboundFlightNumberDetailstypeI.setFlightNumber("117");
		outboundFlightNumberDetailstypeI.setOperationalSuffix("OP");
		
		operatingFlightDetails.setCarrierDetails(outboundCarrierDetailsTypeI166697C);
		
		operatingFlightDetails.setBoardPoint("LHR");//origin
		operatingFlightDetails.setOffPoint("JFK");
		operatingFlightDetails.setFlightDetails(outboundFlightNumberDetailstypeI);
		productLevel.setOperatingFlightDetails(operatingFlightDetails);
						 	
		List<LegLevel> legLevelList = new ArrayList<>();
		LegLevel legLevel = new LegLevel();		
		List<StructuredDateTimeInformationType> legTimes = legLevel.getLegTimes();

		StructuredDateTimeInformationType structuredDateTimeInformationType = new StructuredDateTimeInformationType();
		
		structuredDateTimeInformationType.setBusinessSemantic("STD");
		StructuredDateTimeType18904C dateTime = new StructuredDateTimeType18904C();
		dateTime.setYear("2018");
		dateTime.setMonth("4");
		dateTime.setDay("16");
		dateTime.setHour("9");
		dateTime.setMinutes("52");
		dateTime.setSeconds(BigInteger.valueOf(50));
		structuredDateTimeInformationType.setDateTime(dateTime);	
		legTimes.add(structuredDateTimeInformationType);

		StructuredDateTimeInformationType structuredDateTimeInformationType1 = new StructuredDateTimeInformationType();
		structuredDateTimeInformationType1.setBusinessSemantic("STA");
		StructuredDateTimeType18904C dateTime1 = new StructuredDateTimeType18904C();
		dateTime1.setYear("2018");
		dateTime1.setMonth("4");
		dateTime1.setDay("17");
		dateTime1.setHour("9");
		dateTime1.setMinutes("52");
		dateTime1.setSeconds(BigInteger.valueOf(50));
		structuredDateTimeInformationType1.setDateTime(dateTime1);
		legTimes.add(structuredDateTimeInformationType1);
		legLevel.setLegTimes(legTimes);
		
		AdditionalProductDetailsTypeI additionalProductDetails = new AdditionalProductDetailsTypeI();
		StationInformationTypeI departureStationInfo = new StationInformationTypeI();
		departureStationInfo.setTerminal("T1");
		additionalProductDetails.setDepartureStationInfo(departureStationInfo);	
		
		StationInformationTypeI arrivalStationInfo = new StationInformationTypeI();
		arrivalStationInfo.setTerminal("T4");
		additionalProductDetails.setArrivalStationInfo(arrivalStationInfo);
		legLevel.setAdditionalProductDetails(additionalProductDetails);
		
		
		List<TerminalLocationType116626S> departureGate = new ArrayList<>();
		FacilityInformationType171568C facilityInformationType = new FacilityInformationType171568C();
		facilityInformationType.setIdentifier("GATE2");
		TerminalLocationType116626S terminalLocationType116626S = new TerminalLocationType116626S();
		terminalLocationType116626S.setFacilityDetails(facilityInformationType);
		departureGate.add(terminalLocationType116626S);
		productLevel.setDepartureGate(departureGate);
		
		List<SpecialRequirementsDetailsType198190S> seatInfoList = new ArrayList<>();
		SpecialRequirementsDetailsType198190S specialRequirementsDetails = new SpecialRequirementsDetailsType198190S();
		List<SpecialRequirementsDataDetailsType> specialRequirementsData = new ArrayList<>();
		SpecialRequirementsDataDetailsType specialRequirementsDataDetailsType = new SpecialRequirementsDataDetailsType();
		specialRequirementsDataDetailsType.setSeatNumber("27A");
		specialRequirementsData.add(specialRequirementsDataDetailsType);
		specialRequirementsDetails.setSeatDetails(specialRequirementsData);
		seatInfoList.add(specialRequirementsDetails);
		legLevel.setSeatInfo(seatInfoList);
				
		List<CodedAttributeInformationType208434C> attributeDetailsList = new ArrayList<>();
		CodedAttributeInformationType208434C codedAttributeInformationType = new CodedAttributeInformationType208434C();
		codedAttributeInformationType.setAttributeType(PassengerServiceConstants.PPI);
		attributeDetailsList.add(codedAttributeInformationType);
		CodedAttributeType214203S codedAttributeType214203S = new CodedAttributeType214203S();
		codedAttributeType214203S.setAttributeDetails(attributeDetailsList);
		productLevel.setProductLevelIndicators(codedAttributeType214203S);
				
		List<StatusDetailsType233068C> statusInformationList = new ArrayList<>();
		StatusDetailsType233068C statusDetailsType233068C = new StatusDetailsType233068C();
		statusDetailsType233068C.setIndicator(PassengerServiceConstants.CAC);
		statusInformationList.add(statusDetailsType233068C);
		StatusType208180S statusType = new StatusType208180S();
		statusType.setStatusInformation(statusInformationList);
		legLevel.setLegLevelIndicator(statusType);
		
		CabinDetailsType40636S  cabinDetailsType40636S = new  CabinDetailsType40636S();
		CabinClassDesignationType68442C cabinClassDesignationType =new CabinClassDesignationType68442C();
		cabinClassDesignationType.setBookingClass("R");
		cabinClassDesignationType.setClassDesignator("J"); //Business
		cabinDetailsType40636S.setCabinDetails(cabinClassDesignationType);
		productLevel.setBookedCabinCode(cabinDetailsType40636S);
		 
		 RelatedProductInformationType relatedProductInformationType = new RelatedProductInformationType();
		 relatedProductInformationType.setStatusCode("HK");
		 String flightStatus = ItineraryItemStatus.CONFIRMED.name();
		 productLevel.setBookingStatusDetails(relatedProductInformationType); 
		 
		 List<AddressDetailsGroup> addressDetailsGroupList = new ArrayList<>();
		 AddressDetailsGroup addressDetailsGroup = new AddressDetailsGroup();
		 PlaceLocationIdentificationType203606S placeLocationIdentificationType =new PlaceLocationIdentificationType203606S();
		 placeLocationIdentificationType.setLocationType(PassengerServiceConstants.ADDRESS_QUALIFIER);	
		 addressDetailsGroup.setAddressQualifier(placeLocationIdentificationType);
		 NameAndAddressBatchType nameAndAddressBatchType = new NameAndAddressBatchType();
		 StreetType  streetType = new  StreetType();
		 streetType.setStreet("Lane1,Block4");
		 nameAndAddressBatchType.setTravelerAddress(streetType);
		 nameAndAddressBatchType.setTravelerCity("Delhi");	
		 nameAndAddressBatchType.setTravelerPostcode("London");	
		 nameAndAddressBatchType.setTravelerCountryCode("91");	
		 addressDetailsGroup.setAddressDetails(nameAndAddressBatchType);	
		 addressDetailsGroupList.add(addressDetailsGroup);
		 productLevel.setAddressDetailsGroup(addressDetailsGroupList);
		legLevelList.add(legLevel);
		productLevel.setLegLevel(legLevelList);	
		
		List<StatusDetailsType> statusDetailsTypeList = new ArrayList<>();
		StatusDetailsType statusDetailsType = new StatusDetailsType();
		statusDetailsType.setAction("N");
		statusDetailsType.setIndicator("ARQ");
		StatusDetailsType statusDetailsType2 = new StatusDetailsType();
		statusDetailsType2.setAction("X");
		statusDetailsType2.setIndicator("APR");
		statusDetailsTypeList.add(statusDetailsType);
		statusDetailsTypeList.add(statusDetailsType2);
		StatusType151539S statusType151539S = new StatusType151539S(); 
		statusType151539S.setStatusInformation(statusDetailsTypeList);
		productLevel.setRegProductStatus(statusType151539S);
		
		productLevelList.add(productLevel);
		return productLevelList;
	}
	
  private List<ProductLevel> populateItineraryItemsForCabinClass(String cabinClass) {
        
		List<ProductLevel> productLevelList = new ArrayList<>();
		ProductLevel productLevel = new ProductLevel();
		
		List<CandidateETickets> candidateETickets = new ArrayList<>();
		CandidateETickets candidateETicket = new CandidateETickets();	
		TicketNumberTypeI8732S ticketNumberType = new TicketNumberTypeI8732S();
		TicketNumberDetailsTypeI19962C ticketNumberDetailsType = new TicketNumberDetailsTypeI19962C();
		ticketNumberDetailsType.setNumber("1258774395209");
		ticketNumberType.setDocumentDetails(ticketNumberDetailsType);		
		candidateETicket.setTicketInfo(ticketNumberType);	
		candidateETickets.add(candidateETicket);
		productLevel.setCandidateETickets(candidateETickets);	
		
		List<ItemReferencesAndVersionsType146132S> productIdentifiers = new ArrayList<>();
		
		ItemReferencesAndVersionsType146132S itemReferencesAndVersionsType = new ItemReferencesAndVersionsType146132S();
		UniqueIdDescriptionType value = new UniqueIdDescriptionType();
		value.setPrimeId("2301CB2D000236BD");
		itemReferencesAndVersionsType.setIdSection(value);
		productIdentifiers.add(itemReferencesAndVersionsType);		
		productLevel.setProductIdentifiers(productIdentifiers);
		
		FlightDetailsResponseType operatingFlightDetails = new FlightDetailsResponseType();
		OutboundCarrierDetailsTypeI166697C outboundCarrierDetailsTypeI166697C = new OutboundCarrierDetailsTypeI166697C();
		outboundCarrierDetailsTypeI166697C.setMarketingCarrier("BA");
        
		OutboundFlightNumberDetailstypeI139968C outboundFlightNumberDetailstypeI = null;
		operatingFlightDetails.setCarrierDetails(outboundCarrierDetailsTypeI166697C);
		
		operatingFlightDetails.setBoardPoint("LHR");//origin
		operatingFlightDetails.setOffPoint("JFK");
		operatingFlightDetails.setFlightDetails(outboundFlightNumberDetailstypeI);
		productLevel.setOperatingFlightDetails(operatingFlightDetails);
						 	
		 CabinDetailsType40636S  cabinDetailsType40636S = new  CabinDetailsType40636S();
		 CabinClassDesignationType68442C cabinClassDesignationType =new CabinClassDesignationType68442C();
		 cabinClassDesignationType.setBookingClass("R");
		 if(cabinClass.equalsIgnoreCase("Economy"))
		    cabinClassDesignationType.setClassDesignator("Y"); //Business
		 else  if(cabinClass.equalsIgnoreCase("Premium Economy"))
		     cabinClassDesignationType.setClassDesignator("W"); //Business
		 else  if(cabinClass.equalsIgnoreCase("Business"))	 
			 cabinClassDesignationType.setClassDesignator("J"); //Business		 
		 cabinDetailsType40636S.setCabinDetails(cabinClassDesignationType);
		 productLevel.setBookedCabinCode(cabinDetailsType40636S);
		 
		 RelatedProductInformationType relatedProductInformationType = new RelatedProductInformationType();
		 relatedProductInformationType.setStatusCode("HK");
		 String flightStatus = ItineraryItemStatus.CONFIRMED.name();
		 productLevel.setBookingStatusDetails(relatedProductInformationType); 	
		
		productLevelList.add(productLevel);
		return productLevelList;

	}

	private List<ProductLevel> populateItineraryItemsWithPassengerStatus(String passengerStatus) {

		List<ProductLevel> productLevelList = new ArrayList<>();
		ProductLevel productLevel = new ProductLevel();

		List<CandidateETickets> candidateETickets = new ArrayList<>();
		CandidateETickets candidateETicket = new CandidateETickets();
		TicketNumberTypeI8732S ticketNumberType = new TicketNumberTypeI8732S();
		TicketNumberDetailsTypeI19962C ticketNumberDetailsType = new TicketNumberDetailsTypeI19962C();
		ticketNumberDetailsType.setNumber("1258774395209");
		ticketNumberType.setDocumentDetails(ticketNumberDetailsType);
		candidateETicket.setTicketInfo(ticketNumberType);
		candidateETickets.add(candidateETicket);
		productLevel.setCandidateETickets(candidateETickets);

		List<ItemReferencesAndVersionsType146132S> productIdentifiers = new ArrayList<>();

		ItemReferencesAndVersionsType146132S itemReferencesAndVersionsType = new ItemReferencesAndVersionsType146132S();
		UniqueIdDescriptionType value = new UniqueIdDescriptionType();
		value.setPrimeId("2301CB2D000236BD");
		itemReferencesAndVersionsType.setIdSection(value);
		productIdentifiers.add(itemReferencesAndVersionsType);
		productLevel.setProductIdentifiers(productIdentifiers);
		
		

		FlightDetailsResponseType operatingFlightDetails = new FlightDetailsResponseType();
		OutboundCarrierDetailsTypeI166697C outboundCarrierDetailsTypeI166697C = new OutboundCarrierDetailsTypeI166697C();
		outboundCarrierDetailsTypeI166697C.setMarketingCarrier("");

		OutboundFlightNumberDetailstypeI139968C outboundFlightNumberDetailstypeI = new OutboundFlightNumberDetailstypeI139968C();
		outboundFlightNumberDetailstypeI.setFlightNumber("117");
		outboundFlightNumberDetailstypeI.setOperationalSuffix("OP");

		operatingFlightDetails.setCarrierDetails(outboundCarrierDetailsTypeI166697C);

		operatingFlightDetails.setBoardPoint("LHR");// origin
		operatingFlightDetails.setOffPoint("JFK");
		operatingFlightDetails.setFlightDetails(outboundFlightNumberDetailstypeI);
		productLevel.setOperatingFlightDetails(operatingFlightDetails);
		
		CommercialAgreementsType commercialAgreementsType = new CommercialAgreementsType();
		CompanyRoleIdentificationType companyRoleIdentificationType = new CompanyRoleIdentificationType();
		companyRoleIdentificationType.setAirlineDesignator("BA");
		companyRoleIdentificationType.setCodeshareType("BA001");
		companyRoleIdentificationType.setFlightNumber("280");
		companyRoleIdentificationType.setOperationalSuffix("MK");
		commercialAgreementsType.setCodeshareDetails(companyRoleIdentificationType);
		productLevel.setMarketingFlightInfo(commercialAgreementsType);
		
		
		List<LegLevel> legLevelList = new ArrayList<>();
		LegLevel legLevel = new LegLevel();
		List<StructuredDateTimeInformationType> legTimes = legLevel.getLegTimes();

		StructuredDateTimeInformationType structuredDateTimeInformationType = new StructuredDateTimeInformationType();

		structuredDateTimeInformationType.setBusinessSemantic("STD");
		StructuredDateTimeType18904C dateTime = new StructuredDateTimeType18904C();
		dateTime.setYear("2018");
		dateTime.setMonth("4");
		dateTime.setDay("16");
		dateTime.setHour("9");
		dateTime.setMinutes("52");
		dateTime.setSeconds(BigInteger.valueOf(50));
		structuredDateTimeInformationType.setDateTime(dateTime);
		legTimes.add(structuredDateTimeInformationType);

		StructuredDateTimeInformationType structuredDateTimeInformationType1 = new StructuredDateTimeInformationType();
		structuredDateTimeInformationType1.setBusinessSemantic("STA");
		StructuredDateTimeType18904C dateTime1 = new StructuredDateTimeType18904C();
		dateTime1.setYear("2018");
		dateTime1.setMonth("4");
		dateTime1.setDay("17");
		dateTime1.setHour("9");
		dateTime1.setMinutes("52");
		dateTime1.setSeconds(BigInteger.valueOf(50));
		structuredDateTimeInformationType1.setDateTime(dateTime1);
		legTimes.add(structuredDateTimeInformationType1);
		legLevel.setLegTimes(legTimes);

		AdditionalProductDetailsTypeI additionalProductDetails = new AdditionalProductDetailsTypeI();
		StationInformationTypeI departureStationInfo = new StationInformationTypeI();
		departureStationInfo.setTerminal("T1");
		additionalProductDetails.setDepartureStationInfo(departureStationInfo);
		StationInformationTypeI arrivalStationInfo = new StationInformationTypeI();
		arrivalStationInfo.setTerminal("T4");
		additionalProductDetails.setArrivalStationInfo(arrivalStationInfo);
		legLevel.setAdditionalProductDetails(additionalProductDetails);

		List<TerminalLocationType116626S> departureGate = new ArrayList<>();
		FacilityInformationType171568C facilityInformationType = new FacilityInformationType171568C();
		facilityInformationType.setIdentifier("GATE2");
		TerminalLocationType116626S terminalLocationType116626S = new TerminalLocationType116626S();
		terminalLocationType116626S.setFacilityDetails(facilityInformationType);
		departureGate.add(terminalLocationType116626S);
		productLevel.setDepartureGate(departureGate);

		List<SpecialRequirementsDetailsType198190S> seatInfoList = new ArrayList<>();
		SpecialRequirementsDetailsType198190S specialRequirementsDetails = new SpecialRequirementsDetailsType198190S();
		List<SpecialRequirementsDataDetailsType> specialRequirementsData = new ArrayList<>();
		SpecialRequirementsDataDetailsType specialRequirementsDataDetailsType = new SpecialRequirementsDataDetailsType();
		specialRequirementsDataDetailsType.setSeatNumber("27A");
		specialRequirementsData.add(specialRequirementsDataDetailsType);
		specialRequirementsDetails.setSeatDetails(specialRequirementsData);
		seatInfoList.add(specialRequirementsDetails);
		legLevel.setSeatInfo(seatInfoList);

		List<CodedAttributeInformationType208434C> attributeDetailsList = new ArrayList<>();

		CodedAttributeInformationType208434C codedAttributeInformationType = new CodedAttributeInformationType208434C();
		codedAttributeInformationType.setAttributeType(PassengerServiceConstants.PPI);
		attributeDetailsList.add(codedAttributeInformationType);
		CodedAttributeType214203S codedAttributeType214203S = new CodedAttributeType214203S();
		codedAttributeType214203S.setAttributeDetails(attributeDetailsList);
		productLevel.setProductLevelIndicators(codedAttributeType214203S);

		List<StatusDetailsType233068C> statusInformationList = new ArrayList<>();
		StatusDetailsType233068C statusDetailsType233068C = new StatusDetailsType233068C();
    	if(passengerStatus.equals(PassengerStatus.CHECKEDIN.name()))
		   statusDetailsType233068C.setIndicator(PassengerServiceConstants.CAC);
		else if(passengerStatus.equals(PassengerStatus.NOTCHECKEDIN.name()))
			 statusDetailsType233068C.setIndicator(PassengerServiceConstants.CNC);
		else if(passengerStatus.equals(PassengerStatus.STANDBY.name()))
	    	statusDetailsType233068C.setIndicator(PassengerServiceConstants.CST);
		else if(passengerStatus.equals("Other"))
	    	statusDetailsType233068C.setIndicator("Other");
		statusInformationList.add(statusDetailsType233068C);
		StatusType208180S statusType = new StatusType208180S();
		statusType.setStatusInformation(statusInformationList);
		legLevel.setLegLevelIndicator(statusType);

		CabinDetailsType40636S cabinDetailsType40636S = new CabinDetailsType40636S();
		CabinClassDesignationType68442C cabinClassDesignationType = new CabinClassDesignationType68442C();
		cabinClassDesignationType.setBookingClass("C");
		cabinClassDesignationType.setClassDesignator("Y"); //Economy
		cabinDetailsType40636S.setCabinDetails(cabinClassDesignationType);
		productLevel.setBookedCabinCode(cabinDetailsType40636S);

		RelatedProductInformationType relatedProductInformationType = new RelatedProductInformationType();
		relatedProductInformationType.setStatusCode("HK");
		String flightStatus = ItineraryItemStatus.CONFIRMED.name();
		productLevel.setBookingStatusDetails(relatedProductInformationType);

		legLevelList.add(legLevel);
		productLevel.setLegLevel(legLevelList);
		
		List<StatusDetailsType> statusDetailsTypeList = new ArrayList<>();
		StatusDetailsType statusDetailsType = new StatusDetailsType();
		statusDetailsType.setAction("X");
		statusDetailsType.setIndicator("AQQ");
		StatusDetailsType statusDetailsType2 = new StatusDetailsType();
		statusDetailsType2.setAction("N");
		statusDetailsType2.setIndicator("VDT");
		statusDetailsTypeList.add(statusDetailsType);
		statusDetailsTypeList.add(statusDetailsType2);
		StatusType151539S statusType151539S = new StatusType151539S(); 
		statusType151539S.setStatusInformation(statusDetailsTypeList);
		productLevel.setRegProductStatus(statusType151539S);

		productLevelList.add(productLevel);
		return productLevelList;

	}
	
	private List<ProductLevel> populateItineraryItemsWithFlightStatus(String flightStatus) {

		List<ProductLevel> productLevelList = new ArrayList<>();
		ProductLevel productLevel = new ProductLevel();

		List<CandidateETickets> candidateETickets = new ArrayList<>();
		CandidateETickets candidateETicket = new CandidateETickets();
		TicketNumberTypeI8732S ticketNumberType = new TicketNumberTypeI8732S();
		TicketNumberDetailsTypeI19962C ticketNumberDetailsType = new TicketNumberDetailsTypeI19962C();
		ticketNumberDetailsType.setNumber("1258774395209");
		ticketNumberType.setDocumentDetails(ticketNumberDetailsType);
		candidateETicket.setTicketInfo(ticketNumberType);
		candidateETickets.add(candidateETicket);
		productLevel.setCandidateETickets(candidateETickets);

		List<ItemReferencesAndVersionsType146132S> productIdentifiers = new ArrayList<>();

		ItemReferencesAndVersionsType146132S itemReferencesAndVersionsType = new ItemReferencesAndVersionsType146132S();
		UniqueIdDescriptionType value = new UniqueIdDescriptionType();
		value.setPrimeId("34546645656BA");
		itemReferencesAndVersionsType.setIdSection(value);
		productIdentifiers.add(itemReferencesAndVersionsType);
		productLevel.setProductIdentifiers(productIdentifiers);

		FlightDetailsResponseType operatingFlightDetails = null;
		productLevel.setOperatingFlightDetails(operatingFlightDetails);
		
		CommercialAgreementsType commercialAgreementsType = new CommercialAgreementsType();
		CompanyRoleIdentificationType companyRoleIdentificationType = null;
		commercialAgreementsType.setCodeshareDetails(companyRoleIdentificationType);
		productLevel.setMarketingFlightInfo(commercialAgreementsType);

		List<LegLevel> legLevelList = new ArrayList<>();
		LegLevel legLevel = new LegLevel();
		List<StructuredDateTimeInformationType> legTimes = legLevel.getLegTimes();

		StructuredDateTimeInformationType structuredDateTimeInformationType = new StructuredDateTimeInformationType();

		structuredDateTimeInformationType.setBusinessSemantic("STD");
		StructuredDateTimeType18904C dateTime = null;
		structuredDateTimeInformationType.setDateTime(dateTime);
		legTimes.add(structuredDateTimeInformationType);

		StructuredDateTimeInformationType structuredDateTimeInformationType1 = new StructuredDateTimeInformationType();
		structuredDateTimeInformationType1.setBusinessSemantic("STA");
		StructuredDateTimeType18904C dateTime1 = null;
		structuredDateTimeInformationType1.setDateTime(dateTime1);
		legTimes.add(structuredDateTimeInformationType1);
		legLevel.setLegTimes(legTimes);

		AdditionalProductDetailsTypeI additionalProductDetails = new AdditionalProductDetailsTypeI();
		StationInformationTypeI departureStationInfo = new StationInformationTypeI();
		departureStationInfo.setTerminal("");
		additionalProductDetails.setDepartureStationInfo(departureStationInfo);
		StationInformationTypeI arrivalStationInfo = new StationInformationTypeI();
		arrivalStationInfo.setTerminal("");
		additionalProductDetails.setArrivalStationInfo(arrivalStationInfo);
		legLevel.setAdditionalProductDetails(additionalProductDetails);

		List<TerminalLocationType116626S> departureGate = new ArrayList<>();
		FacilityInformationType171568C facilityInformationType = null;
		TerminalLocationType116626S terminalLocationType116626S = new TerminalLocationType116626S();
		terminalLocationType116626S.setFacilityDetails(facilityInformationType);
		departureGate.add(terminalLocationType116626S);
		productLevel.setDepartureGate(departureGate);

		List<SpecialRequirementsDetailsType198190S> seatInfoList = new ArrayList<>();
		SpecialRequirementsDetailsType198190S specialRequirementsDetails = new SpecialRequirementsDetailsType198190S();
		List<SpecialRequirementsDataDetailsType> specialRequirementsData = new ArrayList<>();
		SpecialRequirementsDataDetailsType specialRequirementsDataDetailsType = new SpecialRequirementsDataDetailsType();
		specialRequirementsDataDetailsType.setSeatNumber("27A");
		specialRequirementsData.add(specialRequirementsDataDetailsType);
		specialRequirementsDetails.setSeatDetails(specialRequirementsData);
		seatInfoList.add(specialRequirementsDetails);
		legLevel.setSeatInfo(seatInfoList);

		List<CodedAttributeInformationType208434C> attributeDetailsList = new ArrayList<>();

		CodedAttributeInformationType208434C codedAttributeInformationType = new CodedAttributeInformationType208434C();
		codedAttributeInformationType.setAttributeType("CCI");
		attributeDetailsList.add(codedAttributeInformationType);
		CodedAttributeType214203S codedAttributeType214203S = new CodedAttributeType214203S();
		codedAttributeType214203S.setAttributeDetails(attributeDetailsList);
		productLevel.setProductLevelIndicators(codedAttributeType214203S);

		List<StatusDetailsType233068C> statusInformationList = new ArrayList<>();
		StatusDetailsType233068C statusDetailsType233068C = new StatusDetailsType233068C();		
		   statusDetailsType233068C.setIndicator(PassengerServiceConstants.CAC);		
		statusInformationList.add(statusDetailsType233068C);
		StatusType208180S statusType = new StatusType208180S();
		statusType.setStatusInformation(statusInformationList);
		legLevel.setLegLevelIndicator(statusType);

		CabinDetailsType40636S cabinDetailsType40636S = new CabinDetailsType40636S();
		CabinClassDesignationType68442C cabinClassDesignationType = null;
		cabinDetailsType40636S.setCabinDetails(cabinClassDesignationType);
		productLevel.setBookedCabinCode(cabinDetailsType40636S);
		
		

		RelatedProductInformationType relatedProductInformationType = new RelatedProductInformationType();
		
		if(flightStatus.equals(ItineraryItemStatus.CONFIRMED.name()))
			relatedProductInformationType.setStatusCode("HK");
		if(flightStatus.equals(ItineraryItemStatus.UNCONFIRMED.name()))
			relatedProductInformationType.setStatusCode("LK");
		if(flightStatus.equals("Other"))
			relatedProductInformationType.setStatusCode("");
		productLevel.setBookingStatusDetails(relatedProductInformationType);

		legLevelList.add(legLevel);
		productLevel.setLegLevel(legLevelList);

		productLevelList.add(productLevel);
		return productLevelList;

	}
	
    }

