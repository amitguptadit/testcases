package com.iag.business.passenger.exception;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.proxy.config.ServiceProxy;


public class DefaultContentProviderTest {
	
	private static final String REQUEST_INVALID_CODE = "passenger.error.REQUEST_INVALID.code";
	
	private static final String REQUEST_INVALID_VALUE = "REQUEST_INVALID";

	@InjectMocks
	private DefaultContentProvider defaultContentProvider;

	@Mock
	private ServiceProxy configurationInfrastructureServiceProxy;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		defaultContentProvider = new DefaultContentProvider(configurationInfrastructureServiceProxy);
	}

	@Test
	public void shouldGetErrorContent() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.ERROR_NAMESPACE,REQUEST_INVALID_CODE))
				.thenReturn(REQUEST_INVALID_VALUE);
		Assert.assertEquals(REQUEST_INVALID_VALUE, defaultContentProvider.getContent(REQUEST_INVALID_CODE));
	}
}
