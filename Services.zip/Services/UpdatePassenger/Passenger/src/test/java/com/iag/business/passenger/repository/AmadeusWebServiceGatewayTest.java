package com.iag.business.passenger.repository;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.WebServiceIOException;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.amadeus.xml.ccprrq_17_1_1a.DCSIDCCPRIdentification;
import com.amadeus.xml.ccprrq_17_1_1a.DCSIDCCPRIdentification.SetOfCriteria;
import com.amadeus.xml.ccprrq_17_1_1a.FlightDetailsQueryType;
import com.amadeus.xml.ccprrq_17_1_1a.ItemReferencesAndVersionsType;
import com.amadeus.xml.ccprrq_17_1_1a.ReservationControlInformationDetailsType;
import com.amadeus.xml.ccprrq_17_1_1a.ReservationControlInformationType;
import com.amadeus.xml.ccprrq_17_1_1a.SelectionDetailsInformationTypeI;
import com.amadeus.xml.ccprrq_17_1_1a.SelectionDetailsType;
import com.amadeus.xml.ccprrq_17_1_1a.UniqueIdDescriptionType;
import com.amadeus.xml.ccprrr_17_1_1a.ApplicationErrorDetailType;
import com.amadeus.xml.ccprrr_17_1_1a.ApplicationErrorInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel;
import com.amadeus.xml.ccprrr_17_1_1a.ErrorGroupType;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.proxy.config.ConfigurationInfrastructureServiceProxy;
import com.iag.business.passenger.session.AmadeusSession;

public class AmadeusWebServiceGatewayTest {

	private static final String SOAP_ACTION_URI = "http://webservices.amadeus.com/1ASIWIAGBA/CCPRRQ_17_1_1A";
	
	private AmadeusWebServiceGateway gateway;

	@Mock
	private WebServiceTemplate amadeusWebServiceTemplate;
	@Mock
	private ConfigurationInfrastructureServiceProxy configurationInfrastructureServiceProxy;

	@Mock
	Jaxb2Marshaller amadeusMarshaller;

	@Mock
	Jaxb2Marshaller amadeusUnMarshaller;
	@Rule
	public final ExpectedException exception = ExpectedException.none();

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		gateway = new AmadeusWebServiceGateway();
		ReflectionTestUtils.setField(gateway, "amadeusMarshaller", amadeusMarshaller);
		ReflectionTestUtils.setField(gateway, "amadeusUnMarshaller", amadeusUnMarshaller);
		ReflectionTestUtils.setField(gateway, "amadeusWebServiceTemplate", amadeusWebServiceTemplate);
		ReflectionTestUtils.setField(gateway, "configurationInfrastructureServiceProxy",
				configurationInfrastructureServiceProxy);
			}
	@SuppressWarnings("unchecked")
	@Test
	public void getWebServiceResponseForPassenger() {

		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposne());
		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForPassengers(createRequestBodyForPassenger(), SOAP_ACTION_URI, getSession());

		Assert.assertNotEquals(null, amedeusResponseDetails);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void getWebServiceResponseForPassengerErroCode() {
			Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn("17011,17111,17112 ,11,17569,17336,17391,19915,19436,19204");
				Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name())).thenReturn("EC,WEC2,WEC");


		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithErroCategory());
		exception.expect(ApplicationServiceException.class);

		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForPassengers(createRequestBodyForPassenger(), SOAP_ACTION_URI, getSession());

	}
	@SuppressWarnings("unchecked")
	@Test
	public void getWebServiceResponseForPassengerErroCodePassengerNotFound() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn("11,17569,17336,17391,19915,19436,19204");

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_NOT_FOUND_CODE_STATUS_LIST.name())).thenReturn(
						"17112,14145,14147 ,14147 ,14145,17347,17503,28469,19507,14806,14810,14809,14808,19695,17332,14807,14789,14788,14787,14786,14784,14782");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name())).thenReturn("EC,WEC2,WEC");


		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithErroCategoryPassengerNotFound());
		exception.expect(ApplicationServiceException.class);

		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForPassengers(createRequestBodyForPassenger(), SOAP_ACTION_URI, getSession());

	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void shouldNotGetPassengerNotFoundForSametBookingIdentifier() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn("11,17569,17336,17391,19915,19436,19204");

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_NOT_FOUND_CODE_STATUS_LIST.name())).thenReturn(
						"17112,14145,14147 ,14147 ,14145,17347,17503,28469,19507,14806,14810,14809,14808,19695,17332,14807,14789,14788,14787,14786,14784,14782");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name())).thenReturn("EC,WEC2,WEC");


		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposne());
		
		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForPassengers(createRequestBodyForPassenger(), SOAP_ACTION_URI, getSession());
		Assert.assertNotEquals(null, amedeusResponseDetails);

	}
	@SuppressWarnings("unchecked")
	@Test
	public void shouldGetPassengerNotFoundForDifferentBookingIdentifier() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn("11,17569,17336,17391,19915,19436,19204");

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_NOT_FOUND_CODE_STATUS_LIST.name())).thenReturn(
						"17112,14145,14147 ,14147 ,14145,17347,17503,28469,19507,14806,14810,14809,14808,19695,17332,14807,14789,14788,14787,14786,14784,14782");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name())).thenReturn("EC,WEC2,WEC");


		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createDifferentSoapResposne());
		exception.expect(ApplicationServiceException.class);

		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForPassengers(createRequestBodyForPassenger(), SOAP_ACTION_URI, getSession());
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void getWebServiceResponseForPassengerErroCodePassengerIgnoreCase() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn("11,17569,17336,17391,19915,19436,19204");

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_NOT_FOUND_CODE_STATUS_LIST.name())).thenReturn(
						"17112,14145,14147 ,14147 ,14145,17347,17503,28469,19507,14806,14810,14809,14808,19695,17332,14807,14789,14788,14787,14786,14784,14782");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_WARNING_CODE_STATUS_LIST.name()))
				.thenReturn("14165 ,17652 ,14025");


		
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name())).thenReturn("EC,WEC2,WEC");

		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithErroCategoryPassengerIgnoreStatusList());

		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForPassengers(createRequestBodyForPassenger(), SOAP_ACTION_URI, getSession());

		Assert.assertNotEquals(null, amedeusResponseDetails);

	}
	@SuppressWarnings("unchecked")
	@Test
	public void getWebServiceResponseForPassengerErroCodeNotExistInConfig() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn("11,17569,17336,17391,19915,19436,19204");

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_NOT_FOUND_CODE_STATUS_LIST.name())).thenReturn(
						"17112,14145,14147 ,14147 ,14145,17347,17503,28469,19507,14806,14810,14809,14808,19695,17332,14807,14789,14788,14787,14786,14784,14782");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_WARNING_CODE_STATUS_LIST.name()))
				.thenReturn("14165 ,17652 ,14025");


		
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name())).thenReturn("EC,WEC2,WEC");

		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithErroCategoryNonExist());
		exception.expect(ApplicationServiceException.class);

		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForPassengers(createRequestBodyForPassenger(), SOAP_ACTION_URI, getSession());


	}
	@SuppressWarnings("unchecked")
	@Test
	public void getWebServiceResponseForPassengerErroCategoryNotExistInConfig() {
			Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn("17011,17111,17112 ,11,17569,17336,17391,19915,19436,19204");
				Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name())).thenReturn("EC,WEC2,WEC");


		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithErroCategoryCode());
		//exception.expect(ApplicationServiceException.class);

		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForPassengers(createRequestBodyForPassenger(), SOAP_ACTION_URI, getSession());
		Assert.assertNotEquals(null, amedeusResponseDetails);


	}
	@SuppressWarnings("unchecked")

	@Test
	public void shouldThowExceptionWhenSocketTimeoutOccuredForGetPassenger() {
		WebServiceIOException serviceNotAvailable = new WebServiceIOException(
				"I/O error: Read timed out; nested exception is java.net.SocketTimeoutException");
		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenThrow(serviceNotAvailable);

		exception.expect(ApplicationServiceException.class);
		gateway.getWebServiceResponseForPassengers(new Object(), SOAP_ACTION_URI, getSession());

	}

	
	@SuppressWarnings("unchecked")
	@Test
	public void shouldThowExceptionWhenAmadeusIsNotAvailableForGetPassenger() {
		WebServiceIOException serviceNotAvailable = new WebServiceIOException(
				"I/O error: BAaccess.test.webservices.1a.amadeus.com");
		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenThrow(serviceNotAvailable);

		exception.expect(ApplicationServiceException.class);

		gateway.getWebServiceResponseForPassengers(new Object(), SOAP_ACTION_URI, getSession());

	}

	public AmadeusSession getSession() {
		AmadeusSession sessionRequest = new AmadeusSession();
		sessionRequest.setChannel("KISOK");
		sessionRequest.setLocation("GB");
		sessionRequest.setScope("BOOKINGS");
		sessionRequest.setSecurityToken("1S3WS869ESHF43PWZW7EF6H5Y9");
		sessionRequest.setSessionId("010A4WCDNO");
		sessionRequest.setSequenceNumber("1");
		return sessionRequest;
	}

	private DCSIDCCPRIdentificationReply createSoapResposne() {
		DCSIDCCPRIdentificationReply amadeusPassengerReply = new DCSIDCCPRIdentificationReply();
		List<CustomerLevel> customerLevelList = new ArrayList<>();
		CustomerLevel customerLevel = new CustomerLevel();
		
		com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationDetailsType reservationControlInformationDetailsType = new com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationDetailsType();
		reservationControlInformationDetailsType.setControlNumber("UKON99");
		com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationType value = new com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationType();
		value.setReservation(reservationControlInformationDetailsType);
		customerLevel.setRecordLocator(value);
		customerLevelList.add(customerLevel);
		amadeusPassengerReply.setCustomerLevel(customerLevelList);
		return amadeusPassengerReply;
	}
	
	private DCSIDCCPRIdentificationReply createDifferentSoapResposne() {
		DCSIDCCPRIdentificationReply amadeusPassengerReply = new DCSIDCCPRIdentificationReply();
		List<CustomerLevel> customerLevelList = new ArrayList<>();
		CustomerLevel customerLevel = new CustomerLevel();
		
		com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationDetailsType reservationControlInformationDetailsType = new com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationDetailsType();
		reservationControlInformationDetailsType.setControlNumber("UKON88");
		com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationType value = new com.amadeus.xml.ccprrr_17_1_1a.ReservationControlInformationType();
		value.setReservation(reservationControlInformationDetailsType);
		customerLevel.setRecordLocator(value);
		customerLevelList.add(customerLevel);
		amadeusPassengerReply.setCustomerLevel(customerLevelList);
		return amadeusPassengerReply;
	}

	private Object createSoapResposneWithErroCategory() {
		DCSIDCCPRIdentificationReply amadeusPassengerReply = new DCSIDCCPRIdentificationReply();

		List<ErrorGroupType> errorList = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();

		ApplicationErrorInformationType valueType = new ApplicationErrorInformationType();
		ApplicationErrorDetailType value = new ApplicationErrorDetailType();
		value.setErrorCode("11");
		valueType.setErrorDetails(value);
		errorGroupType.setErrorOrWarningCodeDetails(valueType);
		value.setErrorCategory("WEC");
		errorList.add(errorGroupType);
		amadeusPassengerReply.setErrors(errorList);

		return amadeusPassengerReply;
	}
	private Object createSoapResposneWithErroCategoryPassengerNotFound() {
		DCSIDCCPRIdentificationReply amadeusPassengerReply = new DCSIDCCPRIdentificationReply();

		List<ErrorGroupType> errorList = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();

		ApplicationErrorInformationType valueType = new ApplicationErrorInformationType();
		ApplicationErrorDetailType value = new ApplicationErrorDetailType();
		value.setErrorCode("17112");
		valueType.setErrorDetails(value);
		errorGroupType.setErrorOrWarningCodeDetails(valueType);
		value.setErrorCategory("WEC");
		errorList.add(errorGroupType);
		amadeusPassengerReply.setErrors(errorList);

		return amadeusPassengerReply;
	}
	private Object createSoapResposneWithErroCategoryPassengerIgnoreStatusList() {
		DCSIDCCPRIdentificationReply amadeusPassengerReply = new DCSIDCCPRIdentificationReply();

		List<ErrorGroupType> errorList = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();

		ApplicationErrorInformationType valueType = new ApplicationErrorInformationType();
		ApplicationErrorDetailType value = new ApplicationErrorDetailType();
		value.setErrorCode("14165");
		valueType.setErrorDetails(value);
		errorGroupType.setErrorOrWarningCodeDetails(valueType);
		value.setErrorCategory("WEC");
		errorList.add(errorGroupType);
		amadeusPassengerReply.setErrors(errorList);

		return amadeusPassengerReply;
	}
	private Object createSoapResposneWithErroCategoryNonExist() {
		DCSIDCCPRIdentificationReply amadeusPassengerReply = new DCSIDCCPRIdentificationReply();

		List<ErrorGroupType> errorList = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();

		ApplicationErrorInformationType valueType = new ApplicationErrorInformationType();
		ApplicationErrorDetailType value = new ApplicationErrorDetailType();
		value.setErrorCode("141695");
		valueType.setErrorDetails(value);
		errorGroupType.setErrorOrWarningCodeDetails(valueType);
		value.setErrorCategory("EC");
		errorList.add(errorGroupType);
		amadeusPassengerReply.setErrors(errorList);

		return amadeusPassengerReply;
	}
	private Object createSoapResposneWithErroCategoryCode() {
		DCSIDCCPRIdentificationReply amadeusPassengerReply = new DCSIDCCPRIdentificationReply();

		List<ErrorGroupType> errorList = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();

		ApplicationErrorInformationType valueType = new ApplicationErrorInformationType();
		ApplicationErrorDetailType value = new ApplicationErrorDetailType();
		value.setErrorCode("11");
		valueType.setErrorDetails(value);
		errorGroupType.setErrorOrWarningCodeDetails(valueType);
		value.setErrorCategory("EC2");
		errorList.add(errorGroupType);
		amadeusPassengerReply.setErrors(errorList);

		return amadeusPassengerReply;
	}

	private DCSIDCCPRIdentification createRequestBodyForPassenger() {
		String bookingIdentifier = "UKON99";
		String passengerIdentifier = "2301DB5600005189";
		DCSIDCCPRIdentification dCSIDC_CPRIdentification = new DCSIDCCPRIdentification();
		SelectionDetailsType selectionDetailsType = new SelectionDetailsType();
		List<SelectionDetailsInformationTypeI> selectionDetailsInformationTypelist = new ArrayList<>();
		SelectionDetailsInformationTypeI selectionDetailsInformationTypeI = new SelectionDetailsInformationTypeI();
		selectionDetailsInformationTypeI.setOption(PassengerServiceConstants.SELECTION_DETAILS_INFORMATION_OPTION);
		selectionDetailsInformationTypelist.add(selectionDetailsInformationTypeI);

		selectionDetailsType.setSelectionDetails(selectionDetailsInformationTypelist);
		dCSIDC_CPRIdentification.setSelectionIndicators(selectionDetailsType);

		SetOfCriteria setOfCriteria = new SetOfCriteria();
		List<ItemReferencesAndVersionsType> itemReferencesAndVersionsList = new ArrayList<>();

		ItemReferencesAndVersionsType itemReferencesAndVersionsType = new ItemReferencesAndVersionsType();
		UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
		uniqueIdDescriptionType.setReferenceQualifier(PassengerServiceConstants.REFERENCE_QUALIFIER);
		uniqueIdDescriptionType.setPrimeId(passengerIdentifier);

		itemReferencesAndVersionsType.setIdSection(uniqueIdDescriptionType);
		itemReferencesAndVersionsList.add(itemReferencesAndVersionsType);
		setOfCriteria.setUniqueIdentifier(itemReferencesAndVersionsList);

		ReservationControlInformationType controlInformationType = new ReservationControlInformationType();
		ReservationControlInformationDetailsType controlInformationDetails = new ReservationControlInformationDetailsType();
		controlInformationDetails.setControlNumber(bookingIdentifier);
		controlInformationType.setReservation(controlInformationDetails);
		setOfCriteria.setRecordLocator(controlInformationType);

		FlightDetailsQueryType flight = new FlightDetailsQueryType();
		setOfCriteria.setTravelCriteria(flight);
		List<SetOfCriteria> ListCritera = new ArrayList<>();
		ListCritera.add(setOfCriteria);
		dCSIDC_CPRIdentification.setSetOfCriteria(ListCritera);
		return dCSIDC_CPRIdentification;
	}
}
