package com.iag.business.passenger.validation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.exception.ValidationServiceExceptionGenerator;

public class PassengerIdentifierValidationTest {

	private static final String DEV_MSG_DATA_INVALID = "Data Invalid";
	private static final String PASSENGERINGIDENTIFER_PATH = "passenger-identifier";
	private static final String PASSENGER_IDENTIFIER_SPECIAL_CHARS = "PAXOfkf@#$$$$";
	private static final String PASSENGER_IDENTIFIER_ABOVE_LIMIT = "etytirtpirtpiwtpiwpittwtytiw6722725722929";
	private static final String PASSENGER_IDENTIFIER_WITHIN_LIMIT = "PAX001rt121333";

	@InjectMocks
	private PassengerIdentifierValidation passengerIdentifierValidation;

	@Mock
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	ValidationServiceException validationServiceException;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		passengerIdentifierValidation = new PassengerIdentifierValidation(validationServiceExceptionGenerator);

	}

	@Test
	public void passengerIdentifierHavingSpecialCharacters() {
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceException());
		validationServiceException = passengerIdentifierValidation.validate(PASSENGER_IDENTIFIER_SPECIAL_CHARS);
		assertNotNull(validationServiceException);
		assertEquals(PassengerErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());
		assertEquals(PASSENGERINGIDENTIFER_PATH, validationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, validationServiceException.getDeveloperMessage());
	}

	@Test
	public void passengerIdentifierWithAboveLimitCharacters() {
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceException());
		validationServiceException = passengerIdentifierValidation.validate(PASSENGER_IDENTIFIER_ABOVE_LIMIT);
		assertNotNull(validationServiceException);
		assertEquals(PassengerErrorCode.DATA_INVALID.name(), validationServiceException.getCode());
		assertEquals(PASSENGERINGIDENTIFER_PATH, validationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, validationServiceException.getDeveloperMessage());
	}

	@Test
	public void passengerIdentifierWithValidValue() {
		ValidationServiceException validationServiceException = null;
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(validationServiceException);
		validationServiceException = passengerIdentifierValidation.validate(PASSENGER_IDENTIFIER_WITHIN_LIMIT);
		assertNull(validationServiceException);
	}

	private ValidationServiceException createValidationServiceException() {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				PassengerErrorCode.DATA_INVALID.name());
		validationServiceException.setDeveloperMessage(DEV_MSG_DATA_INVALID);
		validationServiceException.setPath(PASSENGERINGIDENTIFER_PATH);
		return validationServiceException;
	}

}
