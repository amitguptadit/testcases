package com.iag.business.passenger.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.proxy.config.ServiceProxy;



public class ValidationServiceExceptionGeneratorTest {

	private static final String path = "passenger-identifier";

	private static final String developerMessage_Key = "passenger.error.DATA_INVALID.developer_message_passengeridentifier";

	private static final String developerMessage = "Passenger Identifier is invalid";
	
	@InjectMocks
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;
	
	@Mock
	private ServiceProxy configurationInfrastructureServiceProxy;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void shouldCreateServiceExceptionWithChildError() {
		List<ValidationServiceException> validationServiceExceptionList = new ArrayList<ValidationServiceException>();
		ValidationServiceException childValidationServiceException1 = new ValidationServiceException(
				PassengerErrorCode.DATA_INVALID.name());
		ValidationServiceException childValidationServiceException2 = new ValidationServiceException(
				PassengerErrorCode.DATA_INVALID.name());
		validationServiceExceptionList.add(childValidationServiceException1);
		validationServiceExceptionList.add(childValidationServiceException2);
		ValidationServiceException outputValidationServiceException = validationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionList);
		assertEquals(PassengerErrorCode.REQUEST_INVALID.name(), outputValidationServiceException.getCode());
		assertEquals(2, outputValidationServiceException.getValidationExceptions().size());
		Iterator<ValidationServiceException> iterator = outputValidationServiceException.getValidationExceptions()
				.iterator();
		assertEquals(PassengerErrorCode.DATA_INVALID.name(), iterator.next().getCode());
		assertEquals(PassengerErrorCode.DATA_INVALID.name(), iterator.next().getCode());
	}

	@Test
	public void shouldCreateServiceExceptionWithEmptyList() {
		List<ValidationServiceException> validationServiceExceptionList = new ArrayList<ValidationServiceException>();
		ValidationServiceException validationServiceException = validationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionList);
		assertNotNull(validationServiceException);
		assertEquals(PassengerErrorCode.REQUEST_INVALID.name(), validationServiceException.getCode());
	}

	@Test
	public void shouldCreateValidationError() {
		Mockito.when(configurationInfrastructureServiceProxy
				.retrieveConfiguration(PassengerServiceConstants.ERROR_NAMESPACE,"passenger.error.DATA_INVALID.developer_message_passengeridentifier"))
				.thenReturn(developerMessage);
		ValidationServiceException validationServiceException = validationServiceExceptionGenerator
				.createValidationError(PassengerErrorCode.REQUEST_INVALID.name(), path, developerMessage_Key);
		assertNotNull(validationServiceException);
		assertEquals(PassengerErrorCode.REQUEST_INVALID.name(), validationServiceException.getCode());
		assertEquals(path, validationServiceException.getPath());
		assertEquals(developerMessage, validationServiceException.getDeveloperMessage());
	}

	@Test
	public void shouldCreateServiceException() {
		Mockito.when(configurationInfrastructureServiceProxy
				.retrieveConfiguration(PassengerServiceConstants.ERROR_NAMESPACE,"passenger.error.DATA_INVALID.developer_message_passengeridentifier"))
				.thenReturn(developerMessage);
		ValidationServiceException validationServiceException = validationServiceExceptionGenerator
				.createServiceException(PassengerErrorCode.DATA_INVALID.name(), path, developerMessage_Key);
		assertNotNull(validationServiceException);
		assertEquals(PassengerErrorCode.REQUEST_INVALID.name(), validationServiceException.getCode());
		assertEquals(PassengerErrorCode.DATA_INVALID.name(),
				validationServiceException.getValidationExceptions().iterator().next().getCode());
		assertEquals(path, validationServiceException.getValidationExceptions().iterator().next().getPath());
		assertEquals(developerMessage,
				validationServiceException.getValidationExceptions().iterator().next().getDeveloperMessage());
	}

	@Test
	public void checkBusinessMessagewithErrorCode() {
		Mockito.when(
				configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.ERROR_NAMESPACE,"passenger.error.REQUEST_INVALID.code"))
				.thenReturn("Request Invalid");
		String businessMessage = validationServiceExceptionGenerator
				.getMessageConfigurationValue("passenger.error.REQUEST_INVALID.code");
		assertEquals("Request Invalid", businessMessage);
	}
	
	@Test
	public void checkBusinessMessagewithWithoutErrorCode() {
		Mockito.when(
				configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.ERROR_NAMESPACE,StringUtils.EMPTY))
				.thenReturn(StringUtils.EMPTY);
		String businessMessage = validationServiceExceptionGenerator
				.getMessageConfigurationValue(StringUtils.EMPTY);
		assertEquals(StringUtils.EMPTY, businessMessage);
	}

}
