package com.iag.business.passenger.repository;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.junit.Assert.*;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.WebServiceIOException;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.amadeus.xml.ccpruq_16_6_1a.CountrySubEntityDetailsBatchTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR;
import com.amadeus.xml.ccpruq_16_6_1a.FlightDetailsResponseType;
import com.amadeus.xml.ccpruq_16_6_1a.ItemReferencesAndVersionsType93421S;
import com.amadeus.xml.ccpruq_16_6_1a.NameAndAddressBatchTypeU8146S;
import com.amadeus.xml.ccpruq_16_6_1a.NationalityDetailsTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.NationalityTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.OutboundCarrierDetailsTypeI;
import com.amadeus.xml.ccpruq_16_6_1a.OutboundFlightNumberDetailstypeI3083C;
import com.amadeus.xml.ccpruq_16_6_1a.PlaceLocationIdentificationTypeU8493S;
import com.amadeus.xml.ccpruq_16_6_1a.StatusDetailsType;
import com.amadeus.xml.ccpruq_16_6_1a.StatusType148330S;
import com.amadeus.xml.ccpruq_16_6_1a.StreetTypeU;
import com.amadeus.xml.ccpruq_16_6_1a.TravellerDetailsTypeI;
import com.amadeus.xml.ccpruq_16_6_1a.TravellerInformationTypeI;
import com.amadeus.xml.ccpruq_16_6_1a.TravellerSurnameInformationTypeI;
import com.amadeus.xml.ccpruq_16_6_1a.UniqueIdDescriptionType;
import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR.CustomerEdit;
import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR.CustomerEdit.Edits;
import com.amadeus.xml.ccpruq_16_6_1a.DCSCPREditCPR.CustomerEdit.Edits.AddressDetailsGroup;
import com.amadeus.xml.ccprur_16_6_1a.ApplicationErrorDetailType;
import com.amadeus.xml.ccprur_16_6_1a.ApplicationErrorInformationType;
import com.amadeus.xml.ccprur_16_6_1a.DCSCPREditCPRReply;
import com.amadeus.xml.ccprur_16_6_1a.ErrorGroupType;
import com.amadeus.xml.ccprur_16_6_1a.SelectionDetailsInformationTypeI;
import com.amadeus.xml.ccprur_16_6_1a.SelectionDetailsTypeI;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.domain.model.Carrier;
import com.iag.business.passenger.domain.model.CarrierType;
import com.iag.business.passenger.domain.model.Destination;
import com.iag.business.passenger.domain.model.Eticket;
import com.iag.business.passenger.domain.model.Gate;
import com.iag.business.passenger.domain.model.Itinerary;
import com.iag.business.passenger.domain.model.ItineraryItem;
import com.iag.business.passenger.domain.model.ItineraryItemStatus;
import com.iag.business.passenger.domain.model.Origin;
import com.iag.business.passenger.domain.model.Seat;
import com.iag.business.passenger.domain.model.address.PostalAddress;
import com.iag.business.passenger.domain.model.address.TelecomAddress;
import com.iag.business.passenger.domain.model.address.PostalAddress.PostalAddressBuilder;
import com.iag.business.passenger.domain.model.location.Location;
import com.iag.business.passenger.domain.model.location.LocationType;
import com.iag.business.passenger.domain.model.party.Gender;
import com.iag.business.passenger.domain.model.party.Nationality;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.party.PersonName;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifier;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifierType;
import com.iag.business.passenger.domain.model.party.Person.PersonBuilder;
import com.iag.business.passenger.domain.model.party.PersonName.PersonNameBuilder;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.domain.model.party.role.PassengerStatus;
import com.iag.business.passenger.domain.model.party.role.PassengerType;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact.EmergencyContactBuilder;
import com.iag.business.passenger.domain.model.party.role.Passenger.PassengerBuilder;
import com.iag.business.passenger.proxy.config.ConfigurationInfrastructureServiceProxy;
import com.iag.business.passenger.session.AmadeusSession;


public class AmadeusWebServiceGatewayForUpdatePassengerTest {

	private static final String SOAP_ACTION_URI = "http://webservices.amadeus.com/1ASIWIAGBA/CCPRRQ_17_1_1A";
	private static final String UPDATE_SOAP_URL = "http://webservices.amadeus.com/1ASIWIAGBA/CCPRUQ_16_6_1A";
	/*private static final Object CHILD = "CHILD";
	private static final Object ADULT = "ADULT";
	private static final Object PASSENGER_ID = "PAX0013";
	private static final Object CHECKEDIN = "CHECKEDIN";
	private static final Object PASSENGER_ID_STANDBY = "PAX0013";
	private static final Object STANDBY = "STANDBY";
	private static final Object itineraryItem = "PAX0013";
	private static final Object INFANT = "INFANT";
	private static final Object PASSENGER_ID_NO_REGISTERD_IDENTIFIER = "PAX0013";
	private static final Object PASSENGER_ID_DESTINATION_ADDRESS = "PAX001";
	private static final Object PASSENGER_ID_FLIGHT_CONFIRMED = "PAX0013";
	private static final Object CONFIRMED = "PAX0013";
	private static final Object PASSENGER_ID_BUSINESS_BOOKING = "PAX0013";
	private static final Object BUSINESS = "PAX0013";
	private static final Object PASSENGER_ID_ECONOMY_BOOKING = "PAX0013";
	private static final Object ECONOMY = "PAX0013";
	private static final Object BA = "BA";
	private static final Object ASSOCIATED_PASSENGER_ID = "PAX0013";
	private static final Object MR = "MR";
	private static final Object JAMES = "JAMES";
	private static final Object NORMAN2 = "NORMAN";
	private static final Object PASSENGER_ID_PREMIUM_BOOKING = "PAX0013";
	private static final Object PREMIUM_ECONOMY = "PAX0013";
	private static final String JANE = "JANE";
	private static final String NORMAN = "NORMAN";
	private static final String TELECOM_NUMBER = "TELECOM_NUMBER";
	private static final String LHR = "LHR";
	private static final String UPPER = "UPPER";
	private static final String PAX001 = "PAX001";
	private static final Object C = "C";
	private static final Object GB = "GB";
	private static final String PASSPORT = "PASSPORT";
	private static final Object OP = "OP";
	private static final Object OPERATING = "OPERATING";
	private static final Object OPS = "OPS";
	private static final Object GATE2 = "GATE2";
	private static final Object T4 = "T4";
	private static final Object D001 = "D001";
	private static final Object T2 = "T2";
	private static final Object THOMAS = "THOMAS";
	private static final Object Mr = "Mr";*/
	private static final String SURNAME = "JONES";
	private static final String bookingIdentifier="2301DB2D00009C26";
	private static final String passengerIdentifier = "NQZIB5";
	// amadeusWebServiceGateway
	private AmadeusWebServiceGatewayForUpdatePassenger gateway;

	private static final String SECURITY_TOKEN = "2Y4BVG37P16P42HTA1YFUH5ZBE";

	private static final String PROCESSING_CODE_SUCCESS = "P";

	private static final int SEQUENCE_NUMBER = 1;

	private static final String SESSION_ID = "02WQO94SAI";
	@Mock
	private WebServiceTemplate amadeusWebServiceTemplateForUpdatePassenger;
	@Mock
	private ConfigurationInfrastructureServiceProxy configurationInfrastructureServiceProxy;

	@Mock
	Jaxb2Marshaller amadeusMarshallerForUpdatePassenger;
	
	@Mock
	Jaxb2Marshaller amadeusUnMarshallerForUpdatePassenger;
     
	
	Passenger<String> passenger;
	
	
	@Rule
	public final ExpectedException exception = ExpectedException.none();

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		gateway = new AmadeusWebServiceGatewayForUpdatePassenger();
		ReflectionTestUtils.setField(gateway, "amadeusMarshallerForUpdatePassenger", amadeusMarshallerForUpdatePassenger);
		ReflectionTestUtils.setField(gateway, "amadeusUnMarshallerForUpdatePassenger", amadeusUnMarshallerForUpdatePassenger);
		ReflectionTestUtils.setField(gateway, "amadeusWebServiceTemplateForUpdatePassenger", amadeusWebServiceTemplateForUpdatePassenger);
		ReflectionTestUtils.setField(gateway, "configurationInfrastructureServiceProxy",
				configurationInfrastructureServiceProxy);
	}
    
	@SuppressWarnings("unchecked")
	@Test
	public void getWebServiceResponseForUpdatePassenger() {
		DCSCPREditCPR dcscpEditCPR = createRequestBodyForUpdatePassenge();
		Mockito.when(amadeusWebServiceTemplateForUpdatePassenger.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposne());
		final Object amedeusResponseDetails = gateway.getWebServiceResponseForUpdatePassenger(dcscpEditCPR, UPDATE_SOAP_URL , getSession());
         System.out.println(dcscpEditCPR.getCustomerEdit().size());
		 assertNotEquals(null, amedeusResponseDetails);
	}
	@SuppressWarnings("unchecked")
	@Test
	public void getWebServiceResponseForUpdatePassengerErrorCode() {
			Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn("17011,17111,17112 ,11,17569,17336,17391,19915,19436,19204");
				Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name())).thenReturn("EC,WEC2,WEC");


		Mockito.when(amadeusWebServiceTemplateForUpdatePassenger.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithErroCategory());
		exception.expect(ApplicationServiceException.class);

		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForUpdatePassenger(createRequestBodyForUpdatePassenge(), UPDATE_SOAP_URL, getSession());

	}
	@SuppressWarnings("unchecked")
	@Test
	public void getWebServiceResponseForUpdatePassengerErroCodePassengerNotFound() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn("11,17569,17336,17391,19915,19436,19204");

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_NOT_FOUND_CODE_STATUS_LIST.name())).thenReturn(
						"17112,14145,14147 ,14147 ,14145,17347,17503,28469,19507,14806,14810,14809,14808,19695,17332,14807,14789,14788,14787,14786,14784,14782");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name())).thenReturn("EC,WEC2,WEC");


		Mockito.when(amadeusWebServiceTemplateForUpdatePassenger.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithErroCategoryPassengerNotFound());
		exception.expect(ApplicationServiceException.class);

		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForUpdatePassenger(createRequestBodyForUpdatePassenge(), UPDATE_SOAP_URL, getSession());

	}
	@SuppressWarnings("unchecked")
	@Test
	public void getWebServiceResponseForUpdatePassengerErroCodePassengerIgnoreCase() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn("11,17569,17336,17391,19915,19436,19204");

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_NOT_FOUND_CODE_STATUS_LIST.name())).thenReturn(
						"17112,14145,14147 ,14147 ,14145,17347,17503,28469,19507,14806,14810,14809,14808,19695,17332,14807,14789,14788,14787,14786,14784,14782");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_WARNING_CODE_STATUS_LIST.name()))
				.thenReturn("14165 ,17652 ,14025");


		
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name())).thenReturn("EC,WEC2,WEC");

		Mockito.when(amadeusWebServiceTemplateForUpdatePassenger.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithErroCategoryPassengerIgnoreStatusList());

		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForUpdatePassenger(createRequestBodyForUpdatePassenge(), UPDATE_SOAP_URL, getSession());

		        assertNotEquals(null, amedeusResponseDetails);

	}
	@SuppressWarnings("unchecked")
	@Test
	public void getWebServiceResponseForUpdatePassengerErroCodeNotExistInConfig() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn("11,17569,17336,17391,19915,19436,19204");

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_NOT_FOUND_CODE_STATUS_LIST.name())).thenReturn(
						"17112,14145,14147 ,14147 ,14145,17347,17503,28469,19507,14806,14810,14809,14808,19695,17332,14807,14789,14788,14787,14786,14784,14782");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_WARNING_CODE_STATUS_LIST.name()))
				.thenReturn("14165 ,17652 ,14025");


		
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name())).thenReturn("EC,WEC2,WEC");

		Mockito.when(amadeusWebServiceTemplateForUpdatePassenger.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithErroCategoryNonExist());
		exception.expect(ApplicationServiceException.class);

		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForUpdatePassenger(createRequestBodyForUpdatePassenge(), UPDATE_SOAP_URL, getSession());


	}
	@SuppressWarnings("unchecked")
	@Test
	public void getWebServiceResponseForUpdatePassengerErroCategoryNotExistInConfig() {
			Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn("17011,17111,17112 ,11,17569,17336,17391,19915,19436,19204");
				Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				PassengerServiceConstants.AMADEUS_NAMESPACE,
				PassengerErrorCode.PASSENGER_ERROR_CATEGORY.name())).thenReturn("EC,WEC2,WEC");


		Mockito.when(amadeusWebServiceTemplateForUpdatePassenger.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(createSoapResposneWithErroCategoryCode());
		//exception.expect(ApplicationServiceException.class);

		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForUpdatePassenger(createRequestBodyForUpdatePassenge(), UPDATE_SOAP_URL, getSession());
		    assertNotEquals(null, amedeusResponseDetails);


	}
	@SuppressWarnings("unchecked")

	@Test
	public void shouldThowExceptionWhenSocketTimeoutOccuredForUpdatePassenger() {
		WebServiceIOException serviceNotAvailable = new WebServiceIOException(
				"I/O error: Read timed out; nested exception is java.net.SocketTimeoutException");
		Mockito.when(amadeusWebServiceTemplateForUpdatePassenger.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenThrow(serviceNotAvailable);

		exception.expect(ApplicationServiceException.class);
		gateway.getWebServiceResponseForUpdatePassenger(new Object(), UPDATE_SOAP_URL, getSession());

	}

	
	@SuppressWarnings("unchecked")
	@Test
	public void shouldThowExceptionWhenAmadeusIsNotAvailableForUpdatePassenger() {
		WebServiceIOException serviceNotAvailable = new WebServiceIOException(
				"I/O error: BAaccess.test.webservices.1a.amadeus.com");
		Mockito.when(amadeusWebServiceTemplateForUpdatePassenger.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenThrow(serviceNotAvailable);

		exception.expect(ApplicationServiceException.class);

		gateway.getWebServiceResponseForUpdatePassenger(new Object(), UPDATE_SOAP_URL, getSession());

	}


	private DCSCPREditCPRReply createSoapResposne() {
		DCSCPREditCPRReply amadeusUpdatePassengerReply = new DCSCPREditCPRReply();
		return amadeusUpdatePassengerReply;
	}
	private Object createSoapResposneWithErroCategory() {
		DCSCPREditCPRReply amadeusPassengerReply = new DCSCPREditCPRReply();

		List<ErrorGroupType> errorList = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();

		ApplicationErrorInformationType valueType = new ApplicationErrorInformationType();
		ApplicationErrorDetailType value = new ApplicationErrorDetailType();
		value.setErrorCode("11");
		valueType.setErrorDetails(value);
		errorGroupType.setErrorOrWarningCodeDetails(valueType);
		value.setErrorCategory("WEC");
		errorList.add(errorGroupType);
		amadeusPassengerReply.setErrors(errorList);

		return amadeusPassengerReply;
	}
	private Object createSoapResposneWithErroCategoryPassengerNotFound() {
		DCSCPREditCPRReply amadeusPassengerReply = new DCSCPREditCPRReply();

		List<ErrorGroupType> errorList = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();

		ApplicationErrorInformationType valueType = new ApplicationErrorInformationType();
		ApplicationErrorDetailType value = new ApplicationErrorDetailType();
		value.setErrorCode("17112");
		valueType.setErrorDetails(value);
		errorGroupType.setErrorOrWarningCodeDetails(valueType);
		value.setErrorCategory("WEC");
		errorList.add(errorGroupType);
		amadeusPassengerReply.setErrors(errorList);

		return amadeusPassengerReply;
	}
	private Object createSoapResposneWithErroCategoryPassengerIgnoreStatusList() {
		DCSCPREditCPRReply amadeusPassengerReply = new DCSCPREditCPRReply();

		List<ErrorGroupType> errorList = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();

		ApplicationErrorInformationType valueType = new ApplicationErrorInformationType();
		ApplicationErrorDetailType value = new ApplicationErrorDetailType();
		value.setErrorCode("14165");
		valueType.setErrorDetails(value);
		errorGroupType.setErrorOrWarningCodeDetails(valueType);
		value.setErrorCategory("WEC");
		errorList.add(errorGroupType);
		amadeusPassengerReply.setErrors(errorList);

		return amadeusPassengerReply;
	}
	private Object createSoapResposneWithErroCategoryNonExist() {
		DCSCPREditCPRReply amadeusPassengerReply = new DCSCPREditCPRReply();

		List<ErrorGroupType> errorList = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();

		ApplicationErrorInformationType valueType = new ApplicationErrorInformationType();
		ApplicationErrorDetailType value = new ApplicationErrorDetailType();
		value.setErrorCode("141695");
		valueType.setErrorDetails(value);
		errorGroupType.setErrorOrWarningCodeDetails(valueType);
		value.setErrorCategory("EC");
		errorList.add(errorGroupType);
		amadeusPassengerReply.setErrors(errorList);

		return amadeusPassengerReply;
	}
	private Object createSoapResposneWithErroCategoryCode() {
		DCSCPREditCPRReply amadeusPassengerReply = new DCSCPREditCPRReply();

		List<ErrorGroupType> errorList = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();

		ApplicationErrorInformationType valueType = new ApplicationErrorInformationType();
		ApplicationErrorDetailType value = new ApplicationErrorDetailType();
		value.setErrorCode("11");
		valueType.setErrorDetails(value);
		errorGroupType.setErrorOrWarningCodeDetails(valueType);
		value.setErrorCategory("EC2");
		errorList.add(errorGroupType);
		amadeusPassengerReply.setErrors(errorList);

		return amadeusPassengerReply;
	}
	private DCSCPREditCPR createRequestBodyForUpdatePassenge() {	
		
		DCSCPREditCPR dCSCPREditCPRRequest = new DCSCPREditCPR();
		List<CustomerEdit> customerEditList = buildCustomerDetails();
		dCSCPREditCPRRequest.setCustomerEdit(customerEditList);
		//System.out.println(dCSCPREditCPRRequest.getCustomerEdit().size());
		return dCSCPREditCPRRequest;
	}

	private List<CustomerEdit> buildCustomerDetails() {
		List<CustomerEdit> customerEditList = new ArrayList<>();
		CustomerEdit customerEdit = new CustomerEdit();
		TravellerSurnameInformationTypeI travellerSurnameInformationTypeI = new TravellerSurnameInformationTypeI();
		// map surname -> familyName
		travellerSurnameInformationTypeI.setSurname(SURNAME);  //JONES
		// map type -> type
		travellerSurnameInformationTypeI.setType("A");  //A
		
		TravellerInformationTypeI travellerInformationTypeI = new TravellerInformationTypeI();
		travellerInformationTypeI.setPaxDetails(travellerSurnameInformationTypeI);
		List<TravellerDetailsTypeI> travellerDetailsTypeIList = new ArrayList<>();
		TravellerDetailsTypeI travellerDetailsTypeI = new TravellerDetailsTypeI();
		travellerDetailsTypeI.setGivenName("JHON");  //JHON
		travellerDetailsTypeIList.add(travellerDetailsTypeI);
		travellerInformationTypeI.setOtherPaxDetails(travellerDetailsTypeIList);

		ItemReferencesAndVersionsType93421S itemReferencesAndVersionsType93421S = new ItemReferencesAndVersionsType93421S();
		UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
		uniqueIdDescriptionType.setReferenceQualifier(PassengerServiceConstants.REFERENCE_QUALIFIER);  //UCI
		uniqueIdDescriptionType.setPrimeId(passengerIdentifier); //NQZIB5
		itemReferencesAndVersionsType93421S.setIdSection(uniqueIdDescriptionType);
		customerEdit.setUniqueCustomerId(itemReferencesAndVersionsType93421S);
		customerEdit.setCustomerDetails(travellerInformationTypeI);
		customerEdit.setEdits(getOperatingFlightDetails());
		//customerEdit.setEdits(buildCommonEditsForCustomerDetails(passenger, bookingIdentifier));
		//customerEdit.setEdits(nationalityMapperForUpdatePassenger.buildNationalityDetails(passenger));
		customerEdit.setEdits(getHomeAndDestinationAddress());
		//customerEdit.setEdits(documentsMapperForUpdatePassenger.buildDocuments(passenger));
		//customerEdit.setEdits(emergencyContactMapperForUpdatePassenger.buildEmergencyContact(passenger));
		customerEditList.add(customerEdit);

		return customerEditList;

	}

	private List<Edits> getOperatingFlightDetails() {
		List<Edits> editList = new ArrayList<>();
		Edits edits = new Edits();
		FlightDetailsResponseType flightDetailsResponseType = new FlightDetailsResponseType();
		OutboundCarrierDetailsTypeI outboundCarrierDetailsTypeI = new OutboundCarrierDetailsTypeI();
		List<ItineraryItem> itineraryItemList = new ArrayList<ItineraryItem>();
		ItineraryItem itineraryItem = new ItineraryItem();
		List<Carrier> carriers = new ArrayList<>();
		Carrier carrier = new Carrier();
		carrier.setType(CarrierType.OPERATING);
		carrier.setFlightNumber("15");
		itineraryItem.setCarriers(carriers);
		itineraryItemList.add(itineraryItem);
		List<Carrier> CarrierList = null;
		ItineraryItem Itemitinerary = null;
		String marketingCareer = null;
		String flightNumber = null;
		for (ItineraryItem itineraryItems : itineraryItemList) {
			Itemitinerary = itineraryItems;
			CarrierList = itineraryItems.getCarriers();
			for (Carrier carrier_1 : CarrierList) {
				marketingCareer = carrier_1.getType().name();
				flightNumber = carrier_1.getFlightNumber();
			}
			outboundCarrierDetailsTypeI.setMarketingCarrier(marketingCareer);
			flightDetailsResponseType.setCarrierDetails(outboundCarrierDetailsTypeI);
			OutboundFlightNumberDetailstypeI3083C outboundFlightNumberDetailstypeI3083C = new OutboundFlightNumberDetailstypeI3083C();
			outboundFlightNumberDetailstypeI3083C.setFlightNumber(flightNumber);
			flightDetailsResponseType.setFlightDetails(outboundFlightNumberDetailstypeI3083C);
			// BigInteger.valueOf(itineraryItem.getScheduledDepartureLocalDatetime())
			// BigInteger bigInt = new
			// BigInteger(Itemitinerary.getScheduledDepartureLocalDatetime().toString());
			// flightDetailsResponseType.setDepartureDate(bigInt);
			flightDetailsResponseType.setBoardPoint("LHR");
		}
		edits.setOperatingFlightDetails(flightDetailsResponseType);
		ItemReferencesAndVersionsType93421S itemReferencesAndVersionsType93421S = new ItemReferencesAndVersionsType93421S();
		UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
		uniqueIdDescriptionType.setReferenceQualifier(PassengerServiceConstants.REFERENCE_IDENTIFIER);
		uniqueIdDescriptionType.setPrimeId(bookingIdentifier);
		itemReferencesAndVersionsType93421S.setIdSection(uniqueIdDescriptionType);
		edits.setUniqueProductId(itemReferencesAndVersionsType93421S);
		//edits.setDocuments(getDocuments(passenger));
		StatusType148330S statusType148330S = new StatusType148330S();
		StatusDetailsType statusDetailsTyp = new StatusDetailsType();
		statusDetailsTyp.setIndicator(PassengerServiceConstants.INDICATOR);
		statusDetailsTyp.setAction(PassengerServiceConstants.ACTION);
		statusType148330S.setStatusInformation(statusDetailsTyp);
		edits.setCprGroupDeleteIndicators(statusType148330S);
		editList.add(getNationality(edits));
		//editList.add(getEmergencyContact(edits, passenger));
		editList.add(edits);
		return editList;

	}
	@SuppressWarnings("rawtypes")
	public List<Edits> getHomeAndDestinationAddress() {
		List<Edits> editList = new ArrayList<>();
		Edits edits = new Edits();
		StatusDetailsType detailsTyp = new StatusDetailsType();
		StatusType148330S statusType148330S = new StatusType148330S();
		AddressDetailsGroup addressDetailsGroup = new AddressDetailsGroup();
		NameAndAddressBatchTypeU8146S nameAndAddressBatchTypeU8146S = new NameAndAddressBatchTypeU8146S();
		detailsTyp.setIndicator(PassengerServiceConstants.NATIONALITY_INDICATOR);
		detailsTyp.setAction(PassengerServiceConstants.HOME_DESTINATION_ACTION);
		statusType148330S.setStatusInformation(detailsTyp);
		nameAndAddressBatchTypeU8146S.setTraveler(PassengerServiceConstants.TRAVELER);
		edits.setCprGroupDeleteIndicators(statusType148330S);
		List<ItineraryItem> itineraryItemList = new ArrayList<>();
		ItineraryItem itineraryItem = new ItineraryItem();
		String country = "INDIA";
		String[] addressLine1 = {"NOIDA","SECTOR-44"};
		PostalAddressBuilder postalAddressBuilder = new PostalAddressBuilder(addressLine1,country);
		postalAddressBuilder.setCity("NOIDA");
		postalAddressBuilder.setPostalCode("201301");
		postalAddressBuilder.setState("UP");
		PostalAddress postalAddress = postalAddressBuilder.build();
		String[] address_Line=postalAddress.getAddressLines();
		String City=postalAddress.getCity();
		String State=postalAddress.getState();
		String Country=postalAddress.getCountry();
		String postalCode=postalAddress.getPostCode();
		itineraryItem.setDestinationAddress(postalAddress);
		itineraryItemList.add(itineraryItem);
		for (ItineraryItem itineraryItem_I : itineraryItemList) {
			StreetTypeU streetTypeU = new StreetTypeU();
			String[] addressLineList = itineraryItem_I.getDestinationAddress().getAddressLines();
			String destinationAddressLine = null;
			for (String addressLine : addressLineList) {
				destinationAddressLine = addressLine;
				streetTypeU.setStreet(destinationAddressLine);
			}
			nameAndAddressBatchTypeU8146S.setTravelerAddress(streetTypeU);
			CountrySubEntityDetailsBatchTypeU countrySubEntityDetailsBatchTypeU = new CountrySubEntityDetailsBatchTypeU();
			nameAndAddressBatchTypeU8146S.setTravelerCountry(countrySubEntityDetailsBatchTypeU);
			if (itineraryItem_I.getDestinationAddress() != null) {
				nameAndAddressBatchTypeU8146S.setTravelerCity(itineraryItem_I.getDestinationAddress().getCity());
				nameAndAddressBatchTypeU8146S
						.setTravelerCountryCode(itineraryItem_I.getDestinationAddress().getCountry());
				nameAndAddressBatchTypeU8146S.setTravelerPostcode(itineraryItem_I.getDestinationAddress().getPostCode());
				if (itineraryItem_I.getDestinationAddress().getState() != null) {
					countrySubEntityDetailsBatchTypeU
							.setCountrySubEntityName(itineraryItem.getDestinationAddress().getState());
				}
			}
			addressDetailsGroup.setAddressDetails(nameAndAddressBatchTypeU8146S);
		}
		PlaceLocationIdentificationTypeU8493S placeLocationIdentificationTypeU8493S = new PlaceLocationIdentificationTypeU8493S();
		placeLocationIdentificationTypeU8493S.setLocationType(PassengerServiceConstants.ADDRESS_LOCATION_TYPE);
		
		addressDetailsGroup.setAddressType(placeLocationIdentificationTypeU8493S);
		edits.setAddressDetailsGroup(addressDetailsGroup);
		editList.add(edits);
		return editList;
	}

	private Edits getNationality(Edits edits) {
		StatusDetailsType detailsTyp = new StatusDetailsType();
		detailsTyp.setIndicator(PassengerServiceConstants.NATIONALITY_INDICATOR);
		detailsTyp.setAction(PassengerServiceConstants.NATIONALITY_ACTION);
		StatusType148330S statusType148330S = new StatusType148330S();
		statusType148330S.setStatusInformation(detailsTyp);
		NationalityTypeU nationalityTypeU = new NationalityTypeU();
		nationalityTypeU.setCodeQualifier(PassengerServiceConstants.CODE_QUALIFIER);
		NationalityDetailsTypeU nationalityDetailsTypeU = new NationalityDetailsTypeU();
		nationalityDetailsTypeU.setNationalityCode("IND");
		nationalityTypeU.setNationalityDetails(nationalityDetailsTypeU);
		edits.setCountry(nationalityTypeU);
		edits.setCprGroupDeleteIndicators(statusType148330S);
		return edits;
	}

	public AmadeusSession getSession() {
		AmadeusSession sessionRequest = new AmadeusSession();
		sessionRequest.setChannel("KISOK");
		sessionRequest.setLocation("GB");
		sessionRequest.setScope("BOOKINGS");
		sessionRequest.setSecurityToken("1S3WS869ESHF43PWZW7EF6H5Y9");
		sessionRequest.setSessionId("010A4WCDNO");
		sessionRequest.setSequenceNumber("1");
		return sessionRequest;
	}
}
