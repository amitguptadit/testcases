package com.iag.business.passenger.validation;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.common.collect.Lists;
import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.domain.model.Carrier;
import com.iag.business.passenger.domain.model.CarrierType;
import com.iag.business.passenger.domain.model.Destination;
import com.iag.business.passenger.domain.model.Eticket;
import com.iag.business.passenger.domain.model.Gate;
import com.iag.business.passenger.domain.model.Itinerary;
import com.iag.business.passenger.domain.model.ItineraryItem;
import com.iag.business.passenger.domain.model.ItineraryItemStatus;
import com.iag.business.passenger.domain.model.Origin;
import com.iag.business.passenger.domain.model.Seat;
import com.iag.business.passenger.domain.model.address.TelecomAddress;
import com.iag.business.passenger.domain.model.location.Location;
import com.iag.business.passenger.domain.model.location.LocationType;
import com.iag.business.passenger.domain.model.party.Gender;
import com.iag.business.passenger.domain.model.party.Nationality;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.party.Person.PersonBuilder;
import com.iag.business.passenger.domain.model.party.PersonName;
import com.iag.business.passenger.domain.model.party.PersonName.PersonNameBuilder;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifier;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifierType;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact.EmergencyContactBuilder;
//com.iag.business.passenger.domain.model.party.role
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.domain.model.party.role.Passenger.PassengerBuilder;
import com.iag.business.passenger.domain.model.party.role.PassengerStatus;
import com.iag.business.passenger.domain.model.party.role.PassengerType;
import com.iag.business.passenger.error.matcher.CustomValidationServiceExceptionMatcher;
import com.iag.business.passenger.exception.ValidationServiceExceptionGenerator;



public class UpdatePassengerValidatorTest {
	private static final Object CHILD = "CHILD";
	private static final Object ADULT = "ADULT";
	private static final Object PASSENGER_ID = "PAX0013";
	private static final Object CHECKEDIN = "CHECKEDIN";
	private static final Object PASSENGER_ID_STANDBY = "PAX0013";
	private static final Object STANDBY = "STANDBY";
	private static final Object itineraryItem = "PAX0013";
	private static final Object INFANT = "INFANT";
	private static final Object PASSENGER_ID_NO_REGISTERD_IDENTIFIER = "PAX0013";
	private static final Object PASSENGER_ID_DESTINATION_ADDRESS = "PAX001";
	private static final Object PASSENGER_ID_FLIGHT_CONFIRMED = "PAX0013";
	private static final Object CONFIRMED = "PAX0013";
	private static final Object PASSENGER_ID_BUSINESS_BOOKING = "PAX0013";
	private static final Object BUSINESS = "PAX0013";
	private static final Object PASSENGER_ID_ECONOMY_BOOKING = "PAX0013";
	private static final Object ECONOMY = "PAX0013";
	private static final Object BA = "BA";
	private static final Object ASSOCIATED_PASSENGER_ID = "PAX0013";
	private static final Object MR = "MR";
	private static final Object JAMES = "JAMES";
	private static final Object NORMAN2 = "NORMAN";
	private static final Object PASSENGER_ID_PREMIUM_BOOKING = "PAX0013";
	private static final Object PREMIUM_ECONOMY = "PAX0013";
	private static final String JANE = "JANE";
	private static final String NORMAN = "NORMAN";
	private static final String TELECOM_NUMBER = "TELECOM_NUMBER";
	private static final String LHR = "LHR";
	private static final String UPPER = "UPPER";
	private static final String PAX001 = "PAX001";
	private static final Object C = "C";
	private static final Object GB = "GB";
	private static final String PASSPORT = "PASSPORT";
	private static final Object OP = "OP";
	private static final Object OPERATING = "OPERATING";
	private static final Object OPS = "OPS";
	private static final Object GATE2 = "GATE2";
	private static final Object T4 = "T4";
	private static final Object D001 = "D001";
	private static final Object T2 = "T2";
	private static final Object THOMAS = "THOMAS";
	private static final Object Mr = "Mr";
	
	@InjectMocks
	private UpdatePassengerValidator updatePassengerValidator;

	@Mock
	private  BookingIdentifierValidation mockBookingIdentifierValidation;
	
	@Mock
	private  PassengerIdentifierValidation mockPassengerIdentifierValidation;
	
	@Mock
	private  HeaderValidation headerValueMapValidation;
	
	@Mock
	private  ValidationServiceExceptionGenerator mockValidationServiceExceptionGenerator;
	
	
	private Passenger<String> passenger;
	
	@Mock
	private PassengerFieldsValidation mockPassengerValidation;
	
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	
	
	private static final String DEV_MSG_DATA_INVALID = "Data Invalid";
	
	private static final String PASSENGERINGIDENTIFER_PATH = "passenger-identifier";
	private static final String  BOOKINGIDENTIFER_PATH = "booking-identifier";
	private static final String PASSENGER_IDENTIFER_VALID="PAX001rt12133356";
	private static final String BOOKING_IDENTIFER_VALID="TKT012345678";
	private static final String BOOKING_IDENTIFER_INVALID="TKT01234@#$$$5678";
	private static final String PASSENGER_IDENTIFER_INVALID="afjdafdafudafy@##DJHHDDHhdd";
	
	 
	List<ValidationServiceException> validationServiceExceptionlist;
	
	List<ValidationServiceException> serviceExceptionlist;
	
	Map<String,String> headerValueMap = new HashMap<>();
	
	//String jsonString = "{  \n   \"associatedPassenger\":{  \n      \"identifier\":\"associatedPaxID\"\n   },\n   \"type\":\"ADULT\",\n   \"emergencyContact\":{  \n      \"isDeclined\":false,\n      \"person\":{  \n         \"personName\":{  \n            \"title\":\"Mr.\",\n            \"firstName\":\"Peter\",\n            \"middleName\":\"Middlename\",\n            \"familyName\":\"Rodick\",\n            \"secondFamilyName\":\"SecondFamilyName\"\n         },\n         \"countryOfResidence\":{  \n            \"type\":\"COUNTY\",\n            \"identifier\":\"countryOfResidence\"\n         },\n         \"telecomAddresses\":[  \n            {  \n               \"number\":\"2277633\",\n               \"countryDiallingCode\":\"+44\",\n               \"areaCode\":\"022\"\n            }\n         ],\n         \"postalAddresses\":[  \n            {  \n               \"addressLines\":[  \n                  \"47 MarkLane\"\n               ],\n               \"postCode\":\"GU140AJ\",\n               \"country\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"UK\"\n               },\n               \"city\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"London\"\n               },\n               \"state\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"Middlesex\"\n               },\n               \"county\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"county\"\n               }\n            }\n         ]\n      }\n   },\n   \"person\":{  \n      \"dateOfBirth\":\"2004-12-25\",\n      \"personName\":{  \n         \"title\":\"Mr.\",\n         \"firstName\":\"Peter\",\n         \"middleName\":\"Middlename\",\n         \"familyName\":\"Rodick\",\n         \"secondFamilyName\":\"SecondFamilyName\"\n      },\n      \"gender\":\"MALE\",\n      \"registered-Identifiers\":[  \n         {  \n            \"type\":\"NATIONAL_INSURANCE_CARD\",\n            \"areaOfApplicability\":{  \n               \"type\":\"COUNTY\",\n               \"identifier\":\"areaOfApplicablity\"\n            },\n            \"token\":\"token value\",\n            \"placeOfIssue\":{  \n               \"type\":\"COUNTY\",\n               \"identifier\":\"placeOfIssue\"\n            },\n            \"person\":{  \n               \"personName\":{  \n                  \"title\":\"Mr.\",\n                  \"firstName\":\"Peter\",\n                  \"middleName\":\"Middlename\",\n                  \"familyName\":\"Rodick\",\n                  \"secondFamilyName\":\"SecondFamilyName\"\n               }\n            },\n            \"expiryDate\":\"2004-12-25\"\n         }\n      ],\n      \"nationality\":{  \n         \"type\":\"COUNTY\",\n         \"identifier\":\"NationalityIdentifier\"\n      }\n   },\n   \"dangerousGoods\":{  \n      \"isPresented\":false,\n      \"isConfirmed\":false\n   },\n   \"itinerary\":{  \n      \"eticket\":{  \n         \"identifier\":\"eticket001\"\n      },\n      \"itinerary-items\":[  \n         {  \n            \"identifier\":\"ItinararyItem001\",\n            \"carriers\":[  \n               {  \n                  \"code\":\"carrierCode001\",\n                  \"type\":\"MARKETING\",\n                  \"flightNumber\":\"BA0125\"\n               }\n            ],\n            \"origin\":{  \n               \"identifier\":\"gateIdentifier 001\",\n               \"terminal\":\"T3\",\n               \"gate\":{  \n                  \"number\":\"9A\"\n               }\n            },\n            \"destination\":{  \n               \"identifier\":\"destinationIdentifier001\",\n               \"terminal\":\"1D\",\n               \"gate\":{  \n                  \"number\":\"10A\"\n               }\n            },\n            \"scheduledDepartureLocalDatetime\":\"2004-12-25T14:12:12.000\",\n            \"scheduledArrivalLocalDatetime\":\"2004-12-25T14:12:12.000\",\n            \"seat\":{  \n               \"number\":\"26A\"\n            },\n            \"passengerStatus\":\"STANDBY\",\n            \"bookingClass\":\"Y\",\n            \"cabinCode\":\"cabinCode\",\n            \"destinationAddress\":{  \n               \"addressLines\":[  \n                  \"47 MarkLane\"\n               ],\n               \"postCode\":\"GU140AJ\",\n               \"country\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"UK\"\n               },\n               \"city\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"London\"\n               },\n               \"state\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"Middlesex\"\n               },\n               \"county\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"county\"\n               }\n            },\n            \"status\":\"CONFIRMED\",\n            \"eligibilities\":[  \n               {  \n                  \"code\":\"Eligiblity001\",\n                  \"description\":\"Elegiblities description\"\n               }\n            ]\n         }\n      ]\n   },\n   \"identifier\":\"passengerID\",\n   \"passenger-identifier\":\"passengerIdentifierID\"\n}";

	
	@Before
	public void setUp() throws JsonParseException, JsonMappingException, IOException {
		MockitoAnnotations.initMocks(this);    
		passenger = createPassengerDomain();
		updatePassengerValidator = new UpdatePassengerValidator(mockBookingIdentifierValidation, mockPassengerIdentifierValidation, mockPassengerValidation,
				headerValueMapValidation, mockValidationServiceExceptionGenerator);
		validationServiceExceptionlist = Lists.newArrayList();
	}
	
	
	
	 @Test  
	public void shouldThrowValidationServiceExceptionForInvalidBookingIdentifier() throws JSONException, IOException {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name());
		ValidationServiceException bookingValidationServiceException = createValidationServiceException(
				PassengerErrorCode.DATA_INVALID.name(), BOOKINGIDENTIFER_PATH);
		validationServiceExceptionlist.add(bookingValidationServiceException);
		thrown.expect(ValidationServiceException.class);
		thrown.expect(CustomValidationServiceExceptionMatcher.hasException(validationServiceException));
		when(mockBookingIdentifierValidation.validate(Mockito.anyString()))
				.thenReturn(bookingValidationServiceException);
		when(mockValidationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionlist))
						.thenThrow(validationServiceException);
		updatePassengerValidator.validate(BOOKING_IDENTIFER_INVALID, PASSENGER_IDENTIFER_VALID ,passenger, headerValueMap);

	}
	 
	 @Test  
	public void shouldThrowValidationServiceExceptionForInvalidPassengerIdentifier() throws JSONException, IOException {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name());
		ValidationServiceException passengerValidationServiceException = createValidationServiceException(
				PassengerErrorCode.DATA_INVALID.name(), PASSENGERINGIDENTIFER_PATH);
		validationServiceException.addValidationException(passengerValidationServiceException);
		validationServiceExceptionlist.add(passengerValidationServiceException);
		thrown.expect(ValidationServiceException.class);
		thrown.expect(CustomValidationServiceExceptionMatcher.hasException(validationServiceException));
		when(mockPassengerIdentifierValidation.validate(Mockito.anyString()))
				.thenReturn(passengerValidationServiceException);
		when(mockValidationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionlist))
						.thenThrow(validationServiceException);
		updatePassengerValidator.validate(BOOKING_IDENTIFER_VALID, PASSENGER_IDENTIFER_INVALID,passenger, headerValueMap);

	}
	 
	 @Test  
	public void shouldThrowValidationServiceExceptionForInvalidPassengerAndBokingIdentifier() throws JSONException, IOException {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name());
		ValidationServiceException bookingValidationServiceException = new ValidationServiceException(
				PassengerErrorCode.DATA_INVALID.name());
		bookingValidationServiceException.setPath(BOOKINGIDENTIFER_PATH);
		ValidationServiceException passengerValidationServiceException = createValidationServiceException(
				PassengerErrorCode.DATA_INVALID.name(), PASSENGERINGIDENTIFER_PATH);
		validationServiceException.addValidationException(bookingValidationServiceException);
		validationServiceException.addValidationException(passengerValidationServiceException);
		validationServiceExceptionlist.add(bookingValidationServiceException);
		validationServiceExceptionlist.add(passengerValidationServiceException);

		thrown.expect(ValidationServiceException.class);
		thrown.expect(CustomValidationServiceExceptionMatcher.hasException(validationServiceException));
		when(mockBookingIdentifierValidation.validate(Mockito.anyString()))
				.thenReturn(bookingValidationServiceException);
		when(mockPassengerIdentifierValidation.validate(Mockito.anyString()))
				.thenReturn(passengerValidationServiceException);
		when(mockValidationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionlist))
						.thenThrow(validationServiceException);
		updatePassengerValidator.validate(BOOKING_IDENTIFER_INVALID, PASSENGER_IDENTIFER_INVALID, passenger, headerValueMap);
	}
	

	@Test
	public void shouldPassValidationScenario() throws JSONException, IOException {			
		List<ValidationServiceException> validationServiceExceptionlist = Lists.newArrayList();
		when(mockBookingIdentifierValidation.validate(Mockito.anyString())).thenReturn(null);
		when(mockPassengerIdentifierValidation.validate(Mockito.anyString())).thenReturn(null);
		updatePassengerValidator.validate(BOOKING_IDENTIFER_VALID, PASSENGER_IDENTIFER_VALID,passenger,headerValueMap);
		assertEquals(0,validationServiceExceptionlist.size());
	}
	private ValidationServiceException createValidationServiceException(
			String childErrorCode, String path) {
		ValidationServiceException childValidationServiceException = new ValidationServiceException(childErrorCode);
		childValidationServiceException.setPath(path);
		childValidationServiceException.setDeveloperMessage(DEV_MSG_DATA_INVALID);
		return childValidationServiceException;
	}
	//this passenger creation steps using builder
	private Passenger<String> createPassengerDomain() {
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT,
				populatePerson(), populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		passenger = passengerBuilder.build();
		passenger.setIdentifier(PAX001);
		return passenger;

	}
	private Person<String> populatePerson() {
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("THOMAS", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();

		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);

		Nationality nationality = new Nationality();
		nationality.setType("C");
		nationality.setIdentifier("GB");
		personBuilder.setNationality(nationality);
		List<RegisteredIdentifier<?>> registeredIdentifierList = new ArrayList<>();
		Location<String> location = new Location<>();
		location.setLocationIdentifier("GB");
		location.setType(LocationType.COUNTRY);
		String dateTimeDetails = "12012018";
		RegisteredIdentifier<?> registeredIdentifier = new RegisteredIdentifier<>("dummyToken", null,
				RegisteredIdentifierType.PASSPORT, location, LocalDate.parse(dateTimeDetails), null);
		registeredIdentifierList.add(registeredIdentifier);
		personBuilder.setRegisteredIdentifier(registeredIdentifierList);
		Person<String> person = personBuilder.build();
		return person;
	}
	private Itinerary populateItineraryItemList() {
		ItineraryItem itineraryItem = new ItineraryItem();

		itineraryItem.setIdentifier("2301CB2D000236BD");
		List<Carrier> carriers = new ArrayList<>();
		Carrier operatingCarrier = new Carrier();
		operatingCarrier.setCode("OP");
		operatingCarrier.setType(CarrierType.OPERATING);
		operatingCarrier.setFlightNumber("280");
		operatingCarrier.setOperationalSuffix("OPS");
		Carrier marketingCarrier = new Carrier();
		marketingCarrier.setCode("BA");

		marketingCarrier.setType(CarrierType.MARKETING);
		marketingCarrier.setFlightNumber("111");
		marketingCarrier.setOperationalSuffix("OP");

		carriers.add(operatingCarrier);
		carriers.add(marketingCarrier);

		Origin origin = new Origin();
		origin.setIdentifier(LHR);
		origin.setTerminal("T4");
		Gate gate = new Gate();
		gate.setNumber("GATE2");
		origin.setGate(gate);

		Destination destination = new Destination();
		destination.setIdentifier("D001");
		destination.setTerminal("T2");
		destination.setGate(gate);
		itineraryItem.setCarriers(carriers);
		itineraryItem.setOrigin(origin);
		itineraryItem.setDestination(destination);
		LocalDateTime scheduledDepartureLocalDatetime = new LocalDateTime(2018, 12, 15, 13, 45, 50);
		LocalDateTime scheduledArrivalLocalDatetime = new LocalDateTime(2018, 12, 12, 13, 45, 40);
		itineraryItem.setScheduledDepartureLocalDatetime(scheduledDepartureLocalDatetime);
		itineraryItem.setScheduledArrivalLocalDatetime(scheduledArrivalLocalDatetime);
		itineraryItem.setBookingClass("ECONOMY");
		itineraryItem.setCabinCode(UPPER);
		itineraryItem.setPassengerStatus(PassengerStatus.CHECKEDIN);
		itineraryItem.setStatus(ItineraryItemStatus.CONFIRMED);
		Seat seat = new Seat();
		seat.setNumber("27A");
		itineraryItem.setSeat(seat);

		List<ItineraryItem> itineraryItems = new ArrayList<>();
		itineraryItems.add(itineraryItem);

		Itinerary itinerary = new Itinerary();
		Eticket eticket = new Eticket();
		eticket.setIdentifier("1258774395209");
		itinerary.setEticket(eticket);
		itinerary.setItineraryItems(itineraryItems);
		return itinerary;
	}
	private EmergencyContact<String> populateEmergencyContactDomain() {
		EmergencyContact.EmergencyContactBuilder<String> emergencyBuilder = new EmergencyContactBuilder<String>(
				Boolean.FALSE);

		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder(JANE, NORMAN);
		PersonName PersonName = personNameBuilder.build();

		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		TelecomAddress telecomAddress = new TelecomAddress(TELECOM_NUMBER);
		List<TelecomAddress> telecomAddresses = new ArrayList<>();
		telecomAddresses.add(telecomAddress);
		personBuilder.setTelecomAddresses(telecomAddresses);

		Person<String> person = personBuilder.build();
		emergencyBuilder.setPerson(person);

		return emergencyBuilder.build();
	}
	
}
