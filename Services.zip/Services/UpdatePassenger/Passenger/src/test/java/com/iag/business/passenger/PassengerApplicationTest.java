package com.iag.business.passenger;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.web.client.RestTemplate;

public class PassengerApplicationTest {
	@InjectMocks
	private PassengerApplication PassengerApplication;

	@Mock
	RestTemplateBuilder builder;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void shouldConfigureRestbuilder() {
		RestTemplate restTemplate = new RestTemplate();
		Mockito.when(builder.build()).thenReturn(restTemplate);
		restTemplate = PassengerApplication.restTemplate(builder);
		assertNotNull(restTemplate);
	}

}
