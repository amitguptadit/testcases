package com.iag.business.passenger.error.matcher;

import java.util.ArrayList;
import java.util.List;

//import org.apache.commons.lang.ObjectUtils;
import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

import com.iag.application.exception.ValidationServiceException;


/**
 * CustomApplicationServiceExceptionMatcher is used to match ValidationServiceException
 *
 */
public class CustomValidationServiceExceptionMatcher extends TypeSafeMatcher<ValidationServiceException> {

  public static CustomValidationServiceExceptionMatcher hasException(ValidationServiceException item) {
    return new CustomValidationServiceExceptionMatcher(item);
  }

  private ValidationServiceException foundException;
  private ValidationServiceException expectedException;

  private CustomValidationServiceExceptionMatcher(ValidationServiceException expectedException) {
    this.expectedException = expectedException;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected boolean matchesSafely(final ValidationServiceException exception) {
    this.foundException = exception;
    List<ValidationServiceException> foundValidationExceptions =
        (List<ValidationServiceException>) org.apache.commons.lang3.ObjectUtils.defaultIfNull(foundException.getValidationExceptions(),
            new ArrayList<ValidationServiceException>());
    List<ValidationServiceException> expectedValidationExceptions =
        (List<ValidationServiceException>) org.apache.commons.lang3.ObjectUtils.defaultIfNull(expectedException.getValidationExceptions(),
            new ArrayList<ValidationServiceException>());
    boolean isMatch =
        foundException.getCode().equals(expectedException.getCode())
            && foundValidationExceptions.size() == expectedValidationExceptions.size();
    if (isMatch) {
      for (int i = 0; i < foundValidationExceptions.size(); i++) {
        String foundPath = (String) org.apache.commons.lang3.ObjectUtils.defaultIfNull(foundValidationExceptions.get(i).getPath(), "");
        String expectedpath = (String) org.apache.commons.lang3.ObjectUtils.defaultIfNull(expectedValidationExceptions.get(i).getPath(), "");
        if (!foundValidationExceptions.get(i).getCode().equals(expectedValidationExceptions.get(i).getCode())
            || !foundPath.contains(expectedpath)) {
          isMatch = false;
          break;
          
        }
      }
    }
    return isMatch;
  }

  @Override
  public void describeTo(Description description) {
    description.appendValue(foundException).appendText(" was not found instead of ").appendValue(expectedException);
  }
}