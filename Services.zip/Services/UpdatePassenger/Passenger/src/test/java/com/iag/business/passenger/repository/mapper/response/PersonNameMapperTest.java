package com.iag.business.passenger.repository.mapper.response;




import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.iag.business.passenger.domain.model.party.PersonName;


public class PersonNameMapperTest {
	
	@InjectMocks
	PersonNameMapper personNameMapper;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);		
	}

	@Test
	public void buildPersonName() {
		PersonName personName = personNameMapper.buildPersonName("JAMES", "NORMAN", "Mr");
		assertEquals("JAMES", personName.getFirstName());
		assertEquals("NORMAN", personName.getFamilyName());
		assertEquals("Mr", personName.getTitle());
	}

	

}
