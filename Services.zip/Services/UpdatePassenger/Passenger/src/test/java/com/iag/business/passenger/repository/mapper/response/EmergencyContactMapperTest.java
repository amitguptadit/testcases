package com.iag.business.passenger.repository.mapper.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.CustomerLevelEmergencyContact;
import com.amadeus.xml.ccprrr_17_1_1a.PassengerApiInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.PassengerContactDataTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.StatusDetailsType;
import com.amadeus.xml.ccprrr_17_1_1a.StatusType113175S;
import com.iag.business.passenger.domain.model.party.PersonName;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact;


public class EmergencyContactMapperTest {
	
	@InjectMocks
	EmergencyContactMapper emergencyContactMapper;
	
	@Mock
	private PersonNameMapper personNameMapper;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		emergencyContactMapper = new EmergencyContactMapper(personNameMapper);
		PersonName personName = null;
		Mockito.when(personNameMapper
				.buildPersonName(Mockito.anyString(),Mockito.anyString(),Mockito.anyString()))
		.thenReturn(personName);
	}

	@Test
	public void getPassengerWithEmergencyDetailsWithNotDeclined() {
		EmergencyContact<String> emergencyContactDomain = null;
		Boolean isDeclined = false;
		List<CustomerLevelEmergencyContact> customerLevelEmergencyContactList = createEmergencyContactAmadeusResponse(
				isDeclined);
		emergencyContactDomain = emergencyContactMapper.buildEmergencyContact(customerLevelEmergencyContactList,
				emergencyContactDomain);
		assertNotNull(emergencyContactDomain);
		assertEquals(false, emergencyContactDomain.getIsDeclined());
		assertEquals("2277633", emergencyContactDomain.getPerson().getTelecomAddresses().iterator().next().getNumber());
	}

	@Test
	public void getPassengerWithEmergencyDetailsWithDeclined() {
		EmergencyContact<String> emergencyContactDomain = null;
		Boolean isDeclined = true;
		List<CustomerLevelEmergencyContact> customerLevelEmergencyContactList = createEmergencyContactAmadeusResponse(
				isDeclined);
		emergencyContactDomain = emergencyContactMapper.buildEmergencyContact(customerLevelEmergencyContactList,
				emergencyContactDomain);
		assertNotNull(emergencyContactDomain);
		assertEquals(true, emergencyContactDomain.getIsDeclined());
		assertEquals("2277633", emergencyContactDomain.getPerson().getTelecomAddresses().iterator().next().getNumber());
	}
	
	@Test
	public void getPassengerWithNoEmergencyContactList() {
		EmergencyContact<String> emergencyContactDomain = null;
		List<CustomerLevelEmergencyContact> customerLevelEmergencyContactList = new ArrayList<>();
		emergencyContactDomain = emergencyContactMapper.buildEmergencyContact(customerLevelEmergencyContactList,
				emergencyContactDomain);
		assertNull(emergencyContactDomain);
		}
	
	@Test
	public void getPassengerWithEmergencyDetailsWithOtherStatusInformation() {
		EmergencyContact<String> emergencyContactDomain = null;
		List<CustomerLevelEmergencyContact> customerLevelEmergencyContactList = createEmergencyContact();
		emergencyContactDomain = emergencyContactMapper.buildEmergencyContact(customerLevelEmergencyContactList,
				emergencyContactDomain);
		assertNotNull(emergencyContactDomain);
		assertEquals(false, emergencyContactDomain.getIsDeclined());
		assertEquals("2277633", emergencyContactDomain.getPerson().getTelecomAddresses().iterator().next().getNumber());
	}


	private List<CustomerLevelEmergencyContact> createEmergencyContactAmadeusResponse(Boolean isDeclined) {
		List<CustomerLevelEmergencyContact> customerLevelEmergencyContactList = new ArrayList<>();
		CustomerLevelEmergencyContact customerLevelEmergencyContact = new CustomerLevelEmergencyContact();

		List<StatusDetailsType> statusInformationList = new ArrayList<>();
		StatusDetailsType statusDetailsType = new StatusDetailsType();
		statusDetailsType.setIndicator("DCL");
		statusDetailsType.setAction("0");
		StatusDetailsType statusDetailsType2 = new StatusDetailsType();
		statusDetailsType2.setIndicator("DCL");
		statusDetailsType2.setAction("1");
		StatusDetailsType statusDetailsType3 = new StatusDetailsType();
		statusDetailsType3.setIndicator("DCL");
		statusDetailsType3.setAction("2");
		if (!isDeclined)
			statusInformationList.add(statusDetailsType);
		else
			statusInformationList.add(statusDetailsType2);
        
		statusInformationList.add(statusDetailsType3);
		StatusType113175S statusType = new StatusType113175S();
		statusType.setStatusInformation(statusInformationList);
		customerLevelEmergencyContact.setRegDocIndicators(statusType);
		PassengerApiInformationType passengerApiInformationType = new PassengerApiInformationType();
		PassengerContactDataTypeI passengerContactDataType = new PassengerContactDataTypeI();
		passengerContactDataType.setPhoneNumber("2277633");
		passengerContactDataType.setFirstName("JAMES");
		passengerContactDataType.setSurname("NORMAN");
		passengerApiInformationType.setContactDetails(passengerContactDataType);
		customerLevelEmergencyContact.setTravelerAndDocumentInfo(passengerApiInformationType);
		customerLevelEmergencyContactList.add(customerLevelEmergencyContact);
		return customerLevelEmergencyContactList;
	}
	
	private List<CustomerLevelEmergencyContact> createEmergencyContact() {
		List<CustomerLevelEmergencyContact> customerLevelEmergencyContactList = new ArrayList<>();
		CustomerLevelEmergencyContact customerLevelEmergencyContact = new CustomerLevelEmergencyContact();

		List<StatusDetailsType> statusInformationList = new ArrayList<>();
		StatusDetailsType statusDetailsType = new StatusDetailsType();
		statusDetailsType.setIndicator("CCL");
		statusDetailsType.setAction("0");		
		statusInformationList.add(statusDetailsType);
		StatusType113175S statusType = new StatusType113175S();
		statusType.setStatusInformation(statusInformationList);
		customerLevelEmergencyContact.setRegDocIndicators(statusType);
		PassengerApiInformationType passengerApiInformationType = new PassengerApiInformationType();
		PassengerContactDataTypeI passengerContactDataType = new PassengerContactDataTypeI();
		passengerContactDataType.setPhoneNumber("2277633");
		passengerContactDataType.setFirstName("JAMES");
		passengerContactDataType.setSurname("NORMAN");
		passengerApiInformationType.setContactDetails(passengerContactDataType);
		customerLevelEmergencyContact.setTravelerAndDocumentInfo(passengerApiInformationType);
		customerLevelEmergencyContactList.add(customerLevelEmergencyContact);
		return customerLevelEmergencyContactList;
	}

}
