package com.iag.business.passenger.domain.resource;


import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.hateoas.Link;

public class PassengerResourceTest {
	
	PassengerResource passengerResource;
	
	@Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        passengerResource=new PassengerResource();
			
    }
	@Test
	public void shouldCheckhashCode() {

		assertNotNull(passengerResource.hashCode());
	}
	@Test
	public void shouldCheckEqualNull() {

		assertNotNull(passengerResource.equals(null));
	}
	@Test
	public void shouldCheckEqual() {

		assertNotNull(passengerResource.equals(PassengerResource.class));
	}
	@Test
	public void shouldCheckToString() {

		assertNotNull(passengerResource.toString());
	}
	
	
	@Test
	public void equalsForSelfReference() {

		PassengerResource<String> passengerResource = new PassengerResource<>("passenger");
		assertThat(passengerResource).isEqualTo(passengerResource);
	}

	@Test
	public void checkEqualsAndHashcodeWithEqualContent() {

		PassengerResource<String> passengerResourceLeft = new PassengerResource<>("passenger");
		PassengerResource<String> passengerResourceLeftRight = new PassengerResource<>("passenger");

		assertThat(passengerResourceLeft).isEqualTo(passengerResourceLeftRight);
		assertThat(passengerResourceLeftRight).isEqualTo(passengerResourceLeft);
		assertEquals(passengerResourceLeft.hashCode(), passengerResourceLeftRight.hashCode());	
	}

	@Test
	public void notEqualForDifferentContent() {

		PassengerResource<String> passengerResourceLeft = new PassengerResource<>("passenger");
		PassengerResource<String> passengerResourceLeftRight = new PassengerResource<>("booking");

		assertThat(passengerResourceLeft).isNotEqualTo(passengerResourceLeftRight);
		assertThat(passengerResourceLeftRight).isNotEqualTo(passengerResourceLeft);
		assertNotEquals(passengerResourceLeft.hashCode(), passengerResourceLeftRight.hashCode());	
	}

	@Test
	public void notEqualForDifferentLinks() {
		PassengerResource<String> passengerResourceLeft = new PassengerResource<>("passenger");
		PassengerResource<String> passengerResourceLeftRight = new PassengerResource<>("booking");
		passengerResourceLeftRight.add(new Link("localhost"));
		passengerResourceLeft.add(new Link("remotehost")); 
		assertThat(passengerResourceLeft).isNotEqualTo(passengerResourceLeftRight);
		assertThat(passengerResourceLeftRight).isNotEqualTo(passengerResourceLeft);
	}
	
	@Test
	public void doesNotEqualNull() {
		PassengerResource<String> passengerResourceLeft = new PassengerResource<>("passenger");
		assertThat(passengerResourceLeft.equals(null)).isFalse();
	}
	
	@Test
	public void addsLinkCorrectly(){
		Link link = new Link("foo", Link.REL_NEXT);
		PassengerResource<String> passengerResource = new PassengerResource<>();
		passengerResource.add(link);
		assertThat(passengerResource.getLinks()).contains(link);
	}



	
}
