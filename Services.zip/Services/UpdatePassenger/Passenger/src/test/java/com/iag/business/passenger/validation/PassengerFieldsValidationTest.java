package com.iag.business.passenger.validation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.domain.model.Carrier;
import com.iag.business.passenger.domain.model.CarrierType;
import com.iag.business.passenger.domain.model.Destination;
import com.iag.business.passenger.domain.model.Eticket;
import com.iag.business.passenger.domain.model.Gate;
import com.iag.business.passenger.domain.model.Itinerary;
import com.iag.business.passenger.domain.model.ItineraryItem;
import com.iag.business.passenger.domain.model.ItineraryItemStatus;
import com.iag.business.passenger.domain.model.Origin;
import com.iag.business.passenger.domain.model.Seat;
import com.iag.business.passenger.domain.model.address.TelecomAddress;
import com.iag.business.passenger.domain.model.location.Location;
import com.iag.business.passenger.domain.model.location.LocationType;
import com.iag.business.passenger.domain.model.party.Gender;
import com.iag.business.passenger.domain.model.party.Nationality;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.party.Person.PersonBuilder;
import com.iag.business.passenger.domain.model.party.PersonName;
import com.iag.business.passenger.domain.model.party.PersonName.PersonNameBuilder;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifier;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifierType;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact.EmergencyContactBuilder;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.domain.model.party.role.Passenger.PassengerBuilder;
import com.iag.business.passenger.domain.model.party.role.PassengerStatus;
import com.iag.business.passenger.domain.model.party.role.PassengerType;
import com.iag.business.passenger.exception.ValidationServiceExceptionGenerator;


public class PassengerFieldsValidationTest {
	private static final String TELECOM_NUMBER = "07112345678";
	private static final String JANE = "JANE";
	private static final String NORMAN = "NORMAN ";
	public static final String HEADERVALUE_PATH = "headervalue";
	private static final String DEV_MSG_DATA_INVALID = "Data Invalid";
	private static final String PASSENGER_PATH = "passengervalue";

	@InjectMocks
	private PassengerFieldsValidation passengerFieldValidation;
	
	@Mock
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;
	
	ValidationServiceException updatePassengerValidationServiceException = null;
	
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		
		
	}
	
	@Test
	public void shouldThrowValidationServiceExceptionForPassengerWithNullValue(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());

		Passenger<String> passenger = null;
		Person<String> person = null;
		Itinerary itinerary = null;
		EmergencyContact<String> emergency =null;
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, person,itinerary);
		passengerBuilder.setEmergencyContact(emergency);
		updatePassengerValidationServiceException = passengerFieldValidation.validate(passenger);
		assertNotNull(updatePassengerValidationServiceException);
		assertEquals(PassengerErrorCode.MANDATORY_DATA_MISSING.toString(), updatePassengerValidationServiceException.getCode());
		assertEquals(PASSENGER_PATH, updatePassengerValidationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, updatePassengerValidationServiceException.getDeveloperMessage());
	}
	
	@Test
	public void shouldNotThrowValidationServiceExceptionForPassengerWithNotNullValue(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomain();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNull(updatePassengerValidationServiceException);
	}
	
	@Test
	public void shouldThrowValidationServiceExceptionForPassengerWithEmergencyContactPersonAndItineraryAsNullValue(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithoutEmergencyContactPersonAndItenary();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNotNull(updatePassengerValidationServiceException);
		assertEquals(PassengerErrorCode.MANDATORY_DATA_MISSING.toString(), updatePassengerValidationServiceException.getCode());
		assertEquals(PASSENGER_PATH, updatePassengerValidationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, updatePassengerValidationServiceException.getDeveloperMessage());
	}
	
	@Test
	public void shouldNotThrowValidationServiceExceptionForPassengerWithEmergencyContactValue(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithEmergencyContactAsNotNullAndPersonAndItineraryAsNullValue();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNull(updatePassengerValidationServiceException);
	}
	
	@Test
	public void shouldNotThrowValidationServiceExceptionForPassengerWithEmergencyContactAsNullAndPersonItineryAsNotNullValue(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithEmergencyContactAsNullAndPersonAndItineraryNotNullValue();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNull(updatePassengerValidationServiceException);
	}
	
	@Test
	public void shouldNotThrowValidationServiceExceptionForPassengerWithEmergencyContactAsNullAndPersonAsNullAndItineryAsNotNullValue(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithEmergencyContactAsNullPersonAsNullAndItineraryNotNullValue();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNull(updatePassengerValidationServiceException);
	}
	
	@Test
	public void shouldNotThrowValidationServiceExceptionForPassengerWithEmergencyContactAsNullAndPersonNotNullAndItineryAsNullValue(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithEmergencyContactAsNullPersonAsNotNullAndItineraryNullValue();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNull(updatePassengerValidationServiceException);
	}
	
	@Test
	public void shouldNotThrowValidationServiceExceptionForPassengerWithEmergencyContactAsNotNullAndPersonAsNullAndItineryAsNotNullValue(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithEmergencyContactAsNotNullPersonAsNullAndItineraryNotNullValue();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNull(updatePassengerValidationServiceException);
	}
	
	@Test
	public void shouldNotThrowValidationServiceExceptionForPassengerWithEmergencyContactAsNotNullAndPersonAsNotNullAndItineryAsNullValue(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger =  createPassengerDomainWithEmergencyContactAsNotNullPersonAsNotNullAndItineraryNullValue();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNull(updatePassengerValidationServiceException);
	}
	
	@Test
	public void shouldNotThrowValidationServiceExceptionForPassengerWithPersonContainsRegisteredIdentifier(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithPersonContainsRegisteredIdentifierValue();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNull(updatePassengerValidationServiceException);
	}
	
	@Test
	public void shouldThrowValidationServiceExceptionForPassengerWithPersonWithMandatoryDataInRegisteredIdentifierAsNull(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithPersonContainsRegisteredIdentifierWithRequiredValueAsNull();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNotNull(updatePassengerValidationServiceException);
		assertEquals(PassengerErrorCode.MANDATORY_DATA_MISSING.toString(), updatePassengerValidationServiceException.getCode());
		assertEquals(PASSENGER_PATH, updatePassengerValidationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, updatePassengerValidationServiceException.getDeveloperMessage());
	}
	
	@Test
	public void shouldThrowValidationServiceExceptionForPassengerWithPersonWithMandatoryDataInRegisteredIdentifierAsEmpty(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger =createPassengerDomainWithPersonContainsRegisteredIdentifierWithTokenAsEmpty();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNotNull(updatePassengerValidationServiceException);
		assertEquals(PassengerErrorCode.MANDATORY_DATA_MISSING.toString(), updatePassengerValidationServiceException.getCode());
		assertEquals(PASSENGER_PATH, updatePassengerValidationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, updatePassengerValidationServiceException.getDeveloperMessage());
	}
	
	@Test
	public void shouldNotThrowValidationServiceExceptionForPassengerWithPersonWithNationalityAsNotNull(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithPersonContainsNationality();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNull(updatePassengerValidationServiceException);
	}
	
	@Test
	public void shouldThrowValidationServiceExceptionForPassengerWithPersonAsNotNullAndRegisteredIdentifierAndNationalityAsNull(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithPersonAsNotNullAndRegisteredIdentifierAndNationalityAsNull();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNotNull(updatePassengerValidationServiceException);
		assertEquals(PassengerErrorCode.MANDATORY_DATA_MISSING.toString(), updatePassengerValidationServiceException.getCode());
		assertEquals(PASSENGER_PATH, updatePassengerValidationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, updatePassengerValidationServiceException.getDeveloperMessage());
	}
	
	@Test
	public void shouldThrowValidationServiceExceptionForPassengerWithPersonRegisteredIdentifierWithTokenAsEmptyAndEmergencyContactPlaceOfIssue(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithPersonRegisteredIdentifierWithTokenAsEmptyAndEmergencyContactPlaceOfIssue();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNotNull(updatePassengerValidationServiceException);
		assertEquals(PassengerErrorCode.MANDATORY_DATA_MISSING.toString(), updatePassengerValidationServiceException.getCode());
		assertEquals(PASSENGER_PATH, updatePassengerValidationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, updatePassengerValidationServiceException.getDeveloperMessage());
	}
	
	@Test
	public void shouldThrowValidationServiceExceptionForPassengerWithPersonRegisteredIdentifierWithTokenAndExpirydateAsNullPlaceOfIssueNotNull(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithPersonRegisteredIdentifierWithTokenAndExpirydateAsNullPlaceOfIssueNotNull();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNotNull(updatePassengerValidationServiceException);
		assertEquals(PassengerErrorCode.MANDATORY_DATA_MISSING.toString(), updatePassengerValidationServiceException.getCode());
		assertEquals(PASSENGER_PATH, updatePassengerValidationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, updatePassengerValidationServiceException.getDeveloperMessage());
	}
	
	@Test
	public void shouldThrowValidationServiceExceptionForPassengerWithPersonRegisteredIdentifierWithTokenAndExpirydateAsNotNullPlaceOfIssueNull(){
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		Passenger<String> Passenger = createPassengerDomainWithPersonRegisteredIdentifierWithTokenAndExpirydateAsNotNullPlaceOfIssueNull();
		updatePassengerValidationServiceException =  passengerFieldValidation.validate(Passenger);
		assertNotNull(updatePassengerValidationServiceException);
		assertEquals(PassengerErrorCode.MANDATORY_DATA_MISSING.toString(), updatePassengerValidationServiceException.getCode());
		assertEquals(PASSENGER_PATH, updatePassengerValidationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, updatePassengerValidationServiceException.getDeveloperMessage());
	}
	
	private ValidationServiceException createValidationServiceExceptionForMandatoryData() {
		ValidationServiceException validationServiceException = new ValidationServiceException(
		PassengerErrorCode.MANDATORY_DATA_MISSING.name());
		validationServiceException.setDeveloperMessage(DEV_MSG_DATA_INVALID);
		validationServiceException.setPath(PASSENGER_PATH);
		return validationServiceException;
	}
	
	private Passenger<String> createPassengerDomain(){
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, populatePerson(),
				populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Passenger<String> createPassengerDomainWithoutEmergencyContactPersonAndItenary(){
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, null,null);
		passengerBuilder.setEmergencyContact(null);
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	
	
	private Passenger<String> createPassengerDomainWithEmergencyContactAsNotNullAndPersonAndItineraryAsNullValue(){
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, null,null);
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	 
	private Passenger<String> createPassengerDomainWithEmergencyContactAsNullAndPersonAndItineraryNotNullValue(){
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT,  populatePerson(), populateItineraryItemList());
		passengerBuilder.setEmergencyContact(null);
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Passenger<String> createPassengerDomainWithEmergencyContactAsNullPersonAsNullAndItineraryNotNullValue(){
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, null,
				populateItineraryItemList());
		passengerBuilder.setEmergencyContact(null);
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Passenger<String> createPassengerDomainWithEmergencyContactAsNullPersonAsNotNullAndItineraryNullValue(){
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, 
		         populatePerson(),null);
		passengerBuilder.setEmergencyContact(null);
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Passenger<String> createPassengerDomainWithEmergencyContactAsNotNullPersonAsNotNullAndItineraryNullValue(){
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, 
		         populatePerson(),null);
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Passenger<String> createPassengerDomainWithEmergencyContactAsNotNullPersonAsNullAndItineraryNotNullValue(){
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, 
		         null,populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Passenger<String> createPassengerDomainWithPersonContainsRegisteredIdentifierValue(){
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("THOMAS", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();
		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);
		List<RegisteredIdentifier<?>> registeredIdentifierList = new ArrayList<>();
		Location<String> location = new Location<>();
		location.setLocationIdentifier("GB");
		location.setType(LocationType.COUNTRY);
		String dateTimeDetails = "12012018";
		RegisteredIdentifier<?> registeredIdentifier = new RegisteredIdentifier<>("dummyToken", null,
				RegisteredIdentifierType.PASSPORT, location, LocalDate.parse(dateTimeDetails), null);
		registeredIdentifierList.add(registeredIdentifier);
		personBuilder.setRegisteredIdentifier(registeredIdentifierList);
		Person<String> person = personBuilder.build();
		
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, 
				person, populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Passenger<String> createPassengerDomainWithPersonContainsRegisteredIdentifierWithRequiredValueAsNull(){
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("THOMAS", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();
		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);
		List<RegisteredIdentifier<?>> registeredIdentifierList = new ArrayList<>();
        String token = null;
        Location<String> areaOfApplicability = null;
        Location<String> placeOfIssue = null;
        LocalDate expiryDate = null;
        Person<String> regPerson = null;
		RegisteredIdentifier<?> registeredIdentifier = new RegisteredIdentifier<>(token, areaOfApplicability,
				RegisteredIdentifierType.PASSPORT, placeOfIssue, expiryDate , regPerson);
		registeredIdentifierList.add(registeredIdentifier);
		personBuilder.setRegisteredIdentifier(registeredIdentifierList);
		Person<String> person = personBuilder.build();
		
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, 
				person, populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Passenger<String> createPassengerDomainWithPersonContainsRegisteredIdentifierWithTokenAsEmpty(){
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("THOMAS", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();
		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);
		List<RegisteredIdentifier<?>> registeredIdentifierList = new ArrayList<>();
        String token = "";
        Location<String> areaOfApplicability = new Location<>();
        Location<String> placeOfIssue = new Location<>();
        LocalDate expiryDate = new LocalDate();
        Person<String> regPerson = null;
		RegisteredIdentifier<?> registeredIdentifier = new RegisteredIdentifier<>(token, areaOfApplicability,
				RegisteredIdentifierType.PASSPORT, placeOfIssue, expiryDate , regPerson);
		registeredIdentifierList.add(registeredIdentifier);
		personBuilder.setRegisteredIdentifier(registeredIdentifierList);
		Person<String> person = personBuilder.build();
		
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, 
				person, populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Passenger<String> createPassengerDomainWithPersonRegisteredIdentifierWithTokenAsEmptyAndEmergencyContactPlaceOfIssue(){
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("THOMAS", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();
		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);
		List<RegisteredIdentifier<?>> registeredIdentifierList = new ArrayList<>();
        String token = "";
        Location<String> areaOfApplicability = new Location<>();
        Location<String> placeOfIssue = new Location<>();
        LocalDate expiryDate = new LocalDate();
        Person<String> regPerson = null;
		RegisteredIdentifier<?> registeredIdentifier = new RegisteredIdentifier<>(token, areaOfApplicability,
				RegisteredIdentifierType.PASSPORT, placeOfIssue, expiryDate , regPerson);
		registeredIdentifierList.add(registeredIdentifier);
		personBuilder.setRegisteredIdentifier(registeredIdentifierList);
		Person<String> person = personBuilder.build();
		
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, 
				person, populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Passenger<String> createPassengerDomainWithPersonRegisteredIdentifierWithTokenAndExpirydateAsNullPlaceOfIssueNotNull(){
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("THOMAS", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();
		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);
		List<RegisteredIdentifier<?>> registeredIdentifierList = new ArrayList<>();
        String token = "36546326";
        Location<String> areaOfApplicability = new Location<>();
        Location<String> placeOfIssue = new Location<>();
        LocalDate expiryDate = null;
        Person<String> regPerson = null;
		RegisteredIdentifier<?> registeredIdentifier = new RegisteredIdentifier<>(token, areaOfApplicability,
				RegisteredIdentifierType.PASSPORT, placeOfIssue, expiryDate , regPerson);
		registeredIdentifierList.add(registeredIdentifier);
		personBuilder.setRegisteredIdentifier(registeredIdentifierList);
		Person<String> person = personBuilder.build();
		
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, 
				person, populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Passenger<String> createPassengerDomainWithPersonRegisteredIdentifierWithTokenAndExpirydateAsNotNullPlaceOfIssueNull(){
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("THOMAS", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();
		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);
		List<RegisteredIdentifier<?>> registeredIdentifierList = new ArrayList<>();
        String token = "36546326";
        Location<String> areaOfApplicability = new Location<>();
        Location<String> placeOfIssue = null;
        LocalDate expiryDate = new LocalDate();
        Person<String> regPerson = null;
		RegisteredIdentifier<?> registeredIdentifier = new RegisteredIdentifier<>(token, areaOfApplicability,
				RegisteredIdentifierType.PASSPORT, placeOfIssue, expiryDate , regPerson);
		registeredIdentifierList.add(registeredIdentifier);
		personBuilder.setRegisteredIdentifier(registeredIdentifierList);
		Person<String> person = personBuilder.build();
		
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, 
				person, populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	private Passenger<String> createPassengerDomainWithPersonContainsNationality(){
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("THOMAS", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();

		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);

		Nationality nationality = new Nationality();
		nationality.setType("C");
		nationality.setIdentifier("GB");
		personBuilder.setNationality(nationality);
		Person<String> person = personBuilder.build();
		
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, 
				person, populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Passenger<String> createPassengerDomainWithPersonAsNotNullAndRegisteredIdentifierAndNationalityAsNull(){
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("THOMAS", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();

		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);
		Person<String> person = personBuilder.build();
		
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, 
				person, populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		Passenger<String> passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
	}
	
	private Person<String> populatePerson() {
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("THOMAS", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();

		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);

		Nationality nationality = new Nationality();
		nationality.setType("C");
		nationality.setIdentifier("GB");
		personBuilder.setNationality(nationality);
		List<RegisteredIdentifier<?>> registeredIdentifierList = new ArrayList<>();
		Location<String> location = new Location<>();
		location.setLocationIdentifier("GB");
		location.setType(LocationType.COUNTRY);
		String dateTimeDetails = "12012018";
		RegisteredIdentifier<?> registeredIdentifier = new RegisteredIdentifier<>("dummyToken", null,
				RegisteredIdentifierType.PASSPORT, location, LocalDate.parse(dateTimeDetails), null);
		registeredIdentifierList.add(registeredIdentifier);
		personBuilder.setRegisteredIdentifier(registeredIdentifierList);
		Person<String> person = personBuilder.build();
		return person;
	}
	
	private Itinerary populateItineraryItemList() {
		ItineraryItem itineraryItem = new ItineraryItem();

		itineraryItem.setIdentifier("2301CB2D000236BD");
		List<Carrier> carriers = new ArrayList<>();
		Carrier operatingCarrier = new Carrier();
		operatingCarrier.setCode("OP");
		operatingCarrier.setType(CarrierType.OPERATING);
		operatingCarrier.setFlightNumber("280");
		operatingCarrier.setOperationalSuffix("OPS");
		Carrier marketingCarrier = new Carrier();
		marketingCarrier.setCode("BA");
		marketingCarrier.setType(CarrierType.MARKETING);
		marketingCarrier.setFlightNumber("111");
		marketingCarrier.setOperationalSuffix("OP");

		carriers.add(operatingCarrier);
		carriers.add(marketingCarrier);

		Origin origin = new Origin();
		origin.setIdentifier("LHR");
		origin.setTerminal("T4");
		Gate gate = new Gate();
		gate.setNumber("GATE2");
		origin.setGate(gate);

		Destination destination = new Destination();
		destination.setIdentifier("D001");
		destination.setTerminal("T2");
		destination.setGate(gate);
		itineraryItem.setCarriers(carriers);
		itineraryItem.setOrigin(origin);
		itineraryItem.setDestination(destination);
		LocalDateTime scheduledDepartureLocalDatetime = new LocalDateTime(2018, 12, 15, 13, 45, 50);
		LocalDateTime scheduledArrivalLocalDatetime = new LocalDateTime(2018, 12, 12, 13, 45, 40);
		itineraryItem.setScheduledDepartureLocalDatetime(scheduledDepartureLocalDatetime);
		itineraryItem.setScheduledArrivalLocalDatetime(scheduledArrivalLocalDatetime);
		itineraryItem.setBookingClass("ECONOMY");
		itineraryItem.setCabinCode("UPPER");
		itineraryItem.setPassengerStatus(PassengerStatus.CHECKEDIN);
		itineraryItem.setStatus(ItineraryItemStatus.CONFIRMED);
		Seat seat = new Seat();
		seat.setNumber("27A");
		itineraryItem.setSeat(seat);

		List<ItineraryItem> itineraryItems = new ArrayList<>();
		itineraryItems.add(itineraryItem);

		Itinerary itinerary = new Itinerary();
		Eticket eticket = new Eticket();
		eticket.setIdentifier("1258774395209");
		itinerary.setEticket(eticket);
		itinerary.setItineraryItems(itineraryItems);
		return itinerary;
	}
	
	private EmergencyContact<String> populateEmergencyContactDomain(){
		EmergencyContact.EmergencyContactBuilder<String> emergencyBuilder = new EmergencyContactBuilder<String>(
				Boolean.FALSE);

		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder(JANE, NORMAN);
		PersonName PersonName = personNameBuilder.build();

		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		TelecomAddress telecomAddress = new TelecomAddress(TELECOM_NUMBER);
		List<TelecomAddress> telecomAddresses = new ArrayList<>();
		telecomAddresses.add(telecomAddress);
		personBuilder.setTelecomAddresses(telecomAddresses);

		Person<String> person = personBuilder.build();
		emergencyBuilder.setPerson(person);
	
		return emergencyBuilder.build();
	}

}

