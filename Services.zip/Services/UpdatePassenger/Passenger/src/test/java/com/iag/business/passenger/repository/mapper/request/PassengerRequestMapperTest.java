package com.iag.business.passenger.repository.mapper.request;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.amadeus.xml.ccprrq_17_1_1a.DCSIDCCPRIdentification;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.proxy.config.ConfigurationInfrastructureServiceProxy;

public class PassengerRequestMapperTest {
	PassengerRequestMapper passengerRequestMapper;
	@Mock
     ConfigurationInfrastructureServiceProxy configurationInfrastructureServiceProxy;
	@Before
	public void setUp() {
        MockitoAnnotations.initMocks(this);

		passengerRequestMapper = new PassengerRequestMapper();
		ReflectionTestUtils.setField(passengerRequestMapper, "configurationInfrastructureServiceProxy",
                configurationInfrastructureServiceProxy);
	}
	
	@Test
	public void shouldCreateRequestBodyForPassenger() {
		 Mockito.when(
	                configurationInfrastructureServiceProxy
	                        .retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.PASSENGER_REFERENCE_QUALIFIER.name()))
	                .thenReturn("UCI");
	     
		String passengerIdentifier  = "2301DB2D00009C26";
		String bookingIdentifier = "NQZIB5";
		DCSIDCCPRIdentification reqMapper =passengerRequestMapper.createRequestBodyForPassenger(bookingIdentifier, passengerIdentifier);
		assertNotEquals(null, reqMapper);
		assertEquals("NQZIB5", reqMapper.getSetOfCriteria().get(0).getRecordLocator().getReservation().getControlNumber());
		assertEquals("2301DB2D00009C26", reqMapper.getSetOfCriteria().get(0).getUniqueIdentifier().get(0).getIdSection().getPrimeId());
		assertEquals("UCI", reqMapper.getSetOfCriteria().get(0).getUniqueIdentifier().get(0).getIdSection().getReferenceQualifier());


	}
}
