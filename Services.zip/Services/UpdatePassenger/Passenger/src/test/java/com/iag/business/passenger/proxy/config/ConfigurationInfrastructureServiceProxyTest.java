package com.iag.business.passenger.proxy.config;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.iag.application.exception.ApplicationServiceException;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.error.matcher.CustomApplicationServiceExceptionMatcher;
import com.iag.business.passenger.proxy.config.domain.Configuration;
import com.iag.business.passenger.proxy.config.domain.ConfigurationItems;
import com.iag.business.passenger.proxy.config.domain.ConfigurationNamespace;

public class ConfigurationInfrastructureServiceProxyTest {
	
	private static final String SERVICEURL = "http://serviceName/serviceIdentifier";
	private static final String PASSENGER_ERROR_REQUEST_INVALID_CODE ="passenger.error.REQUEST_INVALID.code";
	private static final String PASSENGER_ERROR_DATA_INVALID_CODE = "passenger.error.DATA_INVALID.code";
	private static final String DATA_INVALID = "DATA_INVALID";
	private static final String  SYSTEM_UNAVAILABLE = "SYSTEM_UNAVAILABLE";
	private static final String REQUEST_INVALID = "REQUEST_INVALID";
	private static final String  ERROR ="Error";
	private static final String  RESOURCE  = "KIO002";
	private static final String VERSION = "V1";
	private static final String DRIVER = "Driver";

	
	@InjectMocks
	ConfigurationInfrastructureServiceProxy configurationInfrastructureServiceProxy;

	@Mock
	RestTemplate restTemplate;

	@Mock
	Map<String, String> serviceErrorMap;

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		configurationInfrastructureServiceProxy = new ConfigurationInfrastructureServiceProxy(SERVICEURL,restTemplate);
		
		}
	
	@Test
	public void shouldRetrieveConfigurationItemForSuccessResponse() {
		Configuration config = createConfiguration();
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(config, HttpStatus.OK);
		Mockito.when(restTemplate.exchange(SERVICEURL, HttpMethod.GET, null, Configuration.class))
				.thenReturn(configurationResponse);
		//configurationInfrastructureServiceProxy.init();
		Mockito.when(serviceErrorMap.get(PASSENGER_ERROR_REQUEST_INVALID_CODE)).thenReturn(REQUEST_INVALID);
		Mockito.when(serviceErrorMap.get(PASSENGER_ERROR_DATA_INVALID_CODE)).thenReturn(DATA_INVALID);
		
		assertEquals(REQUEST_INVALID,
				configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.ERROR_NAMESPACE,PASSENGER_ERROR_REQUEST_INVALID_CODE));
		assertEquals(DATA_INVALID, configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.ERROR_NAMESPACE,PASSENGER_ERROR_DATA_INVALID_CODE));
	}

	@Test
	public void shouldThrowSystemUnavailableExceptionWhenNoConFigurationFound() {
		Configuration config = createConfiguration();
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(config,
				HttpStatus.NOT_FOUND);
		Mockito.when(restTemplate.exchange(SERVICEURL, HttpMethod.GET, null, Configuration.class))
				.thenReturn(configurationResponse);
		thrown.expect(ApplicationServiceException.class);
		thrown.expect(CustomApplicationServiceExceptionMatcher
				.hasException(new ApplicationServiceException(SYSTEM_UNAVAILABLE)));
		configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.ERROR_NAMESPACE,PASSENGER_ERROR_DATA_INVALID_CODE);
		
 	}

	@Test
	public void shouldThrowApplicationServiceExceptionForInvalidHttpMethod() {
		Configuration config = createConfiguration();
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(config, HttpStatus.OK);
		Mockito.when(restTemplate.exchange(SERVICEURL, HttpMethod.POST, null, Configuration.class))
				.thenReturn(configurationResponse);
		thrown.expect(ApplicationServiceException.class);
		thrown.expect(CustomApplicationServiceExceptionMatcher
				.hasException(new ApplicationServiceException(SYSTEM_UNAVAILABLE)));
		configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.ERROR_NAMESPACE,PASSENGER_ERROR_DATA_INVALID_CODE);
	}
	

		
	private Configuration createConfiguration() {
		Configuration config = new Configuration();
		List<ConfigurationNamespace> nameSpace = new ArrayList<>();
		config.setResource(RESOURCE);
		config.setVersion(VERSION);
		config.setIdentifier(DRIVER);
		List<ConfigurationItems> configurationList = new ArrayList<>();
		ConfigurationItems configurationItems = new ConfigurationItems();
		configurationItems.setIdentifier(PASSENGER_ERROR_REQUEST_INVALID_CODE);
		configurationItems.setValue(REQUEST_INVALID);
		configurationList.add(configurationItems);
		ConfigurationItems configurationItem2 = new ConfigurationItems();
		configurationItem2.setIdentifier(PASSENGER_ERROR_DATA_INVALID_CODE);
		configurationItem2.setValue(DATA_INVALID);
		configurationList.add(configurationItem2);
		ConfigurationNamespace configurationNamespaces = new ConfigurationNamespace();
		configurationNamespaces.setName(ERROR);
		configurationNamespaces.setConfigurationItems(configurationList);
		nameSpace.add(configurationNamespaces);
		config.setConfigurationNamespaces(nameSpace);
		return config;

	}

}
