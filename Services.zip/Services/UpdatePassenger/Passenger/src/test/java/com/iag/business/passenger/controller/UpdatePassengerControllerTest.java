/*package com.iag.business.passenger.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.error.matcher.CustomValidationServiceExceptionMatcher;
import com.iag.business.passenger.service.UpdatePassengerService;
import com.iag.business.passenger.session.AmadeusSession;
import com.iag.business.passenger.validation.UpdatePassengerValidator;

public class UpdatePassengerControllerTest {
	String jsonString = "{  \n   \"associatedPassenger\":{  \n      \"identifier\":\"associatedPaxID\"\n   },\n   \"type\":\"ADULT\",\n   \"emergencyContact\":{  \n      \"isDeclined\":false,\n      \"person\":{  \n         \"personName\":{  \n            \"title\":\"Mr.\",\n            \"firstName\":\"Peter\",\n            \"middleName\":\"Middlename\",\n            \"familyName\":\"Rodick\",\n            \"secondFamilyName\":\"SecondFamilyName\"\n         },\n         \"countryOfResidence\":{  \n            \"type\":\"COUNTY\",\n            \"identifier\":\"countryOfResidence\"\n         },\n         \"telecomAddresses\":[  \n            {  \n               \"number\":\"2277633\",\n               \"countryDiallingCode\":\"+44\",\n               \"areaCode\":\"022\"\n            }\n         ],\n         \"postalAddresses\":[  \n            {  \n               \"addressLines\":[  \n                  \"47 MarkLane\"\n               ],\n               \"postCode\":\"GU140AJ\",\n               \"country\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"UK\"\n               },\n               \"city\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"London\"\n               },\n               \"state\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"Middlesex\"\n               },\n               \"county\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"county\"\n               }\n            }\n         ]\n      }\n   },\n   \"person\":{  \n      \"dateOfBirth\":\"2004-12-25\",\n      \"personName\":{  \n         \"title\":\"Mr.\",\n         \"firstName\":\"Peter\",\n         \"middleName\":\"Middlename\",\n         \"familyName\":\"Rodick\",\n         \"secondFamilyName\":\"SecondFamilyName\"\n      },\n      \"gender\":\"MALE\",\n      \"registered-Identifiers\":[  \n         {  \n            \"type\":\"NATIONAL_INSURANCE_CARD\",\n            \"areaOfApplicability\":{  \n               \"type\":\"COUNTY\",\n               \"identifier\":\"areaOfApplicablity\"\n            },\n            \"token\":\"token value\",\n            \"placeOfIssue\":{  \n               \"type\":\"COUNTY\",\n               \"identifier\":\"placeOfIssue\"\n            },\n            \"person\":{  \n               \"personName\":{  \n                  \"title\":\"Mr.\",\n                  \"firstName\":\"Peter\",\n                  \"middleName\":\"Middlename\",\n                  \"familyName\":\"Rodick\",\n                  \"secondFamilyName\":\"SecondFamilyName\"\n               }\n            },\n            \"expiryDate\":\"2004-12-25\"\n         }\n      ],\n      \"nationality\":{  \n         \"type\":\"COUNTY\",\n         \"identifier\":\"NationalityIdentifier\"\n      }\n   },\n   \"dangerousGoods\":{  \n      \"isPresented\":false,\n      \"isConfirmed\":false\n   },\n   \"itinerary\":{  \n      \"eticket\":{  \n         \"identifier\":\"eticket001\"\n      },\n      \"itinerary-items\":[  \n         {  \n            \"identifier\":\"ItinararyItem001\",\n            \"carriers\":[  \n               {  \n                  \"code\":\"carrierCode001\",\n                  \"type\":\"MARKETING\",\n                  \"flightNumber\":\"BA0125\"\n               }\n            ],\n            \"origin\":{  \n               \"identifier\":\"gateIdentifier 001\",\n               \"terminal\":\"T3\",\n               \"gate\":{  \n                  \"number\":\"9A\"\n               }\n            },\n            \"destination\":{  \n               \"identifier\":\"destinationIdentifier001\",\n               \"terminal\":\"1D\",\n               \"gate\":{  \n                  \"number\":\"10A\"\n               }\n            },\n            \"scheduledDepartureLocalDatetime\":\"2004-12-25T14:12:12.000\",\n            \"scheduledArrivalLocalDatetime\":\"2004-12-25T14:12:12.000\",\n            \"seat\":{  \n               \"number\":\"26A\"\n            },\n            \"passengerStatus\":\"STANDBY\",\n            \"bookingClass\":\"Y\",\n            \"cabinCode\":\"cabinCode\",\n            \"destinationAddress\":{  \n               \"addressLines\":[  \n                  \"47 MarkLane\"\n               ],\n               \"postCode\":\"GU140AJ\",\n               \"country\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"UK\"\n               },\n               \"city\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"London\"\n               },\n               \"state\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"Middlesex\"\n               },\n               \"county\":{  \n                  \"type\":\"COUNTY\",\n                  \"identifier\":\"county\"\n               }\n            },\n            \"status\":\"CONFIRMED\",\n            \"eligibilities\":[  \n               {  \n                  \"code\":\"Eligiblity001\",\n                  \"description\":\"Elegiblities description\"\n               }\n            ]\n         }\n      ]\n   },\n   \"identifier\":\"passengerID\",\n   \"passenger-identifier\":\"passengerIdentifierID\"\n}";

	private static final String SELF = "self";
	private static final String ADULT = "ADULT";
	private final static String PASSENGER_ID = "PAX001";
	private final static String PASSENGER_ID2 = "PAX002";
	private final static String ASSOCIATED_PASSENGER_ID = "PAX001";
	private final static String BOOKING_ID = "PAX009";
	private final static String URI = "/bookings/533535/passengers/PAX0099/";
	private final static String INVALID_URI = "/booking/B001/passenger/";
	private static final String PASSENGERINGIDENTIFER_PATH = "passenger-identifier";
	private static final String DEVELOPER_MSG = "Passenger Identifier is invalid";
	private static final String BOOKING = "booking";
	private static final String ALL_PASSENGERS = "AllPassengers";
	public static final String HAL_JSON_VALUE = "application/hal+json;charset=UTF-8";
	private static final String VALID_VISA = "Valid Visa";
	private static final String OK = "OK";
	private static final String CONFIRMED = "CONFIRMED";
	private static final String UPPER = "UPPER";
	private static final String ECONOMY = "ECONOMY";
	private static final String CHECKEDIN = "CHECKEDIN";
	private static final String ARRIVAL_DATE = "2018-07-14T11:15:00.000000";
	private static final String DEPARTURE_DATE = "2018-07-14T10:10:00.000000";
	private static final String BCN = "BCN";
	private static final String TWELVE = "12";
	private static final String LHR = "LHR";
	private static final String TERMINAL = "5";
	private static final String IDENTIFIER = "1";
	private static final String TKT012345678 = "TKT012345678";
	private static final String MR = "MR";
	private static final String MARKETING = "MARKETING";
	private static final String FLIGHT_NUMBER = "101";
	private static final String BA = "BA";
	private static final String EXPIRYDATE = "2025-05-17";
	private static final String TOKEN = "GB12345678";
	private static final String PASSPORT = "PASSPORT";
	private static final String COUNTRY2 = "COUNTRY";
	private static final String NORMAN2 = "NORMAN";
	private static final String JAMES = "JAMES";
	private static final String COUNTRY = "COUNTRY ";
	private static final String UNITED_KINGDOM = "UNITED KINGDOM";
	private static final String DIALINGCODE = "44";
	private static final String TELECOM_NUMBER = "07112345678";
	private static final String NORMAN = "NORMAN ";
	private static final String JANE = "JANE";
	public static final String Associated_PASSENGER = "AssociatedPassenger";
	public static final String INFANT = "INFANT";
	private static final String KISOK = "KISOK";
	public static final String SCOPE = "scope";
	public static final String CHANNEL = "channel";
	public static final String LOCATION = "location";
	public static final String SESSIONIDENTIFIER = "sessionidentifier";
	public static final String TOKENNUMBER = "tokennumber";
	private static final String SESSION123 = "session123";
	private static final String SEC123 = "sec123";
	private static final String BOOKINGS = "BOOKINGS";
	private static final String GB = "GB";
	private static final String GET = "GET";
	private static final String BOOKING_IDENTIFIER_ABOVERANGE_CHARACTER = "ETYTIRTPIRTPIWTPIWPITTWTYTIW6722725722929";
	private static final String PASSENGER_IDENTIFIER_ABOVE_LIMIT = "etytirtpirtpiwtpiwpittwtytiw6722725722929";
	public static final String HEADERVALUE_PATH = "headervalue";

	@InjectMocks
	private UpdatePassengerController updatePassengerController;

	@Mock
	private UpdatePassengerService updatepassengerService;

	@Mock
	private UpdatePassengerValidator mockUpdatePassengerValidator;

	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	@Mock
	private Map<String, String> headerValueMap;

	@Mock
	private AmadeusSession amadeusSession;

	private MockMvc mockMvc;

	private Passenger passenger;

	private AmadeusDataMock amadeusMock;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(updatePassengerController).build();
		amadeusMock = new AmadeusDataMock();
		when(headerValueMap.get(PassengerServiceConstants.TOKENNUMBER)).thenReturn(SEC123);
		when(headerValueMap.get(PassengerServiceConstants.SESSIONIDENTIFIER)).thenReturn(SESSION123);
		when(headerValueMap.get(PassengerServiceConstants.LOCATION)).thenReturn(GB);
		when(headerValueMap.get(PassengerServiceConstants.CHANNEL)).thenReturn(KISOK);
		when(headerValueMap.get(PassengerServiceConstants.SCOPE)).thenReturn(BOOKINGS);
		HttpServletRequest httpServletRequestMock = new MockHttpServletRequest();
		ServletRequestAttributes servletRequestAttributes = new ServletRequestAttributes(httpServletRequestMock);
		RequestContextHolder.setRequestAttributes(servletRequestAttributes);
	}

	@After
	public void teardown() {
		RequestContextHolder.resetRequestAttributes();
	}

	@Test
	public void shouldThrowValidationExceptionWithInvalidPassengerIdentifier() throws Exception {
		ValidationServiceException validationRequestInvalidDataException = createValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name(), PassengerErrorCode.DATA_INVALID.name(),
				PASSENGERINGIDENTIFER_PATH);
		Mockito.doThrow(validationRequestInvalidDataException).when(mockUpdatePassengerValidator).validate(BOOKING_ID,
				PASSENGER_IDENTIFIER_ABOVE_LIMIT, passenger, headerValueMap);
		exceptionRule.expect(ValidationServiceException.class);
		exceptionRule.expect(CustomValidationServiceExceptionMatcher.hasException(validationRequestInvalidDataException));
		updatePassengerController.updatePassenger(BOOKING_ID, PASSENGER_IDENTIFIER_ABOVE_LIMIT, passenger, headerValueMap).getBody();
	}

	@Test
	public void shouldThrowValidationExceptionWithInvalidBookingIdentifier() throws Exception {
		ValidationServiceException validationRequestInvalidDataException = createValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name(), PassengerErrorCode.DATA_INVALID.name(),
				PASSENGERINGIDENTIFER_PATH);
		Mockito.doThrow(validationRequestInvalidDataException).when(mockUpdatePassengerValidator)
				.validate(BOOKING_IDENTIFIER_ABOVERANGE_CHARACTER, PASSENGER_ID, passenger, headerValueMap);
		exceptionRule.expect(ValidationServiceException.class);
		exceptionRule
				.expect(CustomValidationServiceExceptionMatcher.hasException(validationRequestInvalidDataException));
		updatePassengerController.updatePassenger(BOOKING_IDENTIFIER_ABOVERANGE_CHARACTER, PASSENGER_ID, passenger, headerValueMap)
				.getBody();
	}

	@Test
	public void updatePassengerSuccessStatus() throws Exception {
		Mockito.doNothing().when(updatepassengerService).updatePassenger(Mockito.anyString(), Mockito.anyString(),
				Mockito.any(), Mockito.any());
		MvcResult result = mockMvc
				.perform(MockMvcRequestBuilders.post(URI).contentType("application/json").content(jsonString))
				.andExpect(status().is2xxSuccessful()).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());
	}

	@Test
	public void getPassengerErrorStatusOnIncorrectUrl() throws Exception {
		Mockito.doNothing().when(updatepassengerService).updatePassenger(Mockito.anyString(), Mockito.anyString(),
				Mockito.any(), Mockito.any());
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(INVALID_URI))
				.andExpect(status().is4xxClientError()).andReturn();
		assertEquals(HttpStatus.NOT_FOUND.value(), result.getResponse().getStatus());
		assertEquals(GET, result.getRequest().getMethod());
	}

	@Test
	public void getPassengerErrorStatusOnIncorrecMethodType() throws Exception {
		Mockito.doNothing().when(updatepassengerService).updatePassenger(Mockito.anyString(), Mockito.anyString(),
				Mockito.any(), Mockito.any());
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.delete(URI)).andExpect(status().is4xxClientError())
				.andReturn();
		assertEquals(405, result.getResponse().getStatus());
		assertNotEquals(GET, result.getRequest().getMethod());
	}

	private ValidationServiceException createValidationServiceException(String parentErrorCode, String childErrorCode,
			String path) {
		ValidationServiceException validationServiceException = new ValidationServiceException(parentErrorCode);
		validationServiceException.addValidationException(createValidationServiceException(childErrorCode, path));
		return validationServiceException;
	}

	private ValidationServiceException createValidationServiceException(String errorCode, String path) {
		ValidationServiceException childValidationServiceException = new ValidationServiceException(errorCode);
		childValidationServiceException.setDeveloperMessage(DEVELOPER_MSG);
		childValidationServiceException.setPath(path);
		return childValidationServiceException;
	}
}*/