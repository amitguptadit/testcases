package com.iag.business.passenger.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.iag.business.passenger.domain.model.Carrier;
import com.iag.business.passenger.domain.model.CarrierType;
import com.iag.business.passenger.domain.model.Destination;
import com.iag.business.passenger.domain.model.Eligibility;
import com.iag.business.passenger.domain.model.Eticket;
import com.iag.business.passenger.domain.model.Gate;
import com.iag.business.passenger.domain.model.Itinerary;
import com.iag.business.passenger.domain.model.ItineraryItem;
import com.iag.business.passenger.domain.model.ItineraryItemStatus;
import com.iag.business.passenger.domain.model.Origin;
import com.iag.business.passenger.domain.model.Seat;
import com.iag.business.passenger.domain.model.address.TelecomAddress;
import com.iag.business.passenger.domain.model.location.Location;
import com.iag.business.passenger.domain.model.location.LocationType;
import com.iag.business.passenger.domain.model.party.Gender;
import com.iag.business.passenger.domain.model.party.Nationality;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.party.PersonName;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifier;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifierType;
import com.iag.business.passenger.domain.model.party.Person.PersonBuilder;
import com.iag.business.passenger.domain.model.party.PersonName.PersonNameBuilder;
import com.iag.business.passenger.domain.model.party.role.AssociatedPassenger;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.domain.model.party.role.PassengerStatus;
import com.iag.business.passenger.domain.model.party.role.PassengerType;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact.EmergencyContactBuilder;
import com.iag.business.passenger.domain.model.party.role.Passenger.PassengerBuilder;
import com.iag.business.passenger.repository.AmadeusWebServiceGateway;
import com.iag.business.passenger.repository.PassengerRepository;
import com.iag.business.passenger.repository.mapper.request.PassengerRequestMapper;
import com.iag.business.passenger.session.AmadeusSession;

public class PassengerServiceImplTest {
	private final static String PASSENGER_ID = "PAX001";
	private final static String PASSENGER_ID2 = "PAX002";
	private final static String BOOKING_ID = "TKT012345678";
	private static final String SELF = "self";
	private static final String ADULT = "ADULT";
	private final static String ASSOCIATED_PASSENGER_ID = "PAX0013";
	private final static String INVALID_URI = "/booking/B001/passenger/";
	private static final String PASSENGERINGIDENTIFER_PATH = "passenger-identifier";
	private static final String DEVELOPER_MSG = "Passenger Identifier is invalid";
	private static final String BOOKING = "booking";
	private static final String ALL_PASSENGERS = "AllPassengers";
	public static final String HAL_JSON_VALUE = "application/hal+json;charset=UTF-8";
	private static final String VALID_VISA = "Valid Visa";
	private static final String OK = "OK";
	private static final String CONFIRMED = "CONFIRMED";
	private static final String UPPER = "UPPER";
	private static final String ECONOMY = "ECONOMY";
	private static final String CHECKEDIN = "CHECKEDIN";
	private static final String ARRIVAL_DATE = "2018-07-14T11:15:00.000000";
	private static final String DEPARTURE_DATE = "2018-07-14T10:10:00.000000";
	private static final String BCN = "BCN";
	private static final String TWELVE = "12";
	private static final String LHR = "LHR";
	private static final String TERMINAL = "5";
	private static final String IDENTIFIER = "1";
	private static final String TKT012345678 = "TKT012345678";
	private static final String MR = "MR";
	private static final String MARKETING = "MARKETING";
	private static final String FLIGHT_NUMBER = "101";
	private static final String BA = "BA";
	private static final String EXPIRYDATE = "2025-05-17";
	private static final String TOKEN = "GB12345678";
	private static final String PASSPORT = "PASSPORT";
	private static final String COUNTRY2 = "COUNTRY";
	private static final String NORMAN2 = "NORMAN";
	private static final String JAMES = "THOMAS";
	private static final String COUNTRY = "COUNTRY ";
	private static final String UNITED_KINGDOM = "UNITED KINGDOM";
	private static final String DIALINGCODE = "44";
	private static final String TELECOM_NUMBER = "07112345678";
	private static final String NORMAN = "NORMAN ";
	private static final String JANE = "JANE";
	public static final String Associated_PASSENGER = "AssociatedPassenger";
	public static final String INFANT = "INFANT";
	public static final String SCOPE = "scope";
	public static final String CHANNEL = "channel";
	public static final String LOCATION = "location";
	public static final String SESSIONIDENTIFIER = "sessionidentifier";
	public static final String TOKENNUMBER = "tokennumber";
	private static final String GB = "GB";
	private static final Object THOMAS = "THOMAS";
	private static final Object C = "C";
	
	@InjectMocks
	PassengerServiceImpl passengerServiceImpl;

	@Mock
	private PassengerRepository passengerRepository;
	
	@Mock
	private AmadeusSession amadeusSession;

	 private Passenger<String> passenger;
	

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		passengerServiceImpl = new PassengerServiceImpl(passengerRepository);
	}

	@Test
	public void getPassengerDetails() {		
		Passenger passenger = createPassengerDomain();
		Mockito.when(passengerRepository.getPassenger(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(passenger);
		passengerServiceImpl.getPassenger(BOOKING_ID, PASSENGER_ID, amadeusSession);
		assertNotNull(passenger);
		
		assertEquals(PASSENGER_ID, passenger.getIdentifier());
		assertEquals(ADULT, PassengerType.ADULT.name());
		assertEquals(Boolean.FALSE, passenger.getEmergencyContact().getIsDeclined());
		assertNotNull(passenger.getEmergencyContact().getPerson().getPersonName());
		assertEquals(JANE, passenger.getEmergencyContact().getPerson().getPersonName().getFirstName());
		assertEquals(NORMAN, passenger.getEmergencyContact().getPerson().getPersonName().getFamilyName());
		assertNotNull(passenger.getEmergencyContact().getPerson().getTelecomAddresses());
		List<TelecomAddress> telecomList= passenger.getEmergencyContact().getPerson().getTelecomAddresses();
		assertEquals(TELECOM_NUMBER,
				telecomList.get(0).getNumber());
		assertNotNull(passenger.getPerson());
		assertEquals(MR, passenger.getPerson().getPersonName().getTitle());
		assertEquals("THOMAS", passenger.getPerson().getPersonName().getFirstName());
		assertEquals(NORMAN2, passenger.getPerson().getPersonName().getFamilyName());
		assertNotNull(passenger.getPerson().getNationality());
		assertEquals("C", passenger.getPerson().getNationality().getType());
		assertEquals(GB, passenger.getPerson().getNationality().getIdentifier());
	    List<RegisteredIdentifier<?>> registeredIdentifiers = passenger.getPerson().getRegisteredIdentifiers();
	    assertNotNull(PASSPORT,  registeredIdentifiers.get(0).getType().name());
	    assertNotNull("dummyToken",  registeredIdentifiers.get(0).getToken());
		assertEquals("1258774395209", passenger.getItinerary().getEticket().getIdentifier());
		assertEquals("OP", passenger.getItinerary().getItineraryItems().iterator().next().getCarriers().iterator()
				.next().getCode());
		assertEquals("OPERATING", passenger.getItinerary().getItineraryItems().iterator().next().getCarriers()
				.iterator().next().getType().name());
		assertEquals("280", passenger.getItinerary().getItineraryItems().iterator().next().getCarriers().iterator()
				.next().getFlightNumber());
		assertEquals("OPS", passenger.getItinerary().getItineraryItems().iterator().next().getCarriers().iterator()
				.next().getOperationalSuffix());
		assertEquals("GATE2",
				passenger.getItinerary().getItineraryItems().iterator().next().getOrigin().getGate().getNumber());
		assertEquals("T4", passenger.getItinerary().getItineraryItems().iterator().next().getOrigin().getTerminal());
		assertEquals("LHR", passenger.getItinerary().getItineraryItems().iterator().next().getOrigin().getIdentifier());
		assertNotNull(
				passenger.getItinerary().getItineraryItems().iterator().next().getScheduledDepartureLocalDatetime());
		assertNotNull(
				passenger.getItinerary().getItineraryItems().iterator().next().getScheduledArrivalLocalDatetime());
		assertEquals("ECONOMY", passenger.getItinerary().getItineraryItems().iterator().next().getBookingClass());
		assertEquals("27A", passenger.getItinerary().getItineraryItems().iterator().next().getSeat().getNumber());
		assertEquals("CONFIRMED", passenger.getItinerary().getItineraryItems().iterator().next().getStatus().name());
		assertEquals("CHECKEDIN",
				passenger.getItinerary().getItineraryItems().iterator().next().getPassengerStatus().name());
		assertEquals("GATE2",
				passenger.getItinerary().getItineraryItems().iterator().next().getDestination().getGate().getNumber());
		assertEquals("D001",
				passenger.getItinerary().getItineraryItems().iterator().next().getDestination().getIdentifier());
		assertEquals("T2",
				passenger.getItinerary().getItineraryItems().iterator().next().getDestination().getTerminal());
		assertEquals(MR, passenger.getPerson().getPersonName().getTitle());
		assertEquals(THOMAS, passenger.getPerson().getPersonName().getFirstName());
		assertEquals(NORMAN2, passenger.getPerson().getPersonName().getFamilyName());
		assertNotNull(passenger.getPerson().getNationality());
		assertEquals(C, passenger.getPerson().getNationality().getType());
		assertEquals(GB, passenger.getPerson().getNationality().getIdentifier());
		
	}
	@Test
	public void getPassengerDetailsWithAssociatedPassenger() throws Exception {
		Passenger passenger = createPassengerWithAssociatedDomain();
		Mockito.when(passengerRepository.getPassenger(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(passenger);
		passengerServiceImpl.getPassenger(BOOKING_ID, PASSENGER_ID2, amadeusSession);
		assertEquals(PASSENGER_ID2, passenger.getIdentifier());		
		assertEquals(INFANT,PassengerType.INFANT.name());
		assertNotNull(passenger.getAssociatedPassenger());
		assertEquals(ASSOCIATED_PASSENGER_ID,passenger.getAssociatedPassenger().getIdentifier());
	}
	
	
	private Passenger<String> createPassengerDomain(){
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT, populatePerson(),
				populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX001");
		return passenger;
		
	}
	
	private Passenger<String> createPassengerWithAssociatedDomain(){
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.INFANT, populatePerson(),
				populateItineraryItemList());

			AssociatedPassenger<String> associatedPassenger = new AssociatedPassenger<>();
			associatedPassenger.setIdentifier(ASSOCIATED_PASSENGER_ID);
			passengerBuilder.setAssociatedPassenger(associatedPassenger);
		
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		passenger = passengerBuilder.build();
		passenger.setIdentifier("PAX002");
		return passenger;
	}
	
	private EmergencyContact<String> populateEmergencyContactDomain(){
		EmergencyContact.EmergencyContactBuilder<String> emergencyBuilder = new EmergencyContactBuilder<String>(
				Boolean.FALSE);

		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder(JANE, NORMAN);
		PersonName PersonName = personNameBuilder.build();

		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		TelecomAddress telecomAddress = new TelecomAddress(TELECOM_NUMBER);
		List<TelecomAddress> telecomAddresses = new ArrayList<>();
		telecomAddresses.add(telecomAddress);
		personBuilder.setTelecomAddresses(telecomAddresses);

		Person<String> person = personBuilder.build();
		emergencyBuilder.setPerson(person);
	
		return emergencyBuilder.build();
	}
	
	private Person<String> populatePerson() {
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("THOMAS", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();

		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);

		Nationality nationality = new Nationality();
		nationality.setType("C");
		nationality.setIdentifier("GB");
		personBuilder.setNationality(nationality);
		List<RegisteredIdentifier<?>> registeredIdentifierList = new ArrayList<>();
		Location<String> location = new Location<>();
		location.setLocationIdentifier("GB");
		location.setType(LocationType.COUNTRY);
		String dateTimeDetails = "12012018";
		RegisteredIdentifier<?> registeredIdentifier = new RegisteredIdentifier<>("dummyToken", null,
				RegisteredIdentifierType.PASSPORT, location, LocalDate.parse(dateTimeDetails), null);
		registeredIdentifierList.add(registeredIdentifier);
		personBuilder.setRegisteredIdentifier(registeredIdentifierList);
		Person<String> person = personBuilder.build();
		return person;
	}

	private Itinerary populateItineraryItemList() {
		ItineraryItem itineraryItem = new ItineraryItem();

		itineraryItem.setIdentifier("2301CB2D000236BD");
		List<Carrier> carriers = new ArrayList<>();
		Carrier operatingCarrier = new Carrier();
		operatingCarrier.setCode("OP");
		operatingCarrier.setType(CarrierType.OPERATING);
		operatingCarrier.setFlightNumber("280");
		operatingCarrier.setOperationalSuffix("OPS");
		Carrier marketingCarrier = new Carrier();
		marketingCarrier.setCode("BA");
		marketingCarrier.setType(CarrierType.MARKETING);
		marketingCarrier.setFlightNumber("111");
		marketingCarrier.setOperationalSuffix("OP");

		carriers.add(operatingCarrier);
		carriers.add(marketingCarrier);

		Origin origin = new Origin();
		origin.setIdentifier("LHR");
		origin.setTerminal("T4");
		Gate gate = new Gate();
		gate.setNumber("GATE2");
		origin.setGate(gate);

		Destination destination = new Destination();
		destination.setIdentifier("D001");
		destination.setTerminal("T2");
		destination.setGate(gate);
		itineraryItem.setCarriers(carriers);
		itineraryItem.setOrigin(origin);
		itineraryItem.setDestination(destination);
		LocalDateTime scheduledDepartureLocalDatetime = new LocalDateTime(2018, 12, 15, 13, 45, 50);
		LocalDateTime scheduledArrivalLocalDatetime = new LocalDateTime(2018, 12, 12, 13, 45, 40);
		itineraryItem.setScheduledDepartureLocalDatetime(scheduledDepartureLocalDatetime);
		itineraryItem.setScheduledArrivalLocalDatetime(scheduledArrivalLocalDatetime);
		itineraryItem.setBookingClass("ECONOMY");
		itineraryItem.setCabinCode("UPPER");
		itineraryItem.setPassengerStatus(PassengerStatus.CHECKEDIN);
		itineraryItem.setStatus(ItineraryItemStatus.CONFIRMED);
		Seat seat = new Seat();
		seat.setNumber("27A");
		itineraryItem.setSeat(seat);

		List<ItineraryItem> itineraryItems = new ArrayList<>();
		itineraryItems.add(itineraryItem);

		Itinerary itinerary = new Itinerary();
		Eticket eticket = new Eticket();
		eticket.setIdentifier("1258774395209");
		itinerary.setEticket(eticket);
		itinerary.setItineraryItems(itineraryItems);
		return itinerary;
	}
	
}

