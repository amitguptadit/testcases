package com.iag.business.passenger.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;

import com.iag.application.error.ErrorFactory;
import com.iag.application.error.ServiceError;
import com.iag.application.error.ValidationError;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.constant.error.PassengerErrorCode;

public class PassengerServiceExceptionHandlerTest {

	private final static String HTTP_STATUS_CODE = "400";

	private static final String PASSENGERINGIDENTIFER_PATH = "passenger-identifier";

	private static final String BUSINESS_MSG_KEY = "passenger.error.REQUEST_INVALID.business_message";

	private static final String DEVELOPER_MSG_KEY = "passenger.error.DATA_INVALID.developer_message_passengeridentifier";

	private static final String DEVELOPER_MSG = "Passenger Identifier is invalid";

	private static final String DEVELOPER_LINK_KEY = "passenger.error.REQUEST_INVALID.developer_link";

	private static final String DEVELOPER_LINK = "https://developer.iag.com";

	private static final String BUSINESS_MSG = "Request Invalid";

	private static final String APPLICATION_BUSINESS_MSG_KEY = "passenger.error.PASSENGER_NOT_FOUND.business_message";

	private static final String APPLICATION_BUSINESS_MSG_VALUE = "Passenger Not Found";

	@InjectMocks
	private PassengerServiceExceptionHandler passengerServiceExceptionHandler;

	private ServiceErrorResponseGenerator serviceErrorResponseGenerator;

	@Mock
	private DefaultContentProvider mockContentProvider;

	private ServiceError serviceError;

	private ErrorFactory errorFactory;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		serviceErrorResponseGenerator = new ServiceErrorResponseGenerator(mockContentProvider);
		passengerServiceExceptionHandler = new PassengerServiceExceptionHandler(serviceErrorResponseGenerator);
		errorFactory = new ErrorFactory();
	}

	@Test
	public void shouldHandleRequestValidationException() {
		ValidationServiceException validationRequestInvalidDataException = createValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name(), PassengerErrorCode.DATA_INVALID.name(),
				PASSENGERINGIDENTIFER_PATH);
		Mockito.when(errorFactory.createError(validationRequestInvalidDataException, mockContentProvider))
				.thenReturn(serviceError);
		Mockito.when(errorFactory.getStatusCode(validationRequestInvalidDataException, mockContentProvider))
				.thenReturn(HTTP_STATUS_CODE);
		Mockito.when(mockContentProvider.getContent(BUSINESS_MSG_KEY)).thenReturn(BUSINESS_MSG);
		Mockito.when(mockContentProvider.getContent(DEVELOPER_LINK_KEY)).thenReturn(DEVELOPER_LINK);
		Mockito.when(mockContentProvider.getContent(DEVELOPER_MSG_KEY)).thenReturn(DEVELOPER_MSG);
		HttpEntity<ServiceError> result = passengerServiceExceptionHandler
				.handleServiceException(validationRequestInvalidDataException);
		Collection<ValidationError> validationErrorList = ((ValidationError) result.getBody()).getServiceErrors();
		assertNotNull(result.getBody());
		assertEquals(PassengerErrorCode.REQUEST_INVALID.name(), result.getBody().getCode());
		assertEquals(BUSINESS_MSG, result.getBody().getBusinessMessage());
		assertEquals(DEVELOPER_LINK, result.getBody().getDeveloperLink());
		assertEquals(PassengerErrorCode.DATA_INVALID.name(), validationErrorList.iterator().next().getCode());
		assertEquals(PASSENGERINGIDENTIFER_PATH, validationErrorList.iterator().next().getPath());
		assertEquals(DEVELOPER_MSG, validationErrorList.iterator().next().getDeveloperMessage());
	}

	@Test
	public void shouldHandleApplicationException() {
		ApplicationServiceException applicationServiceException = new ApplicationServiceException(
				PassengerErrorCode.PASSENGER_NOT_FOUND.name());
		applicationServiceException.setDeveloperMessage(PassengerErrorCode.PASSENGER_NOT_FOUND.name());
		Mockito.when(mockContentProvider.getContent(APPLICATION_BUSINESS_MSG_KEY))
				.thenReturn(APPLICATION_BUSINESS_MSG_VALUE);
		Mockito.when(errorFactory.getStatusCode(applicationServiceException, mockContentProvider))
				.thenReturn(HTTP_STATUS_CODE);
		HttpEntity<ServiceError> result = passengerServiceExceptionHandler
				.handleServiceException(applicationServiceException);
		assertNotNull(result.getBody());
		assertEquals(PassengerErrorCode.PASSENGER_NOT_FOUND.name(), result.getBody().getCode());
		assertEquals(PassengerErrorCode.PASSENGER_NOT_FOUND.name(), result.getBody().getDeveloperMessage());
		assertEquals(APPLICATION_BUSINESS_MSG_VALUE, result.getBody().getBusinessMessage());

	}

	private ValidationServiceException createValidationServiceException(String parentErrorCode, String childErrorCode,
			String path) {
		ValidationServiceException validationServiceException = new ValidationServiceException(parentErrorCode);
		validationServiceException.addValidationException(createValidationServiceException(childErrorCode, path));
		return validationServiceException;
	}

	private ValidationServiceException createValidationServiceException(String errorCode, String path) {
		ValidationServiceException childValidationServiceException = new ValidationServiceException(errorCode);
		childValidationServiceException.setDeveloperMessage(DEVELOPER_MSG);
		childValidationServiceException.setPath(path);
		return childValidationServiceException;
	}

}
