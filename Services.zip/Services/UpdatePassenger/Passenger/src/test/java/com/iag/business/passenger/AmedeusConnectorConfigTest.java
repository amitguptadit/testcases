/*package com.iag.business.passenger;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.transport.http.CommonsHttpMessageSender;

import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.proxy.config.ConfigurationInfrastructureServiceProxy;


public class AmedeusConnectorConfigTest {


    AmedeusConnectorConfig amedeusConnectorConfig;

    @Mock
    WebServiceTemplate amadeusWebServiceTemplate;

    @Mock
    Jaxb2Marshaller amadeusMarshaller;

    @Mock
    Jaxb2Marshaller amadeusUnMarshaller;

    @Mock
    RestTemplateBuilder builder;

    @Mock
    CommonsHttpMessageSender httpSender;

    @Mock
    private ConfigurationInfrastructureServiceProxy configurationInfrastructureServiceProxy;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        amedeusConnectorConfig = new AmedeusConnectorConfig();
        ReflectionTestUtils.setField(amedeusConnectorConfig, "configurationInfrastructureServiceProxy",
				configurationInfrastructureServiceProxy);
			
    }

    @Test
    public void shouldGetHttpSender() throws Exception {
    	Mockito.when(
                configurationInfrastructureServiceProxy
                        .retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.HTTP_SENDER_WILDCARD_HOSTS.name()))
                .thenReturn("*");
    	Mockito.when(
                configurationInfrastructureServiceProxy
                        .retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.HTTP_SENDER_MAX_HOSTS.name()))
                .thenReturn("5");
    	Mockito.when(
                configurationInfrastructureServiceProxy
                        .retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.HTTP_SENDER_READ_TIME_OUT.name()))
                .thenReturn("10000");
    	Mockito.when(
                configurationInfrastructureServiceProxy
                        .retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.HTTP_SENDER_CONNECTOR_TIME_OUT.name()))
                .thenReturn("100000");
    
        CommonsHttpMessageSender commonsHttpMessageSender = amedeusConnectorConfig.httpSender();
        assertNotNull(commonsHttpMessageSender);
    }

    @Test
    public void shouldTestAmadeusWebServiceTemplate() {
        Mockito.when(
                configurationInfrastructureServiceProxy
                        .retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.PASSENGER_DEFAULT_URL.name()))
                .thenReturn("https://BAaccess.test.webservices.1a.amadeus.com:52069");
        WebServiceTemplate webServiceTemplate = amedeusConnectorConfig.amadeusWebServiceTemplate(amadeusMarshaller,
                amadeusUnMarshaller, httpSender);
        assertNotNull(webServiceTemplate);
        assertNotNull(webServiceTemplate.getDefaultUri());
    }

    @Test
    public void shouldGetAmadeusMarshaller() throws Exception {
        Mockito.when(
        		configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.PASSENGER_MARSHALLER.name()))
                .thenReturn("com.amadeus.xml.ccprrr_17_1_1a");
        
        Jaxb2Marshaller amadeusMarshaller = amedeusConnectorConfig.amadeusMarshaller();
        assertNotNull(amadeusMarshaller);
        assertNotNull(amadeusMarshaller.getContextPath());
    }

    @Test
    public void shouldGetAmadeusUnMarshaller() throws Exception {
        Mockito.when(
        		configurationInfrastructureServiceProxy.retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.PASSENGER_UNMARSHALLER.name()))
                .thenReturn("com.amadeus.xml.ccprrr_17_1_1a");
           Jaxb2Marshaller amadeusUnMarshaller = amedeusConnectorConfig.amadeusUnMarshaller();
        assertNotNull(amadeusUnMarshaller);
        assertNotNull(amadeusUnMarshaller.getContextPath());
    }


}
*/