/*package com.iag.business.passenger.service;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.repository.AmadeusDataMock;
import com.iag.business.passenger.repository.UpdatePassengerAmadeusRepositoryImpl;
import com.iag.business.passenger.session.AmadeusSession;

public class UpdatePassengerServiceImplTest {
	private final static String PASSENGER_ID = "PAX0099";
	private final static String BOOKING_ID = "TKT012345678";
	@InjectMocks
	UpdatePassengerServiceImpl updatePassengerServiceImpl;

	@Mock
	private UpdatePassengerAmadeusRepositoryImpl updatePassengerAmadeusRepositoryImpl;

	@Mock
	private AmadeusSession session;

	AmadeusDataMock passengerMockDataService;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		session = new AmadeusSession();
		passengerMockDataService = new AmadeusDataMock();
	}

	@SuppressWarnings("rawtypes")
	@Test
	public void updatePassengerDetails() {
		Passenger passenger = passengerMockDataService.getPassenger(BOOKING_ID, PASSENGER_ID, session);
		updatePassengerServiceImpl.updatePassenger(BOOKING_ID, PASSENGER_ID, passenger, session);
		Mockito.doNothing().when(updatePassengerAmadeusRepositoryImpl).updatePassenger(Mockito.anyString(),
				Mockito.anyString(), Mockito.any(), Mockito.any());

	}
}
*/