package com.iag.business.passenger.repository.mapper.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.CustomerLevelRegDocs;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel.NationalityGroup;
import com.amadeus.xml.ccprrr_17_1_1a.DocumentIdTypeI232115C;
import com.amadeus.xml.ccprrr_17_1_1a.NationalityTypeU8495S;
import com.amadeus.xml.ccprrr_17_1_1a.PassengerApiInformationType163944S;
import com.amadeus.xml.ccprrr_17_1_1a.PassengerContactDataTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeInformationType13618S;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeType18902C;
import com.amadeus.xml.ccprrr_17_1_1a.TravellerDetailsType279779C;
import com.amadeus.xml.ccprrr_17_1_1a.TravellerInformationType201121S;
import com.amadeus.xml.ccprrr_17_1_1a.TravellerSurnameInformationType279780C;
import com.iag.business.passenger.domain.model.location.Location;
import com.iag.business.passenger.domain.model.location.LocationType;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.party.PersonName;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifier;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifierType;


public class PersonMapperTest {
	@InjectMocks
	PersonMapper personMapper;
	
	@Mock
	private PersonNameMapper personNameMapper;
	
	@Mock
	private RegisteredIdentifiersMapper registeredIdentifiersMapper;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		personMapper = new PersonMapper(personNameMapper,registeredIdentifiersMapper);
		List<RegisteredIdentifier<?>> registeredIdentifierList = buildCustomerLevelRegDocs();
		Mockito.when(registeredIdentifiersMapper
		.buildRegisteredIdentifiers(Mockito.anyList())).thenReturn(registeredIdentifierList);
		PersonName personName = null;
		Mockito.when(personNameMapper
				.buildPersonName(Mockito.anyString(),Mockito.anyString(),Mockito.anyString()))
		.thenReturn(personName);
	}

	@Test
	public void getMalePassengerWithPersonalDetails() {
		CustomerLevel customerLevel = createCustomerLevelMaleResponse();		
		Person<String> person = personMapper.buildPerson(customerLevel);
		assertNotNull(person);
		assertEquals("MALE", person.getGender().name());
		assertNotNull(person.getDateOfBirth());
		assertEquals("COUNTRY",person.getNationality().getType());
		assertEquals("GB",person.getNationality().getIdentifier());
		assertTrue(person.getRegisteredIdentifiers().size() > 0);
		assertEquals("dummyToken", person.getRegisteredIdentifiers().iterator().next().getToken());
		assertEquals("PASSPORT", person.getRegisteredIdentifiers().iterator().next().getType().name());
	}

	@Test
	public void getFemalePassengerWithPersonalDetails() {
		CustomerLevel customerLevel = createCustomerLevelFemaleResponse();
		Person<String> person = personMapper.buildPerson(customerLevel);
		assertNotNull(person);
		assertEquals("FEMALE", person.getGender().name());
		assertNotNull(person.getDateOfBirth());
		assertEquals("COUNTRY",person.getNationality().getType());
		assertEquals("GB",person.getNationality().getIdentifier());
	 }
	
	@Test
	public void getOtherPassengerWithPersonalDetails() {
		CustomerLevel customerLevel = createCustomerLevelNotKnownResponse();
		Person<String> person = personMapper.buildPerson(customerLevel);
		assertNotNull(person);
		assertNull(person.getGender());
		assertNotNull(person.getDateOfBirth());
	 }
	
	
	@Test
	public void getPersonalDetailsWithoutBasicDetails() {
		CustomerLevel customerLevel = createCustomerWithoutBasicDetails();		
		Person<String> person = personMapper.buildPerson(customerLevel);
		assertNotNull(person);
		assertNull(person.getDateOfBirth());
		assertNull( person.getPersonName());
		assertNull( person.getNationality());
		assertNull( person.getRegisteredIdentifiers());
	}


	private CustomerLevel createCustomerLevelMaleResponse() {
		CustomerLevel customerLevel = new CustomerLevel();
		TravellerInformationType201121S travellerInformationType = new TravellerInformationType201121S();

		TravellerSurnameInformationType279780C travellerSurnameInformation = new TravellerSurnameInformationType279780C();
		travellerSurnameInformation.setSurname("Morgan");
		travellerSurnameInformation.setGender("M");
		travellerInformationType.setPaxDetails(travellerSurnameInformation);

		TravellerDetailsType279779C paxTravellerInformation = new TravellerDetailsType279779C();
		paxTravellerInformation.setGivenName("John");
		paxTravellerInformation.setTitle("MR");
		List<TravellerDetailsType279779C> otherPaxlist = new ArrayList<>();
		otherPaxlist.add(paxTravellerInformation);
		travellerInformationType.setOtherPaxDetails(otherPaxlist);

		customerLevel.setCustomerDetails(travellerInformationType);
		StructuredDateTimeInformationType13618S dateOfBirth = new StructuredDateTimeInformationType13618S();
		StructuredDateTimeType18902C dateTime = new StructuredDateTimeType18902C();
		dateTime.setDay("11");
		dateTime.setMonth("12");
		dateTime.setYear("1998");
		dateOfBirth.setDateTime(dateTime);
		customerLevel.setDateOfBirth(dateOfBirth);
		List<CustomerLevelRegDocs> customerLevelRegDocList = new ArrayList<>();

		CustomerLevelRegDocs customerLevelRegDocs = new CustomerLevelRegDocs();
		PassengerApiInformationType163944S passengerApiInformationType163944S = new PassengerApiInformationType163944S();
		DocumentIdTypeI232115C documentIdTypeI232115C = new DocumentIdTypeI232115C();
		documentIdTypeI232115C.setType("P");
		documentIdTypeI232115C.setNumber("GS3445");
	
		passengerApiInformationType163944S.setDocumentIdentification(documentIdTypeI232115C);

		PassengerContactDataTypeI passengerContactDataTypeI = new PassengerContactDataTypeI();
		passengerContactDataTypeI.setFirstName("JAMES");
		passengerContactDataTypeI.setSurname("NORMAN");
		passengerApiInformationType163944S.setContactDetails(passengerContactDataTypeI);
		customerLevelRegDocs.setTravelerAndDocumentInfo(passengerApiInformationType163944S);
		customerLevelRegDocList.add(customerLevelRegDocs);
		customerLevel.setCustomerLevelRegDocs(customerLevelRegDocList);	
		NationalityGroup nationalityGroup = new NationalityGroup();
		NationalityTypeU8495S nationalityType = new NationalityTypeU8495S();
		nationalityType.setCodeQualifier("2");
		com.amadeus.xml.ccprrr_17_1_1a.NationalityDetailsTypeU  nationalityDetailsTypeU  = new com.amadeus.xml.ccprrr_17_1_1a.NationalityDetailsTypeU (); 
		nationalityDetailsTypeU.setNationalityCode("GB");
		nationalityType.setNationalityDetails(nationalityDetailsTypeU);
		nationalityGroup.setNationality(nationalityType);
		ProductLevel productLevel = new ProductLevel();
		productLevel.setNationalityGroup(nationalityGroup);
		List<ProductLevel> productlevelList = new ArrayList<>();
		productlevelList.add(productLevel);
		customerLevel.setProductLevel(productlevelList);
		return customerLevel;
	}

	private CustomerLevel createCustomerLevelFemaleResponse() {
		CustomerLevel customerLevel = new CustomerLevel();
		TravellerInformationType201121S travellerInformationType = new TravellerInformationType201121S();

		TravellerSurnameInformationType279780C travellerSurnameInformation = new TravellerSurnameInformationType279780C();
		travellerSurnameInformation.setSurname("Julie");
		travellerSurnameInformation.setGender("F");
		travellerInformationType.setPaxDetails(travellerSurnameInformation);

		TravellerDetailsType279779C paxTravellerInformation = new TravellerDetailsType279779C();
		paxTravellerInformation.setGivenName("Anderson");
		paxTravellerInformation.setTitle("MRS");
		List<TravellerDetailsType279779C> otherPaxlist = new ArrayList<>();
		otherPaxlist.add(paxTravellerInformation);
		travellerInformationType.setOtherPaxDetails(otherPaxlist);

		customerLevel.setCustomerDetails(travellerInformationType);
		StructuredDateTimeInformationType13618S dateOfBirth = new StructuredDateTimeInformationType13618S();
		StructuredDateTimeType18902C dateTime = new StructuredDateTimeType18902C();
		dateTime.setDay("11");
		dateTime.setMonth("12");
		dateTime.setYear("1998");
		dateOfBirth.setDateTime(dateTime);
		customerLevel.setDateOfBirth(dateOfBirth);
		
		NationalityGroup nationalityGroup = new NationalityGroup();
		NationalityTypeU8495S nationalityType = new NationalityTypeU8495S();
		nationalityType.setCodeQualifier("2");
		com.amadeus.xml.ccprrr_17_1_1a.NationalityDetailsTypeU  nationalityDetailsTypeU  = new com.amadeus.xml.ccprrr_17_1_1a.NationalityDetailsTypeU(); 
		nationalityDetailsTypeU.setNationalityCode("GB");
		nationalityType.setNationalityDetails(nationalityDetailsTypeU);
		nationalityGroup.setNationality(nationalityType);
		ProductLevel productLevel = new ProductLevel();
		productLevel.setNationalityGroup(nationalityGroup);
		List<ProductLevel> productlevelList = new ArrayList<>();
		productlevelList.add(productLevel);
		customerLevel.setProductLevel(productlevelList);

		return customerLevel;

	}	
	
	private CustomerLevel createCustomerLevelNotKnownResponse() {
		CustomerLevel customerLevel = new CustomerLevel();
		TravellerInformationType201121S travellerInformationType = new TravellerInformationType201121S();

		TravellerSurnameInformationType279780C travellerSurnameInformation = new TravellerSurnameInformationType279780C();
		travellerSurnameInformation.setSurname("Marsh");
		travellerSurnameInformation.setGender("NOT_KNOWN");
		travellerInformationType.setPaxDetails(travellerSurnameInformation);

		TravellerDetailsType279779C paxTravellerInformation = new TravellerDetailsType279779C();
		paxTravellerInformation.setGivenName("Anderson");
		List<TravellerDetailsType279779C> otherPaxlist = new ArrayList<>();
		otherPaxlist.add(paxTravellerInformation);
		travellerInformationType.setOtherPaxDetails(otherPaxlist);

		customerLevel.setCustomerDetails(travellerInformationType);
		StructuredDateTimeInformationType13618S dateOfBirth = new StructuredDateTimeInformationType13618S();
		StructuredDateTimeType18902C dateTime = new StructuredDateTimeType18902C();
		dateTime.setDay("11");
		dateTime.setMonth("12");
		dateTime.setYear("1998");
		dateOfBirth.setDateTime(dateTime);
		customerLevel.setDateOfBirth(dateOfBirth);
		
		ProductLevel productLevel = new ProductLevel();
		List<ProductLevel> productlevelList = new ArrayList<>();
		productlevelList.add(productLevel);
		customerLevel.setProductLevel(productlevelList);

		return customerLevel;

	}	
	
	private CustomerLevel createCustomerWithoutBasicDetails(){
		CustomerLevel customerLevel = new CustomerLevel();
		return customerLevel;
	}
	
	private List<RegisteredIdentifier<?>> buildCustomerLevelRegDocs() {
		List<RegisteredIdentifier<?>> registeredIdentifierList = new ArrayList<>();
		Location<String> location = new Location<>();
		location.setLocationIdentifier("GB");
		location.setType(LocationType.COUNTRY);
		String dateTimeDetails = "12012018";
		RegisteredIdentifier<String> registeredIdentifier = new RegisteredIdentifier<>("dummyToken", null,
				RegisteredIdentifierType.PASSPORT, location, LocalDate.parse(dateTimeDetails), null);
		registeredIdentifierList.add(registeredIdentifier);
		return registeredIdentifierList;

	}


}
