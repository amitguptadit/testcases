package com.iag.business.passenger.repository.mapper.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.CustomerLevelRegDocs;
import com.amadeus.xml.ccprrr_17_1_1a.DateTimePeriodDetailsBatchTypeU;
import com.amadeus.xml.ccprrr_17_1_1a.DateTimePeriodType;
import com.amadeus.xml.ccprrr_17_1_1a.DocumentIdTypeI232115C;
import com.amadeus.xml.ccprrr_17_1_1a.LocationIdentificationBatchTypeU139931C;
import com.amadeus.xml.ccprrr_17_1_1a.PassengerApiInformationType163944S;
import com.amadeus.xml.ccprrr_17_1_1a.PassengerContactDataTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.PlaceLocationIdentificationTypeU93016S;
import com.iag.business.passenger.domain.model.location.LocationType;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifier;


public class RegisteredIdentifiersMapperTest {

	RegisteredIdentifiersMapper registeredIdentifiersMapper;

	@Before
	public void setup() {
		registeredIdentifiersMapper = new RegisteredIdentifiersMapper();
	}

	@Test
	public void getPassengerWithRegisteredIdentifierPassportDetails() {
		List<CustomerLevelRegDocs> customerLevelRegDocList = buildCustomerLevelRegDocs("P");
		List<RegisteredIdentifier<?>> registeredIdentifierList = registeredIdentifiersMapper
				.buildRegisteredIdentifiers(customerLevelRegDocList);
		assertTrue(registeredIdentifierList.size() > 0);
		assertEquals("GS3445", registeredIdentifierList.iterator().next().getToken());
		assertEquals("PASSPORT", registeredIdentifierList.iterator().next().getType().name());
		assertNotNull("2022-08-04",registeredIdentifierList.iterator().next().getExpiryDate());
		assertEquals("GB", registeredIdentifierList.iterator().next().getPlaceOfIssue().getLocationIdentifier());
		assertEquals(LocationType.COUNTRY, registeredIdentifierList.iterator().next().getPlaceOfIssue().getType());
		assertEquals("NORMAN", registeredIdentifierList.iterator().next().getPerson().getPersonName().getFamilyName());
		assertEquals("JAMES", registeredIdentifierList.iterator().next().getPerson().getPersonName().getFirstName());
	}

	@Test
	public void getPassengerWithRegisteredIdentifierVisaDetails() {
		List<CustomerLevelRegDocs> customerLevelRegDocList = buildCustomerLevelRegDocs("V");
		List<RegisteredIdentifier<?>> registeredIdentifierList = registeredIdentifiersMapper
				.buildRegisteredIdentifiers(customerLevelRegDocList);
		assertTrue(registeredIdentifierList.size() > 0);
		assertEquals("GB12345678", registeredIdentifierList.iterator().next().getToken());
		assertEquals("VISA", registeredIdentifierList.iterator().next().getType().name());
		assertNotNull(registeredIdentifierList.iterator().next().getExpiryDate());
		assertEquals("GB", registeredIdentifierList.iterator().next().getPlaceOfIssue().getLocationIdentifier());
		assertEquals(LocationType.COUNTRY, registeredIdentifierList.iterator().next().getPlaceOfIssue().getType());
		assertEquals("NORMAN", registeredIdentifierList.iterator().next().getPerson().getPersonName().getFamilyName());
		assertEquals("JAMES", registeredIdentifierList.iterator().next().getPerson().getPersonName().getFirstName());
	}

	@Test
	public void getPassengerWithRegisteredIdentifierIDDetails() {
		List<CustomerLevelRegDocs> customerLevelRegDocList = buildCustomerLevelRegDocs("I");
		List<RegisteredIdentifier<?>> registeredIdentifierList = registeredIdentifiersMapper
				.buildRegisteredIdentifiers(customerLevelRegDocList);
		assertTrue(registeredIdentifierList.size() > 0);
		assertEquals("ID1234567", registeredIdentifierList.iterator().next().getToken());
		assertEquals("NATIONAL_IDENTITY_CARD", registeredIdentifierList.iterator().next().getType().name());
		assertNotNull(registeredIdentifierList.iterator().next().getExpiryDate());
		assertEquals("GB", registeredIdentifierList.iterator().next().getPlaceOfIssue().getLocationIdentifier());
		assertEquals(LocationType.COUNTRY, registeredIdentifierList.iterator().next().getPlaceOfIssue().getType());
		assertEquals("NORMAN", registeredIdentifierList.iterator().next().getPerson().getPersonName().getFamilyName());
		assertEquals("JAMES", registeredIdentifierList.iterator().next().getPerson().getPersonName().getFirstName());
	}

	@Test
	public void getPassengerWithRegisteredIdentifierDrivingLicenceDetails() {
		List<CustomerLevelRegDocs> customerLevelRegDocList = buildCustomerLevelRegDocs("D");
		List<RegisteredIdentifier<?>> registeredIdentifierList = registeredIdentifiersMapper
				.buildRegisteredIdentifiers(customerLevelRegDocList);
		assertTrue(registeredIdentifierList.size() > 0);
		assertEquals("DL12345678", registeredIdentifierList.iterator().next().getToken());
		assertEquals("DRIVING_LICENCE", registeredIdentifierList.iterator().next().getType().name());
		assertNotNull(registeredIdentifierList.iterator().next().getExpiryDate());
		assertEquals("GB", registeredIdentifierList.iterator().next().getPlaceOfIssue().getLocationIdentifier());
		assertEquals(LocationType.COUNTRY, registeredIdentifierList.iterator().next().getPlaceOfIssue().getType());
		assertEquals("NORMAN", registeredIdentifierList.iterator().next().getPerson().getPersonName().getFamilyName());
		assertEquals("JAMES", registeredIdentifierList.iterator().next().getPerson().getPersonName().getFirstName());
	}
	
	@Test
	public void getPassengerRegisteredIdentifierWithOterDocumentInfo() {
		List<CustomerLevelRegDocs> customerLevelRegDocList = buildCustomerLevelRegDocsNoDocumentDate("A");
		List<RegisteredIdentifier<?>> registeredIdentifierList = registeredIdentifiersMapper
				.buildRegisteredIdentifiers(customerLevelRegDocList);
		assertTrue(registeredIdentifierList.size() > 0);
		assertNull(registeredIdentifierList.iterator().next().getExpiryDate());
		assertEquals("DL12345678", registeredIdentifierList.iterator().next().getToken());
		assertEquals("GB", registeredIdentifierList.iterator().next().getPlaceOfIssue().getLocationIdentifier());
		assertEquals(LocationType.COUNTRY, registeredIdentifierList.iterator().next().getPlaceOfIssue().getType());
	}
	
	@Test
	public void getPassengerRegisteredIdentifierWithOtherDateQualifier() {
		List<CustomerLevelRegDocs> customerLevelRegDocList = buildCustomerLevelRegDocsWithOtherDateQualifier("A");
		List<RegisteredIdentifier<?>> registeredIdentifierList = registeredIdentifiersMapper
				.buildRegisteredIdentifiers(customerLevelRegDocList);
		assertTrue(registeredIdentifierList.size() > 0);
		assertNull(registeredIdentifierList.iterator().next().getExpiryDate());
		assertEquals("DL12345678", registeredIdentifierList.iterator().next().getToken());
		assertEquals("GB", registeredIdentifierList.iterator().next().getPlaceOfIssue().getLocationIdentifier());
		assertEquals(LocationType.COUNTRY, registeredIdentifierList.iterator().next().getPlaceOfIssue().getType());
	}
	
	@Test
	public void getPassengerRegisteredIdentifierWithMissingDocumentInfo() {
		List<CustomerLevelRegDocs> customerLevelRegDocList = buildCustomerLevelRegDocsNoCountryCode("D");
		List<RegisteredIdentifier<?>> registeredIdentifierList = registeredIdentifiersMapper
				.buildRegisteredIdentifiers(customerLevelRegDocList);
		assertTrue(registeredIdentifierList.size() > 0);
		assertNull(registeredIdentifierList.iterator().next().getPlaceOfIssue().getType());
		assertNull(registeredIdentifierList.iterator().next().getPlaceOfIssue().getLocationIdentifier());
		assertEquals("DL12345678", registeredIdentifierList.iterator().next().getToken());
		assertEquals("DRIVING_LICENCE", registeredIdentifierList.iterator().next().getType().name());
		assertEquals("NORMAN", registeredIdentifierList.iterator().next().getPerson().getPersonName().getFamilyName());
		assertEquals("JAMES", registeredIdentifierList.iterator().next().getPerson().getPersonName().getFirstName());
	}

	public List<CustomerLevelRegDocs> buildCustomerLevelRegDocs(String identifierType) {
		List<CustomerLevelRegDocs> customerLevelRegDocList = new ArrayList<>();
		CustomerLevelRegDocs customerLevelRegDocs = new CustomerLevelRegDocs();
		PassengerApiInformationType163944S passengerApiInformationType163944S = new PassengerApiInformationType163944S();
		DocumentIdTypeI232115C documentIdTypeI232115C = new DocumentIdTypeI232115C();
		if (identifierType.equals("P")) {
			documentIdTypeI232115C.setType(identifierType);
			documentIdTypeI232115C.setNumber("GS3445");
		} else if (identifierType.equals("I")) {
			documentIdTypeI232115C.setType(identifierType);
			documentIdTypeI232115C.setNumber("ID1234567");
		} else if (identifierType.equals("V")) {
			documentIdTypeI232115C.setType(identifierType);
			documentIdTypeI232115C.setNumber("GB12345678");
		} else if (identifierType.equals("D")) {
			documentIdTypeI232115C.setType(identifierType);
			documentIdTypeI232115C.setNumber("DL12345678");
		}
		passengerApiInformationType163944S.setDocumentIdentification(documentIdTypeI232115C);

		PassengerContactDataTypeI passengerContactDataTypeI = new PassengerContactDataTypeI();
		passengerContactDataTypeI.setFirstName("JAMES");
		passengerContactDataTypeI.setSurname("NORMAN");
		passengerApiInformationType163944S.setContactDetails(passengerContactDataTypeI);
		customerLevelRegDocs.setTravelerAndDocumentInfo(passengerApiInformationType163944S);
		
		List<PlaceLocationIdentificationTypeU93016S> placeLocationIdentificationTypeList = new ArrayList<>();
		PlaceLocationIdentificationTypeU93016S placeLocationIdentificationType = new PlaceLocationIdentificationTypeU93016S();
		placeLocationIdentificationType.setLocationType("91");
		LocationIdentificationBatchTypeU139931C locationIdentificationBatchType = new LocationIdentificationBatchTypeU139931C();
		locationIdentificationBatchType.setCode("GB");
		placeLocationIdentificationType.setLocationDescription(locationIdentificationBatchType);
		placeLocationIdentificationTypeList.add(placeLocationIdentificationType);
		customerLevelRegDocs.setDocumentIssuingCountry(placeLocationIdentificationTypeList);
		
		List<DateTimePeriodType> documentDateList = new ArrayList<>();
		DateTimePeriodType dateTimePeriodType = new DateTimePeriodType();
		DateTimePeriodDetailsBatchTypeU dateTimePeriodDetailsBatchTypeU = new DateTimePeriodDetailsBatchTypeU();
		
		dateTimePeriodDetailsBatchTypeU.setDateTimeQualifier("192");
		dateTimePeriodDetailsBatchTypeU.setFormat("102");
		dateTimePeriodDetailsBatchTypeU.setDateTimeDetails("20220804");
		dateTimePeriodType.setDateTimeDescription(dateTimePeriodDetailsBatchTypeU);
		documentDateList.add(dateTimePeriodType);
		customerLevelRegDocs.setDocumentDate(documentDateList);
		
		customerLevelRegDocList.add(customerLevelRegDocs);
		return customerLevelRegDocList;

	}
	
	public List<CustomerLevelRegDocs> buildCustomerLevelRegDocsNoDocumentDate(String identifierType) {

		List<CustomerLevelRegDocs> customerLevelRegDocList = new ArrayList<>();

		CustomerLevelRegDocs customerLevelRegDocs = new CustomerLevelRegDocs();
		PassengerApiInformationType163944S passengerApiInformationType163944S = new PassengerApiInformationType163944S();
		DocumentIdTypeI232115C documentIdTypeI232115C = new DocumentIdTypeI232115C();	
			documentIdTypeI232115C.setType(identifierType);
			documentIdTypeI232115C.setNumber("DL12345678");
		
		passengerApiInformationType163944S.setDocumentIdentification(documentIdTypeI232115C);	
		customerLevelRegDocs.setTravelerAndDocumentInfo(passengerApiInformationType163944S);
		
		List<PlaceLocationIdentificationTypeU93016S> placeLocationIdentificationTypeList = new ArrayList<>();
		PlaceLocationIdentificationTypeU93016S placeLocationIdentificationType = new PlaceLocationIdentificationTypeU93016S();
		placeLocationIdentificationType.setLocationType("91");
		LocationIdentificationBatchTypeU139931C locationIdentificationBatchType = new LocationIdentificationBatchTypeU139931C();
		locationIdentificationBatchType.setCode("GB");
		placeLocationIdentificationType.setLocationDescription(locationIdentificationBatchType);
		placeLocationIdentificationTypeList.add(placeLocationIdentificationType);
		customerLevelRegDocs.setDocumentIssuingCountry(placeLocationIdentificationTypeList);
		
		List<DateTimePeriodType> documentDateList = new ArrayList<>();
		DateTimePeriodType dateTimePeriodType = new DateTimePeriodType();
		DateTimePeriodDetailsBatchTypeU dateTimePeriodDetailsBatchTypeU = new DateTimePeriodDetailsBatchTypeU();
		dateTimePeriodDetailsBatchTypeU.setDateTimeQualifier("192");
		dateTimePeriodDetailsBatchTypeU.setFormat("100");		
		dateTimePeriodDetailsBatchTypeU.setDateTimeDetails("20220804");
		dateTimePeriodType.setDateTimeDescription(dateTimePeriodDetailsBatchTypeU);
		documentDateList.add(dateTimePeriodType);
		customerLevelRegDocs.setDocumentDate(documentDateList);
		
		customerLevelRegDocList.add(customerLevelRegDocs);
		return customerLevelRegDocList;

	}
	
	public List<CustomerLevelRegDocs> buildCustomerLevelRegDocsWithOtherDateQualifier(String identifierType) {

		List<CustomerLevelRegDocs> customerLevelRegDocList = new ArrayList<>();

		CustomerLevelRegDocs customerLevelRegDocs = new CustomerLevelRegDocs();
		PassengerApiInformationType163944S passengerApiInformationType163944S = new PassengerApiInformationType163944S();
		DocumentIdTypeI232115C documentIdTypeI232115C = new DocumentIdTypeI232115C();	
			documentIdTypeI232115C.setType(identifierType);
			documentIdTypeI232115C.setNumber("DL12345678");
		
		passengerApiInformationType163944S.setDocumentIdentification(documentIdTypeI232115C);

	
		customerLevelRegDocs.setTravelerAndDocumentInfo(passengerApiInformationType163944S);
		
		List<PlaceLocationIdentificationTypeU93016S> placeLocationIdentificationTypeList = new ArrayList<>();
		PlaceLocationIdentificationTypeU93016S placeLocationIdentificationType = new PlaceLocationIdentificationTypeU93016S();
		placeLocationIdentificationType.setLocationType("91");
		LocationIdentificationBatchTypeU139931C locationIdentificationBatchType = new LocationIdentificationBatchTypeU139931C();
		locationIdentificationBatchType.setCode("GB");
		placeLocationIdentificationType.setLocationDescription(locationIdentificationBatchType);
		placeLocationIdentificationTypeList.add(placeLocationIdentificationType);
		customerLevelRegDocs.setDocumentIssuingCountry(placeLocationIdentificationTypeList);
		
		List<DateTimePeriodType> documentDateList = new ArrayList<>();
		DateTimePeriodType dateTimePeriodType = new DateTimePeriodType();
		DateTimePeriodDetailsBatchTypeU dateTimePeriodDetailsBatchTypeU = new DateTimePeriodDetailsBatchTypeU();
		dateTimePeriodDetailsBatchTypeU.setDateTimeQualifier("190");
		dateTimePeriodDetailsBatchTypeU.setFormat("102");		
		dateTimePeriodDetailsBatchTypeU.setDateTimeDetails("20220804");
		dateTimePeriodType.setDateTimeDescription(dateTimePeriodDetailsBatchTypeU);
		documentDateList.add(dateTimePeriodType);
		customerLevelRegDocs.setDocumentDate(documentDateList);
		
		customerLevelRegDocList.add(customerLevelRegDocs);
		return customerLevelRegDocList;

	}
	
	public List<CustomerLevelRegDocs> buildCustomerLevelRegDocsNoCountryCode(String identifierType) {

		List<CustomerLevelRegDocs> customerLevelRegDocList = new ArrayList<>();
		
		CustomerLevelRegDocs customerLevelRegDocs = new CustomerLevelRegDocs();
		PassengerApiInformationType163944S passengerApiInformationType163944S = new PassengerApiInformationType163944S();
		DocumentIdTypeI232115C documentIdTypeI232115C = new DocumentIdTypeI232115C();	
			documentIdTypeI232115C.setType(identifierType);
			documentIdTypeI232115C.setNumber("DL12345678");
			passengerApiInformationType163944S.setDocumentIdentification(documentIdTypeI232115C);			
			customerLevelRegDocs.setTravelerAndDocumentInfo(passengerApiInformationType163944S);		
		
		PassengerContactDataTypeI passengerContactDataTypeI = new PassengerContactDataTypeI();
		passengerContactDataTypeI.setFirstName("JAMES");
		passengerContactDataTypeI.setSurname("NORMAN");
		passengerApiInformationType163944S.setContactDetails(passengerContactDataTypeI);
		customerLevelRegDocs.setTravelerAndDocumentInfo(passengerApiInformationType163944S);
		
		List<PlaceLocationIdentificationTypeU93016S> placeLocationIdentificationTypeList = new ArrayList<>();
		PlaceLocationIdentificationTypeU93016S placeLocationIdentificationType = new PlaceLocationIdentificationTypeU93016S();
		placeLocationIdentificationType.setLocationType("50");
		LocationIdentificationBatchTypeU139931C locationIdentificationBatchType = new LocationIdentificationBatchTypeU139931C();
		locationIdentificationBatchType.setCode("GB");
		placeLocationIdentificationType.setLocationDescription(locationIdentificationBatchType);
		placeLocationIdentificationTypeList.add(placeLocationIdentificationType);
		customerLevelRegDocs.setDocumentIssuingCountry(placeLocationIdentificationTypeList);
		
		List<DateTimePeriodType> documentDateList = new ArrayList<>();
		DateTimePeriodType dateTimePeriodType = new DateTimePeriodType();
		documentDateList.add(dateTimePeriodType);
		customerLevelRegDocs.setDocumentDate(documentDateList);
		
		customerLevelRegDocList.add(customerLevelRegDocs);
		return customerLevelRegDocList;

	}


}
