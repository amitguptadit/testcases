package com.iag.business.passenger.repository.mapper.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.CustomerLevelEmergencyContact;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel;
import com.amadeus.xml.ccprrr_17_1_1a.ItemReferencesAndVersionsType146132S;
import com.amadeus.xml.ccprrr_17_1_1a.TravellerInformationType201121S;
import com.amadeus.xml.ccprrr_17_1_1a.TravellerSurnameInformationType279780C;
import com.amadeus.xml.ccprrr_17_1_1a.UniqueIdDescriptionType;
import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.domain.model.Carrier;
import com.iag.business.passenger.domain.model.CarrierType;
import com.iag.business.passenger.domain.model.Destination;
import com.iag.business.passenger.domain.model.Eticket;
import com.iag.business.passenger.domain.model.Gate;
import com.iag.business.passenger.domain.model.Itinerary;
import com.iag.business.passenger.domain.model.ItineraryItem;
import com.iag.business.passenger.domain.model.ItineraryItemStatus;
import com.iag.business.passenger.domain.model.Origin;
import com.iag.business.passenger.domain.model.Seat;
import com.iag.business.passenger.domain.model.location.Location;
import com.iag.business.passenger.domain.model.location.LocationType;
import com.iag.business.passenger.domain.model.party.Gender;
import com.iag.business.passenger.domain.model.party.Nationality;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.party.Person.PersonBuilder;
import com.iag.business.passenger.domain.model.party.PersonName;
import com.iag.business.passenger.domain.model.party.PersonName.PersonNameBuilder;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifier;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifierType;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.domain.model.party.role.PassengerStatus;


public class PassengerResponseMapperTest {
	@InjectMocks
	PassengerResponseMapper passengerResponseMapper;
	
	@Mock
	private PersonMapper personMapper;
	@Mock
	private ItineraryMapper itineraryMapper;
	@Mock
	private EmergencyContactMapper emergencyContactMapper;
	@Mock
	private DCSIDCCPRIdentificationReply passengerIdentificationReply;	
	
	CustomerLevel customerLevel;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		passengerResponseMapper = new PassengerResponseMapper(emergencyContactMapper, personMapper, itineraryMapper);
		customerLevel = new CustomerLevel();
	}
		
	@Test
	public void getPassengerWithoutAssociatedDetails() {		
		Mockito.when(personMapper.buildPerson(Mockito.any())).thenReturn(populatePerson());
		Mockito.when(itineraryMapper.buildItineraryItems(Mockito.any())).thenReturn(populateItineraryItemList());
		Mockito.when(passengerIdentificationReply.getCustomerLevel()).thenReturn(populatePassengerResponseDetails());
		Passenger<String> passenger = passengerResponseMapper.getPassengerAmadeusResponse(passengerIdentificationReply);
		assertNotNull(passenger);
		assertEquals("PAX001", passenger.getIdentifier());
		assertEquals("ADULT", passenger.getType().name());
		assertNotNull(passenger.getPerson());
		assertEquals("MALE", passenger.getPerson().getGender().name());
		assertEquals("NORMAN", passenger.getPerson().getPersonName().getFamilyName());
		assertEquals("MR", passenger.getPerson().getPersonName().getTitle());
		assertEquals("JAMES", passenger.getPerson().getPersonName().getFirstName());
		assertEquals("C",passenger.getPerson().getNationality().getType());
		assertEquals("GB",passenger.getPerson().getNationality().getIdentifier());
		assertTrue(passenger.getPerson().getRegisteredIdentifiers().size() > 0);
		assertEquals("dummyToken", passenger.getPerson().getRegisteredIdentifiers().iterator().next().getToken());
		assertEquals("PASSPORT", passenger.getPerson().getRegisteredIdentifiers().iterator().next().getType().name());
		assertNotNull(passenger.getItinerary());
		assertTrue(passenger.getItinerary().getItineraryItems().size() > 0);
		assertEquals("1258774395209", passenger.getItinerary().getEticket().getIdentifier());
		assertEquals("OP", passenger.getItinerary().getItineraryItems().iterator().next().getCarriers().iterator()
				.next().getCode());
		assertEquals("OPERATING", passenger.getItinerary().getItineraryItems().iterator().next().getCarriers()
				.iterator().next().getType().name());
		assertEquals("280", passenger.getItinerary().getItineraryItems().iterator().next().getCarriers().iterator()
				.next().getFlightNumber());
		assertEquals("OPS", passenger.getItinerary().getItineraryItems().iterator().next().getCarriers().iterator()
				.next().getOperationalSuffix());
		assertEquals("GATE2",
				passenger.getItinerary().getItineraryItems().iterator().next().getOrigin().getGate().getNumber());
		assertEquals("T4", passenger.getItinerary().getItineraryItems().iterator().next().getOrigin().getTerminal());
		assertEquals("LHR", passenger.getItinerary().getItineraryItems().iterator().next().getOrigin().getIdentifier());
		assertNotNull(
				passenger.getItinerary().getItineraryItems().iterator().next().getScheduledDepartureLocalDatetime());
		assertNotNull(
				passenger.getItinerary().getItineraryItems().iterator().next().getScheduledArrivalLocalDatetime());
		assertEquals("ECONOMY", passenger.getItinerary().getItineraryItems().iterator().next().getBookingClass());
		assertEquals("27A", passenger.getItinerary().getItineraryItems().iterator().next().getSeat().getNumber());
		assertEquals("CONFIRMED", passenger.getItinerary().getItineraryItems().iterator().next().getStatus().name());
		assertEquals("CHECKEDIN",
				passenger.getItinerary().getItineraryItems().iterator().next().getPassengerStatus().name());
		assertEquals("GATE2",
				passenger.getItinerary().getItineraryItems().iterator().next().getDestination().getGate().getNumber());
		assertEquals("D001",
				passenger.getItinerary().getItineraryItems().iterator().next().getDestination().getIdentifier());
		assertEquals("T2",
				passenger.getItinerary().getItineraryItems().iterator().next().getDestination().getTerminal());
		
	}

	@Test
	public void getPassengerWithAssociatedDetails() {
		Mockito.when(personMapper.buildPerson(customerLevel)).thenReturn(populatePerson());
		Mockito.when(itineraryMapper.buildItineraryItems(customerLevel.getProductLevel())).thenReturn(populateItineraryItemList());
		Mockito.when(passengerIdentificationReply.getCustomerLevel()).thenReturn(populatePassengerWithAssociatedResponseDetails());
		Passenger passenger = passengerResponseMapper.getPassengerAmadeusResponse(passengerIdentificationReply);
		assertNotNull(passenger);
		assertEquals("PAX002", passenger.getIdentifier());
		assertEquals("INFANT", passenger.getType().name());
		assertEquals("PAX003", passenger.getAssociatedPassenger().getIdentifier());
	}
	
	@Test
	public void getPassengerTypeAsChildDetails() {
		Mockito.when(personMapper.buildPerson(customerLevel)).thenReturn(populatePerson());
		Mockito.when(itineraryMapper.buildItineraryItems(customerLevel.getProductLevel())).thenReturn(populateItineraryItemList());
		Mockito.when(passengerIdentificationReply.getCustomerLevel()).thenReturn(populatePassengerAsChildResponseDetails());
		Passenger passenger = passengerResponseMapper.getPassengerAmadeusResponse(passengerIdentificationReply);
		assertNotNull(passenger);
		assertEquals("PAX001", passenger.getIdentifier());
		assertEquals("CHILD", passenger.getType().name());		
	}
	
	@Test
	public void shouldNotGetPassengerDetials() {
		List<CustomerLevel> customerLevelList = new ArrayList<>();
		Mockito.when(passengerIdentificationReply.getCustomerLevel()).thenReturn(customerLevelList);
		Passenger passenger = passengerResponseMapper.getPassengerAmadeusResponse(passengerIdentificationReply);
		assertNull(passenger);
	}
	
	@Test
	public void shouldNotGetPassengerDetialsOnAmadeusReplyAsNull() {
		DCSIDCCPRIdentificationReply passengerIdentificationReply = null;
		Passenger passenger = passengerResponseMapper.getPassengerAmadeusResponse(passengerIdentificationReply);
		assertNull(passenger);
	}

	@Test
	public void getPassengerTypeAsOtherDetails() {
		Mockito.when(personMapper.buildPerson(customerLevel)).thenReturn(populatePerson());
		Mockito.when(itineraryMapper.buildItineraryItems(customerLevel.getProductLevel())).thenReturn(populateItineraryItemList());
		Mockito.when(passengerIdentificationReply.getCustomerLevel()).thenReturn(populatePassengerTypeAsOther());
		Passenger passenger = passengerResponseMapper.getPassengerAmadeusResponse(passengerIdentificationReply);
		assertNotNull(passenger);
		assertEquals("PAX001", passenger.getIdentifier());
		assertNull(passenger.getType());		
	}
	
	@Test
	public void getPassengerTypeAsEmpty() {
		Mockito.when(personMapper.buildPerson(customerLevel)).thenReturn(populatePerson());
		Mockito.when(itineraryMapper.buildItineraryItems(customerLevel.getProductLevel())).thenReturn(populateItineraryItemList());
		Mockito.when(passengerIdentificationReply.getCustomerLevel()).thenReturn(populatePassengerTypeAsNull());
		Passenger passenger = passengerResponseMapper.getPassengerAmadeusResponse(passengerIdentificationReply);
		assertNotNull(passenger);
		assertEquals("PAX001", passenger.getIdentifier());
		assertNull(passenger.getType());		
	}
	

	private List<CustomerLevel> populatePassengerResponseDetails() {
		List<CustomerLevel> customerLevelList = new ArrayList<>();
		CustomerLevel customerLevel = new CustomerLevel();
		UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
		uniqueIdDescriptionType.setPrimeId("PAX001");
		ItemReferencesAndVersionsType146132S itemReferenceVersion = new ItemReferencesAndVersionsType146132S(
				uniqueIdDescriptionType);
		customerLevel.setUniqueCustomerId(itemReferenceVersion);
		TravellerInformationType201121S travellerInformationType = new TravellerInformationType201121S();
		TravellerSurnameInformationType279780C travellerSurnameInformation = new TravellerSurnameInformationType279780C();
		travellerSurnameInformation.setType(PassengerServiceConstants.ADULT);
		travellerInformationType.setPaxDetails(travellerSurnameInformation);
		
		List<ProductLevel> productLevelList = new ArrayList<>();
		ProductLevel productLevel = new ProductLevel();
		List<ItemReferencesAndVersionsType146132S> productIdentifiers = new ArrayList<>();
		ItemReferencesAndVersionsType146132S itemReferencesAndVersionsType = new ItemReferencesAndVersionsType146132S();
		UniqueIdDescriptionType value = new UniqueIdDescriptionType();
		value.setReferenceQualifier("SID");
		value.setPrimeId("PAX003");
		itemReferencesAndVersionsType.setIdSection(value);
		productIdentifiers.add(itemReferencesAndVersionsType);
		productLevel.setProductIdentifiers(productIdentifiers);
		productLevelList.add(productLevel);
		customerLevel.setProductLevel(productLevelList);
		
		CustomerLevelEmergencyContact customerLevelEmergencyContact = new CustomerLevelEmergencyContact();
		List<CustomerLevelEmergencyContact> customerLevelEmergencyContactList = new ArrayList<>();
		customerLevelEmergencyContactList.add(customerLevelEmergencyContact);
		customerLevel.setCustomerLevelEmergencyContact(customerLevelEmergencyContactList);
		customerLevel.setCustomerDetails(travellerInformationType);
		customerLevelList.add(customerLevel);
		return customerLevelList;
	}

	private List<CustomerLevel> populatePassengerWithAssociatedResponseDetails() {
		List<CustomerLevel> customerLevelList = new ArrayList<>();
		CustomerLevel customerLevel = new CustomerLevel();
		UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
		uniqueIdDescriptionType.setPrimeId("PAX002");
		ItemReferencesAndVersionsType146132S itemReferenceVersion = new ItemReferencesAndVersionsType146132S(
				uniqueIdDescriptionType);
		customerLevel.setUniqueCustomerId(itemReferenceVersion);
		TravellerInformationType201121S travellerInformationType = new TravellerInformationType201121S();
		TravellerSurnameInformationType279780C travellerSurnameInformation = new TravellerSurnameInformationType279780C();
		travellerSurnameInformation.setType(PassengerServiceConstants.INFANT);
		travellerInformationType.setPaxDetails(travellerSurnameInformation);
		customerLevel.setCustomerDetails(travellerInformationType);

		List<ProductLevel> productLevelList = new ArrayList<>();
		ProductLevel productLevel = new ProductLevel();
		List<ItemReferencesAndVersionsType146132S> productIdentifiers = new ArrayList<>();

		ItemReferencesAndVersionsType146132S itemReferencesAndVersionsType = new ItemReferencesAndVersionsType146132S();
		UniqueIdDescriptionType value = new UniqueIdDescriptionType();
		value.setReferenceQualifier(PassengerServiceConstants.ASSOCIATED_PASSENGER_QUALIFIER);
		value.setPrimeId("PAX003");
		itemReferencesAndVersionsType.setIdSection(value);
		productIdentifiers.add(itemReferencesAndVersionsType);
		productLevel.setProductIdentifiers(productIdentifiers);
		productLevelList.add(productLevel);
		customerLevel.setProductLevel(productLevelList);

		customerLevelList.add(customerLevel);
		return customerLevelList;
	}
	
	private List<CustomerLevel> populatePassengerAsChildResponseDetails() {
		List<CustomerLevel> customerLevelList = new ArrayList<>();
		CustomerLevel customerLevel = new CustomerLevel();
		UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
		uniqueIdDescriptionType.setPrimeId("PAX001");
		ItemReferencesAndVersionsType146132S itemReferenceVersion = new ItemReferencesAndVersionsType146132S(
				uniqueIdDescriptionType);
		customerLevel.setUniqueCustomerId(itemReferenceVersion);
		TravellerInformationType201121S travellerInformationType = new TravellerInformationType201121S();

		TravellerSurnameInformationType279780C travellerSurnameInformation = new TravellerSurnameInformationType279780C();
		travellerSurnameInformation.setType(PassengerServiceConstants.CHILD);
		travellerInformationType.setPaxDetails(travellerSurnameInformation);
		customerLevel.setCustomerDetails(travellerInformationType);
		customerLevelList.add(customerLevel);
		return customerLevelList;
	}
	
	private List<CustomerLevel> populatePassengerTypeAsOther() {
		List<CustomerLevel> customerLevelList = new ArrayList<>();
		CustomerLevel customerLevel = new CustomerLevel();
		UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
		uniqueIdDescriptionType.setPrimeId("PAX001");
		ItemReferencesAndVersionsType146132S itemReferenceVersion = new ItemReferencesAndVersionsType146132S(
				uniqueIdDescriptionType);
		customerLevel.setUniqueCustomerId(itemReferenceVersion);
		TravellerInformationType201121S travellerInformationType = new TravellerInformationType201121S();

		TravellerSurnameInformationType279780C travellerSurnameInformation = new TravellerSurnameInformationType279780C();
		travellerSurnameInformation.setType("Old");
		travellerInformationType.setPaxDetails(travellerSurnameInformation);
		customerLevel.setCustomerDetails(travellerInformationType);
		customerLevelList.add(customerLevel);
		return customerLevelList;
	}
	
	private List<CustomerLevel> populatePassengerTypeAsNull() {
		List<CustomerLevel> customerLevelList = new ArrayList<>();
		CustomerLevel customerLevel = new CustomerLevel();
		UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
		uniqueIdDescriptionType.setPrimeId("PAX001");
		ItemReferencesAndVersionsType146132S itemReferenceVersion = new ItemReferencesAndVersionsType146132S(
				uniqueIdDescriptionType);
		customerLevel.setUniqueCustomerId(itemReferenceVersion);
		TravellerInformationType201121S travellerInformationType = new TravellerInformationType201121S();
		TravellerSurnameInformationType279780C travellerSurnameInformation = null;
		travellerInformationType.setPaxDetails(travellerSurnameInformation);
		customerLevel.setCustomerDetails(travellerInformationType);
		customerLevelList.add(customerLevel);
		return customerLevelList;
	}

	private Person<String> populatePerson() {
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("JAMES", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();

		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);

		Nationality nationality = new Nationality();
		nationality.setType("C");
		nationality.setIdentifier("GB");
		personBuilder.setNationality(nationality);
		List<RegisteredIdentifier<?>> registeredIdentifierList = new ArrayList<>();
		Location<String> location = new Location<>();
		location.setLocationIdentifier("GB");
		location.setType(LocationType.COUNTRY);
		String dateTimeDetails = "12012018";
		RegisteredIdentifier<?> registeredIdentifier = new RegisteredIdentifier<>("dummyToken", null,
				RegisteredIdentifierType.PASSPORT, location, LocalDate.parse(dateTimeDetails), null);
		registeredIdentifierList.add(registeredIdentifier);
		personBuilder.setRegisteredIdentifier(registeredIdentifierList);
		Person<String> person = personBuilder.build();
		return person;
	}

	private Itinerary populateItineraryItemList() {
		ItineraryItem itineraryItem = new ItineraryItem();
		itineraryItem.setIdentifier("2301CB2D000236BD");
		List<Carrier> carriers = new ArrayList<>();
		Carrier operatingCarrier = new Carrier();
		operatingCarrier.setCode("OP");
		operatingCarrier.setType(CarrierType.OPERATING);
		operatingCarrier.setFlightNumber("280");
		operatingCarrier.setOperationalSuffix("OPS");
		Carrier marketingCarrier = new Carrier();
		marketingCarrier.setCode("BA");
		marketingCarrier.setType(CarrierType.MARKETING);
		marketingCarrier.setFlightNumber("111");
		marketingCarrier.setOperationalSuffix("OP");

		carriers.add(operatingCarrier);
		carriers.add(marketingCarrier);

		Origin origin = new Origin();
		origin.setIdentifier("LHR");
		origin.setTerminal("T4");
		Gate gate = new Gate();
		gate.setNumber("GATE2");
		origin.setGate(gate);

		Destination destination = new Destination();
		destination.setIdentifier("D001");
		destination.setTerminal("T2");
		destination.setGate(gate);
		itineraryItem.setCarriers(carriers);
		itineraryItem.setOrigin(origin);
		itineraryItem.setDestination(destination);
		LocalDateTime scheduledDepartureLocalDatetime = new LocalDateTime(2018, 12, 15, 13, 45, 50);
		LocalDateTime scheduledArrivalLocalDatetime = new LocalDateTime(2018, 12, 12, 13, 45, 40);
		itineraryItem.setScheduledDepartureLocalDatetime(scheduledDepartureLocalDatetime);
		itineraryItem.setScheduledArrivalLocalDatetime(scheduledArrivalLocalDatetime);
		itineraryItem.setBookingClass("ECONOMY");
		itineraryItem.setCabinCode("UPPER");
		itineraryItem.setPassengerStatus(PassengerStatus.CHECKEDIN);
		itineraryItem.setStatus(ItineraryItemStatus.CONFIRMED);
		Seat seat = new Seat();
		seat.setNumber("27A");
		itineraryItem.setSeat(seat);

		List<ItineraryItem> itineraryItems = new ArrayList<>();
		itineraryItems.add(itineraryItem);

		Itinerary itinerary = new Itinerary();
		Eticket eticket = new Eticket();
		eticket.setIdentifier("1258774395209");
		itinerary.setEticket(eticket);
		itinerary.setItineraryItems(itineraryItems);
		return itinerary;
	}

}

