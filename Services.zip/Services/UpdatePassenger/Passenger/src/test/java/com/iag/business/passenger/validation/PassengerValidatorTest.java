package com.iag.business.passenger.validation;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.google.common.collect.Lists;
import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.error.matcher.CustomValidationServiceExceptionMatcher;
import com.iag.business.passenger.exception.ValidationServiceExceptionGenerator;

public class PassengerValidatorTest {
	
	@InjectMocks
	private PassengerValidator passengerValidator;
	
	@Mock
	private  BookingIdentifierValidation mockBookingIdentifierValidation;
	
	@Mock
	private  PassengerIdentifierValidation mockPassengerIdentifierValidation;
	
	@Mock
	private  HeaderValidation headerValueMapValidation;
	
	@Mock
	private  ValidationServiceExceptionGenerator mockValidationServiceExceptionGenerator;
	
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	
	
	private static final String DEV_MSG_DATA_INVALID = "Data Invalid";
	
	private static final String PASSENGERINGIDENTIFER_PATH = "passenger-identifier";
	private static final String  BOOKINGIDENTIFER_PATH = "booking-identifier";
	private static final String PASSENGER_IDENTIFER_VALID="PAX001rt12133356";
	private static final String BOOKING_IDENTIFER_VALID="TKT012345678";
	private static final String BOOKING_IDENTIFER_INVALID="TKT01234@#$$$5678";
	private static final String PASSENGER_IDENTIFER_INVALID="afjdafdafudafy@##DJHHDDHhdd";
	
	 
	List<ValidationServiceException> validationServiceExceptionlist;
	
	List<ValidationServiceException> serviceExceptionlist;
	
	Map<String,String> headerValueMap = new HashMap<>();
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		passengerValidator = new PassengerValidator(mockBookingIdentifierValidation, mockPassengerIdentifierValidation,
				headerValueMapValidation, mockValidationServiceExceptionGenerator);
		validationServiceExceptionlist = Lists.newArrayList();
	}
	
	 @Test  
	public void shouldThrowValidationServiceExceptionForInvalidBookingIdentifier() {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name());
		ValidationServiceException bookingValidationServiceException = createValidationServiceException(
				PassengerErrorCode.DATA_INVALID.name(), BOOKINGIDENTIFER_PATH);
		validationServiceExceptionlist.add(bookingValidationServiceException);
		thrown.expect(ValidationServiceException.class);
		thrown.expect(CustomValidationServiceExceptionMatcher.hasException(validationServiceException));
		when(mockBookingIdentifierValidation.validate(Mockito.anyString()))
				.thenReturn(bookingValidationServiceException);
		when(mockValidationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionlist))
						.thenThrow(validationServiceException);
		passengerValidator.validate(BOOKING_IDENTIFER_INVALID, PASSENGER_IDENTIFER_VALID, headerValueMap);

	}
	 
	 @Test  
	public void shouldThrowValidationServiceExceptionForInvalidPassengerIdentifier() {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name());
		ValidationServiceException passengerValidationServiceException = createValidationServiceException(
				PassengerErrorCode.DATA_INVALID.name(), PASSENGERINGIDENTIFER_PATH);
		validationServiceException.addValidationException(passengerValidationServiceException);
		validationServiceExceptionlist.add(passengerValidationServiceException);
		thrown.expect(ValidationServiceException.class);
		thrown.expect(CustomValidationServiceExceptionMatcher.hasException(validationServiceException));
		when(mockPassengerIdentifierValidation.validate(Mockito.anyString()))
				.thenReturn(passengerValidationServiceException);
		when(mockValidationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionlist))
						.thenThrow(validationServiceException);
		passengerValidator.validate(BOOKING_IDENTIFER_VALID, PASSENGER_IDENTIFER_INVALID, headerValueMap);

	}
	 
	 @Test  
	public void shouldThrowValidationServiceExceptionForInvalidPassengerAndBokingIdentifier() {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name());
		ValidationServiceException bookingValidationServiceException = new ValidationServiceException(
				PassengerErrorCode.DATA_INVALID.name());
		bookingValidationServiceException.setPath(BOOKINGIDENTIFER_PATH);
		ValidationServiceException passengerValidationServiceException = createValidationServiceException(
				PassengerErrorCode.DATA_INVALID.name(), PASSENGERINGIDENTIFER_PATH);
		validationServiceException.addValidationException(bookingValidationServiceException);
		validationServiceException.addValidationException(passengerValidationServiceException);
		validationServiceExceptionlist.add(bookingValidationServiceException);
		validationServiceExceptionlist.add(passengerValidationServiceException);

		thrown.expect(ValidationServiceException.class);
		thrown.expect(CustomValidationServiceExceptionMatcher.hasException(validationServiceException));
		when(mockBookingIdentifierValidation.validate(Mockito.anyString()))
				.thenReturn(bookingValidationServiceException);
		when(mockPassengerIdentifierValidation.validate(Mockito.anyString()))
				.thenReturn(passengerValidationServiceException);
		when(mockValidationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionlist))
						.thenThrow(validationServiceException);
		passengerValidator.validate(BOOKING_IDENTIFER_INVALID, PASSENGER_IDENTIFER_INVALID, headerValueMap);
	}
	

	@Test
	public void shouldPassValidation() {			
		List<ValidationServiceException> validationServiceExceptionlist = Lists.newArrayList();
		when(mockBookingIdentifierValidation.validate(Mockito.anyString())).thenReturn(null);
		when(mockPassengerIdentifierValidation.validate(Mockito.anyString())).thenReturn(null);
		passengerValidator.validate(BOOKING_IDENTIFER_VALID, PASSENGER_IDENTIFER_VALID,headerValueMap);
		assertEquals(0,validationServiceExceptionlist.size());
	}
		
	private ValidationServiceException createValidationServiceException(
			String childErrorCode, String path) {
		ValidationServiceException childValidationServiceException = new ValidationServiceException(childErrorCode);
		childValidationServiceException.setPath(path);
		childValidationServiceException.setDeveloperMessage(DEV_MSG_DATA_INVALID);
		return childValidationServiceException;
	}
	
}
