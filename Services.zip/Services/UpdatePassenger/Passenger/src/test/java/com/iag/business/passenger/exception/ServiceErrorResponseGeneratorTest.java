package com.iag.business.passenger.exception;

import java.util.Collection;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;

import com.iag.application.error.ContentProvider;
import com.iag.application.error.ErrorFactory;
import com.iag.application.error.ServiceError;
import com.iag.application.error.ValidationError;
import com.iag.application.exception.ApplicationServiceException;
import com.iag.application.exception.ValidationServiceException;
import com.iag.business.passenger.constant.error.PassengerErrorCode;


public class ServiceErrorResponseGeneratorTest {
	

	@InjectMocks
	private ServiceErrorResponseGenerator serviceErrorResponseGenerator;

	@Mock
	private ContentProvider contentProvider;

	private ErrorFactory errorFactory = new ErrorFactory();

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		serviceErrorResponseGenerator = new ServiceErrorResponseGenerator(contentProvider);
	}
	
	@Test
	public void validateServiceErrorResponse() {
		ValidationServiceException validationServiceException = createValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name(), PassengerErrorCode.DATA_INVALID.name());

		ServiceError serviceError = serviceErrorResponseGenerator.createServiceError(validationServiceException);
		Collection<ValidationError> validationErrorList = ((ValidationError) serviceError).getServiceErrors();
		Assert.assertNotNull(serviceError);
		Assert.assertEquals(PassengerErrorCode.REQUEST_INVALID.name(), serviceError.getCode());
		Assert.assertEquals(PassengerErrorCode.DATA_INVALID.name(), validationErrorList.iterator().next().getCode());
	}

	@Test
	public void shouldGetHttpStatusCodeForRequestInvalid() {
		ValidationServiceException validationServiceException = createValidationServiceException(
				PassengerErrorCode.REQUEST_INVALID.name(), PassengerErrorCode.DATA_INVALID.name());
		Mockito.when(errorFactory.getStatusCode(validationServiceException, contentProvider)).thenReturn(HttpStatus.BAD_REQUEST.toString());
		String httpStatusCode = serviceErrorResponseGenerator.getStatusCode(validationServiceException);
		Assert.assertEquals(HttpStatus.BAD_REQUEST.toString(), httpStatusCode);
	}
	
	@Test
	public void shouldGetHttpStatusCodeForSystemUnavailable() {
		ApplicationServiceException serviceException = createApplicationServiceException(
				PassengerErrorCode.SYSTEM_UNAVAILABLE.name());
		Mockito.when(errorFactory.getStatusCode(serviceException, contentProvider)).thenReturn(PassengerErrorCode.SYSTEM_UNAVAILABLE.name());
		serviceErrorResponseGenerator.getStatusCode(serviceException);
		Assert.assertEquals(PassengerErrorCode.SYSTEM_UNAVAILABLE.name(), serviceException.getCode());
	}

	private ValidationServiceException createValidationServiceException(String parentError, String childError) {
		ValidationServiceException validationServiceException = new ValidationServiceException(parentError);
		ValidationServiceException childValidationServiceException = new ValidationServiceException(childError);
		validationServiceException.addValidationException(childValidationServiceException);
		return validationServiceException;
	}
	
	private ApplicationServiceException createApplicationServiceException(String parentError) {
		ApplicationServiceException serviceException = new ApplicationServiceException(parentError);
		return serviceException;
	}
	
	
}
