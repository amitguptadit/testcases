package com.iag.business.passenger.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.iag.business.passenger.constant.PassengerServiceConstants;
import com.iag.business.passenger.constant.error.PassengerErrorCode;
import com.iag.business.passenger.domain.model.Carrier;
import com.iag.business.passenger.domain.model.CarrierType;
import com.iag.business.passenger.domain.model.Destination;
import com.iag.business.passenger.domain.model.Eticket;
import com.iag.business.passenger.domain.model.Gate;
import com.iag.business.passenger.domain.model.Itinerary;
import com.iag.business.passenger.domain.model.ItineraryItem;
import com.iag.business.passenger.domain.model.ItineraryItemStatus;
import com.iag.business.passenger.domain.model.Origin;
import com.iag.business.passenger.domain.model.Seat;
import com.iag.business.passenger.domain.model.address.TelecomAddress;
import com.iag.business.passenger.domain.model.location.Location;
import com.iag.business.passenger.domain.model.location.LocationType;
import com.iag.business.passenger.domain.model.party.Gender;
import com.iag.business.passenger.domain.model.party.Nationality;
import com.iag.business.passenger.domain.model.party.Person;
import com.iag.business.passenger.domain.model.party.Person.PersonBuilder;
import com.iag.business.passenger.domain.model.party.PersonName;
import com.iag.business.passenger.domain.model.party.PersonName.PersonNameBuilder;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifier;
import com.iag.business.passenger.domain.model.party.RegisteredIdentifierType;
import com.iag.business.passenger.domain.model.party.role.AssociatedPassenger;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact;
import com.iag.business.passenger.domain.model.party.role.EmergencyContact.EmergencyContactBuilder;
import com.iag.business.passenger.domain.model.party.role.Passenger;
import com.iag.business.passenger.domain.model.party.role.Passenger.PassengerBuilder;
import com.iag.business.passenger.domain.model.party.role.PassengerStatus;
import com.iag.business.passenger.domain.model.party.role.PassengerType;
import com.iag.business.passenger.proxy.config.ConfigurationInfrastructureServiceProxy;
import com.iag.business.passenger.repository.mapper.request.PassengerRequestMapper;
import com.iag.business.passenger.repository.mapper.response.PassengerResponseMapper;
import com.iag.business.passenger.session.AmadeusSession;



public class PassengerRepositoryImplTest {	
	
	private final static String PASSENGER_ID = "PAX001";
    private final static String PASSENGER_ID2 = "PAX002";
	private final static String BOOKING_ID = "2301DB2D00009C26";
    private static final String CHILD = "CHILD";
	private static final String ADULT = "ADULT";
	private static final String CHECKEDIN = "CHECKEDIN";
	private static final String CONFIRMED = "CONFIRMED";
	private static final String NOTCHECKEDIN = "NOTCHECKEDIN";
	private static final String UNCONFIRMED = "UNCONFIRMED";
	private static final String STANDBY = "STANDBY";
	private static final String INFANT = "INFANT";
	private static final String MR = "MR";
	private static final String NORMAN2 = "NORMAN";
	private static final String JANE = "JANE";
	private static final String NORMAN = "NORMAN";
	private static final String TELECOM_NUMBER = "TELECOM_NUMBER";
	private static final String LHR = "LHR";
	private static final String UPPER = "UPPER";
	private static final String C = "C";
	private static final String GB = "GB";
	private static final String PASSPORT = "PASSPORT";
	private static final String OP = "OP";
	private static final String OPERATING = "OPERATING";
	private static final String OPS = "OPS";
	private static final String GATE2 = "GATE2";
	private static final String T4 = "T4";
	private static final String D001 = "D001";
	private static final String T2 = "T2";
	private static final String THOMAS = "THOMAS";
		
	PassengerRepositoryImpl passengerRepositoryImpl;
	@Mock
	PassengerRequestMapper passengerRequestMapper;
	@Mock
	PassengerResponseMapper passengerResponseMapper;
	@Mock
	private WebServiceTemplate amadeusWebServiceTemplate;
	@Mock
	AmadeusWebServiceGateway amadeusWebServiceGateway;
	
	AmadeusSession session;

	private Passenger<String> passenger;

	 @Mock
	 private ConfigurationInfrastructureServiceProxy configurationInfrastructureServiceProxy;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		session = new AmadeusSession();
		passengerRepositoryImpl = new PassengerRepositoryImpl();
		ReflectionTestUtils.setField(passengerRepositoryImpl, "passengerRequestMapper", passengerRequestMapper);
		ReflectionTestUtils.setField(passengerRepositoryImpl, "amadeusWebServiceGateway", amadeusWebServiceGateway);
		ReflectionTestUtils.setField(passengerRepositoryImpl, "passengerResponseMapper", passengerResponseMapper);
		ReflectionTestUtils.setField(passengerRepositoryImpl, "configurationInfrastructureServiceProxy", configurationInfrastructureServiceProxy);
		Mockito.when(configurationInfrastructureServiceProxy
                        .retrieveConfiguration(PassengerServiceConstants.AMADEUS_NAMESPACE,PassengerErrorCode.PASSENGER_SOAP_URL.name()))
	       .thenReturn("http://webservices.amadeus.com/1ASIWIAGBA/CCPRRQ_17_1_1A");
 	}
	
	@Test
	public void getPassengerDetails(){	
		Passenger passenger = createPassengerDomain();
		Mockito.when(passengerResponseMapper.getPassengerAmadeusResponse(Mockito.any())).thenReturn(createPassengerDomain());
		passenger = passengerRepositoryImpl.getPassenger(BOOKING_ID, PASSENGER_ID, getSession());
		assertEquals(PASSENGER_ID, passenger.getIdentifier());
		assertEquals(INFANT, PassengerType.INFANT.name());
		assertNotNull(passenger.getPerson());
		assertEquals(MR, passenger.getPerson().getPersonName().getTitle());
		assertEquals(THOMAS, passenger.getPerson().getPersonName().getFirstName());
		assertEquals(NORMAN2, passenger.getPerson().getPersonName().getFamilyName());
		assertNotNull(passenger.getPerson().getNationality());
		assertEquals(C, passenger.getPerson().getNationality().getType());
		assertEquals(GB, passenger.getPerson().getNationality().getIdentifier());
		List<RegisteredIdentifier<?>> registeredIdentifiers = passenger.getPerson().getRegisteredIdentifiers();
		assertNotNull(PASSPORT, registeredIdentifiers.get(0).getType().name());
		assertNotNull("dummyToken", registeredIdentifiers.get(0).getToken());
		assertEquals("1258774395209", passenger.getItinerary().getEticket().getIdentifier());
		assertEquals(OP, passenger.getItinerary().getItineraryItems().iterator().next().getCarriers().iterator().next()
				.getCode());
		assertEquals(OPERATING, passenger.getItinerary().getItineraryItems().iterator().next().getCarriers().iterator()
				.next().getType().name());
		assertEquals("280", passenger.getItinerary().getItineraryItems().iterator().next().getCarriers().iterator()
				.next().getFlightNumber());
		assertEquals(OPS, passenger.getItinerary().getItineraryItems().iterator().next().getCarriers().iterator().next()
				.getOperationalSuffix());
		assertEquals(GATE2,
				passenger.getItinerary().getItineraryItems().iterator().next().getOrigin().getGate().getNumber());
		assertEquals(T4, passenger.getItinerary().getItineraryItems().iterator().next().getOrigin().getTerminal());
		assertEquals(LHR, passenger.getItinerary().getItineraryItems().iterator().next().getOrigin().getIdentifier());
		assertNotNull(
				passenger.getItinerary().getItineraryItems().iterator().next().getScheduledDepartureLocalDatetime());
		assertNotNull(
				passenger.getItinerary().getItineraryItems().iterator().next().getScheduledArrivalLocalDatetime());
		assertEquals("27A", passenger.getItinerary().getItineraryItems().iterator().next().getSeat().getNumber());
		assertEquals(CHECKEDIN,
				passenger.getItinerary().getItineraryItems().iterator().next().getPassengerStatus().name());
		assertEquals(GATE2,
				passenger.getItinerary().getItineraryItems().iterator().next().getDestination().getGate().getNumber());
		assertEquals(D001,
				passenger.getItinerary().getItineraryItems().iterator().next().getDestination().getIdentifier());
		assertEquals(T2, passenger.getItinerary().getItineraryItems().iterator().next().getDestination().getTerminal());
		assertEquals(MR, passenger.getPerson().getPersonName().getTitle());
		assertEquals(THOMAS, passenger.getPerson().getPersonName().getFirstName());
		assertEquals(NORMAN2, passenger.getPerson().getPersonName().getFamilyName());
		assertNotNull(passenger.getPerson().getNationality());
		assertEquals(C, passenger.getPerson().getNationality().getType());
		assertEquals(GB, passenger.getPerson().getNationality().getIdentifier());
	}
	
	@Test
	public void getPassengerDetailsWithAssociatedPassenger(){	
		Mockito.when(passengerResponseMapper.getPassengerAmadeusResponse(Mockito.any())).thenReturn(createPassengerWithAssociatedDomain());
		passenger = passengerRepositoryImpl.getPassenger(BOOKING_ID, PASSENGER_ID2, getSession());
		assertNotNull(passenger);
		assertEquals(PASSENGER_ID2, passenger.getIdentifier());
		assertEquals(PASSENGER_ID, passenger.getAssociatedPassenger().getIdentifier());
		assertEquals(INFANT, passenger.getType().name());		
	}
	
	@Test
	public void getPassengerDetailsWithoutAssociatedPassenger() {
		Mockito.when(passengerResponseMapper.getPassengerAmadeusResponse(Mockito.any())).thenReturn(createPassengerDomain());
		passenger = passengerRepositoryImpl.getPassenger(BOOKING_ID, PASSENGER_ID, getSession());
		assertNotNull(passenger);
		assertEquals(PASSENGER_ID, passenger.getIdentifier());
		assertEquals(ADULT, passenger.getType().name());
	}
	
	@Test
	public void getPassengerTypeAsChild() {
		Mockito.when(passengerResponseMapper.getPassengerAmadeusResponse(Mockito.any())).thenReturn(createPassengerDomainAsChild());
		passenger = passengerRepositoryImpl.getPassenger(BOOKING_ID, PASSENGER_ID, getSession());
		assertEquals(CHILD, PassengerType.CHILD.name());
	}
	
	@Test
	public void getPassengerStatusAsStandby() {
		Passenger passenger = createPassengerForSTANDBYStatus();
		Mockito.when(passengerResponseMapper.getPassengerAmadeusResponse(Mockito.any())).thenReturn(passenger);
		passenger = passengerRepositoryImpl.getPassenger(BOOKING_ID, PASSENGER_ID2, getSession());
		assertEquals(PASSENGER_ID2, passenger.getIdentifier());
		assertEquals(STANDBY,passenger.getItinerary().getItineraryItems().iterator().next().getPassengerStatus().name());
	}
	
	@Test
	public void getPassengerStatusAsCheckedin() {
		Passenger passenger = createPassengerForCheckedinStatus();
		Mockito.when(passengerResponseMapper.getPassengerAmadeusResponse(Mockito.any())).thenReturn(passenger);
		passenger = passengerRepositoryImpl.getPassenger(BOOKING_ID, PASSENGER_ID2, getSession());
		assertEquals(PASSENGER_ID2, passenger.getIdentifier());
		assertEquals(CHECKEDIN, passenger.getItinerary().getItineraryItems().iterator().next().getPassengerStatus().name());
	}

	@Test
	public void getPassengerStatusAsNotCheckedin() {
		Passenger passenger = createPassengerForNotCheckedinStatus();
		Mockito.when(passengerResponseMapper.getPassengerAmadeusResponse(Mockito.any())).thenReturn(passenger);
		passenger = passengerRepositoryImpl.getPassenger(BOOKING_ID, PASSENGER_ID2, getSession());
		assertNotNull(passenger);
		assertEquals(PASSENGER_ID2, passenger.getIdentifier());
		assertEquals(NOTCHECKEDIN,passenger.getItinerary().getItineraryItems().iterator().next().getPassengerStatus().name());
	}
	
	@Test
	public void getPassengerWithFlightStatusAsConfirmed() {
		Passenger passenger = createPassengerWithConfirmedBookingStatus();
		Mockito.when(passengerResponseMapper.getPassengerAmadeusResponse(Mockito.any())).thenReturn(passenger);
		passenger = passengerRepositoryImpl.getPassenger(BOOKING_ID, PASSENGER_ID2, getSession());
		assertEquals(PASSENGER_ID2, passenger.getIdentifier());
		assertEquals(CONFIRMED, passenger.getItinerary().getItineraryItems().iterator().next().getStatus().name());
	}
	
	@Test
	public void getPassengerWithFlightStatusAsNotConfirmed() {
		Passenger passenger = createPassengerWithNotConfirmedBookingStatus();
		Mockito.when(passengerResponseMapper.getPassengerAmadeusResponse(Mockito.any())).thenReturn(passenger);
		passenger = passengerRepositoryImpl.getPassenger(BOOKING_ID, PASSENGER_ID2, getSession());
		assertEquals(PASSENGER_ID2, passenger.getIdentifier());
		assertEquals(UNCONFIRMED, passenger.getItinerary().getItineraryItems().iterator().next().getStatus().name());
	}
	
	@Test
	public void getPassengerWithRegisteredIdentifierWithPassport() {
		Passenger passenger = createPassengerDomain();
		Mockito.when(passengerResponseMapper.getPassengerAmadeusResponse(Mockito.any())).thenReturn(passenger);
		passenger = passengerRepositoryImpl.getPassenger(BOOKING_ID, PASSENGER_ID, getSession());
		assertEquals(PASSENGER_ID, passenger.getIdentifier());
		List<RegisteredIdentifier<?>> registeredIdentifiers = passenger.getPerson().getRegisteredIdentifiers();
		assertTrue(registeredIdentifiers.size() > 0);		
		assertEquals(PASSPORT, registeredIdentifiers.get(0).getType().name());
		
	}

	
	private Passenger<String> createPassengerDomain() {
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.ADULT,
				populatePerson(), populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		passenger = passengerBuilder.build();
		passenger.setIdentifier(PASSENGER_ID);
		return passenger;

	}
	
	private Passenger<String> createPassengerDomainAsChild() {
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.CHILD,
				populatePerson(), populateItineraryItemList());
		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		passenger = passengerBuilder.build();
		passenger.setIdentifier(PASSENGER_ID);
		return passenger;

	}

	private Passenger<String> createPassengerWithAssociatedDomain() {
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.INFANT,
				populatePerson(), populateItineraryItemList());

		AssociatedPassenger<String> associatedPassenger = new AssociatedPassenger<>();
		associatedPassenger.setIdentifier(PASSENGER_ID);
		passengerBuilder.setAssociatedPassenger(associatedPassenger);

		passengerBuilder.setEmergencyContact(populateEmergencyContactDomain());
		passenger = passengerBuilder.build();
		passenger.setIdentifier(PASSENGER_ID2);
		return passenger;
	}

	private EmergencyContact<String> populateEmergencyContactDomain() {
		EmergencyContact.EmergencyContactBuilder<String> emergencyBuilder = new EmergencyContactBuilder<String>(
				Boolean.FALSE);

		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder(JANE, NORMAN);
		PersonName PersonName = personNameBuilder.build();

		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		TelecomAddress telecomAddress = new TelecomAddress(TELECOM_NUMBER);
		List<TelecomAddress> telecomAddresses = new ArrayList<>();
		telecomAddresses.add(telecomAddress);
		personBuilder.setTelecomAddresses(telecomAddresses);

		Person<String> person = personBuilder.build();
		emergencyBuilder.setPerson(person);

		return emergencyBuilder.build();
	}

	private Person<String> populatePerson() {
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder("THOMAS", "NORMAN");
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();

		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		personBuilder.setGender(Gender.MALE);

		Nationality nationality = new Nationality();
		nationality.setType("C");
		nationality.setIdentifier("GB");
		personBuilder.setNationality(nationality);
		List<RegisteredIdentifier<?>> registeredIdentifierList = new ArrayList<>();
		Location<String> location = new Location<>();
		location.setLocationIdentifier("GB");
		location.setType(LocationType.COUNTRY);
		String dateTimeDetails = "12012018";
		RegisteredIdentifier<?> registeredIdentifier = new RegisteredIdentifier<>("dummyToken", null,
				RegisteredIdentifierType.PASSPORT, location, LocalDate.parse(dateTimeDetails), null);
		registeredIdentifierList.add(registeredIdentifier);
		personBuilder.setRegisteredIdentifier(registeredIdentifierList);
		Person<String> person = personBuilder.build();
		return person;
	}

	private Itinerary populateItineraryItemList() {
		ItineraryItem itineraryItem = new ItineraryItem();

		itineraryItem.setIdentifier("2301CB2D000236BD");
		List<Carrier> carriers = new ArrayList<>();
		Carrier operatingCarrier = new Carrier();
		operatingCarrier.setCode("OP");
		operatingCarrier.setType(CarrierType.OPERATING);
		operatingCarrier.setFlightNumber("280");
		operatingCarrier.setOperationalSuffix("OPS");
		Carrier marketingCarrier = new Carrier();
		marketingCarrier.setCode("BA");

		marketingCarrier.setType(CarrierType.MARKETING);
		marketingCarrier.setFlightNumber("111");
		marketingCarrier.setOperationalSuffix("OP");

		carriers.add(operatingCarrier);
		carriers.add(marketingCarrier);

		Origin origin = new Origin();
		origin.setIdentifier(LHR);
		origin.setTerminal("T4");
		Gate gate = new Gate();
		gate.setNumber("GATE2");
		origin.setGate(gate);

		Destination destination = new Destination();
		destination.setIdentifier("D001");
		destination.setTerminal("T2");
		destination.setGate(gate);
		itineraryItem.setCarriers(carriers);
		itineraryItem.setOrigin(origin);
		itineraryItem.setDestination(destination);
		LocalDateTime scheduledDepartureLocalDatetime = new LocalDateTime(2018, 12, 15, 13, 45, 50);
		LocalDateTime scheduledArrivalLocalDatetime = new LocalDateTime(2018, 12, 12, 13, 45, 40);
		itineraryItem.setScheduledDepartureLocalDatetime(scheduledDepartureLocalDatetime);
		itineraryItem.setScheduledArrivalLocalDatetime(scheduledArrivalLocalDatetime);
		itineraryItem.setBookingClass("ECONOMY");
		itineraryItem.setCabinCode(UPPER);
		itineraryItem.setPassengerStatus(PassengerStatus.CHECKEDIN);
		itineraryItem.setStatus(ItineraryItemStatus.CONFIRMED);
		Seat seat = new Seat();
		seat.setNumber("27A");
		itineraryItem.setSeat(seat);

		List<ItineraryItem> itineraryItems = new ArrayList<>();
		itineraryItems.add(itineraryItem);

		Itinerary itinerary = new Itinerary();
		Eticket eticket = new Eticket();
		eticket.setIdentifier("1258774395209");
		itinerary.setEticket(eticket);
		itinerary.setItineraryItems(itineraryItems);
		return itinerary;
	}

	private Passenger createPassengerForNotCheckedinStatus() {
		String firstName = "JAMES";		
		String familyName = "NORMAN";
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder(firstName, familyName);
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();
		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		Person<String> person = personBuilder.build();
		AssociatedPassenger<String> associatedPassenger = new AssociatedPassenger<>();
		associatedPassenger.setIdentifier(PASSENGER_ID);
		List<ItineraryItem> itineraryItems = new ArrayList<ItineraryItem>();
		ItineraryItem itineraryItem = new ItineraryItem();
		itineraryItem.setBookingClass("V");
		itineraryItem.setCabinCode("M");
		itineraryItem.setPassengerStatus(PassengerStatus.NOTCHECKEDIN);
		itineraryItems.add(itineraryItem);
		Itinerary itinerary = new Itinerary();
		itinerary.setItineraryItems(itineraryItems);
		// PersonBuilder instance
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.INFANT, person,
				itinerary);
		passengerBuilder.setAssociatedPassenger(associatedPassenger);
		Passenger passenger = passengerBuilder.build();
		passenger.setIdentifier(PASSENGER_ID2);
		return passenger;
	}

	private Passenger createPassengerForCheckedinStatus() {
		String firstName = "JAMES";		
		String familyName = "NORMAN";
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder(firstName, familyName);
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();
		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		Person<String> person = personBuilder.build();
		AssociatedPassenger<String> associatedPassenger = new AssociatedPassenger<>();
		associatedPassenger.setIdentifier(PASSENGER_ID);
		List<ItineraryItem> itineraryItems = new ArrayList<ItineraryItem>();
		ItineraryItem itineraryItem = new ItineraryItem();
		itineraryItem.setBookingClass("S");
		itineraryItem.setCabinCode("C001");
		itineraryItem.setPassengerStatus(PassengerStatus.CHECKEDIN);
		itineraryItems.add(itineraryItem);
		Itinerary itinerary = new Itinerary();
		itinerary.setItineraryItems(itineraryItems);
		// PersonBuilder instance
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.INFANT, person,
				itinerary);
		passengerBuilder.setAssociatedPassenger(associatedPassenger);
		Passenger passenger = passengerBuilder.build();
		passenger.setIdentifier(PASSENGER_ID2);
		return passenger;

	}

	private Passenger createPassengerForSTANDBYStatus() {		
		String firstName = "JAMES";		
		String familyName = "NORMAN";
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder(firstName, familyName);
		personNameBuilder.setTitle("MR");
		personNameBuilder.setMiddleName("");
		personNameBuilder.setSecondFamilyName("");
		PersonName PersonName = personNameBuilder.build();
		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		Person<String> person = personBuilder.build();
		AssociatedPassenger<String> associatedPassenger = new AssociatedPassenger<>();
		associatedPassenger.setIdentifier(PASSENGER_ID);
		List<ItineraryItem> itineraryItems = new ArrayList<ItineraryItem>();
		ItineraryItem itineraryItem = new ItineraryItem();
		itineraryItem.setBookingClass("S");
		itineraryItem.setCabinCode("C001");
		itineraryItem.setPassengerStatus(PassengerStatus.STANDBY);
		itineraryItems.add(itineraryItem);
		Itinerary itinerary = new Itinerary();
		itinerary.setItineraryItems(itineraryItems);
		// PersonBuilder instance
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.INFANT, person,
				itinerary);
		passengerBuilder.setAssociatedPassenger(associatedPassenger);
		Passenger passenger = passengerBuilder.build();
		passenger.setIdentifier(PASSENGER_ID2);
		return passenger;

	}
	
	private Passenger createPassengerWithConfirmedBookingStatus() {
		String firstName = "JAMES";		
		String familyName = "NORMAN";
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder(firstName, familyName);
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();
		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		Person<String> person = personBuilder.build();
		AssociatedPassenger<String> associatedPassenger = new AssociatedPassenger<>();
		associatedPassenger.setIdentifier(PASSENGER_ID);
		List<ItineraryItem> itineraryItems = new ArrayList<ItineraryItem>();
		ItineraryItem itineraryItem = new ItineraryItem();
		itineraryItem.setBookingClass("S");
		itineraryItem.setCabinCode("C001");
		itineraryItem.setPassengerStatus(PassengerStatus.CHECKEDIN);
		itineraryItem.setStatus(ItineraryItemStatus.CONFIRMED);
		itineraryItems.add(itineraryItem);
		Itinerary itinerary = new Itinerary();
		itinerary.setItineraryItems(itineraryItems);
		// PersonBuilder instance
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.INFANT, person,
				itinerary);
		passengerBuilder.setAssociatedPassenger(associatedPassenger);
		Passenger passenger = passengerBuilder.build();
		passenger.setIdentifier(PASSENGER_ID2);
		return passenger;

	}
	
	private Passenger createPassengerWithNotConfirmedBookingStatus() {
		String firstName = "JAMES";		
		String familyName = "NORMAN";
		PersonName.PersonNameBuilder personNameBuilder = new PersonNameBuilder(firstName, familyName);
		personNameBuilder.setTitle("MR");
		PersonName PersonName = personNameBuilder.build();
		Person.PersonBuilder<String> personBuilder = new PersonBuilder<String>(PersonName);
		Person<String> person = personBuilder.build();
		AssociatedPassenger<String> associatedPassenger = new AssociatedPassenger<>();
		associatedPassenger.setIdentifier(PASSENGER_ID);
		List<ItineraryItem> itineraryItems = new ArrayList<ItineraryItem>();
		ItineraryItem itineraryItem = new ItineraryItem();
		itineraryItem.setBookingClass("S");
		itineraryItem.setCabinCode("C001");
		itineraryItem.setPassengerStatus(PassengerStatus.CHECKEDIN);
		itineraryItem.setStatus(ItineraryItemStatus.UNCONFIRMED);
		itineraryItems.add(itineraryItem);
		Itinerary itinerary = new Itinerary();
		itinerary.setItineraryItems(itineraryItems);
		// PersonBuilder instance
		Passenger.PassengerBuilder<String> passengerBuilder = new PassengerBuilder<String>(PassengerType.INFANT, person,
				itinerary);
		passengerBuilder.setAssociatedPassenger(associatedPassenger);
		Passenger passenger = passengerBuilder.build();
		passenger.setIdentifier(PASSENGER_ID2);
		return passenger;
	}
	
	private AmadeusSession getSession() {
		AmadeusSession sessionRequest = new AmadeusSession();
		sessionRequest.setChannel("KISOK");
		sessionRequest.setLocation("GB");
		sessionRequest.setScope("BOOKINGS");
		sessionRequest.setSecurityToken("1S3WS869ESHF43PWZW7EF6H5Y9");
		sessionRequest.setSessionId("010A4WCDNO");
		sessionRequest.setSequenceNumber("1");
		return sessionRequest;
	}

	

}
