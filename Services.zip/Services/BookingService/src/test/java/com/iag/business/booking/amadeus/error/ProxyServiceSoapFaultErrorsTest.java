package com.iag.business.booking.amadeus.error;

import org.junit.Assert;
import org.junit.Test;

public class ProxyServiceSoapFaultErrorsTest {

    @Test
    public void shouldProduceAProperErrorCodeForProperKey() {
        ProxyServiceSoapFaultErrors proxyServiceSoapFaultErrors = ProxyServiceSoapFaultErrors
                .getErrorCode(ProxyServiceSoapFaultErrors.DATA_INVALID.name());
        Assert.assertEquals(proxyServiceSoapFaultErrors, ProxyServiceSoapFaultErrors.DATA_INVALID);
    }

    @Test
    public void shouldNotProduceAnyResultForKeyNotAvailbleInProxyServiceSoapFaultErrors() {
        ProxyServiceSoapFaultErrors proxyServiceSoapFaultErrors = ProxyServiceSoapFaultErrors
                .getErrorCode("versionAvailble");
        Assert.assertNull(proxyServiceSoapFaultErrors);
    }

    @Test
    public void shouldNotProduceAnyResultForBlankKeyNotAvailbleInProxyServiceSoapFaultErrors() {
        ProxyServiceSoapFaultErrors proxyServiceSoapFaultErrors = ProxyServiceSoapFaultErrors.getErrorCode("");
        Assert.assertNull(proxyServiceSoapFaultErrors);
    }

    @Test
    public void shouldNotProduceAnyResultForNullKeyNotAvailbleInProxyServiceSoapFaultErrors() {
        ProxyServiceSoapFaultErrors proxyServiceSoapFaultErrors = ProxyServiceSoapFaultErrors.getErrorCode(null);
        Assert.assertNull(proxyServiceSoapFaultErrors);
    }
}