package com.iag.business.booking.exception;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.proxy.ServiceProxy;


public class DefaultContentProviderTest {

	@InjectMocks
	private DefaultContentProvider defaultContentProvider;

	@Mock
	private ServiceProxy configurationInfrastructureServiceProxy;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		defaultContentProvider = new DefaultContentProvider(configurationInfrastructureServiceProxy);
	}

	@Test
	public void sholdGetContent() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE, "booking.error.REQUEST_INVALID.code"))
				.thenReturn("REQUEST_INVALID");
		Assert.assertEquals("REQUEST_INVALID", defaultContentProvider.getContent("booking.error.REQUEST_INVALID.code"));
	}
}
