package com.iag.application.exception;

import java.math.BigInteger;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class ValidationServiceExceptionFactoryTest {
  
  private ValidationServiceExceptionFactory validationServiceExceptionFactory;
  
  @Mock
  ExceptionProvider exceptionProvider;

  private static final String ERROR_CODE = "REQUEST_INVALID";
  private static final String PARENT_ERROR_CODE_POSTFIX = ".parent.code";
  private static final String ERROR_CODE_POSTFIX = ".code";

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
    validationServiceExceptionFactory = new ValidationServiceExceptionFactory();
  }

  @Test
  public void shouldCreateValidationServiceException() {
    final String childErrorCode = "MANDATORY_DATA_MISSING";
    Mockito.when(exceptionProvider.getCode(ERROR_CODE + PARENT_ERROR_CODE_POSTFIX)).thenReturn(ERROR_CODE);
    Mockito.when(exceptionProvider.getCode(ERROR_CODE + ERROR_CODE_POSTFIX)).thenReturn(childErrorCode);
    
    ValidationServiceException validationServiceException =
        (ValidationServiceException) validationServiceExceptionFactory
            .createServiceException(ERROR_CODE, exceptionProvider);
    
    Assert.assertNotNull(validationServiceException);
    Assert.assertEquals(ERROR_CODE, validationServiceException.getCode());
    Assert.assertEquals(null, validationServiceException.getDeveloperMessage());
    Assert.assertEquals(null, validationServiceException.getOptionalNamespace());
    Assert.assertEquals(null, validationServiceException.getPath());    
    
    List<ValidationServiceException> validationServiceExceptionList =
        (List<ValidationServiceException>) validationServiceException.getValidationExceptions();
    Assert.assertTrue(!validationServiceExceptionList.isEmpty());
    Assert.assertEquals(BigInteger.ONE.intValue() ,validationServiceExceptionList.size());
    ValidationServiceException childValidationServiceException = validationServiceExceptionList.get(BigInteger.ZERO.intValue());
    Assert.assertEquals(childErrorCode, childValidationServiceException.getCode());
    Assert.assertEquals(null, childValidationServiceException.getDeveloperMessage());
    Assert.assertEquals(null, childValidationServiceException.getOptionalNamespace());
    Assert.assertEquals(null, childValidationServiceException.getPath());
  }
}
