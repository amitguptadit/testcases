package com.iag.business.booking.repository.impl.mapper.request;

import javax.xml.transform.dom.DOMResult;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.iag.domain.model.session.Session;

public class AmedeusRequestHeaderMapperTest {
	AmedeusRequestHeaderMapper amedeusRequestHeaderMapper;
	@Mock
	Element element;
	@Mock
	Document document;

	private static final String tokenNumber = "3MD2XG84Y84O1NVHD7L0CCZWV";
	private static final String sessionIdentifier = "011MH5M2PH";
	private static final String sequenceNumber = "1";
	
	@Before
	public void setUp() {
		document = Mockito.mock(Document.class);
		element = Mockito.mock(Element.class);
		amedeusRequestHeaderMapper = new AmedeusRequestHeaderMapper();
	}

	@Test
	public void shouldAddSessionDetailsToSoapHeaderforAllValue() {
		SoapMessage message = Mockito.mock(SoapMessage.class);
		SoapHeader soapHeader = Mockito.mock(SoapHeader.class);
		Mockito.when(message.getSoapHeader()).thenReturn(soapHeader);
		DOMResult xmlHeader = Mockito.mock(DOMResult.class);
		Mockito.when(soapHeader.getResult()).thenReturn(xmlHeader);
		Node headerNode = Mockito.mock(Node.class);
		Mockito.when(xmlHeader.getNode()).thenReturn(headerNode);
		Mockito.when(headerNode.getOwnerDocument()).thenReturn(document);
		Mockito.when(document.createElementNS(Mockito.anyString(), Mockito.anyString())).thenReturn(element);
		amedeusRequestHeaderMapper.mapHeaders(message, "soapAction", getSessionRequest());
	}

	@Test
	public void shouldReturnNotWhenSessionIdentifierValueIsNuLL() {
		SoapMessage message = Mockito.mock(SoapMessage.class);
		SoapHeader soapHeader = Mockito.mock(SoapHeader.class);
		Mockito.when(message.getSoapHeader()).thenReturn(soapHeader);
		DOMResult xmlHeader = Mockito.mock(DOMResult.class);
		Mockito.when(soapHeader.getResult()).thenReturn(xmlHeader);
		Node headerNode = Mockito.mock(Node.class);
		Mockito.when(xmlHeader.getNode()).thenReturn(headerNode);
		Mockito.when(headerNode.getOwnerDocument()).thenReturn(document);
		Mockito.when(document.createElementNS(Mockito.anyString(), Mockito.anyString())).thenReturn(element);

		amedeusRequestHeaderMapper.mapHeaders(message, "soapAction", getSessionRequestForEmptyIdentifier());

	}

	@Test
	public void shouldReturnNotWhenTokenValueIsNuLL() {
		SoapMessage message = Mockito.mock(SoapMessage.class);
		SoapHeader soapHeader = Mockito.mock(SoapHeader.class);
		Mockito.when(message.getSoapHeader()).thenReturn(soapHeader);
		DOMResult xmlHeader = Mockito.mock(DOMResult.class);
		Mockito.when(soapHeader.getResult()).thenReturn(xmlHeader);
		Node headerNode = Mockito.mock(Node.class);
		Mockito.when(xmlHeader.getNode()).thenReturn(headerNode);
		Mockito.when(headerNode.getOwnerDocument()).thenReturn(document);
		Mockito.when(document.createElementNS(Mockito.anyString(), Mockito.anyString())).thenReturn(element);

		amedeusRequestHeaderMapper.mapHeaders(message, "soapAction", getSessionRequestForEmptyToken());

	}

	public Session getSessionRequest() {
		Session sessionRequest = new Session();
		sessionRequest.setChannel("KISOK");
		sessionRequest.setLocation("GB");
		sessionRequest.setScope("BOOKINGS");
		sessionRequest.setTokenNumber(tokenNumber);
		sessionRequest.setSessionIdentifier(sessionIdentifier);
		sessionRequest.setSequenceNumber(sequenceNumber);
		return sessionRequest;
	}

	public Session getSessionRequestForEmptyIdentifier() {
		Session sessionRequest = new Session();
		sessionRequest.setChannel("KISOK");
		sessionRequest.setLocation("GB");
		sessionRequest.setScope("BOOKINGS");
		sessionRequest.setTokenNumber(tokenNumber);
		sessionRequest.setSessionIdentifier("");
		sessionRequest.setSequenceNumber(sequenceNumber);
		return sessionRequest;
	}

	public Session getSessionRequestForEmptyToken() {
		Session sessionRequest = new Session();
		sessionRequest.setChannel("KISOK");
		sessionRequest.setLocation("GB");
		sessionRequest.setScope("BOOKINGS");
		sessionRequest.setTokenNumber(tokenNumber);
		sessionRequest.setSessionIdentifier("");
		sessionRequest.setSequenceNumber(sequenceNumber);
		return sessionRequest;
	}

}
