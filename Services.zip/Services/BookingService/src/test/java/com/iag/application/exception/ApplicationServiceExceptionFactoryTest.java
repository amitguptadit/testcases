package com.iag.application.exception;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class ApplicationServiceExceptionFactoryTest {
  
  private ApplicationServiceExceptionFactory applicationServiceExceptionFactory;
  
  @Mock
  ExceptionProvider exceptionProvider;
  
  private static final String ERROR_CODE = "RESOURCE_NOT_FOUND";  
  private static final String ERROR_CODE_POSTFIX = ".code";  
  
  @Before
  public void setUp(){
    MockitoAnnotations.initMocks(this);
    applicationServiceExceptionFactory = new ApplicationServiceExceptionFactory();
  }
  
  @Test
  public void shouldCreateServiceException() {
    
    Mockito.when(exceptionProvider.getCode(ERROR_CODE + ERROR_CODE_POSTFIX)).thenReturn(ERROR_CODE+ERROR_CODE_POSTFIX);
    
    ApplicationServiceException applicationServiceException = (ApplicationServiceException) applicationServiceExceptionFactory
                    .createServiceException(ERROR_CODE, exceptionProvider);
    Assert.assertNotNull(applicationServiceException);
    Assert.assertEquals(ERROR_CODE+ERROR_CODE_POSTFIX, applicationServiceException.getCode());
    Assert.assertEquals(null, applicationServiceException.getDeveloperMessage());
    Assert.assertEquals(null, applicationServiceException.getOptionalNamespace());
  }
}
