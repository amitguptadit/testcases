package com.iag.application.exception;

import static org.junit.Assert.fail;

import java.math.BigInteger;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.google.common.base.Optional;

public class ExceptionFactoryTest {

  private ExceptionFactory exceptionFactory;
  
  @Mock
  private ExceptionProvider exceptionProvider;
  
  private static final String EXCEPTION_TYPE_FINDER_POSTFIX = ".exception";
  private static final String PARENT_ERROR_CODE_POSTFIX = ".parent.code";
  private static final String ERROR_CODE_POSTFIX = ".code";

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
    exceptionFactory = new ExceptionFactory();
  }

  @Test
  public void shouldThrowExceptionWhenClassNameIsInvalid() {
    final String errorCode = "ServiceException";    
    Mockito.when(exceptionProvider.getExceptionClass(errorCode + EXCEPTION_TYPE_FINDER_POSTFIX)).thenReturn("test");
    try {
      exceptionFactory.createException("ServiceException", exceptionProvider,Optional.<String>absent());
      Assert.fail("Must throw exception");
    } catch (Exception e) {
      Assert.assertTrue(e instanceof ExceptionInstantiationException);
    }
  }

  @Test
  public void shouldThrowExceptionWhenClassNameIsBlank() {
    final String errorCode = "blank";
    Mockito.when(exceptionProvider.getExceptionClass(errorCode + EXCEPTION_TYPE_FINDER_POSTFIX)).thenReturn("");
    try {
      exceptionFactory.createException("blank", exceptionProvider,Optional.<String>absent());
      Assert.fail("Must throw exception");
    } catch (Exception e) {
      Assert.assertTrue(e instanceof ExceptionInstantiationException);
    }
  }

  @Test
  public void shouldThrowExceptionWhenClassNameIsNull() {
    final String errorCode = "null";
    Mockito.when(exceptionProvider.getExceptionClass(errorCode + EXCEPTION_TYPE_FINDER_POSTFIX)).thenReturn(null);
    try {
      exceptionFactory.createException("null", exceptionProvider,Optional.<String>absent());
      Assert.fail("Must throw exception");
    } catch (Exception e) {
      Assert.assertTrue(e instanceof ExceptionInstantiationException);
    }

  }

  @Test
  public void shouldInstantiateValidationServiceExceptionWhenNamespaceIsAbsent() {
    final String errorCode = "REQUEST_INVALID";
    final String childErrorCode = "MANDATORY_DATA_MISSING";
    ServiceException serviceException = null;
    Mockito.when(exceptionProvider.getExceptionClass(errorCode + EXCEPTION_TYPE_FINDER_POSTFIX)).thenReturn(
        "com.iag.application.exception.ValidationServiceException");
    Mockito.when(exceptionProvider.getCode(errorCode + PARENT_ERROR_CODE_POSTFIX)).thenReturn(errorCode);
    Mockito.when(exceptionProvider.getCode(errorCode + ERROR_CODE_POSTFIX)).thenReturn(childErrorCode);
    try {
      serviceException = exceptionFactory.createException(errorCode, exceptionProvider, Optional.<String>absent());
    } catch (Exception e) {
      e.printStackTrace();
      fail();
    }
    Assert.assertNotNull(serviceException);
    Assert.assertEquals("com.iag.application.exception.ValidationServiceException", serviceException.getClass().getName());
    ValidationServiceException validationServiceException = (ValidationServiceException) serviceException;
    Assert.assertEquals(errorCode, validationServiceException.getCode());
    Assert.assertEquals(null, validationServiceException.getDeveloperMessage());
    Assert.assertEquals(null, validationServiceException.getOptionalNamespace());
    Assert.assertEquals(null, validationServiceException.getPath());    
    
    List<ValidationServiceException> validationServiceExceptionList =
        (List<ValidationServiceException>) validationServiceException.getValidationExceptions();
    Assert.assertTrue(!validationServiceExceptionList.isEmpty());
    Assert.assertEquals(BigInteger.ONE.intValue() ,validationServiceExceptionList.size());
    ValidationServiceException childValidationServiceException = validationServiceExceptionList.get(BigInteger.ZERO.intValue());
    Assert.assertEquals(childErrorCode, childValidationServiceException.getCode());
    Assert.assertEquals(null, childValidationServiceException.getDeveloperMessage());
    Assert.assertEquals(null, childValidationServiceException.getOptionalNamespace());
    Assert.assertEquals(null, childValidationServiceException.getPath());
  }

  @Test
  public void shouldThrowExceptionWhenErrorCodeIsBlank() {
    try {
       exceptionFactory.createException("", exceptionProvider,Optional.<String>absent());
    } catch (Exception e) {
      Assert.assertTrue(e instanceof ExceptionInstantiationException);
    }
  }

  @Test
  public void shouldThrowExceptionWhenErrorCodeIsNull() {
    try {
      exceptionFactory.createException(null, exceptionProvider,Optional.<String>absent());
    } catch (Exception e) {
      Assert.assertTrue(e instanceof ExceptionInstantiationException);
    }
  }
  
  @Test
  public void shouldInstantiateValidationServiceExceptionWhenNamespaceIsPresent() {
    final String errorCode = "REQUEST_INVALID";
    final String childErrorCode = "MANDATORY_DATA_MISSING";
    ServiceException serviceException = null;
    Mockito.when(exceptionProvider.getExceptionClass(errorCode + EXCEPTION_TYPE_FINDER_POSTFIX)).thenReturn(
        "com.iag.application.exception.ValidationServiceException");
    Mockito.when(exceptionProvider.getCode(errorCode + PARENT_ERROR_CODE_POSTFIX)).thenReturn(errorCode);
    Mockito.when(exceptionProvider.getCode(errorCode + ERROR_CODE_POSTFIX)).thenReturn(childErrorCode);
    try {
      serviceException = exceptionFactory.createException(errorCode, exceptionProvider, Optional.of("iag"));
    } catch (Exception e) {
      e.printStackTrace();
      fail();
    }
    Assert.assertNotNull(serviceException);
    Assert.assertEquals("com.iag.application.exception.ValidationServiceException", serviceException.getClass().getName());
    ValidationServiceException validationServiceException = (ValidationServiceException) serviceException;
    Assert.assertEquals(errorCode, validationServiceException.getCode());
    Assert.assertEquals(null, validationServiceException.getDeveloperMessage());
    Assert.assertEquals("iag", validationServiceException.getOptionalNamespace());
    Assert.assertEquals(null, validationServiceException.getPath());    
    
    List<ValidationServiceException> validationServiceExceptionList =
        (List<ValidationServiceException>) validationServiceException.getValidationExceptions();
    Assert.assertTrue(!validationServiceExceptionList.isEmpty());
    Assert.assertEquals(BigInteger.ONE.intValue() ,validationServiceExceptionList.size());
    ValidationServiceException childValidationServiceException = validationServiceExceptionList.get(BigInteger.ZERO.intValue());
    Assert.assertEquals(childErrorCode, childValidationServiceException.getCode());
    Assert.assertEquals(null, childValidationServiceException.getDeveloperMessage());
    Assert.assertEquals(null, childValidationServiceException.getOptionalNamespace());
    Assert.assertEquals(null, childValidationServiceException.getPath());
  }
  
  @Test
  public void shouldInstantiateApplicationServiceExceptionWhenNamespaceIsPresent() {
    final String errorCode = "REQUEST_INVALID";    
    ServiceException serviceException = null;
    Mockito.when(exceptionProvider.getExceptionClass(errorCode + EXCEPTION_TYPE_FINDER_POSTFIX)).thenReturn(
        "com.iag.application.exception.ApplicationServiceException");    
    Mockito.when(exceptionProvider.getCode(errorCode + ERROR_CODE_POSTFIX)).thenReturn(errorCode);
    try {
      serviceException = exceptionFactory.createException(errorCode, exceptionProvider, Optional.of("iag"));
    } catch (Exception e) {
      e.printStackTrace();
      fail();
    }
    Assert.assertNotNull(serviceException);
    Assert.assertEquals("com.iag.application.exception.ApplicationServiceException", serviceException.getClass().getName());
    ApplicationServiceException applicationServiceException = (ApplicationServiceException) serviceException;
    Assert.assertEquals(errorCode, applicationServiceException.getCode());
    Assert.assertEquals(null, applicationServiceException.getDeveloperMessage());
    Assert.assertEquals("iag", applicationServiceException.getOptionalNamespace());
  }
  
  @Test
  public void shouldThrowIllegalStateExceptionWhenUnSupportedServiceExceptionIsLocated() {
    
    final class UnSupportedServiceException extends ServiceException {

      /**
       * Parameterised Constructor.
       * @param code
       */
      public UnSupportedServiceException(final String code) {
        super(code);        
      }
    }
    
    final String errorCode = "REQUEST_INVALID";
    ServiceException serviceException = new UnSupportedServiceException(errorCode);
    Mockito.when(exceptionProvider.getExceptionClass(errorCode + EXCEPTION_TYPE_FINDER_POSTFIX)).thenReturn(
        serviceException.getClass().getName());    
    try {
      exceptionFactory.createException(errorCode, exceptionProvider, Optional.of("OptionalNamespace"));
    } catch (Exception e) {
      Assert.assertTrue(e instanceof IllegalStateException);      
    }    
  }
  
  @Test
  public void shouldThrowExceptionWhenExceptionNameIsNotFromServiceExceptionFamily() {
       
    final String errorCode = "REQUEST_INVALID";    
    Mockito.when(exceptionProvider.getExceptionClass(errorCode + EXCEPTION_TYPE_FINDER_POSTFIX)).thenReturn(
        "com.iag.application.exception.ExceptionInstantiationException");    
    try {
      exceptionFactory.createException(errorCode, exceptionProvider, Optional.of("OptionalNamespace"));
    } catch (Exception e) {
      Assert.assertTrue(e instanceof IllegalStateException);      
    }    
  }
}
