package com.iag.business.booking.validation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.application.exception.ValidationServiceException;
import com.iag.business.booking.error.BookingErrorCode;
import com.iag.business.booking.exception.ValidationServiceExceptionGenerator;
import com.iag.business.booking.validation.BookingIdentifierValidation;


public class BookingIdentifierValidationTest {

	private static final String BOOKINGIDENTIFER_PATH = "booking-identifier";

	private static final String DEV_MSG_DATA_INVALID = "Data Invalid";

	@InjectMocks
	private BookingIdentifierValidation bookingIdentifierValidation;

	@Mock
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	ValidationServiceException validationServiceException;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		bookingIdentifierValidation = new BookingIdentifierValidation(validationServiceExceptionGenerator);
	}

	@Test
	public void testBookingIdentifierWithoutAlphanumeric() {
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForDataInvalid());
		validationServiceException = bookingIdentifierValidation.validate("TK@#$$$$");
		assertNotNull(validationServiceException);
		assertEquals(BookingErrorCode.DATA_INVALID.toString(), validationServiceException.getCode());
		assertEquals(BOOKINGIDENTIFER_PATH, validationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, validationServiceException.getDeveloperMessage());
	}


	@Test
	public void testBookingIdentifierAboveLimitCharacter() {
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForDataInvalid());
		validationServiceException = bookingIdentifierValidation.validate("etytirtpirtpiwtpiwpittwtytiw6722725722929");
		assertNotNull(validationServiceException);
		assertEquals(BookingErrorCode.DATA_INVALID.name(), validationServiceException.getCode());
		assertEquals(BOOKINGIDENTIFER_PATH, validationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, validationServiceException.getDeveloperMessage());
	}

	@Test
	public void testBookingIdentifierWithValidCharacter() {
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForDataInvalid());
		validationServiceException = bookingIdentifierValidation.validate("TK001213");
		assertNull(validationServiceException);
	}

	private ValidationServiceException createValidationServiceExceptionForDataInvalid() {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				BookingErrorCode.DATA_INVALID.name());
		validationServiceException.setDeveloperMessage(DEV_MSG_DATA_INVALID);
		validationServiceException.setPath(BOOKINGIDENTIFER_PATH);
		return validationServiceException;
	}
}
