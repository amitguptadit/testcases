package com.iag.business.booking.proxy;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.iag.application.exception.ApplicationServiceException;
import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.error.matcher.CustomApplicationServiceExceptionMatcher;
import com.iag.business.booking.proxy.model.Configuration;
import com.iag.business.booking.proxy.model.ConfigurationItems;
import com.iag.business.booking.proxy.model.ConfigurationNamespace;
import com.iag.business.booking.proxy.model.ConfigurationNamespaces;
import com.iag.business.booking.urlgenerator.ServiceUrlGenerator;

public class ConfigurationInfrastructureServiceProxyTest {

	private static final String SERVICE_ID = "configuration";

	

	@Mock
	RestTemplate restTemplate;

	@Mock
	Map<String, String> serviceErrorMap;

	@Mock
	ServiceUrlGenerator serviceUrlGenerator;
	
	@Mock
	DiscoveryClient mockDiscoveryClient;
	
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	
	@InjectMocks
	ConfigurationInfrastructureServiceProxy configurationInfrastructureServiceProxy;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(configurationInfrastructureServiceProxy, "serviceUrlGenerator", serviceUrlGenerator);
		configurationInfrastructureServiceProxy = new ConfigurationInfrastructureServiceProxy("servicelUrl", "configuration", "BookingService", "BookingServiceV1" ,restTemplate, serviceUrlGenerator);
	}
	
	@Test
	public void shouldRetrieveConfigurationItemForSuccessResponse() {
		Configuration config = createConfiguration();
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(config, HttpStatus.OK);
		Mockito.when(serviceUrlGenerator.generateUrl(SERVICE_ID)).thenReturn("http://www.url.com");
		Mockito.when(restTemplate.exchange("http://www.url.comservicelUrl?resource=BookingService&identifier=BookingServiceV1", HttpMethod.GET, null, Configuration.class))
				.thenReturn(configurationResponse);
		configurationInfrastructureServiceProxy.init();
		assertEquals("REQUEST_INVALID",
				configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE, "booking.error.REQUEST_INVALID.code"));
		assertEquals("DATA_INVALID", configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE, "booking.error.DATA_INVALID.code"));
	}

	@Test
	public void shouldRetrieveConfigurationNamespaceBlank() {
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(getBlankNamespaceConfig(), HttpStatus.OK);
		Mockito.when(serviceUrlGenerator.generateUrl(SERVICE_ID)).thenReturn("http://www.url.com");
		Mockito.when(restTemplate.exchange("http://www.url.comservicelUrl?resource=BookingService&identifier=BookingServiceV1", HttpMethod.GET, null, Configuration.class)).thenReturn(configurationResponse);;
		configurationInfrastructureServiceProxy.init();
		assertEquals(null,
				configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE, "booking.error.REQUEST_INVALID.code"));
		assertEquals(null, configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE, "booking.error.DATA_INVALID.code"));
	}
	
	/*@Test
	public void shouldRetrieveConfigurationItemsBlank() {
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(getBlankConfigurationItemsConfig(), HttpStatus.OK);
		Mockito.when(serviceUrlGenerator.generateUrl(SERVICE_ID)).thenReturn("http://www.url.com");
		Mockito.when(restTemplate.exchange("http://www.url.comservicelUrl?resource=BookingService&identifier=BookingServiceV1", HttpMethod.GET, null, Configuration.class)).thenReturn(configurationResponse);;
		configurationInfrastructureServiceProxy.init();
		assertEquals(null,
				configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE, "booking.error.REQUEST_INVALID.code"));
		assertEquals(null, configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE, "booking.error.DATA_INVALID.code"));
	}*/

	
	@Test
	public void shouldThrowSystemUnavailableExceptionWhenNoConFiguratinFound() {
		Configuration config = createConfiguration();
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(config,
				HttpStatus.NOT_FOUND);
		Mockito.when(restTemplate.exchange("servicelUrl", HttpMethod.GET, null, Configuration.class))
				.thenReturn(configurationResponse);
		thrown.expect(ApplicationServiceException.class);
		thrown.expect(CustomApplicationServiceExceptionMatcher
				.hasException(new ApplicationServiceException("SYSTEM_UNAVAILABLE")));
		configurationInfrastructureServiceProxy.init();
		
 	}

	@Test
	public void shouldThrowApplicationServiceExceptionForUrlIsNull() {
		Configuration config = createConfiguration();
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(config, HttpStatus.OK);
		Mockito.when(restTemplate.exchange(null, HttpMethod.GET, null, Configuration.class))
				.thenReturn(configurationResponse);
		thrown.expect(ApplicationServiceException.class);
		thrown.expect(CustomApplicationServiceExceptionMatcher
				.hasException(new ApplicationServiceException("SYSTEM_UNAVAILABLE")));
		configurationInfrastructureServiceProxy.init();
	}
	
	@Test
	public void checkConfigurationstatusNotOK() {
		Configuration localConfig = createConfiguration();
		Mockito.when(serviceUrlGenerator.generateUrl(SERVICE_ID)).thenReturn("http://www.url.com");
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(localConfig, HttpStatus.BAD_REQUEST);
		Mockito.when(restTemplate.exchange("http://www.url.comservicelUrl?resource=BookingService&identifier=BookingServiceV1", HttpMethod.GET, null, Configuration.class)).thenReturn(configurationResponse);
		thrown.expect(ApplicationServiceException.class);
		thrown.expect(CustomApplicationServiceExceptionMatcher.hasException(new ApplicationServiceException("SYSTEM_UNAVAILABLE")));
		configurationInfrastructureServiceProxy.init();
	}
	
	private Configuration getBlankConfigurationItemsConfig() {
		Configuration config = new Configuration();
		List<ConfigurationNamespace> nameSpace = new ArrayList<>();
		config.setResource("KIO002");
		config.setVersion("V1");
		config.setIdentifier("Driver");
		List<ConfigurationItems> configurationList = new ArrayList<>();
		ConfigurationItems configurationItems = new ConfigurationItems();
		configurationList.add(configurationItems);
		ConfigurationNamespace configurationNamespaces = new ConfigurationNamespace(BookingServiceConstants.ERROR_NAMESPACE, configurationList);
		configurationNamespaces.setName(BookingServiceConstants.ERROR_NAMESPACE);
		nameSpace.add(configurationNamespaces);
		config.setConfigurationNamespaces(nameSpace);
		return config;
	}

	private Configuration getBlankNamespaceConfig() {
		Configuration config = new Configuration();
		List<ConfigurationNamespace> nameSpace = new ArrayList<>();
		List<ConfigurationItems> configurationList = new ArrayList<>();
		ConfigurationNamespace configurationNamespaces = new ConfigurationNamespace(BookingServiceConstants.ERROR_NAMESPACE, configurationList);
		configurationNamespaces.setName(BookingServiceConstants.ERROR_NAMESPACE);
		nameSpace.add(configurationNamespaces);
		
		config.setConfigurationNamespaces(nameSpace);
		return config;
	}

	@Test
	public void shouldThrowRestExceptionForUrlIsNull() {
		Mockito.when(restTemplate.exchange("servicelUrl", HttpMethod.GET, null, Configuration.class)).thenThrow(RestClientException.class);
		thrown.expect(ApplicationServiceException.class);
		thrown.expect(CustomApplicationServiceExceptionMatcher
				.hasException(new ApplicationServiceException("SYSTEM_UNAVAILABLE")));
		configurationInfrastructureServiceProxy.init();
	}
	
	
	private Configuration createConfiguration() {
		Configuration config = new Configuration();
		List<ConfigurationNamespace> nameSpace = new ArrayList<>();
		config.setResource("KIO002");
		config.setVersion("V1");
		config.setIdentifier("Driver");
		List<ConfigurationItems> configurationList = new ArrayList<>();
		ConfigurationItems configurationItems = new ConfigurationItems();
		configurationItems.setIdentifier("booking.error.REQUEST_INVALID.code");
		configurationItems.setValue("REQUEST_INVALID");
		configurationList.add(configurationItems);
		ConfigurationItems configurationItem2 = new ConfigurationItems();
		configurationItem2.setIdentifier("booking.error.DATA_INVALID.code");
		configurationItem2.setValue("DATA_INVALID");
		configurationList.add(configurationItem2);
		ConfigurationNamespace configurationNamespaces = new ConfigurationNamespace(BookingServiceConstants.ERROR_NAMESPACE, configurationList);
		configurationNamespaces.setName(BookingServiceConstants.ERROR_NAMESPACE);
		//configurationNamespaces.setConfigurationItems(configurationList);
		nameSpace.add(configurationNamespaces);
		config.setConfigurationNamespaces(nameSpace);
		return config;

	}

}
