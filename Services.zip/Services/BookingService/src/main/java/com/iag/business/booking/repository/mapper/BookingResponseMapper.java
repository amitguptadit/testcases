package com.iag.business.booking.repository.mapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amadeus.xml.ccprrr_17_1_1a.CodedAttributeInformationType208434C;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel;
import com.amadeus.xml.ccprrr_17_1_1a.DCSIDCCPRIdentificationReply.CustomerLevel.ProductLevel.LegLevel;
import com.amadeus.xml.ccprrr_17_1_1a.StatusDetailsTypeI;
import com.amadeus.xml.ccprrr_17_1_1a.StructuredDateTimeInformationType;
import com.amadeus.xml.ccprrr_17_1_1a.TerminalLocationType116626S;
import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.proxy.ConfigurationInfrastructureServiceProxy;
import com.iag.domain.model.Carrier;
import com.iag.domain.model.CarrierType;
import com.iag.domain.model.Destination;
import com.iag.domain.model.Gate;
import com.iag.domain.model.Origin;
import com.iag.domain.model.booking.Booking;
import com.iag.domain.model.flight.AcceptanceAndBoardingStatus;
import com.iag.domain.model.flight.BookingStatus;
import com.iag.domain.model.flight.FlightLeg;
import com.iag.domain.model.flight.FlightSegment;
import com.iag.domain.model.flight.FlightSegmentStatuses;
import com.iag.domain.model.flight.FlightSegmentType;

@Component
public class BookingResponseMapper {
	public static final Logger logger = LoggerFactory.getLogger(BookingResponseMapper.class);

	@Autowired
	private ConfigurationInfrastructureServiceProxy serviceProxy;

	/**
	 * This method is used to map Service Response From Amadues Response
	 * 
	 * @param amadeusReply
	 * @return
	 */
	public List<Booking> maps(DCSIDCCPRIdentificationReply amadeusReply) {

		logger.info("Method start: map()");
		logger.debug("Method start: map()" + amadeusReply);
		List<Booking> bookings = new ArrayList<Booking>();
		Booking booking = null;
		List<String> flightSegmentUniqueList = null;
		List<FlightSegment> flightSegmentsList = null;
		Map<String, List<FlightSegment>> bookingsFlightSegmentLists = new HashMap<String, List<FlightSegment>>();
		Map<String, List<String>> bookingsFlightSegmentListFromToList = new HashMap<String, List<String>>();
		String identifier = null;
		if (amadeusReply.getCustomerLevel().size() > 0) {
			for (CustomerLevel customerLevel : amadeusReply.getCustomerLevel()) {
				FlightSegment flightSegment = null;
				List<Carrier> carrierList = new ArrayList<Carrier>();
				if (customerLevel.getRecordLocator() != null
						&& customerLevel.getRecordLocator().getReservation() != null && StringUtils
								.isNotEmpty(customerLevel.getRecordLocator().getReservation().getControlNumber())) {
					identifier = customerLevel.getRecordLocator().getReservation().getControlNumber();
				}
				if (bookingsFlightSegmentLists.containsKey(identifier)) {
					flightSegmentsList = bookingsFlightSegmentLists.get(identifier);
					flightSegmentUniqueList = bookingsFlightSegmentListFromToList.get(identifier);
				} else {
					flightSegmentUniqueList = new ArrayList<String>();
					flightSegmentsList = new ArrayList<>();
					bookingsFlightSegmentLists.put(identifier, flightSegmentsList);
					bookingsFlightSegmentListFromToList.put(identifier, flightSegmentUniqueList);
				}
				if (customerLevel.getProductLevel().size() > 0) {

					populateFlightSegmentList(flightSegmentUniqueList, customerLevel, flightSegment, carrierList,
							flightSegmentsList);
				}

			}
		}
		Iterator iterator = bookingsFlightSegmentLists.keySet().iterator();
		String bookingIdentifier = null;
		while (iterator.hasNext()) {
			bookingIdentifier = (String) iterator.next();
			List<FlightSegment> bookingFlightSegments = bookingsFlightSegmentLists.get(bookingIdentifier);
			booking = new Booking.BookingBuilder(bookingIdentifier, bookingFlightSegments).build();
			bookings.add(booking);
		}

		logger.info("Method end: map()");
		logger.debug("Method end: map()" + bookings);
		return bookings;
	}

	/**
	 * This method is used to map Service Response From Amadues Response
	 * 
	 * @param amadeusReply
	 * @return
	 */
	public Booking map(DCSIDCCPRIdentificationReply amadeusReply) {
		logger.info("Method start: map()");
		logger.debug("Method start: map()" + amadeusReply);
		Booking booking = null;
		List<String> flightSegmentUniqueList;
		List<FlightSegment> flightSegmentsList = new ArrayList<>();
		String identifier = null;
		if (amadeusReply.getCustomerLevel().size() > 0) {
			flightSegmentUniqueList = new ArrayList<String>();
			for (CustomerLevel customerLevel : amadeusReply.getCustomerLevel()) {
				FlightSegment flightSegment = null;
				List<Carrier> carrierList = new ArrayList<Carrier>();
				if (customerLevel.getRecordLocator() != null
						&& customerLevel.getRecordLocator().getReservation() != null && StringUtils
								.isNotEmpty(customerLevel.getRecordLocator().getReservation().getControlNumber())) {
					identifier = customerLevel.getRecordLocator().getReservation().getControlNumber();
				}
				if (customerLevel.getProductLevel().size() > 0) {

					populateFlightSegmentList(flightSegmentUniqueList, customerLevel, flightSegment, carrierList,
							flightSegmentsList);
				}

			}
		}
		booking = new Booking.BookingBuilder(identifier, flightSegmentsList).build();
		logger.info("Method end: map()");
		logger.debug("Method end: map()" + booking);
		return booking;
	}

	/**
	 * @param flightSegmentUniqueList
	 * @param customerLevel
	 * @param flightSegment
	 * @param filghtLeglist
	 * @param carrierList
	 * @param flightSegmentsList
	 * @return
	 */
	private void populateFlightSegmentList(List<String> flightSegmentUniqueList, CustomerLevel customerLevel,
			FlightSegment flightSegment, List<Carrier> carrierList, List<FlightSegment> flightSegmentsList) {
		for (ProductLevel productLevel : customerLevel.getProductLevel()) {
			List<FlightLeg> filghtLeglist = new ArrayList<FlightLeg>();
			FlightSegmentType flightSegmentType = populateFlightSegmentType(flightSegment, productLevel);
			FlightSegmentStatuses flightSegmentStatus = populateFlightSegmentStatus(flightSegment, productLevel);
			Origin flightSegmentOriginValues = populatingFlightSegmentOriginValues(flightSegment, productLevel);
			Destination flightSegmentDestinationValues = populatingFlightSegmentDestinationValues(flightSegment,
					productLevel);
			populatingFlightLegDetails(flightSegment, productLevel, filghtLeglist);
			org.joda.time.LocalDateTime flightSegmentScheduledDepartuerDateTime = populatingFlightSegmentScheduledDepartuerDateTime(
					filghtLeglist, flightSegmentOriginValues);
			// populatingFlightSegmentScheduledDepartuerDateTime(
			// flightSegment, productLevel);
			org.joda.time.LocalDateTime flightSegmentScheduledArrivalDateTime = populatingFlightSegmentScheduledArrivalDateTime(
					filghtLeglist, flightSegmentDestinationValues);
			// populatingFlightSegmentScheduledArrivalDateTime(
			// flightSegment, productLevel);
			Carrier flightSegmentCarrierValues = populatingFlightSegmentCarrierValues(flightSegment, productLevel);

			carrierList.add(flightSegmentCarrierValues);
			String Key = flightSegmentOriginValues.getIdentifier() + "-"
					+ flightSegmentDestinationValues.getIdentifier();
			logger.info("\nFlight segments List >> " + flightSegmentUniqueList);
			if (!flightSegmentUniqueList.contains(Key)) {
				flightSegmentUniqueList.add(Key);
				logger.info("\nFlight segments Created >> " + Key);
				flightSegment = new FlightSegment.FlightSegmentBuilder(flightSegmentType, flightSegmentStatus,
						flightSegmentOriginValues, flightSegmentDestinationValues,
						flightSegmentScheduledDepartuerDateTime, flightSegmentScheduledArrivalDateTime, filghtLeglist)
								.setCarriers(carrierList).build();
				flightSegmentsList.add(flightSegment);
			}
		}

	}

	private LocalDateTime populatingFlightSegmentScheduledArrivalDateTime(List<FlightLeg> filghtLeglist,
			Destination flightSegmentDestinationValues) {
		LocalDateTime dateTime = null;

		for (FlightLeg flightLeg : filghtLeglist) {
			if (flightLeg.getDestination().getIdentifier()
					.equalsIgnoreCase(flightSegmentDestinationValues.getIdentifier())) {
				dateTime = flightLeg.getScheduledArrivalLocalDatetime();
				break;
			}
		}
		return dateTime;
	}

	private LocalDateTime populatingFlightSegmentScheduledDepartuerDateTime(List<FlightLeg> filghtLeglist,
			Origin flightSegmentOriginValues) {

		LocalDateTime dateTime = null;

		for (FlightLeg flightLeg : filghtLeglist) {
			if (flightLeg.getOrigin().getIdentifier().equalsIgnoreCase(flightSegmentOriginValues.getIdentifier())) {
				dateTime = flightLeg.getScheduledDepartureLocalDatetime();
				break;
			}
		}

		return dateTime;
	}

	/**
	 * This method is used to map FlightSegment status from Amadeus response
	 * which will be a part of service response
	 * 
	 * @param flightSegment
	 * @param productLevel
	 */
	private FlightSegmentStatuses populateFlightSegmentStatus(FlightSegment flightSegment, ProductLevel productLevel) {
		/*
		 * FlightSegmentStatus segmentStatus = null;
		 * 
		 * if (productLevel.getBookingStatusDetails() != null &&
		 * StringUtils.isNotEmpty(productLevel.getBookingStatusDetails().
		 * getStatusCode())) { String statusCode =
		 * productLevel.getBookingStatusDetails().getStatusCode(); if
		 * (serviceProxy.retrieveConfiguration(BookingServiceConstants.
		 * FLIGHT_SEGMENT_STATUS_CONFIRM) .contains(statusCode)) segmentStatus =
		 * FlightSegmentStatus.CONFIRMED; else segmentStatus =
		 * FlightSegmentStatus.UNCONFIRMED; }
		 */

		FlightSegmentStatuses segmentStatus = new FlightSegmentStatuses();

		String statusCode = productLevel.getBookingStatusDetails().getStatusCode();
		if (serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE, BookingServiceConstants.FLIGHT_SEGMENT_STATUS_CONFIRM)
				.contains(statusCode))
			segmentStatus.setBookingStatus(BookingStatus.CONFIRMED);
		else
			segmentStatus.setBookingStatus(BookingStatus.UNCONFIRMED);

		for (StatusDetailsTypeI statusDetailType : productLevel.getFlightStatuses().getStatusInformation()) {
			if (statusDetailType.getIndicator().equalsIgnoreCase(BookingServiceConstants.ACCEPTANCESTATUS)) {
				if (statusDetailType.getAction().equalsIgnoreCase(BookingServiceConstants.CLOSED)) {
					segmentStatus.setAcceptanceStatus(AcceptanceAndBoardingStatus.CLOSED);
				} else if (statusDetailType.getAction().equalsIgnoreCase(BookingServiceConstants.NOTOPEN)) {
					segmentStatus.setAcceptanceStatus(AcceptanceAndBoardingStatus.NOTOPEN);
				} else if (statusDetailType.getAction().equalsIgnoreCase(BookingServiceConstants.SUSPENDED)) {
					segmentStatus.setAcceptanceStatus(AcceptanceAndBoardingStatus.SUSPENDED);
				} else {
					segmentStatus.setAcceptanceStatus(AcceptanceAndBoardingStatus.OPEN);
				}
			}
			if (statusDetailType.getIndicator().equalsIgnoreCase(BookingServiceConstants.BOARDINGSTATUS)) {
				if (statusDetailType.getAction().equalsIgnoreCase(BookingServiceConstants.CLOSED)) {
					segmentStatus.setAcceptanceStatus(AcceptanceAndBoardingStatus.CLOSED);
				}
				if (statusDetailType.getAction().equalsIgnoreCase(BookingServiceConstants.NOTOPEN)) {
					segmentStatus.setAcceptanceStatus(AcceptanceAndBoardingStatus.NOTOPEN);
				}
				if (statusDetailType.getAction().equalsIgnoreCase(BookingServiceConstants.SUSPENDED)) {
					segmentStatus.setAcceptanceStatus(AcceptanceAndBoardingStatus.SUSPENDED);
				}
				if (statusDetailType.getAction().equalsIgnoreCase(BookingServiceConstants.OPEN)) {
					{
						segmentStatus.setAcceptanceStatus(AcceptanceAndBoardingStatus.OPEN);
					}
				}
			}
		}

		return segmentStatus;
	}

	/**
	 * This method is used to map FlightSegment type from Amadeus response which
	 * will be a part of service response
	 * 
	 * @param flightSegment
	 * @param productLevel
	 */
	private FlightSegmentType populateFlightSegmentType(FlightSegment flightSegment, ProductLevel productLevel) {
		FlightSegmentType segmentType = null;
		if (productLevel.getProductLevelIndicators() != null
				&& productLevel.getProductLevelIndicators().getAttributeDetails().size() > 0) {
			for (CodedAttributeInformationType208434C attributeDetails : productLevel.getProductLevelIndicators()
					.getAttributeDetails()) {
				if (StringUtils.isNotEmpty(attributeDetails.getAttributeType())) {
					String flightSegmentType = attributeDetails.getAttributeType();
					if (serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE, BookingServiceConstants.ATTRIBUTE_TYPE_RETURN)
							.contains(flightSegmentType))
						segmentType = FlightSegmentType.RETURN;
					else if (serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE, BookingServiceConstants.ATTRIBUTE_TYPE_INBOUND)
							.contains(flightSegmentType))
						segmentType = FlightSegmentType.INBOUND;
					else if (serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE, BookingServiceConstants.ATTRIBUTE_TYPE_ONWARD)
							.contains(flightSegmentType))
						segmentType = FlightSegmentType.ONWARD;
					else
						segmentType = FlightSegmentType.OUTBOUND;
				}
			}
		}
		return segmentType;
	}

	/**
	 * This method is used to map FlightSegment Origin properties Identifier,
	 * Terminal, Gate from Amadeus Response which will be a part of service
	 * response
	 * 
	 * @param flightSegment
	 * @param productLevel
	 */
	private Origin populatingFlightSegmentOriginValues(FlightSegment flightSegment, ProductLevel productLevel) {
		Origin originOfflightSegment = new Origin();
		if (productLevel.getOperatingFlightDetails() != null
				&& StringUtils.isNotEmpty(productLevel.getOperatingFlightDetails().getBoardPoint())) {
			String flightSegmentOriginIdentifier = productLevel.getOperatingFlightDetails().getBoardPoint();
			originOfflightSegment.setIdentifier(flightSegmentOriginIdentifier);
		}
		if (productLevel.getLegLevel().size() > 0) {
			for (LegLevel legLevel : productLevel.getLegLevel()) {
				if (legLevel.getAdditionalProductDetails() != null
						&& legLevel.getAdditionalProductDetails().getDepartureStationInfo() != null
						&& StringUtils.isNotEmpty(
								legLevel.getAdditionalProductDetails().getDepartureStationInfo().getTerminal())) {
					originOfflightSegment.setTerminal(
							legLevel.getAdditionalProductDetails().getDepartureStationInfo().getTerminal());
				}
			}
		}
		if (productLevel.getDepartureGate().size() > 0) {
			for (TerminalLocationType116626S departureGate : productLevel.getDepartureGate()) {
				if (departureGate.getFacilityDetails() != null) {
					if (StringUtils.isNotEmpty(departureGate.getFacilityDetails().getIdentifier())) {
						String flightSegmentOriginGateNo = departureGate.getFacilityDetails().getIdentifier();
						Gate gateOfflightSegmentDeparture = new Gate();
						gateOfflightSegmentDeparture.setNumber(flightSegmentOriginGateNo);
						originOfflightSegment.setGate(gateOfflightSegmentDeparture);
					}
				}
			}
		}
		return originOfflightSegment;
	}

	/**
	 * This method is used to map FlightSegment Destination properties
	 * Identifier, Terminal, Gate from Amadeus Response which will be a part of
	 * service response
	 * 
	 * @param flightSegment
	 * @param productLevel
	 */
	private Destination populatingFlightSegmentDestinationValues(FlightSegment flightSegment,
			ProductLevel productLevel) {
		Destination destinationOfflightSegment = new Destination();

		/*
		 * Gate gateOfflightSegmentDest = new Gate();
		 * gateOfflightSegmentDest.setNumber(serviceProxy.retrieveConfiguration(
		 * BookingServiceConstants.GATE_NO_NA));
		 * destinationOfflightSegment.setGate(gateOfflightSegmentDest);
		 */

		if (productLevel.getOperatingFlightDetails() != null
				&& StringUtils.isNotEmpty(productLevel.getOperatingFlightDetails().getOffPoint())) {
			String flightSegmentDestinationIdentifier = productLevel.getOperatingFlightDetails().getOffPoint();
			destinationOfflightSegment.setIdentifier(flightSegmentDestinationIdentifier);
		}
		if (productLevel.getLegLevel().size() > 0) {
			for (LegLevel legLevel : productLevel.getLegLevel()) {
				if (legLevel.getAdditionalProductDetails() != null
						&& legLevel.getAdditionalProductDetails().getArrivalStationInfo() != null
						&& StringUtils.isNotEmpty(
								legLevel.getAdditionalProductDetails().getArrivalStationInfo().getTerminal())) {
					String flightSegmentDestinationterminal = legLevel.getAdditionalProductDetails()
							.getArrivalStationInfo().getTerminal();
					destinationOfflightSegment.setTerminal(flightSegmentDestinationterminal);
				}
			}
		}
		return destinationOfflightSegment;
	}

	/**
	 * This method is used to map FlightSegment Scheduled Departure DateTime
	 * from Amadeus Response which will be a part of service response
	 * 
	 * @param flightSegment
	 * @param productLevel
	 */
	/*
	 * private org.joda.time.LocalDateTime
	 * populatingFlightSegmentScheduledDepartuerDateTime(FlightSegment
	 * flightSegment, ProductLevel productLevel) { org.joda.time.LocalDateTime
	 * scheduledDepartuerLocalDateTime = null; int scheduledDepartureLocalYear =
	 * 0; int scheduledDepartureLocalMonth = 0; int scheduledDepartureLocalDay =
	 * 0; int scheduleDepartureLocalHours = 0; int scheduleDepartureLocalMinuts
	 * = 0;
	 * 
	 * if (productLevel.getOperatingFlightDetails() != null) {
	 * 
	 * if (StringUtils.isNotEmpty(productLevel.getOperatingFlightDetails().
	 * getDepartureDate())) { String departureDate =
	 * productLevel.getOperatingFlightDetails().getDepartureDate();
	 * scheduledDepartureLocalYear = Integer.parseInt(departureDate.substring(0,
	 * 4)); scheduledDepartureLocalMonth =
	 * Integer.parseInt(departureDate.substring(4, 6));
	 * scheduledDepartureLocalDay = Integer.parseInt(departureDate.substring(6,
	 * 8));
	 * 
	 * } if
	 * (productLevel.getOperatingFlightDetails().getDateAndTimeRange().size() >
	 * 0) { for (ProductDateTimeTypeI166696C dateAndTimeRange :
	 * productLevel.getOperatingFlightDetails() .getDateAndTimeRange()) { if
	 * (StringUtils.isNotEmpty(dateAndTimeRange.getDepartureTime())) { String
	 * departureTime = dateAndTimeRange.getDepartureTime();
	 * scheduleDepartureLocalHours = Integer.parseInt(departureTime.substring(0,
	 * 2)); scheduleDepartureLocalMinuts =
	 * Integer.parseInt(departureTime.substring(2, 4)); } } } } if
	 * (scheduledDepartureLocalMonth > 0 && scheduledDepartureLocalDay > 0) {
	 * scheduledDepartuerLocalDateTime = new
	 * org.joda.time.LocalDateTime(scheduledDepartureLocalYear,
	 * scheduledDepartureLocalMonth, scheduledDepartureLocalDay,
	 * scheduleDepartureLocalHours, scheduleDepartureLocalMinuts, 0); } return
	 * scheduledDepartuerLocalDateTime; }
	 */

	/**
	 * This method is used to map FlightSegment Scheduled Arrival DateTime from
	 * Amadeus Response which will be a part of service response
	 * 
	 * @param flightSegment
	 * @param productLevel
	 */
	/*
	 * private org.joda.time.LocalDateTime
	 * populatingFlightSegmentScheduledArrivalDateTime(FlightSegment
	 * flightSegment, ProductLevel productLevel) { org.joda.time.LocalDateTime
	 * scheduledArrivalLocalDateTime = null; int scheduledArrivalLocalYear = 0;
	 * int scheduledArrivalLocalMonth = 0; int scheduledArrivalLocalDay = 0; int
	 * scheduleArrivalLocalHours = 0; int scheduleArrivalLocalMinuts = 0;
	 * 
	 * if (productLevel.getOperatingFlightDetails() != null) {
	 * 
	 * if (StringUtils.isNotEmpty(productLevel.getOperatingFlightDetails().
	 * getArrivalDate())) { String arrivalDate =
	 * productLevel.getOperatingFlightDetails().getArrivalDate();
	 * scheduledArrivalLocalYear = Integer.parseInt(arrivalDate.substring(0,
	 * 4)); scheduledArrivalLocalMonth =
	 * Integer.parseInt(arrivalDate.substring(4, 6)); scheduledArrivalLocalDay =
	 * Integer.parseInt(arrivalDate.substring(6, 8));
	 * 
	 * } if
	 * (productLevel.getOperatingFlightDetails().getDateAndTimeRange().size() >
	 * 0) { for (ProductDateTimeTypeI166696C dateAndTimeRange :
	 * productLevel.getOperatingFlightDetails() .getDateAndTimeRange()) { if
	 * (StringUtils.isNotEmpty(dateAndTimeRange.getArrivalTime())) { String
	 * departureTime = dateAndTimeRange.getArrivalTime();
	 * scheduleArrivalLocalHours = Integer.parseInt(departureTime.substring(0,
	 * 2)); scheduleArrivalLocalMinuts =
	 * Integer.parseInt(departureTime.substring(2, 4)); } } } } if
	 * (scheduledArrivalLocalMonth > 0 && scheduledArrivalLocalDay > 0) {
	 * scheduledArrivalLocalDateTime = new
	 * org.joda.time.LocalDateTime(scheduledArrivalLocalYear,
	 * scheduledArrivalLocalMonth, scheduledArrivalLocalDay,
	 * scheduleArrivalLocalHours, scheduleArrivalLocalMinuts, 0); } return
	 * scheduledArrivalLocalDateTime; }
	 */
	/**
	 * This method is used to map FlightSegment Carrier properties Code, Type,
	 * FlightNumber, OperationalSuffix from Amadeus Response which will be a
	 * part of service response
	 * 
	 * @param flightSegment
	 * @param productLevel
	 */

	private Carrier populatingFlightSegmentCarrierValues(FlightSegment flightSegment, ProductLevel productLevel) {
		Carrier carrier = new Carrier();
		if (productLevel.getOperatingFlightDetails() != null
				&& productLevel.getOperatingFlightDetails().getFlightDetails() != null) {

			if (StringUtils.isNotEmpty(productLevel.getOperatingFlightDetails().getFlightDetails().getFlightNumber())) {
				String carrierFlightNumber = productLevel.getOperatingFlightDetails().getFlightDetails()
						.getFlightNumber();
				carrier.setFlightNumber(carrierFlightNumber);
			}
			if (StringUtils
					.isNotEmpty(productLevel.getOperatingFlightDetails().getFlightDetails().getOperationalSuffix())) {
				String carrierOperationalSuffix = productLevel.getOperatingFlightDetails().getFlightDetails()
						.getOperationalSuffix();
				carrier.setOperationalSuffix(carrierOperationalSuffix);
			}
			if (productLevel.getOperatingFlightDetails().getCarrierDetails() != null) {
				if (StringUtils.isNotEmpty(
						productLevel.getOperatingFlightDetails().getCarrierDetails().getMarketingCarrier())) {
					String marketingCarrier = productLevel.getOperatingFlightDetails().getCarrierDetails()
							.getMarketingCarrier();
					carrier.setCode(marketingCarrier);
					carrier.setType(CarrierType.MARKETING);
				} else {
					String otherCarrier = productLevel.getOperatingFlightDetails().getCarrierDetails()
							.getOtherCarrier();
					carrier.setCode(otherCarrier);
					carrier.setType(CarrierType.OPERATING);
				}
			}

		}
		return carrier;
	}

	/**
	 * This method is used to map following FlightLeg Properties FlightLeg
	 * Origin Identifier, Terminal, Gate FlightLeg Destination Identifier,
	 * Terminal, Gate FlightLeg Scheduled Arrival and Departure DateTime which
	 * will be a part of service response
	 * 
	 * @param flightSegment
	 * @param productLevel
	 * @param filghtLeglist
	 */
	private void populatingFlightLegDetails(FlightSegment flightSegment, ProductLevel productLevel,
			List<FlightLeg> filghtLeglist) {
		FlightLeg flightLeg = null;
		if (productLevel.getLegLevel().size() > 0) {
			for (LegLevel legLevel : productLevel.getLegLevel()) {
				Origin originOfFl = new Origin();
				Destination destinationOfFl = new Destination();
				/*
				 * Gate gateOfFlDest = new Gate();
				 * gateOfFlDest.setNumber(serviceProxy.retrieveConfiguration(
				 * BookingServiceConstants.GATE_NO_NA));
				 * destinationOfFl.setGate(gateOfFlDest);
				 */
				populateIdentifier(legLevel, originOfFl, destinationOfFl);
				populateTerminalInfo(legLevel, originOfFl, destinationOfFl);
				populateDepartureGate(productLevel, originOfFl);
				flightLeg = new FlightLeg.FlightLegBuilder(originOfFl, destinationOfFl, populateDepartureDate(legLevel),
						populateArrivalDateTime(legLevel)).build();
				filghtLeglist.add(flightLeg);
			}
		}
	}

	/**
	 * @param legLevel
	 * @return
	 */
	private LocalDateTime populateArrivalDateTime(LegLevel legLevel) {
		org.joda.time.LocalDateTime scheduledArrivalDateTime = null;
		int flightLegScheduledArrivalYear = 0;
		int flightLegScheduledArrivalMonth = 0;
		int flightLegScheduledArrivalDay = 0;
		int flightLegScheduledArrivalHour = 0;
		int flightLegScheduledArrivalMinutes = 0;
		int flightLegScheduledArrivalSeconds = 0;
		if (legLevel.getLegTimes().size() > 0) {
			for (StructuredDateTimeInformationType structuredDateTimeInformationType : legLevel.getLegTimes()) {
				if (structuredDateTimeInformationType.getBusinessSemantic()
						.contains(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE, BookingServiceConstants.FLIGHT_LEG_ARRIVAL_STA))
						&& structuredDateTimeInformationType.getDateTime() != null) {
					if (StringUtils.isNotEmpty(structuredDateTimeInformationType.getDateTime().getYear())) {
						flightLegScheduledArrivalYear = Integer
								.parseInt(structuredDateTimeInformationType.getDateTime().getYear());
					}
					if (StringUtils.isNotEmpty(structuredDateTimeInformationType.getDateTime().getMonth())) {
						flightLegScheduledArrivalMonth = Integer
								.parseInt(structuredDateTimeInformationType.getDateTime().getMonth());
					}
					if (StringUtils.isNotEmpty(structuredDateTimeInformationType.getDateTime().getDay())) {
						flightLegScheduledArrivalDay = Integer
								.parseInt(structuredDateTimeInformationType.getDateTime().getDay());
					}
					if (StringUtils.isNotEmpty(structuredDateTimeInformationType.getDateTime().getHour())) {
						flightLegScheduledArrivalHour = Integer
								.parseInt(structuredDateTimeInformationType.getDateTime().getHour());
					}
					if (StringUtils.isNotEmpty(structuredDateTimeInformationType.getDateTime().getMinutes())) {
						flightLegScheduledArrivalMinutes = Integer
								.parseInt(structuredDateTimeInformationType.getDateTime().getMinutes());
					}
					if (structuredDateTimeInformationType.getDateTime().getSeconds().intValue() > 0) {
						flightLegScheduledArrivalSeconds = structuredDateTimeInformationType.getDateTime().getSeconds()
								.intValue();
					}
				}
			}
		}
		if (flightLegScheduledArrivalMonth > 0 && flightLegScheduledArrivalDay > 0) {
			scheduledArrivalDateTime = new org.joda.time.LocalDateTime(flightLegScheduledArrivalYear,
					flightLegScheduledArrivalMonth, flightLegScheduledArrivalDay, flightLegScheduledArrivalHour,
					flightLegScheduledArrivalMinutes, flightLegScheduledArrivalSeconds);
		}
		return scheduledArrivalDateTime;
	}

	/**
	 * @param legLevel
	 * @return
	 */
	private LocalDateTime populateDepartureDate(LegLevel legLevel) {
		org.joda.time.LocalDateTime scheduledDepartureDateTime = null;
		int flightLegScheduledDepartureYear = 0;
		int flightLegScheduledDepartureMonth = 0;
		int flightLegScheduledDepartureDay = 0;
		int flightLegScheduledDepartureHour = 0;
		int flightLegScheduledDepartureMinutes = 0;
		int flightLegScheduledDepartureSeconds = 0;
		if (legLevel.getLegTimes().size() > 0) {
			for (StructuredDateTimeInformationType structuredDateTimeInformationType : legLevel.getLegTimes()) {
				if (structuredDateTimeInformationType.getBusinessSemantic()
						.contains(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUSCODES_NAMESPACE, BookingServiceConstants.FLIGHT_LEG_DEPARTURE_STD))
						&& structuredDateTimeInformationType.getDateTime() != null) {
					if (StringUtils.isNotEmpty(structuredDateTimeInformationType.getDateTime().getYear())) {
						flightLegScheduledDepartureYear = Integer
								.parseInt(structuredDateTimeInformationType.getDateTime().getYear());
					}
					if (StringUtils.isNotEmpty(structuredDateTimeInformationType.getDateTime().getMonth())) {
						flightLegScheduledDepartureMonth = Integer
								.parseInt(structuredDateTimeInformationType.getDateTime().getMonth());
					}
					if (StringUtils.isNotEmpty(structuredDateTimeInformationType.getDateTime().getDay())) {
						flightLegScheduledDepartureDay = Integer
								.parseInt(structuredDateTimeInformationType.getDateTime().getDay());
					}
					if (StringUtils.isNotEmpty(structuredDateTimeInformationType.getDateTime().getHour())) {
						flightLegScheduledDepartureHour = Integer
								.parseInt(structuredDateTimeInformationType.getDateTime().getHour());
					}
					if (StringUtils.isNotEmpty(structuredDateTimeInformationType.getDateTime().getMinutes())) {
						flightLegScheduledDepartureMinutes = Integer
								.parseInt(structuredDateTimeInformationType.getDateTime().getMinutes());
					}
					if (structuredDateTimeInformationType.getDateTime().getSeconds().intValue() > 0) {
						flightLegScheduledDepartureSeconds = structuredDateTimeInformationType.getDateTime()
								.getSeconds().intValue();
					}
				}
			}
		}
		if (flightLegScheduledDepartureMonth > 0 && flightLegScheduledDepartureDay > 0) {
			scheduledDepartureDateTime = new org.joda.time.LocalDateTime(flightLegScheduledDepartureYear,
					flightLegScheduledDepartureMonth, flightLegScheduledDepartureDay, flightLegScheduledDepartureHour,
					flightLegScheduledDepartureMinutes, flightLegScheduledDepartureSeconds);
		}
		return scheduledDepartureDateTime;
	}

	/**
	 * @param productLevel
	 * @param originOfFl
	 */
	private void populateDepartureGate(ProductLevel productLevel, Origin originOfFl) {
		if (productLevel.getDepartureGate().size() > 0) {
			for (TerminalLocationType116626S departureGate : productLevel.getDepartureGate()) {
				if (departureGate.getFacilityDetails() != null
						&& StringUtils.isNotEmpty(departureGate.getFacilityDetails().getIdentifier())) {
					String flOriginGateNo = departureGate.getFacilityDetails().getIdentifier();
					Gate gateOfFlOrigin = new Gate();
					gateOfFlOrigin.setNumber(flOriginGateNo);
					originOfFl.setGate(gateOfFlOrigin);
				}
			}
		}
	}

	/**
	 * @param legLevel
	 * @param originOfFl
	 * @param destinationOfFl
	 */
	private void populateTerminalInfo(LegLevel legLevel, Origin originOfFl, Destination destinationOfFl) {
		if (legLevel.getAdditionalProductDetails() != null) {
			if (legLevel.getAdditionalProductDetails().getDepartureStationInfo() != null && StringUtils
					.isNotEmpty(legLevel.getAdditionalProductDetails().getDepartureStationInfo().getTerminal())) {
				originOfFl.setTerminal(legLevel.getAdditionalProductDetails().getDepartureStationInfo().getTerminal());
			}
			if (legLevel.getAdditionalProductDetails().getArrivalStationInfo() != null && StringUtils
					.isNotEmpty(legLevel.getAdditionalProductDetails().getArrivalStationInfo().getTerminal())) {
				destinationOfFl
						.setTerminal(legLevel.getAdditionalProductDetails().getArrivalStationInfo().getTerminal());
			}
		}
	}

	/**
	 * @param legLevel
	 * @param originOfFl
	 * @param destinationOfFl
	 */
	private void populateIdentifier(LegLevel legLevel, Origin originOfFl, Destination destinationOfFl) {
		String flOriginIdenfifier = legLevel.getLegRouting().getOrigin();
		originOfFl.setIdentifier(flOriginIdenfifier);
		String flDestinationIdenfier = legLevel.getLegRouting().getDestination();
		destinationOfFl.setIdentifier(flDestinationIdenfier);

	}
}
