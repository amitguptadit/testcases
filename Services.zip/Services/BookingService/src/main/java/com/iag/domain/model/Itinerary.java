
package com.iag.domain.model;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iag.domain.model.utility.ToStringBuilder;


/**
 * A collection of  itinerary items , passenger wants to check-in for .
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "eticket",
    "itinerary-items"
})
public class Itinerary {

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("eticket")
    private Eticket eticket;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("itinerary-items")
    private List<ItineraryItem> itineraryItems = new ArrayList<ItineraryItem>();
   
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("eticket")
    public Eticket getEticket() {
        return eticket;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("eticket")
    public void setEticket(Eticket eticket) {
        this.eticket = eticket;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("itinerary-items")
    public List<ItineraryItem> getItineraryItems() {
        return itineraryItems;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("itinerary-items")
    public void setItineraryItems(List<ItineraryItem> itineraryItems) {
        this.itineraryItems = itineraryItems;
    }

    

    @Override
    public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {
      return ToStringBuilder.generateToString(this);
    }


}
