package com.iag.application.error;

import java.util.ArrayList;
import java.util.Collection;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * ValidationError setting validate request and response related exception.
 * 
 */
public final class ValidationError extends ServiceError {
  private String path;
  @JsonProperty("childError")
  private Collection<ValidationError> serviceErrors;

  ValidationError(final String code) {
    super(code);
  }

  /**
   * This method adds supplied child validation error in list of validation errors.
   * @param childValidationError
   */
  public void addValidationError(final ValidationError childValidationError) {
    if (serviceErrors == null) {
      serviceErrors = new ArrayList<ValidationError>();
    }
    serviceErrors.add(childValidationError);
  }

  public String getPath() {
    return path;
  }

  public void setPath(final String path) {
    this.path = path;
  }

  public Collection<ValidationError> getServiceErrors() {
    return serviceErrors;
  }
}
