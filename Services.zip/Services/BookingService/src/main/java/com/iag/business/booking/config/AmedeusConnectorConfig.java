package com.iag.business.booking.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.proxy.ConfigurationInfrastructureServiceProxy;
import com.iag.business.booking.repository.amadeus.proxy.AmadeusWebServiceProxy;

@Configuration
public class AmedeusConnectorConfig {
	
	@Autowired
    private  ConfigurationInfrastructureServiceProxy serviceProxy;
	
	@Bean
	public WebServiceTemplate amadeusWebServiceTemplate(Jaxb2Marshaller amadeusMarshaller,
			Jaxb2Marshaller amadeusUnMarshaller) {
		WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
		webServiceTemplate.setMarshaller(amadeusMarshaller);
		webServiceTemplate.setUnmarshaller(amadeusUnMarshaller);
		webServiceTemplate.setDefaultUri(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUS_NAMESPACE, BookingServiceConstants.AMADEUS_GATEWAY_WEBURL));
		return webServiceTemplate;
	}

	@Bean
	public Jaxb2Marshaller amadeusMarshaller() {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setContextPaths(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUS_NAMESPACE, BookingServiceConstants.AMADEUS_RESPONSE_MARSHALLER));
		Map<String, Boolean> marshallerProperties = new HashMap<String, Boolean>();
		marshallerProperties.put(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		return jaxb2Marshaller;
	}

	@Bean
	public Jaxb2Marshaller amadeusUnMarshaller() {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setContextPaths(serviceProxy.retrieveConfiguration(BookingServiceConstants.AMADEUS_NAMESPACE, BookingServiceConstants.AMADEUS_RESPONSE_UNMARSHALLER));
		Map<String, Boolean> marshallerProperties = new HashMap<String, Boolean>();
		marshallerProperties.put(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		return jaxb2Marshaller;
	}

	@Bean
	public AmadeusWebServiceProxy amadeusWebServiceGateway() {
		return new AmadeusWebServiceProxy();
	}

}