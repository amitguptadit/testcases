package com.iag.business.booking.proxy;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.iag.application.exception.ApplicationServiceException;
import com.iag.business.booking.error.BookingErrorCode;
import com.iag.business.booking.proxy.model.Configuration;
import com.iag.business.booking.proxy.model.ConfigurationNamespace;
import com.iag.business.booking.urlgenerator.ServiceUrlGenerator;

@Component

public class ConfigurationInfrastructureServiceProxy implements ServiceProxy {
	private static final Logger logger = LoggerFactory.getLogger(ConfigurationInfrastructureServiceProxy.class);

	private final Map<String, String> serviceConfigMap = new HashMap<>();
	private final Map<String, Map<String, String>> configNamespacesMap = new ConcurrentHashMap<>();
	private final String configPath;
	private final RestTemplate restTemplate;
	private ServiceUrlGenerator serviceUrlGenerator;
	private final String SERVICE_ID;
	private final String RESOURCE_VALUE;
	private final String IDENTIFIER_VALUE;
	private final String RESOURCE = "resource";
	private final String IDENTIFIER = "identifier";

	@Autowired
	public ConfigurationInfrastructureServiceProxy(@Value("${config.url}") final String configPath,
			@Value("${configuration.service}") final String serviceId,
			@Value("${config.resource}") final String resourceValue,
			@Value("${config.identifier}") final String identifier, final RestTemplate restTemplate, final ServiceUrlGenerator serviceUrlGenerator) {
		this.configPath = configPath;
		this.restTemplate = restTemplate;
		this.SERVICE_ID = serviceId;
		this.RESOURCE_VALUE = resourceValue;
		this.IDENTIFIER_VALUE = identifier;
		this.serviceUrlGenerator = serviceUrlGenerator;
	}

	@PostConstruct
	public void init() {
		Configuration configuration = null;
		try {
			String url = serviceUrlGenerator.generateUrl(SERVICE_ID);
			if (url == null) {
				logger.error("Call to {} is made to validate the token - Failed", SERVICE_ID);
				throw new ApplicationServiceException(BookingErrorCode.SYSTEM_UNAVAILABLE.name(), null);
			}

			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url + configPath)
					.queryParam(RESOURCE, RESOURCE_VALUE).queryParam(IDENTIFIER, IDENTIFIER_VALUE);
			ResponseEntity<Configuration> configurationResponse = restTemplate.exchange(builder.toUriString(),
					HttpMethod.GET, null, Configuration.class);
			configuration = configurationResponse.getBody();
			if (!configurationResponse.getStatusCode().is2xxSuccessful()) {
				logger.error("Http Status code is not successful");
				ApplicationServiceException appException = new ApplicationServiceException(
						BookingErrorCode.SYSTEM_UNAVAILABLE.name());
				throw appException;
			}
		} catch (Exception resourceEx) {
			logger.error("Configuration service is down. Exception type:{}" + resourceEx.getMessage());
			ApplicationServiceException appException = new ApplicationServiceException(
					BookingErrorCode.SYSTEM_UNAVAILABLE.name());
			throw appException;
		}

		retrieveServiceGatewayConfiguration(configuration);
	}

	// TODO: implementation to call Configuration service
	@Override
	public String retrieveConfiguration(String configurationName, String key) {
		logger.info("start method:retrieveConfiguration(), key: {}", key);
		logger.info("start method:retrieveConfiguration(), configurationName: {}", configurationName);
		return configNamespacesMap.get(configurationName).get(key.toLowerCase());
	}

	// TODO: implementation to call Configuration service from Eureka Server
	/*
	 * @Override public String retrieveConfiguration(String configurationName,
	 * String key) { logger.info("start method:retrieveConfiguration(), key: {}"
	 * , key); if (!configNamespacesMap.isEmpty()) {
	 * System.out.println(configNamespacesMap.get(configurationName).get(key));
	 * return configNamespacesMap.get(configurationName).get(key.toLowerCase());
	 * } else { ResponseEntity<Configuration> configurationResponse; try {
	 * configurationResponse = restTemplate.exchange(configPath, HttpMethod.GET,
	 * null, Configuration.class); } catch (RestClientException restException) {
	 * logger.error("Config Service is down."); throw new
	 * RuntimeException(restException.getMessage()); } if (configurationResponse
	 * == null || !configurationResponse.getStatusCode().is2xxSuccessful()) {
	 * logger.error("Response status is invalid."); throw new
	 * ApplicationServiceException(ServiceGatewayErrorCodes.SYSTEM_UNAVAILABLE.
	 * name()); }
	 * retrieveServiceGatewayConfiguration(configurationResponse.getBody());
	 * return configNamespacesMap.get(configurationName).get(key.toLowerCase());
	 * }
	 * 
	 * }
	 */
	/**
	 * @param configuration
	 * @return
	 */
	private void retrieveServiceGatewayConfiguration(Configuration configuration) {
		List<ConfigurationNamespace> configurationList = configuration.getConfigurationNamespaces();
		for (ConfigurationNamespace configurationNamespaces : configurationList) {
			configurationNamespaces.getConfigurationItems().forEach(configurationItem -> {
				serviceConfigMap.put(configurationItem.getIdentifier().toLowerCase(), configurationItem.getValue());
			});
			configNamespacesMap.put(configurationNamespaces.getName(), serviceConfigMap);
			Collections.unmodifiableMap(configNamespacesMap);
		}
	}
}
