package com.iag.domain.model.party;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.iag.domain.model.utility.ToStringBuilder;

/**
 * This class encapsulates details about a person's name.
 * @param firstName : String First Name of the person.
 * @param familyName : String family name of the Person.
 * @param middleInitials : List<Character> middle names of a person.
 * @param middleNames : List<String> middle names of a person.
 * @param secondFamilyName : String second family name.
 * @param suffix : String suffix of name if any.
 * @param title : String title of the name.
 * @param type : type of name e.g. BIRTH_NAME.
 * @param effective : date range when this name is effective.
 */
@SuppressWarnings("serial")
@JsonInclude(Include.NON_EMPTY)
public final class PersonName implements Serializable {

  private String title;
  private String firstName;
  private String middleName;
  private String familyName;
  private String secondFamilyName;
 

  /**
   * Default constructor,reflectively picked by frameworks like jaxb to create and initialise the state of object.
   */
  private PersonName() {
  }

  /**
   * Class can not be directly instantiated from the client code.
   * @param builder
   */
  private PersonName(final PersonNameBuilder builder) {
    this();
    this.title = builder.title;
    this.firstName = builder.firstName;
    this.middleName = builder.middleName;
    this.familyName = builder.familyName;
    this.secondFamilyName = builder.secondFamilyName;
    this.title = builder.title;
  }

 

  public String getMiddleName() {
    return middleName;
  }

  public String getFamilyName() {
    return familyName;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getSecondFamilyName() {
    return secondFamilyName;
  }

  public String getTitle() {
    return title;
  }
  

  /**
   * Builder Class of PersonName which allows fields to be populated
   * optionally,making PersonName immutable at the same time.
   */
  public static class PersonNameBuilder {
	  private String title;
	  private String firstName;
	  private String middleName;
	  private String familyName;
	  private String secondFamilyName;

    /**
     * Builder constructor only receives the required attributes.
     * @param firstName
     * @param familyName
     */
    public PersonNameBuilder(final String firstName, final String familyName) {
      this.firstName = firstName;
      this.familyName = familyName;
    }

    
    
    /**
     * Initialise optional attributes middleNames.
     * @param middleNamesList
     * @return
     */
    public PersonNameBuilder setMiddleName(final String middleName) {
      this.middleName = middleName;
      return this;
    }


    /**
     * Initialise optional attributes secondFamilyName.
     * @param secondName
     * @return
     */
    public PersonNameBuilder setSecondFamilyName(final String secondName) {
      this.secondFamilyName = secondName;
      return this;
    }

    /**
     * Initialise optional attributes suffix.
     * @param suffixValue
     * @return
     */
    public PersonNameBuilder setTitle(final String title) {
      this.title = title;
      return this;
    }

    

    /**
     * Method finally returns the built instance.
     * @return
     */
    public PersonName build() {
      return new PersonName(this);
    }

  }

  @Override
  public int hashCode() {
    return HashCodeBuilder.reflectionHashCode(this);
  }

  @Override
  public boolean equals(final Object obj) {
    return EqualsBuilder.reflectionEquals(this, obj);
  }

  @Override
  public String toString() {
    return ToStringBuilder.generateToString(this);
  }
}
