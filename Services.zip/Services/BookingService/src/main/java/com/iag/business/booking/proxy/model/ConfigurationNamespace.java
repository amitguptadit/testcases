
package com.iag.business.booking.proxy.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ConfigurationNamespace {

	/**
	 * @param name
	 * @param configurationItems
	 * @param configurationNamespaces
	 */
	

	private String name;
	private List<ConfigurationItems> configurationItems =new ArrayList<>();
	@JsonProperty("configurationNamespaces")
	private List<ConfigurationNamespace> configurationNamespaces =new ArrayList<>(); ;
	
	public ConfigurationNamespace() {
		
	}

	public ConfigurationNamespace(String name, List<ConfigurationItems> configurationItems) {
		this.name = name;
		this.configurationItems = configurationItems;
	}
	public ConfigurationNamespace(String name, List<ConfigurationItems> configurationItems,
			List<ConfigurationNamespace> configurationNamespaces) {
		this.name = name;
		this.configurationItems = configurationItems;
		this.configurationNamespaces = configurationNamespaces;
	}
	public String getName() {
		return name;
	}

	public List<ConfigurationNamespace> getConfigurationNamespaces() {
		return configurationNamespaces;
	}

	public void setConfigurationNamespaces(List<ConfigurationNamespace> configurationNamespaces) {
		this.configurationNamespaces = configurationNamespaces;
	}

	public void setConfigurationItems(List<ConfigurationItems> configurationItems) {
		this.configurationItems = configurationItems;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ConfigurationItems> getConfigurationItems() {
		return configurationItems;
	}


	@Override
	public String toString() {
		return "ConfigurationNamespaces [name=" + name + ", configurationItems=" + configurationItems
				+ ", configurationNamespaces=" + configurationNamespaces + "]";
	}


}
