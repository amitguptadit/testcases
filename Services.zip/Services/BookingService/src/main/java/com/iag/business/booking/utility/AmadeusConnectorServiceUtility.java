package com.iag.business.booking.utility;
	
	import org.apache.commons.lang3.StringUtils;
	import org.slf4j.Logger;
	import org.slf4j.LoggerFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Component;

import com.iag.business.booking.constants.BookingServiceConstants;
import com.iag.business.booking.proxy.ServiceProxy;


	@Component
	public class AmadeusConnectorServiceUtility {
		public static final String MESSAGE_CONFIGURATION_KEYWORD = "booking.error.";
		public static final String KEY_SEPARATOR_DOT = ".";
		public static final String KEY_SEPARATOR = "-";

	    private static final Logger LOG = LoggerFactory.getLogger(AmadeusConnectorServiceUtility.class);

		private final ServiceProxy configurationInfrastructureServiceProxy;

		@Autowired
		public AmadeusConnectorServiceUtility(final ServiceProxy configurationInfrastructureServiceProxy) {
			this.configurationInfrastructureServiceProxy = configurationInfrastructureServiceProxy;

		}

		/**
		 * Function to get the message based on the message key.
		 * 
		 * @param key
		 * @return
		 */
		public String getMessageConfigurationValue(final String key) {
			String value = StringUtils.EMPTY;
			if (!StringUtils.EMPTY.equals(StringUtils.trimToEmpty(key))) {
				String urlKey = new StringBuilder().append(MESSAGE_CONFIGURATION_KEYWORD)
						.append(key.replace(KEY_SEPARATOR_DOT, KEY_SEPARATOR)).toString();
				LOG.info("getMessageConfigurationValue method invoke .{}", urlKey);

				value = configurationInfrastructureServiceProxy.retrieveConfiguration(BookingServiceConstants.ERROR_NAMESPACE, urlKey);
			}
			return value;
		}

	}


