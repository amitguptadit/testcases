
package com.iag.domain.model.party.role;

/**
 * Associated Passenger
 * <p>
 * 
 * 
 */
public class AssociatedPassenger<K> extends PartyRole<K>{

}
