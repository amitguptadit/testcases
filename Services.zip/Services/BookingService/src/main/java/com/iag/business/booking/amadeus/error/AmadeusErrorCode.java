package com.iag.business.booking.amadeus.error;

/**
 * Enumeration containing error codes used as key by Membership Business Service to
 * fetch error message from infrastructure data source.
 */
public enum AmadeusErrorCode {
  
	
	REQUEST_INVALID,MANDATORY_DATA_MISSING, MAX_POOL_LIMIT_REACHED, SYSTEM_UNAVAILABLE,BOOKING_NOT_FOUND
}
