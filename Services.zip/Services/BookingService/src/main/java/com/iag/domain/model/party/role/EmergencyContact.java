
package com.iag.domain.model.party.role;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iag.domain.model.party.Person;
import com.iag.domain.model.utility.ToStringBuilder;


/**
 * Emergency contact details for the passenger
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "isDeclined",
    "person"
})
public final class EmergencyContact<K> extends PartyRole<K> implements Serializable {

	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("isDeclined")
	private Boolean isDeclined;
	/**
	 * Details of emergency contact of the passenger.
	 * 
	 */
	@JsonProperty("person")
	@JsonPropertyDescription("Details of emergency contact of the passenger.")
	private Person<K> person;

	private EmergencyContact() {

	}

	private EmergencyContact(final EmergencyContactBuilder<K> builder) {
		this();
		this.isDeclined = builder.isDeclined;
		this.person = builder.person;
	}

	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("isDeclined")
	public Boolean getIsDeclined() {
		return isDeclined;
	}

	/**
	 * Details of emergency contact of the passenger.
	 * 
	 */
	@JsonProperty("person")
	public Person<K> getPerson() {
		return person;
	}

	public static class EmergencyContactBuilder<K> {

		private Person<K> person;
		private Boolean isDeclined;

		public EmergencyContactBuilder(Boolean isDeclined) {
			this.isDeclined = isDeclined;
		}

		/**
		 * Details of emergency contact of the passenger.
		 * 
		 * @return
		 * 
		 */
		@JsonProperty("person")
		public EmergencyContactBuilder<K> setPerson(Person<K> person) {
			this.person = person;
			return this;
		}

		/**
		 * Method finally returns the built instance.
		 * 
		 * @return
		 */
		public EmergencyContact<K> build() {
			return new EmergencyContact<K>(this);
		}

	}

    @Override
    public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {
      return ToStringBuilder.generateToString(this);
    }


}
