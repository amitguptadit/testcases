
package com.iag.domain.model;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iag.domain.model.utility.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "code",
    "type",
    "flightNumber",
    "operationalSuffix"
})
public class Carrier {

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("code")
    private String code;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("type")
    private CarrierType type;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("flightNumber")
    private String flightNumber;
    
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("operationalSuffix")
    private String operationalSuffix;
    
    public String getOperationalSuffix() {
		return operationalSuffix;
	}

	public void setOperationalSuffix(String operationalSuffix) {
		this.operationalSuffix = operationalSuffix;
	}

	/**
     * 
     * (Required)
     * 
     */
    @JsonProperty("code")
    public String getCode() {
        return code;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("code")
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("type")
    public CarrierType getType() {
        return type;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("type")
    public void setType(CarrierType type) {
        this.type = type;
    }


    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("flightNumber")
    public String getFlightNumber() {
        return flightNumber;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("flightNumber")
    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    @Override
    public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {
      return ToStringBuilder.generateToString(this);
    }



}
