package com.iag.domain.model.party.role;

public enum PassengerType {
    INFANT,
    CHILD,
    ADULT
}