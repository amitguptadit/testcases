package com.iag.business.booking.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iag.business.booking.repository.BookingRepository;
import com.iag.domain.model.booking.Booking;
import com.iag.domain.model.booking.BookingSearchCriteria;
import com.iag.domain.model.booking.Bookings;
import com.iag.domain.model.session.Session;

@Service
public class BookingServiceImpl implements BookingService {

	private static final Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);
	private final BookingRepository bookingRepository;

	@Autowired
	public BookingServiceImpl(final BookingRepository bookingRepository) {
		this.bookingRepository = bookingRepository;
	}

	@Override
	public Booking getBooking(String bookingIdentifier, Session session) {
		logger.debug("method start getBooking(), Booking-Identifier: {}, session: {}", bookingIdentifier);
		logger.info("method start getBooking(), Booking-Identifier: {}, session: {}", bookingIdentifier);
		BookingSearchCriteria bookingSearchCriteria = new BookingSearchCriteria();
		bookingSearchCriteria.setBookingIdentifier(bookingIdentifier);
		logger.info("method End: getBooking()");
		return bookingRepository.getBooking(bookingSearchCriteria, session);

	}
	
	@Override
	public List<Booking> getBookings(BookingSearchCriteria bookingSearchCriteria, Session session) {
		logger.debug("method start getBooking(), Booking-Identifier: {}, session: {}", bookingSearchCriteria);
		logger.info("method start getBooking(), Booking-Identifier: {}, session: {}", bookingSearchCriteria);
		return bookingRepository.getBookings(bookingSearchCriteria, session);
	}

}
