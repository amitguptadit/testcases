package com.iag.business.booking.repository;


import java.util.List;

import com.iag.domain.model.booking.Booking;
import com.iag.domain.model.booking.BookingSearchCriteria;
import com.iag.domain.model.session.Session;

public interface BookingRepository {

	public Booking getBooking(BookingSearchCriteria bookingSearchCriteria, Session session);
	
	public List<Booking> getBookings(BookingSearchCriteria bookingSearchCriteria, Session session);

}
