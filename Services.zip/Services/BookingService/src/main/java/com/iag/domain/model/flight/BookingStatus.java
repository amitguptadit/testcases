package com.iag.domain.model.flight;

public enum BookingStatus {
    CONFIRMED,
    UNCONFIRMED,
    DELAYED;
}
