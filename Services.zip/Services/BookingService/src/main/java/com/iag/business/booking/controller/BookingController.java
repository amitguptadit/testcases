package com.iag.business.booking.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

import java.util.List;
import java.util.Map;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iag.business.booking.service.BookingService;
import com.iag.business.booking.validation.BookingServiceValidator;
import com.iag.domain.model.booking.Booking;
import com.iag.domain.model.booking.BookingResource;
import com.iag.domain.model.booking.BookingSearchCriteria;
import com.iag.domain.model.booking.Bookings;
import com.iag.domain.model.session.Session;

/**
 * This controller class is used to connect booking service.
 */
@RestController
public class BookingController {
	public static final Logger logger = LoggerFactory.getLogger(BookingController.class);
	private final BookingServiceValidator boookingServiceValidator;
	private final BookingService bookingService;
	private static final String BOOKINGS = "bookings";
	private static final String _SELF = "_self";
	private static final String PASSENGERS = "passengers";
	private static final String ALL_PASSENGERS = "allPassengers";
	private static final String TOKEN_NUMBER = "tokennumber";
	private static final String SESSION_IDENTIFIER = "sessionidentifier";
	private static final String LOCATION = "location";
	private static final String CHANNEL = "channel";
	private static final String SCOPE = "scope";
	private static final String STATUS = "status";

	@Autowired
	public BookingController(final BookingServiceValidator boookingServiceValidator,
			final BookingService bookingService) {
		this.boookingServiceValidator = boookingServiceValidator;
		this.bookingService = bookingService;
	}

	

	/**
	 * This method is responsible to retrieve Booking information and details
	 * are retrieved on the basis of booking Identifier information.
	 * 
	 * @param BookingIdentifier
	 * @param requestHeaderMap
	 */

	@GetMapping(value = "/bookings/{booking-identifier}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BookingResource<Booking>> getBooking(
			@PathVariable(value = "booking-identifier") final String bookingIdentifier,
			@RequestHeader final Map<String, String> headerValueMap) {
		logger.info("method start: getBooking(), Booking-Identifier: {}", bookingIdentifier);

		boookingServiceValidator.validate(bookingIdentifier);
		Booking booking = bookingService.getBooking(bookingIdentifier, populateHeader(headerValueMap));
		BookingResource<Booking> bookingResource = new BookingResource<>(booking);
		createHateoasLinks(bookingResource, booking, bookingIdentifier);

		logger.info("method End: getBooking()");
		return new ResponseEntity<>(bookingResource, HttpStatus.OK);
	}
	
	@GetMapping(value = "/bookings", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BookingResource<Bookings>> getBookings(
			@RequestParam(value = "firstname", required=false) final String firstName,
			@RequestParam(value = "bid", required=false) final String bID,
			@RequestParam(value = "familyname", required=false) final String familyName,
			@RequestParam(value = "identifiertype", required=false) final String identifierType,
			@RequestParam(value = "token", required=false) final String token,
			@RequestParam(value = "flightnumber", required=false) final String flightNumber,
			@RequestParam(value = "destination", required=false) final String destination,
			@RequestHeader final Map<String, String> headerValueMap) {
		logger.info("method start: getBooking(), Booking-Identifier: {}");
		
		/*System.out.println("QueryParams "
				+ "\n" + "firstName = " + firstName
				+ "\n" + "familyName = " + familyName
				+ "\n" + "identifierType = " + identifierType
				+ "\n" + "token = " + token
				+ "\n" + "flightNumber = " + flightNumber
				+ "\n" + "destination = " + destination);*/

		BookingSearchCriteria bookingSearchCriteria = populateBookingSearchCriteria(firstName, familyName, identifierType, token, flightNumber, destination, bID);
		List<Booking> bookingsResponse = bookingService.getBookings(bookingSearchCriteria, populateHeader(headerValueMap));
		Bookings bookings = new Bookings.BookingsBuilder(bookingsResponse, bookingsResponse.size()).build();
		BookingResource<Bookings> bookingResource = new BookingResource<>(bookings);
		createHateoasLinksForBookings(bookingResource, bookings, firstName);
		logger.info("method End: getBooking()");
		return new ResponseEntity<>(bookingResource, HttpStatus.OK);
	}


	private BookingSearchCriteria populateBookingSearchCriteria(String firstName, String familyName, String identifierType, String token,
			String flightNumber, String destination, String bID) {
		BookingSearchCriteria bookingSearchCriteria = new BookingSearchCriteria();
		bookingSearchCriteria.setFamilyName(familyName);
		bookingSearchCriteria.setFirstName(firstName);
		bookingSearchCriteria.setIdentifierType(identifierType);
		bookingSearchCriteria.setToken(token);
		bookingSearchCriteria.setFlightNumber(flightNumber);
		bookingSearchCriteria.setDestination(destination);
		bookingSearchCriteria.setBookingIdentifier(bID);
		return bookingSearchCriteria;
		
	}



	private void createHateoasLinks(com.iag.domain.model.booking.BookingResource<Booking> bookingResource,
			Booking booking, String bookingIdentifier) {
		bookingResource.add(linkTo(BookingController.class).slash(BOOKINGS).slash(bookingIdentifier).withRel(_SELF));
		bookingResource.add(linkTo(BookingController.class).slash(BOOKINGS).slash(bookingIdentifier).slash(PASSENGERS)
				.withRel(ALL_PASSENGERS));
	}
	
	private void createHateoasLinksForBookings(com.iag.domain.model.booking.BookingResource<Bookings> bookingResource,
			Bookings booking, String bookingIdentifier) {
		bookingResource.add(linkTo(BookingController.class).slash(BOOKINGS).slash(bookingIdentifier).withRel(_SELF));
		bookingResource.add(linkTo(BookingController.class).slash(BOOKINGS).slash(bookingIdentifier).slash(PASSENGERS)
				.withRel(ALL_PASSENGERS));
	}

	private Session populateHeader(final Map<String, String> headerValueMap) {
		Session session = new Session();
		if (headerValueMap != null) {
			session.setSessionIdentifier(headerValueMap.get(SESSION_IDENTIFIER));
			session.setTokenNumber(headerValueMap.get(TOKEN_NUMBER));
			session.setLocation(headerValueMap.get(LOCATION));
			session.setChannel(headerValueMap.get(CHANNEL));
			session.setScope(headerValueMap.get(SCOPE));
			session.setStatus(headerValueMap.get(STATUS));
			/*System.out.println("Ankur Session = "+ 
			session.getChannel() + 
			session.getTokenNumber()+
			session.getLocation() + 
			session.getScope() + 
			session.getStatus() + 
			session.getSessionIdentifier());*/
		}
		return session;
	}

}