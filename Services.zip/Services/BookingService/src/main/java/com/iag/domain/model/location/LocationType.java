package com.iag.domain.model.location;

public enum LocationType {
  COUNTRY,STATE,COUNTY,CITY,AIRPORT,STATION
}
