package com.iag.business.checkin.repository;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amadeus.xml.cregrq_16_2_1a.DCSACCCheckRegulatoryRqts;
import com.amadeus.xml.cregrr_16_2_1a.DCSACCCheckRegulatoryRqtsReply;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.domain.response.CheckInValidation;
import com.iag.business.checkin.domain.response.ValidationOutcome;
import com.iag.business.checkin.mapper.CheckInValidationRequestMapper;
import com.iag.business.checkin.mapper.CheckInValidationResponseMapper;
import com.iag.business.checkin.proxy.config.ServiceProxy;
import com.iag.business.checkin.session.AmadeusSession;
import com.iag.domain.model.CheckIn;

/**
 * 
 * Repository class to call Amadeus Service and convert it into
 * CheckInValidation object
 *
 */
@Repository
public class CheckInValidationRepository {

	private static final Logger logger = LoggerFactory.getLogger(CheckInValidationRepository.class);

	@Autowired
	private CheckInValidationRequestMapper checkInValidationRequestMapper;

	@Autowired
	private CheckInValidationResponseMapper checkInValidationResponseMapper;

	@Autowired
	private ServiceProxy configurationInfrastructureServiceProxy;

	@Autowired
	AmadeusWebServiceGateway amadeusWebServiceGateway;

	/**
	 * Returns CheckInValidation object as response
	 * 
	 * @param bookingIdentifier
	 *            -booking identifier received in URI Param
	 * @param session
	 *            - session object
	 * @param checkIn
	 *            - checkIn object
	 * @return
	 */
	public CheckInValidation checkInValidation(String bookingIdentifier, AmadeusSession session, CheckIn checkIn) {
		logger.info("method start: checkInValidation(), bookingIdentifier: {} ", bookingIdentifier);
		CheckInValidation checkInValidation = null;
		ValidationOutcome validationOutcomeOperational = null;
		if (checkIn.getFlightSegments() != null && !checkIn.getFlightSegments().isEmpty()) {
			validationOutcomeOperational = performOperationalCheck(checkIn);
			checkInValidation = new CheckInValidation();
			List<ValidationOutcome> validationOutcomesList = new ArrayList<>();
			validationOutcomesList.add(validationOutcomeOperational);
			checkInValidation.setValidationOutcomes(validationOutcomesList);
			checkInValidation.setTotalRecords(validationOutcomesList.size());
			if (CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_FAILURE.equals(validationOutcomeOperational.getResult())) {
				return checkInValidation;
			}
		}
		if (checkIn.getPassengers() != null && !checkIn.getPassengers().isEmpty()) {
			DCSACCCheckRegulatoryRqts request = checkInValidationRequestMapper.map(checkIn);
			String amadeusUrl = configurationInfrastructureServiceProxy.retrieveConfiguration(
					CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY);
			DCSACCCheckRegulatoryRqtsReply dcsaccCheckRegulatoryRqtsReply = (DCSACCCheckRegulatoryRqtsReply) amadeusWebServiceGateway
					.getWebServiceResponseForCheckInValidation(request, amadeusUrl, session);
			checkInValidation = checkInValidationResponseMapper.map(dcsaccCheckRegulatoryRqtsReply);
			if (validationOutcomeOperational != null) {
				checkInValidation.getValidationOutcomes().add(validationOutcomeOperational);
				checkInValidation.setTotalRecords(checkInValidation.getValidationOutcomes().size());
			}

		} else {
			return checkInValidation;
		}
		logger.info("method end: checkInValidation()");
		return checkInValidation;

	}
	/**
	 * Perform operational check
	 * 
	 * @param  CheckIn
	 * @return ValidationOutcome
	 */
	public ValidationOutcome performOperationalCheck(CheckIn checkIn) {
		logger.info("method start: performOperationalCheck()");

		ValidationOutcome validationOutcome = null;

		if (checkIn.getFlightSegments().get(0).getFlightLegs().get(0).getOrigin().getIdentifier()
				.equalsIgnoreCase(checkIn.getKioskLocation().getIdentifier())
				&& checkIn.getFlightSegments().get(0).getFlightLegs().get(0).getOrigin().getTerminal()
						.equalsIgnoreCase(checkIn.getKioskLocation().getTerminal())) {

			validationOutcome = new ValidationOutcome();

			validationOutcome.setCode(configurationInfrastructureServiceProxy.retrieveConfiguration(
					CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
					CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
							+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_CODE_KEY));
			validationOutcome.setDescription(configurationInfrastructureServiceProxy.retrieveConfiguration(
					CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
					CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
							+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_DESCRIPTION_KEY));
			validationOutcome.setValidationType(CheckInValidationConstants.VALIDATION_TYPE_OPERATIONAL);
			validationOutcome.setResult(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_SUCCESS);

		} else {
			validationOutcome = new ValidationOutcome();

			validationOutcome.setCode(configurationInfrastructureServiceProxy.retrieveConfiguration(
					CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
					CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
							+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_FAILURE_CODE_KEY));
			validationOutcome.setDescription(configurationInfrastructureServiceProxy.retrieveConfiguration(
					CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
					CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
							+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_FAILURE_DESCRIPTION_KEY));
			validationOutcome.setValidationType(CheckInValidationConstants.VALIDATION_TYPE_OPERATIONAL);
			validationOutcome.setResult(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_FAILURE);

		}
		logger.info("method end: performOperationalCheck()");
		return validationOutcome;

	}

}
