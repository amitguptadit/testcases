package com.iag.business.checkin.controller;

import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.domain.response.CheckInValidation;
import com.iag.business.checkin.service.CheckInValidationService;
import com.iag.business.checkin.session.AmadeusSession;
import com.iag.business.checkin.validation.CheckInValidator;
import com.iag.domain.model.CheckIn;

/**
 * 
 * Controller to intercept Check-in validation request
 *
 */
@RestController
public class CheckInValidationController {

	private static final Logger logger = LoggerFactory.getLogger(CheckInValidationController.class);

	private static final String BOOKING_IDENTIFIER = "booking-identifier";

	@Autowired
	private CheckInValidationService checkInValidationService;

	@Autowired
	private CheckInValidator checkInValidator;

	@Autowired
	private AmadeusSession amadeusSession;

	/**
	 * This service allows service consumer to manage Check-In resource
	 * 
	 * @param bookingIdentifier
	 * @param headerValueMap
	 * @param requestHeaderMap
	 * @param checkIn-
	 *            CheckIn Object consisting of passenger(s) , flightSegment(s)
	 * @return - CheckInValidation
	 */

	@PostMapping(value = "/bookings/{" + BOOKING_IDENTIFIER + "}" + "/check-ins/validations", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<CheckInValidation> checkInValidation(
			@PathVariable(value = "booking-identifier") String bookingIdentifier,
			@RequestHeader final Map<String, String> headerValueMap, @RequestBody CheckIn checkIn) {

		logger.info("method start: checkInValidation(), bookingIdentifier: {}", bookingIdentifier);
		populateHeader(headerValueMap);
		checkInValidator.validate(bookingIdentifier, checkIn, headerValueMap);
		CheckInValidation checkInValidation = checkInValidationService.checkInValidation(bookingIdentifier,
				amadeusSession, checkIn);
		logger.info("method end: checkInValidation()");

		return Optional.ofNullable(checkInValidation)
				.map(checkInValidationResponse -> new ResponseEntity<>(checkInValidationResponse, HttpStatus.CREATED))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	/**
	 * populateHeader method used to populate Amadeus session from header
	 * 
	 * @param headerValueMap
	 * @return amadeusSession
	 */
	private AmadeusSession populateHeader(final Map<String, String> headerValueMap) {
		amadeusSession.setSessionId(headerValueMap.get(CheckInValidationConstants.SESSIONID));
		amadeusSession.setSequenceNumber(headerValueMap.get(CheckInValidationConstants.SEQUENCENUMBER));
		amadeusSession.setSecurityToken(headerValueMap.get(CheckInValidationConstants.SECURITY_TOKEN));
		amadeusSession.setLocation(headerValueMap.get(CheckInValidationConstants.LOCATION));
		amadeusSession.setChannel(headerValueMap.get(CheckInValidationConstants.CHANNEL));
		amadeusSession.setScope(headerValueMap.get(CheckInValidationConstants.SCOPE));
		return amadeusSession;
	}
}
