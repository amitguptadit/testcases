package com.iag.business.checkin.repository;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;

/**
 * AmadeusHeaderClientInterceptor class is responsible for generating SOAP
 * request header.
 */
public class AmadeusHeaderClientInterceptor implements ClientInterceptor {

	private static final Logger logger = LoggerFactory.getLogger(AmadeusHeaderClientInterceptor.class);

	@Override
	public boolean handleFault(final MessageContext messageContext) {
		return true;
	}

	/**
	 * This method is to intercept the webservice request and create a soap
	 * header into it.
	 */
	@Override
	public boolean handleRequest(final MessageContext messageContext) {
		try {
			logger.debug("creating the soap header");
			logger.debug("### SOAP REQUEST ###");
			try {
				ByteArrayOutputStream buffer = new ByteArrayOutputStream();
				messageContext.getRequest().writeTo(buffer);
				String payload = buffer.toString(java.nio.charset.StandardCharsets.UTF_8.name());
				logger.debug((payload));
			} catch (IOException e) {
				throw new WebServiceClientException("Can not write the SOAP request into the out stream", e) {
					private static final long serialVersionUID = -7118480620416458069L;
				};
			}
		} catch (Exception e) {
			logger.error(
					"Error while creating the soap header in handleRequest() in AmadeusHeaderClientInterceptor");
			logger.error("Error while creating the soap header in handleRequest() in AmadeusHeaderClientInterceptor : {}",
					e);
			return false;
		}
		return true;
	}

	public void afterCompletion(MessageContext arg0, Exception arg1) throws WebServiceClientException {
		logger.debug("completed");
	}

	@Override
	public boolean handleResponse(MessageContext messageContext) throws WebServiceClientException {
		try {
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();
			messageContext.getResponse().writeTo(buffer);
			String payload = buffer.toString(java.nio.charset.StandardCharsets.UTF_8.name());
			logger.debug((payload));
		} catch (IOException e) {
			throw new WebServiceClientException("Can not write the SOAP response into the out stream", e) {
				private static final long serialVersionUID = -7118480620416458069L;
			};
		}
		return true;
	}

}
