package com.iag.business.checkin;

import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health.Builder;

/**
 * ApplicationHealthIndicator is responsible for checking health status of
 * application.
 */
public class ApplicationHealthIndicator extends AbstractHealthIndicator {

	@Override
	protected void doHealthCheck(final Builder builder) {
		builder.up();

	}

}
