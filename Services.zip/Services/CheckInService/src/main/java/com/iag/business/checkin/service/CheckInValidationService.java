package com.iag.business.checkin.service;

import org.springframework.stereotype.Service;

import com.iag.business.checkin.domain.response.CheckInValidation;
import com.iag.business.checkin.session.AmadeusSession;
import com.iag.domain.model.CheckIn;

/**
 * 
 * Defines contract to retrieve CheckInValidation from supplied
 * bookingIdentifier , Session and CheckIn .
 */
@Service
public interface CheckInValidationService {

	/**
	 * returns Instance of CheckInValidation as response from Amadeus
	 * 
	 * @param bookingIdentifier
	 * @param session
	 * @param checkIn
	 * @return CheckInValidation
	 */
	public CheckInValidation checkInValidation(String bookingIdentifier, AmadeusSession session, CheckIn checkIn);
}
