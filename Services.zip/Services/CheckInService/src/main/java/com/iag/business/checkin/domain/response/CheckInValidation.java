package com.iag.business.checkin.domain.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * Response object for check-in validation service response
 *
 */
public class CheckInValidation {

	@JsonProperty("total-records")
	private int totalRecords;

	@JsonProperty("validation-outcomes")
	private List<ValidationOutcome> validationOutcomes;

	/**
	 * @return the totalRecords
	 */
	public int getTotalRecords() {
		return totalRecords;
	}

	/**
	 * @param totalRecords
	 *            the totalRecords to set
	 */
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}

	/**
	 * @return the validationOutcomes
	 */
	public List<ValidationOutcome> getValidationOutcomes() {
		return validationOutcomes;
	}

	/**
	 * @param validationOutcomes
	 *            the validationOutcomes to set
	 */
	public void setValidationOutcomes(List<ValidationOutcome> validationOutcomes) {
		this.validationOutcomes = validationOutcomes;
	}

	@Override
	public String toString() {
		return "CheckInValidation [totalRecords=" + totalRecords + ", validationOutcomes=" + validationOutcomes + "]";
	}

}
