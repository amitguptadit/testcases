package com.iag.business.checkin.validation;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.exception.ValidationServiceExceptionGenerator;
import com.iag.business.checkin.validation.OperationalCheckValidation;
import com.iag.domain.model.CheckIn;

/**
 * Class to validate attributes required for check-in validation service
 *
 */
@Component
public class CheckInValidator {

	private static final Logger logger = LoggerFactory.getLogger(CheckInValidator.class);
	private final BookingIdentifierValidation bookingIdentifierValidation;

	private final HeaderValidation headerValueMapValidation;
	private final OperationalCheckValidation opertaionalCheckValidation;

	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	/**
	 * Constructor to initialize class attributes.
	 * 
	 * @param bookingIdentifierValidation
	 * @param validationServiceExceptionGenerator
	 * @param headerValueMapValidation
	 * @param opertaionalCheckValidation
	 * 
	 */
	@Autowired
	public CheckInValidator(final BookingIdentifierValidation bookingIdentifierValidation,
			ValidationServiceExceptionGenerator validationServiceExceptionGenerator,

			HeaderValidation headerValueMapValidation, OperationalCheckValidation opertaionalCheckValidation) {

		this.bookingIdentifierValidation = bookingIdentifierValidation;
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
		this.headerValueMapValidation = headerValueMapValidation;
		this.opertaionalCheckValidation = opertaionalCheckValidation;

	}

	/**
	 * Throws validation exception when there is any violation of required
	 * fields or rule
	 * 
	 * @param bookingIdentifier
	 *            - booking identifier
	 * @param checkIn
	 *            - CheckIn object
	 * @param headerValueMap
	 */
	public void validate(final String bookingIdentifier, final CheckIn checkIn,
			final Map<String, String> headerValueMap) {

		logger.info("method start: validate(), bookingIdentifier: {}", bookingIdentifier);

		List<ValidationServiceException> validationServiceExceptionlist = Lists.newArrayList();
		validationServiceExceptionlist.addAll(opertaionalCheckValidation.validate(checkIn));
		validationServiceExceptionlist.add(bookingIdentifierValidation.validate(bookingIdentifier));
		validationServiceExceptionlist.add(headerValueMapValidation.validate(headerValueMap));
		validationServiceExceptionlist.removeAll(Collections.singleton(null));
		if (!validationServiceExceptionlist.isEmpty()) {
			logger.error("Request validation exception occured.");
			throw validationServiceExceptionGenerator
					.createServiceExceptionWithChildError(validationServiceExceptionlist);
		}

		logger.info("method end: validate()");
	}

}
