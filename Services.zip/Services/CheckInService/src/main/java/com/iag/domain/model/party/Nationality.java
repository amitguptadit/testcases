
package com.iag.domain.model.party;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "type",
    "identifier"
})
public class Nationality {

    /**
     * COUNTY, COUNTRY of the area/region.
     * (Required)
     * 
     */
    @JsonProperty("type")
    @JsonPropertyDescription("COUNTY, COUNTRY of the area/region.")
    private String type;
    /**
     * ISO 3166-1 code for the country. Is a 2 letter code specific to a country.e.g. GB, ES, IN etc.
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    @JsonPropertyDescription("ISO 3166-1 code for the country. Is a 2 letter code specific to a country.e.g. GB, ES, IN etc.")
    private String identifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * COUNTY, COUNTRY of the area/region.
     * (Required)
     * 
     */
    @JsonProperty("type")
    public String getType() {
        return type;
    }

    /**
     * COUNTY, COUNTRY of the area/region.
     * (Required)
     * 
     */
    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    public Nationality withType(String type) {
        this.type = type;
        return this;
    }

    /**
     * ISO 3166-1 code for the country. Is a 2 letter code specific to a country.e.g. GB, ES, IN etc.
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    public String getIdentifier() {
        return identifier;
    }

    /**
     * ISO 3166-1 code for the country. Is a 2 letter code specific to a country.e.g. GB, ES, IN etc.
     * (Required)
     * 
     */
    @JsonProperty("identifier")
    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public Nationality withIdentifier(String identifier) {
        this.identifier = identifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Nationality withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(type).append(identifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Nationality) == false) {
            return false;
        }
        Nationality rhs = ((Nationality) other);
        return new EqualsBuilder().append(type, rhs.type).append(identifier, rhs.identifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
