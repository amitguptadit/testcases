package com.iag.business.checkin.validation;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.iag.business.checkin.application.error.MessageConstants;
import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.exception.ValidationServiceExceptionGenerator;

/**
 * HeaderValueMap Validation is used for validating request header.
 *
 */

@Component
public class HeaderValidation {

	private static final Logger logger = LoggerFactory.getLogger(HeaderValidation.class);
	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	/**
	 * @param validationServiceExceptionGenerator
	 */
	@Autowired
	public HeaderValidation(final ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * @param validationServiceExceptionList
	 * @param passengerIdentifier
	 * @return
	 */
	public ValidationServiceException validate(final Map<String, String> headerValueMap) {
		logger.info("start method:validate(), headerValueMap: {}", headerValueMap);
		ValidationServiceException headerValidationServiceException = null;
		if (CollectionUtils.isEmpty(headerValueMap)) {
			headerValidationServiceException = createValidationError(CheckInErrorCode.MANDATORY_DATA_MISSING.name());
		}
		logger.info("end method:validate()");
		return headerValidationServiceException;
	}

	private ValidationServiceException createValidationError(String errorCode) {
		return validationServiceExceptionGenerator.createValidationError(errorCode,
				CheckInValidationConstants.HEADERVALUE_PATH,
				MessageConstants.CHECKINVALIDATION_ERROR + errorCode + CheckInValidationConstants.DEVMSG_HEADERVALUE);

	}

}
