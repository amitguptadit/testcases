package com.iag.business.checkin.validation;

import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.exception.ValidationServiceExceptionGenerator;

/**
 * Class to validate Booking identifier
 *
 */
@Component
public class BookingIdentifierValidation {
	private static final Logger logger = LoggerFactory.getLogger(BookingIdentifierValidation.class);
	private final ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	/**
	 * @param validationServiceExceptionGenerator
	 */
	@Autowired
	public BookingIdentifierValidation(final ValidationServiceExceptionGenerator validationServiceExceptionGenerator) {
		this.validationServiceExceptionGenerator = validationServiceExceptionGenerator;
	}

	/**
	 * Returns ValidationServiceException instance when there is any mismatch in
	 * specified regex and Booking identifier received in URI param or when
	 * booking identifier is null
	 * 
	 * @param validationServiceExceptionList
	 * @param bookingIdentifier
	 * @return
	 */
	public ValidationServiceException validate(final String bookingIdentifier) {
		logger.info("method start: validate() , bookingIdentifier: {}", bookingIdentifier);
		ValidationServiceException bookingValidationServiceException = null;
		Pattern bookingIdentifierMatcher = Pattern.compile(CheckInValidationConstants.BOOKING_IDENTIFIER_PATTERN);
		if (!bookingIdentifierMatcher.matcher(bookingIdentifier).matches()) {
			bookingValidationServiceException = validationServiceExceptionGenerator.createValidationError(
					CheckInErrorCode.DATA_INVALID.name(), CheckInValidationConstants.BOOKING_IDENTIFIER_PATH,
					CheckInValidationConstants.DEVELOPER_MESSAGE_BOOKING_IDENTIFIER);
		}
		logger.info("end method:validate()");
		return bookingValidationServiceException;
	}
}
