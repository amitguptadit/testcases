package com.iag.business.checkin;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.URIException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.transport.http.CommonsHttpMessageSender;

import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.proxy.config.ServiceProxy;
import com.iag.business.checkin.repository.AmadeusHeaderClientInterceptor;

@Configuration
public class AmedeusConnectorConfig {

	@Autowired
	private ServiceProxy configurationInfrastructureServiceProxy;

	private static final Logger logger = LoggerFactory.getLogger(AmedeusConnectorConfig.class);

	@Bean
	AmadeusHeaderClientInterceptor amadeusHeaderClientInterceptor() {
		return new AmadeusHeaderClientInterceptor();
	}

	/**
	 * 
	 * @return
	 * @throws URIException
	 */
	@SuppressWarnings("deprecation")
	@Bean
	public CommonsHttpMessageSender httpSender() throws URIException {
		CommonsHttpMessageSender commonsHttpMessageSender = new CommonsHttpMessageSender();
		Map<String, String> maxConnectionsPerHost = new HashMap<>();
		maxConnectionsPerHost.put(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.HTTP_SENDER_WILDCARD_HOSTS.name()),
				configurationInfrastructureServiceProxy.retrieveConfiguration(
						CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.HTTP_SENDER_MAX_HOSTS.name()));
		commonsHttpMessageSender.setAcceptGzipEncoding(true);
		commonsHttpMessageSender.setReadTimeout(Integer.parseInt(configurationInfrastructureServiceProxy
				.retrieveConfiguration(CheckInValidationConstants.AMADEUS_NAMESPACE,
						CheckInErrorCode.HTTP_SENDER_READ_TIME_OUT.name())));
		commonsHttpMessageSender.setConnectionTimeout(Integer.parseInt(configurationInfrastructureServiceProxy
				.retrieveConfiguration(CheckInValidationConstants.AMADEUS_NAMESPACE,
						CheckInErrorCode.HTTP_SENDER_CONNECTOR_TIME_OUT.name())));
		commonsHttpMessageSender.setMaxConnectionsPerHost(maxConnectionsPerHost);
		return commonsHttpMessageSender;
	}

	/**
	 * 
	 * @param amadeusMarshaller
	 * @param amadeusUnMarshaller
	 * @param httpSender
	 * @return
	 */
	@Bean
	public WebServiceTemplate amadeusWebServiceTemplate(Jaxb2Marshaller amadeusMarshaller,
			Jaxb2Marshaller amadeusUnMarshaller, CommonsHttpMessageSender httpSender) {
		ClientInterceptor[] clientInterceptors = { amadeusHeaderClientInterceptor() };
		CommonsHttpMessageSender[] httsenders = { httpSender };
		WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
		webServiceTemplate.setMarshaller(amadeusMarshaller);
		webServiceTemplate.setUnmarshaller(amadeusUnMarshaller);
		webServiceTemplate.setMessageSenders(httsenders);
		webServiceTemplate.setInterceptors(clientInterceptors);
		webServiceTemplate.setDefaultUri(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.DEFAULT_URL_KEY));
		return webServiceTemplate;

	}

	/**
	 * Method o marshall Request object to XML
	 * 
	 * @return
	 */
	@Bean
	public Jaxb2Marshaller amadeusMarshaller() {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		logger.info("amadeusMarshaller method invoking");
		jaxb2Marshaller.setContextPaths(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE,
				CheckInValidationConstants.CHECKIN_VALIDATION_MARSHALLER_KEY));
		Map<String, Boolean> marshallerProperties = new HashMap<>();
		marshallerProperties.put(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		return jaxb2Marshaller;
	}

	/**
	 * Method to unmarshall amadeus XML response to Java Object
	 * 
	 * @return
	 */
	@Bean
	public Jaxb2Marshaller amadeusUnMarshaller() {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		logger.info("amadeusUnMarshaller method invoking");
		jaxb2Marshaller.setContextPaths(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE,
				CheckInValidationConstants.CHECKIN_VALIDATION_UNMARSHALLER_KEY));
		Map<String, Boolean> marshallerProperties = new HashMap<>();
		marshallerProperties.put(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		return jaxb2Marshaller;
	}

}
