package com.iag.domain.model.address;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.iag.domain.model.location.Location;
import com.iag.domain.model.utility.ToStringBuilder;

/**
 * PostalAddress class represents postal address which could be of various types such as
 * Temporary, Business, Home postal addresses.
 * @param addressLines : List of address lines in String.
 * @param city : String city corresponding to this {@link Address}.
 * @param postCode : String post code corresponding to this {@link Address}.
 * @param country : It represents {@link Location} information.
 * @param state : It represents {@link Location} information.
 * @param city : It represents {@link Location} information.
 * @param county : It represents {@link Location} information.
 * @param companyName : Name of the company if its a company address.
 * @param placeType :it represents(@link PostalAddressType) information.
 */
public class PostalAddress extends Address implements Serializable {
  private String[] addressLines;
  private String postCode;
  private String country;
  private String city;
  private String state;
  private String county;

  /**
   * private default constructor helps to create instances of this class at runtime by frameworks
   * like jaxb.
   */
  public PostalAddress() {
  }

  /**
   * Class can not be directly instantiated from the client code.
   * @param builder
   */
  private PostalAddress(final PostalAddressBuilder builder) {
    this();
    this.addressLines = builder.addressLines;
    this.city = builder.city;
    this.postCode = builder.postCode;
    this.country = builder.country;
    this.state = builder.state;
    this.county = builder.county;
  }

  public String getCountry() {
    return country;
  }

  public String[] getAddressLines() {
    return addressLines;
  }

  public String getCity() {
    return city;
  }

  public String getPostCode() {
    return postCode;
  }

  public String getState() {
    return state;
  }

  public String getCounty() {
    return county;
  }



  /**
   * Builder Class of PostalAddress which allows fields to be populated
   * optionally,making PostalAddress immutable at the same time.
   */
  public static class PostalAddressBuilder {

    public String county;
	private String[] addressLines;
    private String country;
    private String city;
    private String state;
    private String postCode;
    
    public PostalAddressBuilder setCounty(String county) {
		this.county = county;
		return this;
	}
    /**
     * Builder constructor only receives the required attributes.
     * @param addressLines
     * @param postCode
     * @param country
     * @param placeType
     */
    public PostalAddressBuilder(final String[] addressLines, final String country) {
      this.addressLines = addressLines;
      this.country = country;
    }

    /**
     * Initialise optional attributes city.
     * @param cityOfAddress
     * @return
     */
    public PostalAddressBuilder setCity(final String cityOfAddress) {
      this.city = cityOfAddress;
      return this;
    }

    /**
     * Initialise optional attributes state.
     * @param state
     * @return
     */
    public PostalAddressBuilder setState(final String state) {
      this.state = state;
      return this;
    }
    
    /**
     * Initialise optional attributes state.
     * @param state
     * @return
     */
    public PostalAddressBuilder setPostalCode(final String postalCode) {
      this.postCode = postalCode;
      return this;
    }

    
    /**
     * Method finally returns the built instance.
     * @return
     */
    public PostalAddress build() {
      return new PostalAddress(this);
    }

  }

  @Override
  public int hashCode() {
    return HashCodeBuilder.reflectionHashCode(this);
  }

  @Override
  public boolean equals(final Object obj) {
    return EqualsBuilder.reflectionEquals(this, obj);
  }

  @Override
  public String toString() {
    return ToStringBuilder.generateToString(this);
  }

}
