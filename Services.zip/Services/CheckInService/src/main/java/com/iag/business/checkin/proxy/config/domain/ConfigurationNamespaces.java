package com.iag.business.checkin.proxy.config.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * Create ConfigurationNamespaces 
 *
 */
public class ConfigurationNamespaces {

	private String name;
	private List<ConfigurationItems> configurationItems = new ArrayList<>();
	private List<ConfigurationNamespace> configurationNamespaceList;

	public String getName() {
		return name;
	}

	public List<ConfigurationNamespace> getConfigurationNamespaces() {
		return configurationNamespaceList;
	}

	public void setConfigurationNamespaces(List<ConfigurationNamespace> configurationNamespaces) {
		this.configurationNamespaceList = configurationNamespaces;
	}

	public void setConfigurationItems(List<ConfigurationItems> configurationItems) {
		this.configurationItems = configurationItems;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ConfigurationItems> getConfigurationItems() {
		return configurationItems;
	}

	@Override
	public String toString() {
		return "ConfigurationNamespaces [name=" + name + ", configurationItems=" + configurationItems
				+ ", configurationNamespaces=" + configurationNamespaceList + "]";
	}

}
