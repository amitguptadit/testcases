package com.iag.business.checkin.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iag.business.checkin.domain.response.CheckInValidation;
import com.iag.business.checkin.repository.CheckInValidationRepository;
import com.iag.business.checkin.session.AmadeusSession;
import com.iag.domain.model.CheckIn;

/**
 * CheckInValidationService Implementation class to get CheckInValidation Object
 * 
 * @see CheckInValidationRepository
 * 
 */
@Service
public class CheckInValidationServiceImpl implements CheckInValidationService {

	private static final Logger logger = LoggerFactory.getLogger(CheckInValidationServiceImpl.class);

	@Autowired
	private CheckInValidationRepository checkInRepository;

	/**
	 * It calls CheckInRepository to get CheckInValidation object.
	 * 
	 * @param bookingIdentifier
	 *            -booking identifier received in URI Param
	 * @param Session
	 *            - session object
	 * @param CheckIn
	 *            - checkIn object
	 * @return CheckInValidation - checkInValidation object
	 */
	@Override
	public CheckInValidation checkInValidation(String bookingIdentifier, AmadeusSession session, CheckIn checkIn) {
		logger.info("method start : checkInValidation(), bookingIdentifier: {}", bookingIdentifier);
		return checkInRepository.checkInValidation(bookingIdentifier, session, checkIn);
	}

}
