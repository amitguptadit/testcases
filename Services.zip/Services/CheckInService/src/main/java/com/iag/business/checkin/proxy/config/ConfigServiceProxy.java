package com.iag.business.checkin.proxy.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.iag.business.checkin.application.exception.ApplicationServiceException;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.proxy.config.domain.Configuration;
import com.iag.business.checkin.proxy.config.domain.ConfigurationNamespaces;

/**
 * 
 * Class to retrieve Configuration messages in serviceErrorMap(key,value) from
 * configuration service API on post construct
 *
 */
@Component
public class ConfigServiceProxy implements ServiceProxy {
	private static final Logger logger = LoggerFactory.getLogger(ConfigServiceProxy.class);

	private Map<String, String> serviceConfigMap = new HashMap<>();
	private final Map<String, Map<String, String>> configNamespacesMap = new ConcurrentHashMap<>();

	private final ServiceUrlGenerator serviceUrlGenerator;
	private final String configurationServiceName;
	private final RestTemplate restTemplate;

	private static final String CONFIGURATION_SERVICE_URL = "/configurations";
	public static final String IDENTIFIER_KEY = "identifier";

	public static final String RESOURCE_KEY_IDENTIFIER = "resource";
	public static final String VERSION = "version";

	private final List<HttpStatus> ignoredStatusCodes = Lists.newArrayList();

	private final String configurationIdentifierKey;

	private final String configurationResourceKey;

    /*
	 * 
	 * ConfigServiceProxy constructor
	 * @param serviceName
	 * @param restTemplate
	 * @param serviceUrlGenerator
	 *
	 */
	@Autowired
	public ConfigServiceProxy(@Value("${configuration.service.name}") final String serviceName,
			final RestTemplate restTemplate, final ServiceUrlGenerator serviceUrlGenerator,@Value("${checkin.configuration.resource}") final String configurationResourceKeyIdentifier,
			@Value("${checkin.configuration.identifier}") final String configurationIdentifierKey)

	{
		ignoredStatusCodes.add(HttpStatus.NOT_FOUND);
		this.configurationServiceName = serviceName;
		this.restTemplate = restTemplate;
		this.serviceUrlGenerator = serviceUrlGenerator;
		this.configurationIdentifierKey = configurationIdentifierKey;
		this.configurationResourceKey = configurationResourceKeyIdentifier;

	}

	/**
	 * Retrieves value with respect to supplied key
	 */
	@Override
	public String retrieveConfiguration(String configurationName, String key) {
		logger.info("start method:retrieveConfiguration(), key: {}", key);
		if (configNamespacesMap.isEmpty()) {
			retrieveConfiguration();
		}
		return configNamespacesMap.get(configurationName).get(key);
	}

	/**
	 * Method to call configuration service API to retrieve configuration
	 * messages for check-in errors
	 * 
	 * Throws ApplicationServiceException when service is unavailable or request
	 * is invalid
	 * 
	 * Pending future implementation to call Configuration service from Eureka
	 * Server
	 * 
	 * @return
	 */
	void retrieveConfiguration() {
		final String url = getServiceURL() + CONFIGURATION_SERVICE_URL;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
				.queryParam(RESOURCE_KEY_IDENTIFIER, configurationResourceKey).queryParam(IDENTIFIER_KEY, configurationIdentifierKey);
		Configuration configuration = null;
		ResponseEntity<Configuration> result;
		String uri = builder.toUriString();
		logger.info("start method : retrieveConfiguration() : Calling configuration service API with URI : {}", uri);
		result = restTemplate.exchange(uri, HttpMethod.GET, null, Configuration.class);
		if (result == null || !result.getStatusCode().is2xxSuccessful()) {
			logger.error("#No Error configuration found for Check-In Validation ");
			throw new ApplicationServiceException(CheckInErrorCode.CONFIGURATION_NOT_FOUND.name());
		}
		configuration = result.getBody();
		logger.info("Recieved configuration instance: {} ", configuration);
		initializeConfigurationMap(configuration);

	}

	/**
	 * Initializes serviceErrorMap with (identifier,value) as key and value
	 * received in Configuration object returned from configuration service API
	 * 
	 * @param configuration
	 */
	private void initializeConfigurationMap(Configuration configuration) {
		List<ConfigurationNamespaces> configurationNamespaceList = configuration.getConfigurationNamespaces();
		for (ConfigurationNamespaces configurationNamespaces : configurationNamespaceList) {
			serviceConfigMap = new HashMap<>();
			configurationNamespaces.getConfigurationItems().forEach(configurationItem -> 
				serviceConfigMap.put(configurationItem.getIdentifier(), configurationItem.getValue())
			);
			configNamespacesMap.put(configurationNamespaces.getName(), serviceConfigMap);
		}
		logger.info("method initializeConfigurationMap() : serviceErrorMap initialized to : {}", serviceConfigMap);
	}

	/**
	 * 
	 * @return optionalServiceURL
	 */
	private String getServiceURL() {
		Optional<String> optionalServiceURL = Optional
				.fromNullable(serviceUrlGenerator.generateUrl(configurationServiceName));
		if (!optionalServiceURL.isPresent()) {
			logger.error("method getServiceURL() : !optionalServiceURL.isPresent()");
			throw new ApplicationServiceException(CheckInErrorCode.SYSTEM_UNAVAILABLE.name());
		}
		return optionalServiceURL.get();
	}

}
