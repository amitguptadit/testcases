package com.iag.business.checkin.proxy.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.google.common.collect.FluentIterable;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;

/**
 * This class provides functionality to generate URL by fetching information
 * from service registration server Eureka.
 */
@Component
public class ServiceUrlGenerator {

	private static final String COLON = ":";

	private static final String URL_PATH_SEPARATOR = "://";

	private static final String SCHEME = "http";

	private final EurekaClient eurekaClient;

	/**
	 * Instantiate service url generator to generate service url.
	 * 
	 * @param eurekaClient
	 */

	@Autowired
	public ServiceUrlGenerator(final EurekaClient eurekaClient) {
		this.eurekaClient = eurekaClient;
	}

	/**
	 * Generates complete service URL by consuming service name and service meta
	 * data.
	 * 
	 * @param serviceName	
	 * @return url
	 */
	public String generateUrl(final String serviceName) {
		String url = null;
		Application application = eurekaClient.getApplication(serviceName);
		if (application != null) {
			List<InstanceInfo> serviceInstances = application.getInstances();
			if (CollectionUtils.isEmpty(serviceInstances)) {
				return null;
			}
			InstanceInfo instanceInfo = FluentIterable.from(serviceInstances).first().get();
			url = SCHEME + URL_PATH_SEPARATOR + instanceInfo.getIPAddr() + COLON + instanceInfo.getPort();
		}
		return url;

	}

}
