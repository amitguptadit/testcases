package com.iag.business.checkin.exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iag.business.checkin.application.error.ContentProvider;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.proxy.config.ServiceProxy;

/**
 * Implementation of ContentProvider to support application error module.
 */
@Component
public class DefaultContentProvider implements ContentProvider {

	private final ServiceProxy configurationInfrastructureServiceProxy;

	/**
	 * Constructs ExceptionHandler instance with the supplied service proxy.
	 * 
	 * @param configurationInfrastructureServiceProxy
	 */
	@Autowired
	public DefaultContentProvider(final ServiceProxy configurationInfrastructureServiceProxy) {
		this.configurationInfrastructureServiceProxy = configurationInfrastructureServiceProxy;
	}

	/**
	 * Passing key to proxy, get value and set it in bussinesMessage,
	 * developerLink.
	 * 
	 * @param error
	 *            passing service object to method.
	 * @return String object.
	 */
	public String getContent(final String error) {

		return configurationInfrastructureServiceProxy.retrieveConfiguration(CheckInValidationConstants.ERROR_NAMESPACE,
				error);

	}
}
