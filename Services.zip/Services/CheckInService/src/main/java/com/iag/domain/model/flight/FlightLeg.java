
package com.iag.domain.model.flight;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.joda.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.iag.domain.model.Destination;
import com.iag.domain.model.Origin;
import com.iag.domain.model.adapters.JodaLocalDateTimeAdapter;
import com.iag.domain.model.adapters.JsonJodaDateTimeDeSerializer;
import com.iag.domain.model.adapters.JsonJodaDateTimeSerializer;
import com.iag.domain.model.utility.ToStringBuilder;


/**
 * A flight leg is a trip of an aircraft, from take-off to landing. It is a smaller part of an overall journey which involves landing at an intermediate airport. Each leg starts and ends at a different airport.
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "origin",
    "destination",
    "scheduledDepartureLocalDatetime",
    "scheduledArrivalLocalDatetime"
})
public class FlightLeg {

    /**
     * 
     * (Required)
     * 
     */
	private FlightLeg(){}
	
    @JsonProperty("origin")
    private Origin origin;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("destination")
    private Destination destination;
    /**
     * Scheduled departure local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.
     * (Required)
     * 
     */
    @JsonProperty("scheduledDepartureLocalDatetime")
    @JsonPropertyDescription("Scheduled departure local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.")
    @XmlJavaTypeAdapter(JodaLocalDateTimeAdapter.class)
    @JsonSerialize(using = JsonJodaDateTimeSerializer.class)
    @JsonDeserialize(using = JsonJodaDateTimeDeSerializer.class)
    private LocalDateTime scheduledDepartureLocalDatetime;
    /**
     * Scheduled arrival local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.
     * (Required)
     * 
     */
    @JsonProperty("scheduledArrivalLocalDatetime")
    @JsonPropertyDescription("Scheduled arrival local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.")
    @XmlJavaTypeAdapter(JodaLocalDateTimeAdapter.class)
    @JsonSerialize(using = JsonJodaDateTimeSerializer.class)
    @JsonDeserialize(using = JsonJodaDateTimeDeSerializer.class)
    private LocalDateTime scheduledArrivalLocalDatetime;

    public FlightLeg(FlightLegBuilder flightLegBuilder) {
    	this.origin = flightLegBuilder.origin;
        this.destination = flightLegBuilder.destination;
        this.scheduledDepartureLocalDatetime = flightLegBuilder.scheduledDepartureLocalDatetime;
        this.scheduledArrivalLocalDatetime = flightLegBuilder.scheduledArrivalLocalDatetime;
	}

	/**
     * 
     * (Required)
     * 
     */
    @JsonProperty("origin")
    public Origin getOrigin() {
        return origin;
    }

    

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("destination")
    public Destination getDestination() {
        return destination;
    }

    
    /**
     * Scheduled departure local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.
     * (Required)
     * 
     */
    @JsonProperty("scheduledDepartureLocalDatetime")
    public LocalDateTime getScheduledDepartureLocalDatetime() {
        return scheduledDepartureLocalDatetime;
    }

    

    /**
     * Scheduled arrival local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.
     * (Required)
     * 
     */
    @JsonProperty("scheduledArrivalLocalDatetime")
    public LocalDateTime getScheduledArrivalLocalDatetime() {
        return scheduledArrivalLocalDatetime;
    }
    
    
    public static class FlightLegBuilder {
    	
    	/**
         * 
         * (Required)
         * 
         */
        @JsonProperty("origin")
        private Origin origin;
        /**
         * 
         * (Required)
         * 
         */
        @JsonProperty("destination")
        private Destination destination;
        /**
         * Scheduled departure local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.
         * (Required)
         * 
         */
        @JsonProperty("scheduledDepartureLocalDatetime")
        @JsonPropertyDescription("Scheduled departure local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.")
        @XmlJavaTypeAdapter(JodaLocalDateTimeAdapter.class)
        @JsonSerialize(using = JsonJodaDateTimeSerializer.class)
        @JsonDeserialize(using = JsonJodaDateTimeDeSerializer.class)
        private LocalDateTime scheduledDepartureLocalDatetime;
        /**
         * Scheduled arrival local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.
         * (Required)
         * 
         */
        @JsonProperty("scheduledArrivalLocalDatetime")
        @JsonPropertyDescription("Scheduled arrival local date and time of flight. Format yyyy-mm-ddThh:mm:ss.ffffff, ISO-8601 calendar date format.")
        @XmlJavaTypeAdapter(JodaLocalDateTimeAdapter.class)
        @JsonSerialize(using = JsonJodaDateTimeSerializer.class)
        @JsonDeserialize(using = JsonJodaDateTimeDeSerializer.class)
        private LocalDateTime scheduledArrivalLocalDatetime;

    	
    	public FlightLegBuilder (final Origin origin, final Destination destination, 
    			final LocalDateTime  scheduledDepartureLocalDatetime, final LocalDateTime scheduledArrivalLocalDatetime){
    		this.origin = origin;
    		this.destination = destination;
    		this.scheduledDepartureLocalDatetime = scheduledDepartureLocalDatetime;
    		this.scheduledArrivalLocalDatetime = scheduledArrivalLocalDatetime;
    	}
    	
    	/**
         * Method finally returns the built instance.
         * @return
         */
        public FlightLeg build() {
          return new FlightLeg(this);
        }
    }
    
    
    @Override
    public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(final Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {
      return ToStringBuilder.generateToString(this);
    }

}
