package com.iag.business.checkin.validation;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.google.common.collect.Lists;
import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.error.matcher.CustomValidationServiceExceptionMatcher;
import com.iag.business.checkin.exception.ValidationServiceExceptionGenerator;
import com.iag.domain.model.CheckIn;

public class CheckInValidatorTest {

	@InjectMocks
	private CheckInValidator checkInValidator;

	@Mock
	private BookingIdentifierValidation mockBookingIdentifierValidation;

	@Mock
	private OperationalCheckValidation mockOperationalCheckValidation;

	@Mock
	private HeaderValidation headerValueMapValidation;

	@Mock
	CheckIn checkIn;

	@Mock
	private ValidationServiceExceptionGenerator mockValidationServiceExceptionGenerator;

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	private static final String DEV_MSG_DATA_INVALID = "Data Invalid";

	private static final String BOOKING_IDENTIFER_VALID = "TKT012345678";
	private static final String BOOKING_IDENTIFER_INVALID = "TKT01234@#$$$5678";

	List<ValidationServiceException> validationServiceExceptionlist;

	List<ValidationServiceException> serviceExceptionlist;

	Map<String, String> headerValueMap = new HashMap<>();

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		checkInValidator = new CheckInValidator(mockBookingIdentifierValidation,
				mockValidationServiceExceptionGenerator, headerValueMapValidation, mockOperationalCheckValidation);
		validationServiceExceptionlist = Lists.newArrayList();
		checkIn = new CheckIn();
	}

	@Test
	public void shouldThrowValidationServiceExceptionForOperationalCheck() {
		List<ValidationServiceException> operationalValidationServiceExceptionList = new ArrayList<>();
		
		ValidationServiceException opertaionalCheckValidationServiceException = createValidationServiceException(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.FLIGHT_SEGMENTS_PATH,
				CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING);
		operationalValidationServiceExceptionList.add(opertaionalCheckValidationServiceException);
		validationServiceExceptionlist.add(opertaionalCheckValidationServiceException);
		thrown.expect(ValidationServiceException.class);
		thrown.expect(CustomValidationServiceExceptionMatcher.hasException(opertaionalCheckValidationServiceException));
		when(mockOperationalCheckValidation.validate(checkIn)).thenReturn(operationalValidationServiceExceptionList);
		when(mockValidationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionlist))
						.thenThrow(opertaionalCheckValidationServiceException);
		checkInValidator.validate(BOOKING_IDENTIFER_INVALID, checkIn, headerValueMap);

	}
	
	@Test
	public void shouldThrowValidationServiceExceptionForInvalidBookingIdentifier() {
	
		ValidationServiceException validationServiceException = createValidationServiceException(
				CheckInErrorCode.DATA_INVALID.name(), CheckInValidationConstants.BOOKING_IDENTIFIER_PATH,
				CheckInValidationConstants.DEVELOPER_MESSAGE_BOOKING_IDENTIFIER);	
		validationServiceExceptionlist.add(validationServiceException);
		thrown.expect(ValidationServiceException.class);
		thrown.expect(CustomValidationServiceExceptionMatcher.hasException(validationServiceException));
		when(mockBookingIdentifierValidation.validate(Mockito.anyString())).thenReturn(validationServiceException);		
		when(mockValidationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionlist))
						.thenThrow(validationServiceException);
		checkInValidator.validate(BOOKING_IDENTIFER_INVALID, checkIn, headerValueMap);

	}	

	@Test
	public void shouldPassCheckInValidationSuccessfully() {

		List<ValidationServiceException> validationServiceExceptionlist = Lists.newArrayList();
		List<ValidationServiceException> operationValidationExceptionList = Lists.newArrayList() ;
		when(mockBookingIdentifierValidation.validate(Mockito.anyString())).thenReturn(null);	
		when(mockOperationalCheckValidation.validate(checkIn)).thenReturn(operationValidationExceptionList);	
		checkInValidator.validate(BOOKING_IDENTIFER_VALID, checkIn, headerValueMap);
		assertEquals(0, validationServiceExceptionlist.size());
	}

	

	public ValidationServiceException createServiceExceptionWithChildError(
			final List<ValidationServiceException> validationServiceExceptionList) {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				CheckInErrorCode.REQUEST_INVALID.name());
		for (ValidationServiceException childValidationServiceException : validationServiceExceptionList) {
			validationServiceException.addValidationException(childValidationServiceException);
		}
		return validationServiceException;
	}

	private ValidationServiceException createValidationServiceException(String parentErrorCode, String childErrorCode,
			String path) {
		ValidationServiceException validationServiceException = new ValidationServiceException(parentErrorCode);
		validationServiceException.addValidationException(createValidationServiceException(childErrorCode, path));
		return validationServiceException;
	}

	private ValidationServiceException createValidationServiceException(String childErrorCode, String path) {
		ValidationServiceException childValidationServiceException = new ValidationServiceException(childErrorCode);
		childValidationServiceException.setPath(path);
		childValidationServiceException.setDeveloperMessage(DEV_MSG_DATA_INVALID);
		return childValidationServiceException;
	}

}
