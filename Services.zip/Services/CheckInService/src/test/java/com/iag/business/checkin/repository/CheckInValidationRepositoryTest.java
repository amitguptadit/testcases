package com.iag.business.checkin.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ClassPathResource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.amadeus.xml.cregrr_16_2_1a.DCSACCCheckRegulatoryRqtsReply;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.domain.response.CheckInValidation;
import com.iag.business.checkin.mapper.CheckInValidationRequestMapper;
import com.iag.business.checkin.mapper.CheckInValidationResponseMapper;
import com.iag.business.checkin.proxy.config.ServiceProxy;
import com.iag.business.checkin.session.AmadeusSession;
import com.iag.business.checkin.utility.AmadeusConnectorServiceUtility;
import com.iag.domain.model.CheckIn;
import com.iag.domain.model.flight.FlightSegment;
import com.iag.domain.model.party.role.Passenger;

public class CheckInValidationRepositoryTest {

	private final static String BOOKING_ID1 = "CHK001PAX1S";
	public static final String VALIDATION_TYPE = "ELIGIBILITY";
	public static final String VALIDATION_TYPE_OPERATIONAL = "OPERATIONAL";
	public static final String SUCCESS_MSG = "SUCCESS";
	public static final String FAILED_MSG = "FAILURE";
	public static final String WARNING_MSG = "WARNING";

	private final static String SAMPLE_REQUEST_PAX2F = "static/Json/amadeus_sample_request_PAX2F.json";
	private final static String SAMPLE_REQUEST_PAX2S = "static/Json/amadeus_sample_request_PAX2S.json";
	private final static String SAMPLE_REQUEST_PAX1F = "static/Json/amadeus_sample_request_PAX1F.json";
	private final static String SAMPLE_REQUEST_PAX1S = "static/Json/amadeus_sample_request_PAX1S.json";
	private final static String SAMPLE_REQUEST_PAX1ERRORWARNING = "static/Json/amadeus_sample_request_error_warning.json";

	private final static String SAMPLE_REQUEST_1 = "static/Json/sampleRequest_1.json";

	private final static String CHK001PAX2S = "CHK001PAX2S";
	private final static String CHK001PAX1F = "CHK001PAX1F";
	private final static String CHK001PAX2SF = "CHK001PAX2SF";
	private final static String CHK001PAX2F = "CHK001PAX2F";

	private static final String SECURITY_TOKEN = "2Y4BVG37P16P42HTA1YFUH5ZBE";

	private static final String SESSION_ID = "02WQO94SAI";

	@Mock
	private AmadeusConnectorServiceUtility amadeusConnectorServiceUtility;

	@Rule
	public final ExpectedException exception = ExpectedException.none();

	private static final String AMADEUS_PAX2S_JSON = "mock_response/amadeus_PAX2S.json";
	private static final String AMADEUS_PAX1F_JSON = "mock_response/amadeus_PAX1F.json";
	private static final String AMADEUS_PAX2F_JSON = "mock_response/amadeus_PAX2F.json";
	private static final String AMADEUS_PAX1S_JSON = "mock_response/amadeus_PAX1S.json";
	private static final String AMADEUS_ERROR_WARNING_JSON = "mock_response/amadeus_error_warning.json";
	private static final String DESCRIPTION_SUCCESS = "DESCRIPTION_SUCCESS";
	private static final String DESCRIPTION_FAILURE = "DESCRIPTION_FAILURE";
	private static final String CODE_SUCCESS = "CODE_SUCCESS";
	private static final String CODE_FAILURE = "CODE_SUCCESS";

	@InjectMocks
	private CheckInValidationRepository checkInRepository;

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	AmadeusSession session;

	CheckIn checkIn2PAXF;

	CheckIn checkIn;

	CheckIn checkInPAX2S;

	CheckIn checkInPAX1F;

	@Mock
	Jaxb2Marshaller amadeusMarshaller;

	@Mock
	Jaxb2Marshaller amadeusUnMarshaller;

	@Mock
	private WebServiceTemplate amadeusWebServiceTemplate;

	@Mock
	CheckInValidationResponseMapper checkInValidationResponseMapper;

	private CheckIn checkInPAX1S;

	@Mock
	AmadeusWebServiceGateway amadeusWebServiceGateway;

	@Mock
	private ServiceProxy configurationInfrastructureServiceProxy;

	@Mock
	CheckInValidationRequestMapper checkInValidationRequestMapper;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		checkIn2PAXF = new ObjectMapper().readValue(getJSONStringFromFile(SAMPLE_REQUEST_PAX2F), CheckIn.class);
		checkIn = new ObjectMapper().readValue(getJSONStringFromFile(SAMPLE_REQUEST_1), CheckIn.class);
		checkInPAX2S = new ObjectMapper().readValue(getJSONStringFromFile(SAMPLE_REQUEST_PAX2S), CheckIn.class);
		checkInPAX1F = new ObjectMapper().readValue(getJSONStringFromFile(SAMPLE_REQUEST_PAX1F), CheckIn.class);
		checkInPAX1S = new ObjectMapper().readValue(getJSONStringFromFile(SAMPLE_REQUEST_PAX1S), CheckIn.class);
		session = new AmadeusSession();
	}

	@Test
	public void shouldTestBothOperationalAndEligibilityCheck() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_CODE_KEY))
				.thenReturn(CODE_SUCCESS);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_DESCRIPTION_KEY))
				.thenReturn(DESCRIPTION_SUCCESS);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX1S_JSON));
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(BOOKING_ID1, session, checkInPAX1S);

		assertNotNull(checkInValidation);
		assertNotNull(checkInValidation.getValidationOutcomes());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getPassenger());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getPassenger().getPassengerIdentifier());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getCode());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getResult());
		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().get(0).getValidationType());
		assertEquals(SUCCESS_MSG, checkInValidation.getValidationOutcomes().get(0).getResult());
		assertEquals(checkInPAX1S.getPassengers().iterator().next().getIdentifier(),
				checkInValidation.getValidationOutcomes().get(0).getPassenger().getPassengerIdentifier());

		assertEquals(CODE_SUCCESS, checkInValidation.getValidationOutcomes().get(1).getCode());
		assertEquals(SUCCESS_MSG, checkInValidation.getValidationOutcomes().get(1).getResult());
		assertEquals(VALIDATION_TYPE_OPERATIONAL, checkInValidation.getValidationOutcomes().get(1).getValidationType());
		assertEquals(DESCRIPTION_SUCCESS, checkInValidation.getValidationOutcomes().get(1).getDescription());

	}

	@Test
	public void shouldTestOperationalValidationCheckSuccess() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_CODE_KEY))
				.thenReturn(CODE_SUCCESS);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_DESCRIPTION_KEY))
				.thenReturn(DESCRIPTION_SUCCESS);
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX2S_JSON));
		checkInPAX1S.setPassengers(null);
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(BOOKING_ID1, session, checkInPAX1S);
		assertNotNull(checkInValidation);
		assertNotNull(checkInValidation.getValidationOutcomes());
		assertEquals(CODE_SUCCESS, checkInValidation.getValidationOutcomes().get(0).getCode());
		assertEquals(SUCCESS_MSG, checkInValidation.getValidationOutcomes().get(0).getResult());
		assertEquals(VALIDATION_TYPE_OPERATIONAL, checkInValidation.getValidationOutcomes().get(0).getValidationType());
		assertEquals(DESCRIPTION_SUCCESS, checkInValidation.getValidationOutcomes().get(0).getDescription());
	}

	@Test
	public void shouldTestOperationalValidationWhenFlightSegmentIsNull() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_CODE_KEY))
				.thenReturn(CODE_SUCCESS);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_DESCRIPTION_KEY))
				.thenReturn(DESCRIPTION_SUCCESS);
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX2S_JSON));
		checkInPAX1F.setFlightSegments(null);
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(BOOKING_ID1, session, checkInPAX1F);
		assertNotNull(checkInValidation);
		assertNotNull(checkInValidation.getValidationOutcomes());

		assertNotEquals(VALIDATION_TYPE_OPERATIONAL,
				checkInValidation.getValidationOutcomes().get(0).getValidationType());
		assertNotEquals(VALIDATION_TYPE_OPERATIONAL,
				checkInValidation.getValidationOutcomes().get(1).getValidationType());

	}

	@Test
	public void shouldTestOperationalValidationWhenFlightSegmentIsEmpty() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_CODE_KEY))
				.thenReturn(CODE_SUCCESS);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_DESCRIPTION_KEY))
				.thenReturn(DESCRIPTION_SUCCESS);
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX2S_JSON));
		checkInPAX1S.setFlightSegments(new ArrayList<FlightSegment>());
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(BOOKING_ID1, session, checkInPAX1S);
		assertNotNull(checkInValidation);
		assertNotNull(checkInValidation.getValidationOutcomes());

		assertNotEquals(VALIDATION_TYPE_OPERATIONAL,
				checkInValidation.getValidationOutcomes().get(0).getValidationType());
		assertNotEquals(VALIDATION_TYPE_OPERATIONAL,
				checkInValidation.getValidationOutcomes().get(1).getValidationType());

	}

	@Test
	public void shouldTestOperationalValidationWithoutPassanger() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_CODE_KEY))
				.thenReturn(CODE_SUCCESS);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_SUCCESS_DESCRIPTION_KEY))
				.thenReturn(DESCRIPTION_SUCCESS);
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX2S_JSON));

		checkInPAX1F.setPassengers(new ArrayList<Passenger>());		
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(BOOKING_ID1, session, checkInPAX1F);
		assertNotNull(checkInValidation);
		assertNotNull(checkInValidation.getValidationOutcomes());

		assertEquals(VALIDATION_TYPE_OPERATIONAL,
				checkInValidation.getValidationOutcomes().get(0).getValidationType());

	}

	@Test
	public void shouldTestOperationalValidationCheckFailure() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_FAILURE_CODE_KEY))
				.thenReturn(CODE_FAILURE);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_OPERATIONAL_FAILURE_DESCRIPTION_KEY))
				.thenReturn(DESCRIPTION_FAILURE);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX1S_JSON));
		checkInPAX1S.getFlightSegments().get(0).getFlightLegs().get(0).getOrigin().setTerminal("");
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(BOOKING_ID1, session, checkInPAX1S);

		assertNotNull(checkInValidation);
		assertNotNull(checkInValidation.getValidationOutcomes());

		assertEquals(CODE_FAILURE, checkInValidation.getValidationOutcomes().get(0).getCode());
		assertEquals(FAILED_MSG, checkInValidation.getValidationOutcomes().get(0).getResult());
		assertEquals(VALIDATION_TYPE_OPERATIONAL, checkInValidation.getValidationOutcomes().get(0).getValidationType());
		assertEquals(DESCRIPTION_FAILURE, checkInValidation.getValidationOutcomes().get(0).getDescription());

	}

	@Test
	public void shouldReturnCheckInValidationSuccessoOutcome() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX2S_JSON));
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(BOOKING_ID1, session, checkIn);
		assertNotNull(checkInValidation);
		assertNotNull(checkInValidation.getValidationOutcomes());
	}

	/**
	 * Test success response for single passengers
	 * 
	 * @throws IOException
	 * @throws JAXBException
	 */
	@Test
	public void shouldTestCheckInValidationSuccessResponseWithSinglePassenger() throws JAXBException, IOException {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX1S_JSON));
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(BOOKING_ID1, session, checkInPAX1S);
		assertTrue(checkInValidation.getTotalRecords() != 0);
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getPassenger());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getPassenger().getPassengerIdentifier());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getCode());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getResult());
		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().get(0).getValidationType());
		assertEquals(SUCCESS_MSG, checkInValidation.getValidationOutcomes().get(0).getResult());
		assertEquals(checkInPAX1S.getPassengers().iterator().next().getIdentifier(),
				checkInValidation.getValidationOutcomes().get(0).getPassenger().getPassengerIdentifier());

	}

	/**
	 * Test success response for multiple passengers
	 * 
	 * @throws IOException
	 * @throws JAXBException
	 */
	@Test
	public void shouldTestCheckInValidationSuccessResponseWithMultiplePassengers() throws JAXBException, IOException {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX2S_JSON));
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(CHK001PAX2S, session, checkInPAX2S);
		assertTrue(checkInValidation.getTotalRecords() != 0);

		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getPassenger());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getPassenger().getPassengerIdentifier());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getCode());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getResult());
		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().get(0).getValidationType());
		assertEquals(SUCCESS_MSG, checkInValidation.getValidationOutcomes().get(0).getResult());

		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getPassenger());
		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getPassenger().getPassengerIdentifier());
		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getCode());
		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getResult());
		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().get(1).getValidationType());
		assertEquals(SUCCESS_MSG, checkInValidation.getValidationOutcomes().get(1).getResult());

		assertEquals(checkInPAX2S.getPassengers().get(0).getIdentifier(),
				checkInValidation.getValidationOutcomes().get(0).getPassenger().getPassengerIdentifier());
		assertEquals(checkInPAX2S.getPassengers().get(1).getIdentifier(),
				checkInValidation.getValidationOutcomes().get(1).getPassenger().getPassengerIdentifier());
	}

	/**
	 * Test total records and outcome list size are equal
	 * 
	 * @throws IOException
	 * @throws JAXBException
	 */
	@Test
	public void shouldTestEqualityOfTotalRecordsAndOutcomesSize() throws JAXBException, IOException {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX2S_JSON));
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(BOOKING_ID1, session, checkIn2PAXF);
		assertTrue(checkInValidation.getTotalRecords() != 0);

	}

	/**
	 * Test failed response with single passenger in outcome and request
	 * 
	 * @throws IOException
	 * @throws JAXBException
	 */
	@Test
	public void shouldTestCheckInValidationOutcomesFailedResponseWithSinglePassenger()
			throws JAXBException, IOException {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX1F_JSON));
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(CHK001PAX1F, session, checkInPAX1F);
		assertTrue(checkInValidation.getTotalRecords() != 0);

		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().iterator().next().getValidationType());
		assertEquals(FAILED_MSG, checkInValidation.getValidationOutcomes().iterator().next().getResult());
		assertNotNull(checkInValidation.getValidationOutcomes().iterator().next().getCode());
		assertEquals(checkInPAX1F.getPassengers().iterator().next().getIdentifier(),
				checkInValidation.getValidationOutcomes().iterator().next().getPassenger().getPassengerIdentifier());
	}

	/**
	 * 
	 * @throws IOException
	 * @throws JAXBException
	 */
	@Test
	public void shouldTestCheckInValidationOutcomesErrorAndWarningResponse() throws Exception {
		CheckIn checkInPAX1ErrorWarning = new ObjectMapper()
				.readValue(getJSONStringFromFile(SAMPLE_REQUEST_PAX1ERRORWARNING), CheckIn.class);
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_ERROR_WARNING_JSON));
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(CHK001PAX2SF, session,
				checkInPAX1ErrorWarning);
		assertTrue(checkInValidation.getTotalRecords() != 0);
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getPassenger());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getPassenger().getPassengerIdentifier());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getCode());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getResult());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getDescription());
		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().get(0).getValidationType());
		assertEquals(FAILED_MSG, checkInValidation.getValidationOutcomes().get(0).getResult());

		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getPassenger());
		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getPassenger().getPassengerIdentifier());
		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getCode());
		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getResult());
		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getDescription());
		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().get(1).getValidationType());
		assertEquals(WARNING_MSG, checkInValidation.getValidationOutcomes().get(1).getResult());
	}

	/**
	 * @throws IOException
	 * @throws JAXBException
	 * 
	 */
	@Test
	public void shouldTestCheckInValidationOutcomesFailedResponseWithMultiplePassengers()
			throws JAXBException, IOException {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX2F_JSON));
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(CHK001PAX2F, session, checkIn2PAXF);
		assertTrue(checkInValidation.getTotalRecords() != 0);
		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().get(0).getValidationType());
		assertEquals(FAILED_MSG, checkInValidation.getValidationOutcomes().get(0).getResult());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getCode());
		assertEquals(checkIn2PAXF.getPassengers().get(0).getIdentifier(),
				checkInValidation.getValidationOutcomes().get(0).getPassenger().getPassengerIdentifier());
		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().get(1).getValidationType());
		assertEquals(FAILED_MSG, checkInValidation.getValidationOutcomes().get(1).getResult());
		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getCode());
		assertEquals(checkIn2PAXF.getPassengers().get(1).getIdentifier(),
				checkInValidation.getValidationOutcomes().get(1).getPassenger().getPassengerIdentifier());
	}

	@Test
	public void shouldTestDescriptionWithValue() throws JAXBException, IOException {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInValidationConstants.AMADEUS_URL_KEY))
				.thenReturn(CheckInValidationConstants.AMADEUS_URL);
		Mockito.when(amadeusWebServiceGateway.getWebServiceResponseForCheckInValidation(Mockito.any(),
				Mockito.anyString(), Mockito.any())).thenReturn(new DCSACCCheckRegulatoryRqtsReply());
		Mockito.when(checkInValidationResponseMapper.map(Mockito.any(DCSACCCheckRegulatoryRqtsReply.class)))
				.thenReturn(getMappedResponse(AMADEUS_PAX2S_JSON));
		CheckInValidation checkInValidation = checkInRepository.checkInValidation(BOOKING_ID1, session, checkIn);
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getDescription());
	}

	private CheckInValidation getMappedResponse(String fileName) throws IOException {
		InputStream inputstream = new ClassPathResource(fileName).getInputStream();
		CheckInValidation checkInValidation = new ObjectMapper().readValue(inputstream, CheckInValidation.class);
		return checkInValidation;
	}

	public AmadeusSession getSession() {
		AmadeusSession sessionRequest = new AmadeusSession();
		sessionRequest.setChannel("KISOK");
		sessionRequest.setLocation("GB");
		sessionRequest.setScope("BOOKINGS");
		sessionRequest.setSecurityToken(SECURITY_TOKEN);
		sessionRequest.setSessionId(SESSION_ID);
		sessionRequest.setSequenceNumber("1");
		return sessionRequest;
	}

	/**
	 * Used for returning JSON string from specified file name
	 * 
	 * @param fileName
	 * @return
	 * @throws ParseException
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public String getJSONStringFromFile(String fileName) throws Exception {
		JSONParser parser = new JSONParser();
		JSONObject jsonObject;
		ClassLoader classLoader = getClass().getClassLoader();
		File jsonFile = new File(classLoader.getResource(fileName).getFile());
		jsonObject = (JSONObject) parser.parse(new FileReader(jsonFile));
		return jsonObject.toString();
	}

}