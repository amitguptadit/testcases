package com.iag.business.checkin.error.matcher;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

import com.iag.business.checkin.application.exception.ApplicationServiceException;



/**
 * CustomApplicationServiceExceptionMatcher is used to match ApplicationServiceException
 *
 */
public class CustomApplicationServiceExceptionMatcher extends TypeSafeMatcher<ApplicationServiceException> {

  public static CustomApplicationServiceExceptionMatcher hasException(ApplicationServiceException item) {
    return new CustomApplicationServiceExceptionMatcher(item);
  }

  private ApplicationServiceException foundException;
  private ApplicationServiceException expectedException;

  private CustomApplicationServiceExceptionMatcher(ApplicationServiceException expectedException) {
    this.expectedException = expectedException;
  }

  @Override
  protected boolean matchesSafely(final ApplicationServiceException exception) {
    this.foundException = exception;
    return foundException.getCode().equals(expectedException.getCode());
  }

  @Override
  public void describeTo(Description description) {
    description.appendValue(foundException.getCode()).appendText(" was not found instead of ")
                    .appendValue(expectedException.getCode());
  }
}