package com.iag.business.checkin.utility;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.proxy.config.ServiceProxy;


public class AmadeusConnectorServiceUtilityTest {
    private static final String BLANK_VALUE = StringUtils.EMPTY;
    private AmadeusConnectorServiceUtility amadeusConnectorServiceUtility;

    @Mock
    private ServiceProxy configurationInfrastructureServiceProxy;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        amadeusConnectorServiceUtility = new AmadeusConnectorServiceUtility(configurationInfrastructureServiceProxy);

    }

    @Test
    public void findingMessageConfigurationValueWithValidKey() {

        String validKey = "msg.message.business.REQUEST_UNAUTHORIZED";
        String validValue = "";
        Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,getUrlKey(validKey)))
                .thenReturn(validValue);
        String value = amadeusConnectorServiceUtility.getMessageConfigurationValue(validKey);
        Assert.assertEquals(validValue, value);

    }

    @Test
    public void findingMessageConfigurationValueWithBlankKey() {

        String validKey = BLANK_VALUE;
        String validValue = BLANK_VALUE;
        Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,getUrlKey(validKey)))
                .thenReturn(validValue);
        String value = amadeusConnectorServiceUtility.getMessageConfigurationValue(validKey);
        Assert.assertEquals(StringUtils.EMPTY, value);

    }

    @Test
    public void findingMessageConfigurationValueWithNullKey() {

        Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,getUrlKey(BLANK_VALUE)))
                .thenReturn(BLANK_VALUE);
        String value = amadeusConnectorServiceUtility.getMessageConfigurationValue(BLANK_VALUE);
        Assert.assertEquals(BLANK_VALUE, value);

    }

    @Test
    public void findingMessageConfigurationValueWithInValidKey() {

        String validKey = "msg.message.business.REQUEST_UNAUTHORIZED_ABC";
        String validValue = "";
        Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,getUrlKey(validKey)))
                .thenReturn(validValue);
        String value = amadeusConnectorServiceUtility.getMessageConfigurationValue(validKey);
        Assert.assertEquals(BLANK_VALUE, value);

    }

    String getUrlKey(String key) {
        return new StringBuilder()
                .append(CheckInValidationConstants.MESSAGE_CONFIGURATION_KEYWORD)
                .append(key.replace(CheckInValidationConstants.KEY_SEPARATOR_DOT,
                		CheckInValidationConstants.KEY_SEPARATOR)).toString();

    }

}
