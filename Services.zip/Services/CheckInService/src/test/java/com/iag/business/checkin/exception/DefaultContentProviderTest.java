package com.iag.business.checkin.exception;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.business.checkin.application.error.MessageConstants;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.proxy.config.ServiceProxy;

public class DefaultContentProviderTest {

	@InjectMocks
	private DefaultContentProvider defaultContentProvider;

	@Mock
	private ServiceProxy configurationInfrastructureServiceProxy;

	private static final String CODE = ".code";
	private final static String REQUEST_INVALID = "REQUEST_INVALID";

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		defaultContentProvider = new DefaultContentProvider(configurationInfrastructureServiceProxy);
	}

	@Test
	public void shouldGetErrorContent() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(CheckInValidationConstants.ERROR_NAMESPACE,
				MessageConstants.CHECKINVALIDATION_ERROR + CheckInErrorCode.REQUEST_INVALID + CODE))
				.thenReturn(REQUEST_INVALID);
		Assert.assertEquals(REQUEST_INVALID, defaultContentProvider
				.getContent(MessageConstants.CHECKINVALIDATION_ERROR + CheckInErrorCode.REQUEST_INVALID + CODE));
	}
}
