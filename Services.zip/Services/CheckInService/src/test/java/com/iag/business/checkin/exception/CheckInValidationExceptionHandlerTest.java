package com.iag.business.checkin.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;

import com.iag.business.checkin.application.error.ErrorFactory;
import com.iag.business.checkin.application.error.ServiceError;
import com.iag.business.checkin.application.error.ValidationError;
import com.iag.business.checkin.application.exception.ApplicationServiceException;
import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.error.CheckInErrorCode;

public class CheckInValidationExceptionHandlerTest {

	private final static String HTTP_STATUS_CODE = "400";
	private static final String BOOKINGIDENTIFIER_PATH = "booking-identifier";
	private static final String BUSINESS_MSG_KEY = "checkinvalidation.error.REQUEST_INVALID.business_message";
	private static final String DEVELOPER_MSG_KEY = "checkinvalidation.error.MANDATORY_DATA_MISSING.developer_message";
	private static final String DEVELOPER_MSG = "Booking Identifier is invalid";
	private static final String DEVELOPER_LINK_KEY = "checkinvalidation.error.REQUEST_INVALID.developer_link";
	private static final String DEVELOPER_LINK = "https://developer.iag.com";
	private static final String BUSINESS_MSG = "Request Invalid";
	private static final String APPLICATION_BUSINESS_MSG_KEY = "checkinvalidation.error.MANDATORY_DATA_MISSING.business_message";
	private static final String APPLICATION_BUSINESS_MSG_VALUE = "Mandatory Data Missing";

	@InjectMocks
	private CheckInValidationExceptionHandler checkInValidationExceptionHandler;

	private ServiceErrorResponseGenerator serviceErrorResponseGenerator;

	@Mock
	private DefaultContentProvider mockContentProvider;

	private ServiceError serviceError;

	private ErrorFactory errorFactory;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		serviceErrorResponseGenerator = new ServiceErrorResponseGenerator(mockContentProvider);
		checkInValidationExceptionHandler = new CheckInValidationExceptionHandler(serviceErrorResponseGenerator);
		errorFactory = new ErrorFactory();

	}

	@Test
	public void shouldHandleValidationException() {
		ValidationServiceException validationRequestInvalidDataException = createValidationServiceException(
				CheckInErrorCode.REQUEST_INVALID.name(), CheckInErrorCode.DATA_INVALID.name(), BOOKINGIDENTIFIER_PATH);
		Mockito.when(errorFactory.createError(validationRequestInvalidDataException, mockContentProvider))
				.thenReturn(serviceError);
		Mockito.when(errorFactory.getStatusCode(validationRequestInvalidDataException, mockContentProvider))
				.thenReturn(HTTP_STATUS_CODE);
		Mockito.when(mockContentProvider.getContent(BUSINESS_MSG_KEY)).thenReturn(BUSINESS_MSG);
		Mockito.when(mockContentProvider.getContent(DEVELOPER_LINK_KEY)).thenReturn(DEVELOPER_LINK);
		Mockito.when(mockContentProvider.getContent(DEVELOPER_MSG_KEY)).thenReturn(DEVELOPER_MSG);
		HttpEntity<ServiceError> result = checkInValidationExceptionHandler
				.handleServiceException(validationRequestInvalidDataException);
		Collection<ValidationError> validationErrorList = ((ValidationError) result.getBody()).getServiceErrors();
		assertNotNull(result.getBody());
		assertEquals(CheckInErrorCode.REQUEST_INVALID.name(), result.getBody().getCode());
		assertEquals(BUSINESS_MSG, result.getBody().getBusinessMessage());
		assertEquals(DEVELOPER_LINK, result.getBody().getDeveloperLink());
		assertEquals(CheckInErrorCode.DATA_INVALID.name(), validationErrorList.iterator().next().getCode());
		assertEquals(BOOKINGIDENTIFIER_PATH, validationErrorList.iterator().next().getPath());
		assertEquals(DEVELOPER_MSG, validationErrorList.iterator().next().getDeveloperMessage());
	}

	@Test
	public void shouldHandleApplicationException() {
		ApplicationServiceException applicationServiceException = new ApplicationServiceException(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name());
		applicationServiceException.setDeveloperMessage(CheckInErrorCode.MANDATORY_DATA_MISSING.name());
		Mockito.when(mockContentProvider.getContent(APPLICATION_BUSINESS_MSG_KEY))
				.thenReturn(APPLICATION_BUSINESS_MSG_VALUE);
		Mockito.when(errorFactory.getStatusCode(applicationServiceException, mockContentProvider))
				.thenReturn(HTTP_STATUS_CODE);
		HttpEntity<ServiceError> result = checkInValidationExceptionHandler
				.handleServiceException(applicationServiceException);
		assertNotNull(result.getBody());
		assertEquals(CheckInErrorCode.MANDATORY_DATA_MISSING.name(), result.getBody().getCode());
		assertEquals(CheckInErrorCode.MANDATORY_DATA_MISSING.name(), result.getBody().getDeveloperMessage());
		assertEquals(APPLICATION_BUSINESS_MSG_VALUE, result.getBody().getBusinessMessage());

	}

	private ValidationServiceException createValidationServiceException(String parentErrorCode, String childErrorCode,
			String path) {
		ValidationServiceException validationServiceException = new ValidationServiceException(parentErrorCode);
		validationServiceException.addValidationException(createValidationServiceException(childErrorCode, path));
		return validationServiceException;
	}

	private ValidationServiceException createValidationServiceException(String errorCode, String path) {
		ValidationServiceException childValidationServiceException = new ValidationServiceException(errorCode);
		childValidationServiceException.setDeveloperMessage(DEVELOPER_MSG);
		childValidationServiceException.setPath(path);
		return childValidationServiceException;
	}

}
