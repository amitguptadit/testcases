package com.iag.business.checkin;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.web.client.RestTemplateBuilder;

public class CheckInValidationServiceApplicationTest {
	@InjectMocks
	private CheckInValidationServiceApplication CheckInValidationServiceApplication;

	@Mock
	RestTemplateBuilder builder;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void shouldConfigureRestbuilder() {
		CheckInValidationServiceApplication.restTemplate(builder);
	}

}
