package com.iag.business.checkin.repository;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.WebServiceIOException;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapFaultException;

import com.amadeus.xml.cregrq_16_2_1a.DCSACCCheckRegulatoryRqts;
import com.amadeus.xml.cregrr_16_2_1a.ApplicationErrorDetailType;
import com.amadeus.xml.cregrr_16_2_1a.ApplicationErrorInformationType;
import com.amadeus.xml.cregrr_16_2_1a.DCSACCCheckRegulatoryRqtsReply;
import com.amadeus.xml.cregrr_16_2_1a.ErrorGroupType;
import com.amadeus.xml.cregrr_16_2_1a.FreeTextInformationType;
import com.iag.business.checkin.application.exception.ApplicationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.proxy.config.ServiceProxy;
import com.iag.business.checkin.session.AmadeusSession;
import com.iag.business.checkin.utility.AmadeusConnectorServiceUtility;

public class AmadeusWebServiceGatewayTest {

	private static final String SOAP_ACTION_URI = "http://webservices.amadeus.com/1ASIWIAGBA/CCPRRQ_17_1_1A";

	private AmadeusWebServiceGateway gateway;

	@Mock
	private WebServiceTemplate amadeusWebServiceTemplate;

	@Mock
	Jaxb2Marshaller amadeusMarshaller;

	@Mock
	Jaxb2Marshaller amadeusUnMarshaller;
	@Mock
	private AmadeusConnectorServiceUtility amadeusConnectorServiceUtility;

	@Mock
	private ServiceProxy configurationInfrastructureServiceProxy;
	@Rule
	public final ExpectedException exception = ExpectedException.none();

	private static final String AMADEUS_PAX2S = "mock_response/amadeus_PAX2S.xml";

	private final static String FLIGHT_CANCELLED_ERROR_CODE = "18015";
	private final static String FLIGHT_SUSPENDED_ERROR_CODE = "14220";
	private final static String FLIGHT_NOT_OPERATIONAL_ERROR_CODE = "17084";
	private final static String FLIGHT_NOT_ACTIVE_ERROR_CODE = "19227";
	private final static String FLIGHT_LOCKED_ERROR_CODE = "14024";
	private final static String BOARDING_CLOSED_ERROR_CODE = "14204";
	private final static String ERROR_CATEGORY_LIST = "EC,WEC2,WEC";
	private final static String ERROR_CATEGORY_CODE = "EC";
	private final static String WARNINGERROR_CATEGORY_CODE = "WEC";
	private final static String SYSTEM_UNAVAILABLE_CODE_STATUS_LIST = "17011,17111,17112 ,11,17569,17336,17391,19915,19436,19204";
	private final static String SYSTEM_UNAVAILABLE = "SYSTEM_UNAVAILABLE";
	
	AmadeusSession session;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		gateway = new AmadeusWebServiceGateway();
		ReflectionTestUtils.setField(gateway, "amadeusMarshaller", amadeusMarshaller);
		ReflectionTestUtils.setField(gateway, "amadeusUnMarshaller", amadeusUnMarshaller);
		ReflectionTestUtils.setField(gateway, "amadeusWebServiceTemplate", amadeusWebServiceTemplate);
		ReflectionTestUtils.setField(gateway, "configurationInfrastructureServiceProxy",
				configurationInfrastructureServiceProxy);
		session = new AmadeusSession();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void ShouldReturnWebServiceResponseForCheckInValidation() throws Exception {
		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(getDummyAmadeusObject(AMADEUS_PAX2S));
		final Object amedeusResponseDetails = gateway
				.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);
		Assert.assertNotEquals(null, amedeusResponseDetails);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThrowExceptionOnSystemUnavailable() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE,
				CheckInErrorCode.SYSTEM_UNAVAILABLE_CODE_STATUS_LIST.name()))
				.thenReturn(SYSTEM_UNAVAILABLE_CODE_STATUS_LIST);
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.ERROR_CATEGORY.name()))
				.thenReturn(ERROR_CATEGORY_LIST);
		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class)))
				.thenReturn(createDummyResponse("11", WARNINGERROR_CATEGORY_CODE));
		exception.expect(ApplicationServiceException.class);
		gateway.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThrowSystemUnavialableExceptionOnInvalidErrorCode() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.WARNING_CODE_STATUS_LIST.name()))
				.thenReturn("17624");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.IGNORE_CODE_STATUS_LIST.name()))
				.thenReturn("17335,19223,19226");
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.ERROR_CATEGORY.name()))
				.thenReturn(ERROR_CATEGORY_LIST);
		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class)))
				.thenReturn(createDummyResponse("199999", ERROR_CATEGORY_CODE));
		exception.expect(ApplicationServiceException.class);
		gateway.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThrowExceptionForFlightCancelled() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.FLIGHT_CANCELLED_CODE_STATUS.name()))
				.thenReturn(FLIGHT_CANCELLED_ERROR_CODE);
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.ERROR_CATEGORY.name()))
				.thenReturn(ERROR_CATEGORY_LIST);

		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class)))
				.thenReturn(createDummyResponse(FLIGHT_CANCELLED_ERROR_CODE, ERROR_CATEGORY_CODE));
		exception.expect(ApplicationServiceException.class);
		gateway.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThrowExceptionForFlightSuspended() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.FLIGHT_SUSPENDED_CODE_STATUS.name()))
				.thenReturn(FLIGHT_SUSPENDED_ERROR_CODE);
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.ERROR_CATEGORY.name()))
				.thenReturn(ERROR_CATEGORY_LIST);

		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class)))
				.thenReturn(createDummyResponse(FLIGHT_SUSPENDED_ERROR_CODE, ERROR_CATEGORY_CODE));
		exception.expect(ApplicationServiceException.class);
		gateway.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThrowExceptionForFlightNotActive() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.FLIGHT_NOT_ACTIVE_CODE_STATUS.name()))
				.thenReturn(FLIGHT_NOT_ACTIVE_ERROR_CODE);
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.ERROR_CATEGORY.name()))
				.thenReturn(ERROR_CATEGORY_LIST);
		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class)))
				.thenReturn(createDummyResponse(FLIGHT_NOT_ACTIVE_ERROR_CODE, ERROR_CATEGORY_CODE));
		exception.expect(ApplicationServiceException.class);
		gateway.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThrowExceptionForBoardingClosed() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.BOARDING_CLOSED_CODE_STATUS.name()))
				.thenReturn(BOARDING_CLOSED_ERROR_CODE);
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.ERROR_CATEGORY.name()))
				.thenReturn(ERROR_CATEGORY_LIST);
		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class)))
				.thenReturn(createDummyResponse(BOARDING_CLOSED_ERROR_CODE, ERROR_CATEGORY_CODE));
		exception.expect(ApplicationServiceException.class);
		gateway.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThrowExceptionForFlightNotOperational() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE,
				CheckInErrorCode.FLIGHT_NOT_OPERATIONAL_CODE_STATUS.name()))
				.thenReturn(FLIGHT_NOT_OPERATIONAL_ERROR_CODE);
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.ERROR_CATEGORY.name()))
				.thenReturn(ERROR_CATEGORY_LIST);
		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class)))
				.thenReturn(createDummyResponse(FLIGHT_NOT_OPERATIONAL_ERROR_CODE, ERROR_CATEGORY_CODE));
		exception.expect(ApplicationServiceException.class);
		gateway.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThrowExceptionForFlightLocked() throws Exception {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.FLIGHT_LOCKED_CODE_STATUS.name()))
				.thenReturn(FLIGHT_LOCKED_ERROR_CODE);
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.AMADEUS_NAMESPACE, CheckInErrorCode.ERROR_CATEGORY.name()))
				.thenReturn(ERROR_CATEGORY_LIST);
		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class)))
				.thenReturn(createDummyResponse(FLIGHT_LOCKED_ERROR_CODE, ERROR_CATEGORY_CODE));
		exception.expect(ApplicationServiceException.class);
		gateway.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);

	}

	@Test
	public void shouldThowExceptionWhenErrorOccuredWhileCallingAmadeus() {
		SoapFaultException faultException = new SoapFaultException("Bad SecurityToken");
		Mockito.when(amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
				Mockito.any(WebServiceMessageCallback.class))).thenThrow(faultException);
		exception.expect(ApplicationServiceException.class);
		exception.expectMessage(SYSTEM_UNAVAILABLE);
		gateway.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThowExceptionWhenAmadeusIsNotAvailable() {
		WebServiceIOException serviceNotAvailable = new WebServiceIOException(
				"I/O error: BAaccess.test.webservices.1a.amadeus.com");
		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenThrow(serviceNotAvailable);
		exception.expect(ApplicationServiceException.class);
		gateway.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);
	}

	@Test
	public void shouldThowExceptionWhenSocketTimeoutOccured() {
		WebServiceIOException serviceNotAvailable = new WebServiceIOException(
				"I/O error: Read timed out; nested exception is java.net.SocketTimeoutException");
		Mockito.when(amadeusWebServiceTemplate.marshalSendAndReceive(Mockito.any(Object.class),
				Mockito.any(WebServiceMessageCallback.class))).thenThrow(serviceNotAvailable);
		exception.expect(ApplicationServiceException.class);
		exception.expectMessage(SYSTEM_UNAVAILABLE);
		gateway.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThrowExceptionOnInvalidResponse() throws JAXBException, IOException {
		Mockito.when(amadeusWebServiceTemplate.sendAndReceive(Mockito.any(WebServiceMessageCallback.class),
				Mockito.any(WebServiceMessageExtractor.class))).thenReturn(null);
		exception.expect(ApplicationServiceException.class);
		exception.expectMessage(SYSTEM_UNAVAILABLE);
		gateway.getWebServiceResponseForCheckInValidation(new DCSACCCheckRegulatoryRqts(), SOAP_ACTION_URI, session);
	}

	public DCSACCCheckRegulatoryRqtsReply getDummyAmadeusObject(String fileName) throws JAXBException, IOException {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(fileName).getFile());
		JAXBContext jaxbContext = JAXBContext.newInstance(DCSACCCheckRegulatoryRqtsReply.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		DCSACCCheckRegulatoryRqtsReply dCSACCCheckRegulatoryRqtsReply = (DCSACCCheckRegulatoryRqtsReply) unmarshaller
				.unmarshal(file);
		return dCSACCCheckRegulatoryRqtsReply;
	}

	/**
	 * Used for returning JSON string from specified file name
	 * 
	 * @param fileName
	 * @return
	 */
	public String getJSONStringFromFile(String fileName) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONObject jsonObject;
		ClassLoader classLoader = getClass().getClassLoader();
		File jsonFile = new File(classLoader.getResource(fileName).getFile());
		jsonObject = (JSONObject) parser.parse(new FileReader(jsonFile));
		return jsonObject.toString();
	}

	private Object createDummyResponse(String errorCode, String errorCategory) {
		DCSACCCheckRegulatoryRqtsReply amadeusPassengerReply = new DCSACCCheckRegulatoryRqtsReply();
		List<ErrorGroupType> errorList = new ArrayList<>();
		ErrorGroupType errorGroupType = new ErrorGroupType();
		ApplicationErrorInformationType valueType = new ApplicationErrorInformationType();
		ApplicationErrorDetailType value = new ApplicationErrorDetailType();
		FreeTextInformationType freeTextInformationType = new FreeTextInformationType();
		List<String> freeTextList = new ArrayList<>();
		freeTextList.add("Free text line 1");
		freeTextList.add("Free text line 2");
		value.setErrorCode(errorCode);
		valueType.setErrorDetails(value);
		errorGroupType.setErrorOrWarningCodeDetails(valueType);
		value.setErrorCategory(errorCategory);
		errorGroupType.setErrorWarningDescription(freeTextInformationType);
		errorGroupType.getErrorWarningDescription().setFreeText(freeTextList);
		errorList.add(errorGroupType);
		amadeusPassengerReply.setErrors(errorList);
		return amadeusPassengerReply;
	}

}
