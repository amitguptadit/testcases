package com.iag.business.checkin.exception;

import java.util.Collection;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.business.checkin.application.error.ContentProvider;
import com.iag.business.checkin.application.error.ErrorFactory;
import com.iag.business.checkin.application.error.ServiceError;
import com.iag.business.checkin.application.error.ValidationError;
import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.error.CheckInErrorCode;

public class ServiceErrorResponseGeneratorTest {

	@InjectMocks
	private ServiceErrorResponseGenerator serviceErrorResponseGenerator;

	@Mock
	private ContentProvider contentProvider;

	private ErrorFactory errorFactory = new ErrorFactory();

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		serviceErrorResponseGenerator = new ServiceErrorResponseGenerator(contentProvider);
	}

	@Test
	public void validateServiceErrorResponse() {
		ValidationServiceException validationServiceException = createValidationServiceException(
				CheckInErrorCode.REQUEST_INVALID.name(), CheckInErrorCode.DATA_INVALID.name());

		ServiceError serviceError = serviceErrorResponseGenerator.createServiceError(validationServiceException);
		Collection<ValidationError> validationErrorList = ((ValidationError) serviceError).getServiceErrors();
		Assert.assertNotNull(serviceError);
		Assert.assertEquals(CheckInErrorCode.REQUEST_INVALID.name(), serviceError.getCode());
		Assert.assertEquals(CheckInErrorCode.DATA_INVALID.name(), validationErrorList.iterator().next().getCode());
	}

	@Test
	public void shouldGetHttpStatusCodeForRequestInvalid() {
		ValidationServiceException validationServiceException = createValidationServiceException(
				CheckInErrorCode.REQUEST_INVALID.name(), CheckInErrorCode.DATA_INVALID.name());
		Mockito.when(errorFactory.getStatusCode(validationServiceException, contentProvider)).thenReturn("400");
		String httpStatusCode = serviceErrorResponseGenerator.getStatusCode(validationServiceException);
		Assert.assertEquals("400", httpStatusCode);
	}

	@Test
	public void shouldGetHttpStatusCodeForSystemUnavailable() {
		ValidationServiceException validationServiceException = createValidationServiceException(
				CheckInErrorCode.SYSTEM_UNAVAILABLE.name(), CheckInErrorCode.SYSTEM_UNAVAILABLE.name());
		Mockito.when(errorFactory.getStatusCode(validationServiceException, contentProvider)).thenReturn("503");
		String httpStatusCode = serviceErrorResponseGenerator.getStatusCode(validationServiceException);
		Assert.assertEquals("503", httpStatusCode);
	}

	private ValidationServiceException createValidationServiceException(String parentError, String childError) {
		ValidationServiceException validationServiceException = new ValidationServiceException(parentError);
		ValidationServiceException childValidationServiceException = new ValidationServiceException(childError);
		validationServiceException.addValidationException(childValidationServiceException);
		return validationServiceException;
	}
}
