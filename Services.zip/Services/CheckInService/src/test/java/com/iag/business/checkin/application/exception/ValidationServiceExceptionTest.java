package com.iag.business.checkin.application.exception;

import java.math.BigInteger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ValidationServiceExceptionTest {
  
  private ValidationServiceException validationServiceException;
  
  private static final String ERROR_CODE = "NAME_INVALID";
  
  @Before
  public void setUp(){
    validationServiceException = new ValidationServiceException(ERROR_CODE);
  }
  
  @Test
  public void shouldAddValidationExceptionWhenListIsNull(){
    validationServiceException.addValidationException(validationServiceException);
    Assert.assertNotNull(validationServiceException.getValidationExceptions());
    Assert.assertEquals(BigInteger.ONE.intValue(), validationServiceException.getValidationExceptions().size());
  }
  
  @Test
  public void shouldAddValidationExceptionWhenListIsNotNull(){    
    validationServiceException.addValidationException(validationServiceException);
    validationServiceException.addValidationException(validationServiceException);
    Assert.assertNotNull(validationServiceException.getValidationExceptions());
    Assert.assertEquals(2, validationServiceException.getValidationExceptions().size());
  }
}
