package com.iag.business.checkin.validation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.exception.ValidationServiceExceptionGenerator;

public class HeaderValidationTest {

	public static final String HEADERVALUE_PATH = "headervalue";

	private static final String DEV_MSG_DATA_INVALID = "Data Invalid";

	private static final String SESSION123 = "session123";
	private static final String SEC123 = "sec123";
	private static final String BOOKINGS = "BOOKINGS";
	private static final String KISOK = "KISOK";

	private static final String COUNTRY_CODE = "GB";

	@InjectMocks
	private HeaderValidation headerValueMapValidation;

	@Mock
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	ValidationServiceException validationServiceException;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

	}

	@Test
	public void testBookingIdentifierWithNullValue() {
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(createValidationServiceExceptionForMandatoryData());
		validationServiceException = headerValueMapValidation.validate(null);
		assertNotNull(validationServiceException);
		assertEquals(CheckInErrorCode.MANDATORY_DATA_MISSING.toString(), validationServiceException.getCode());
		assertEquals(HEADERVALUE_PATH, validationServiceException.getPath());
		assertEquals(DEV_MSG_DATA_INVALID, validationServiceException.getDeveloperMessage());
	}

	@Test
	public void testBookingIdentifierWithValidCharacter() {
		ValidationServiceException validationServiceException = null;
		Map<String, String> headerValueMap = new HashMap<>();
		headerValueMap.put("tokennumber", SEC123);
		headerValueMap.put("sessionidentifier", SESSION123);
		headerValueMap.put("location", COUNTRY_CODE);
		headerValueMap.put("channel", KISOK);
		headerValueMap.put("scope", BOOKINGS);
		when(validationServiceExceptionGenerator.createValidationError(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(validationServiceException);
		validationServiceException = headerValueMapValidation.validate(headerValueMap);
		assertNull(validationServiceException);
	}

	private ValidationServiceException createValidationServiceExceptionForMandatoryData() {
		ValidationServiceException validationServiceException = new ValidationServiceException(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name());
		validationServiceException.setDeveloperMessage(DEV_MSG_DATA_INVALID);
		validationServiceException.setPath(HEADERVALUE_PATH);
		return validationServiceException;
	}
}
