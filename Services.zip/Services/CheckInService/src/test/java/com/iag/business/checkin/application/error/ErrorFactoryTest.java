package com.iag.business.checkin.application.error;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.business.checkin.application.exception.ServiceException;
import com.iag.business.checkin.application.exception.ValidationServiceException;

public class ErrorFactoryTest {

	private static final String CODE_POSTFIX = ".status.code";
	private static final String DEVELOPER_LINK_KEY = ".developer_link";
	private static final String NAMESPACE = "";
	private static final String BUSINESS_MESSAGE_KEY = ".business_message";

	ErrorFactory errorFactory = new ErrorFactory();

	@Mock
	ContentProvider contentProvider;
	@Mock
	ServiceException exception;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void shouldCreateValidationErrorObjectForValidationExceptionHavingNoChild() {
		ValidationServiceException exception = new ValidationServiceException("REQUEST_INVALID");
		exception.setDeveloperMessage("Request validation failed");
		exception.setPath("/domain/service");
		Mockito.when(contentProvider.getContent(MessageConstants.CHECKINVALIDATION_ERROR
				+ StringUtils.trimToEmpty(NAMESPACE) + exception.getCode() + BUSINESS_MESSAGE_KEY))
				.thenReturn("REQUEST_INVALID");
		Mockito.when(contentProvider
				.getContent(MessageConstants.CHECKINVALIDATION_ERROR + exception.getCode() + DEVELOPER_LINK_KEY))
				.thenReturn("www.iag.com");

		ValidationError error = (ValidationError) errorFactory.createError(exception, contentProvider);
		Assert.assertEquals(exception.getCode(), error.getCode());
		Assert.assertEquals(exception.getDeveloperMessage(), error.getDeveloperMessage());
		Assert.assertEquals("REQUEST_INVALID", error.getBusinessMessage());
		Assert.assertEquals("www.iag.com", error.getDeveloperLink());
		Assert.assertNull(error.getServiceErrors());
		Assert.assertEquals("/domain/service", error.getPath());
	}

	@Test
	public void shouldThrowExceptionForUnSupportedServiceExceptions() {

		class UnSupportedServiceException extends ServiceException {

			UnSupportedServiceException() {
				super("REQUEST_INVALID");
			}
		}

		UnSupportedServiceException unSupportedServiceException = new UnSupportedServiceException();
		unSupportedServiceException.setDeveloperMessage("Request validation failed");

		try {
			errorFactory.createError(unSupportedServiceException, contentProvider);
			Assert.fail("This test case must fail against throwing Unrecognized Exception.");
		} catch (Exception e) {
			Assert.assertTrue(e instanceof IllegalStateException);
		}
	}

	@Test
	public void shouldThrowExceptionForNull() {
		try {
			errorFactory.createError(null, contentProvider);
			Assert.fail("This test case must fail against found null.");
		} catch (Exception e) {
			Assert.assertTrue(e instanceof IllegalStateException);
		}
	}

	@Test
	public void shouldGetStatusCode() {
		String expectedOptionalNamespace = "";
		String expectedExceptionCode = "REQUEST_INVALID";
		Mockito.when(exception.getOptionalNamespace()).thenReturn(expectedOptionalNamespace);
		Mockito.when(exception.getCode()).thenReturn(expectedExceptionCode);
		String errorStatusCode = new StringBuffer().append(MessageConstants.CHECKINVALIDATION_ERROR)
				.append(expectedOptionalNamespace).append(expectedExceptionCode).append(CODE_POSTFIX).toString();
		Mockito.when(contentProvider.getContent(errorStatusCode)).thenReturn(DEVELOPER_LINK_KEY);

		String statusCode = errorFactory.getStatusCode(exception, contentProvider);
		Assert.assertNotNull(statusCode);
		Assert.assertEquals(DEVELOPER_LINK_KEY, statusCode);
	}

	@Test
	public void shouldThrowExceptionWhenExceptionParameterIsNull() {
		try {
			errorFactory.getStatusCode(null, contentProvider);
			Assert.fail("This test case must fail against found null.");
		} catch (Exception e) {
			Assert.assertTrue(e instanceof IllegalStateException);
		}

	}
}
