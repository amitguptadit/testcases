package com.iag.business.checkin.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.proxy.config.ServiceProxy;

public class ValidationServiceExceptionGeneratorTest {

	private static final String PATH = "booking-identifier";
	private static final String DEVELOPER_MESSAGE = "Booking Identifier is invalid";
	private final static String REQUEST_INVALID = "Request Invalid";
	private final static String DEV_MESSAGE_BOOKING_IDENTIFIER_KEY = "checkinvalidation.error.DATA_INVALID.developer_message_bookingidentifier";
	private final static String REQUEST_INVALID_ERROR_CODE = "checkinvalidation.error.REQUEST_INVALID.code";

	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;
	@Mock
	private ServiceProxy configurationInfrastructureServiceProxy;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		validationServiceExceptionGenerator = new ValidationServiceExceptionGenerator(
				configurationInfrastructureServiceProxy);
	}

	@Test
	public void shouldCreateServiceExceptionWithChildError() {
		List<ValidationServiceException> validationServiceExceptionList = new ArrayList<ValidationServiceException>();
		ValidationServiceException childValidationServiceException1 = new ValidationServiceException(
				CheckInErrorCode.DATA_INVALID.name());
		ValidationServiceException childValidationServiceException2 = new ValidationServiceException(
				CheckInErrorCode.DATA_INVALID.name());
		validationServiceExceptionList.add(childValidationServiceException1);
		validationServiceExceptionList.add(childValidationServiceException2);
		ValidationServiceException outputValidationServiceException = validationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionList);
		assertEquals(CheckInErrorCode.REQUEST_INVALID.name(), outputValidationServiceException.getCode());
		assertEquals(2, outputValidationServiceException.getValidationExceptions().size());
		Iterator<ValidationServiceException> iterator = outputValidationServiceException.getValidationExceptions()
				.iterator();
		assertEquals(CheckInErrorCode.DATA_INVALID.name(), iterator.next().getCode());
		assertEquals(CheckInErrorCode.DATA_INVALID.name(), iterator.next().getCode());
	}

	@Test
	public void shouldCreateServiceExceptionWithEmptyList() {
		List<ValidationServiceException> validationServiceExceptionList = new ArrayList<ValidationServiceException>();
		ValidationServiceException validationServiceException = validationServiceExceptionGenerator
				.createServiceExceptionWithChildError(validationServiceExceptionList);
		assertNotNull(validationServiceException);
		assertEquals(CheckInErrorCode.REQUEST_INVALID.name(), validationServiceException.getCode());
	}

	@Test
	public void shouldCreateValidationError() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(CheckInValidationConstants.ERROR_NAMESPACE,DEV_MESSAGE_BOOKING_IDENTIFIER_KEY))
				.thenReturn(DEVELOPER_MESSAGE);
		ValidationServiceException validationServiceException = validationServiceExceptionGenerator
				.createValidationError(CheckInErrorCode.REQUEST_INVALID.name(), PATH,
						DEV_MESSAGE_BOOKING_IDENTIFIER_KEY);
		assertNotNull(validationServiceException);
		assertEquals(CheckInErrorCode.REQUEST_INVALID.name(), validationServiceException.getCode());
		assertEquals(PATH, validationServiceException.getPath());
		assertEquals(DEVELOPER_MESSAGE, validationServiceException.getDeveloperMessage());
	}

	@Test
	public void shouldCreateServiceException() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(CheckInValidationConstants.ERROR_NAMESPACE,DEV_MESSAGE_BOOKING_IDENTIFIER_KEY))
				.thenReturn(DEVELOPER_MESSAGE);
		ValidationServiceException validationServiceException = validationServiceExceptionGenerator
				.createServiceException(CheckInErrorCode.DATA_INVALID.name(), PATH, DEV_MESSAGE_BOOKING_IDENTIFIER_KEY);
		assertNotNull(validationServiceException);
		assertEquals(CheckInErrorCode.REQUEST_INVALID.name(), validationServiceException.getCode());
		assertEquals(CheckInErrorCode.DATA_INVALID.name(),
				validationServiceException.getValidationExceptions().iterator().next().getCode());
		assertEquals(PATH, validationServiceException.getValidationExceptions().iterator().next().getPath());
		assertEquals(DEVELOPER_MESSAGE,
				validationServiceException.getValidationExceptions().iterator().next().getDeveloperMessage());
	}

	@Test
	public void checkBusinessMessagewithErrorCode() {
		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(CheckInValidationConstants.ERROR_NAMESPACE,REQUEST_INVALID_ERROR_CODE))
				.thenReturn(REQUEST_INVALID);
		String businessMessage = validationServiceExceptionGenerator
				.getMessageConfigurationValue(REQUEST_INVALID_ERROR_CODE);
		assertEquals(REQUEST_INVALID, businessMessage);
	}

	@Test
	public void shouldReturnEmptyStringOnNullOrEmptyKey() {
		String businessMessage1 = validationServiceExceptionGenerator.getMessageConfigurationValue(null);
		assertTrue(businessMessage1.isEmpty());
		String businessMessage2 = validationServiceExceptionGenerator.getMessageConfigurationValue("");
		assertTrue(businessMessage2.isEmpty());
	}

}
