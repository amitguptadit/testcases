package com.iag.business.checkin.validation;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iag.business.checkin.application.error.MessageConstants;
import com.iag.business.checkin.application.exception.ApplicationServiceException;
import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.exception.ValidationServiceExceptionGenerator;
import com.iag.domain.model.CheckIn;
import com.iag.domain.model.flight.FlightSegment;

public class OperationalCheckValidationTest {
	@InjectMocks
	private OperationalCheckValidation operationalCheckValidation;

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@Mock
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	ValidationServiceException validationServiceException;

	List<ValidationServiceException> validationServiceExceptionList;

	CheckIn checkIn;

	private final static String FILENAME = "static/Json/sampleRequest_operation_check.json";
	public static final String DEVELOPER_MESSAGE = ".developer_message";

	public static final String DEVELOPER_MESSAGE_OPERATIONAL = MessageConstants.CHECKINVALIDATION_ERROR
			+ CheckInErrorCode.MANDATORY_DATA_MISSING.name() + DEVELOPER_MESSAGE;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		checkIn = new ObjectMapper().readValue(getJSONStringFromFile(FILENAME), CheckIn.class);

	}

	@Test
	public void shouldTestTerminalNotEmpty() {
		checkIn.getFlightSegments().get(0).getFlightLegs().get(0).getOrigin().setTerminal(new String());
		Mockito.when(validationServiceExceptionGenerator.createValidationError(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.FLIGHT_SEGMENTS_PATH,
				DEVELOPER_MESSAGE_OPERATIONAL))
				.thenReturn(createValidationServiceException(CheckInErrorCode.MANDATORY_DATA_MISSING.name(),
						CheckInValidationConstants.FLIGHT_SEGMENTS_PATH, DEVELOPER_MESSAGE_OPERATIONAL));
		validationServiceExceptionList = operationalCheckValidation.validate(checkIn);
		validationServiceException = validationServiceExceptionList.get(0);
		Assert.assertEquals(CheckInErrorCode.MANDATORY_DATA_MISSING.name(), validationServiceException.getCode());
		Assert.assertEquals(DEVELOPER_MESSAGE_OPERATIONAL, validationServiceException.getDeveloperMessage());
		Assert.assertEquals(CheckInValidationConstants.FLIGHT_SEGMENTS_PATH, validationServiceException.getPath());
	}

	@Test
	public void shouldTestTerminalNotNull() {
		checkIn.getFlightSegments().get(0).getFlightLegs().get(0).getOrigin().setTerminal(null);
		Mockito.when(validationServiceExceptionGenerator.createValidationError(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.FLIGHT_SEGMENTS_PATH,
				DEVELOPER_MESSAGE_OPERATIONAL))
				.thenReturn(createValidationServiceException(CheckInErrorCode.MANDATORY_DATA_MISSING.name(),
						CheckInValidationConstants.FLIGHT_SEGMENTS_PATH, DEVELOPER_MESSAGE_OPERATIONAL));
		validationServiceExceptionList = operationalCheckValidation.validate(checkIn);
		validationServiceException = validationServiceExceptionList.get(0);
		Assert.assertEquals(CheckInErrorCode.MANDATORY_DATA_MISSING.name(), validationServiceException.getCode());
		Assert.assertEquals(DEVELOPER_MESSAGE_OPERATIONAL, validationServiceException.getDeveloperMessage());
		Assert.assertEquals(CheckInValidationConstants.FLIGHT_SEGMENTS_PATH, validationServiceException.getPath());
	}

	@Test
	public void shouldTestOperationCheckValidationWithoutErrors() {

		Mockito.when(validationServiceExceptionGenerator.createValidationError(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.FLIGHT_SEGMENTS_PATH,
				DEVELOPER_MESSAGE_OPERATIONAL))
				.thenReturn(createValidationServiceException(CheckInErrorCode.MANDATORY_DATA_MISSING.name(),
						CheckInValidationConstants.FLIGHT_SEGMENTS_PATH, DEVELOPER_MESSAGE_OPERATIONAL));
		validationServiceExceptionList = operationalCheckValidation.validate(checkIn);

		Assert.assertEquals(0, validationServiceExceptionList.size());
	}
	
	@Test
	public void shouldTestFlightSegmentsNotNull() {
		checkIn.setFlightSegments(null);
		Mockito.when(validationServiceExceptionGenerator.createValidationError(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.FLIGHT_SEGMENTS_PATH,
				DEVELOPER_MESSAGE_OPERATIONAL))
				.thenReturn(createValidationServiceException(CheckInErrorCode.MANDATORY_DATA_MISSING.name(),
						CheckInValidationConstants.FLIGHT_SEGMENTS_PATH, DEVELOPER_MESSAGE_OPERATIONAL));
		validationServiceExceptionList = operationalCheckValidation.validate(checkIn);

		Assert.assertEquals(0, validationServiceExceptionList.size());
	}
	
	@Test
	public void shouldTestFlightSegmentsNotEmpty() {
		checkIn.setFlightSegments(new ArrayList<FlightSegment>());
		Mockito.when(validationServiceExceptionGenerator.createValidationError(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.FLIGHT_SEGMENTS_PATH,
				DEVELOPER_MESSAGE_OPERATIONAL))
				.thenReturn(createValidationServiceException(CheckInErrorCode.MANDATORY_DATA_MISSING.name(),
						CheckInValidationConstants.FLIGHT_SEGMENTS_PATH, DEVELOPER_MESSAGE_OPERATIONAL));
		validationServiceExceptionList = operationalCheckValidation.validate(checkIn);

		Assert.assertEquals(0, validationServiceExceptionList.size());
	}

	@Test
	public void shouldTestKisokLocationNotNull() {

		checkIn.getFlightSegments().get(0).getFlightLegs().get(0).getOrigin().setTerminal(null);
		Mockito.when(validationServiceExceptionGenerator.createValidationError(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.FLIGHT_SEGMENTS_PATH,
				DEVELOPER_MESSAGE_OPERATIONAL))
				.thenReturn(createValidationServiceException(CheckInErrorCode.MANDATORY_DATA_MISSING.name(),
						CheckInValidationConstants.FLIGHT_SEGMENTS_PATH, DEVELOPER_MESSAGE_OPERATIONAL));
		validationServiceExceptionList = operationalCheckValidation.validate(checkIn);
		validationServiceException = validationServiceExceptionList.get(0);

		Assert.assertEquals(CheckInErrorCode.MANDATORY_DATA_MISSING.name(), validationServiceException.getCode());
		Assert.assertEquals(DEVELOPER_MESSAGE_OPERATIONAL, validationServiceException.getDeveloperMessage());
		Assert.assertEquals(CheckInValidationConstants.FLIGHT_SEGMENTS_PATH, validationServiceException.getPath());
		Assert.assertEquals(1, validationServiceExceptionList.size());
	}

	@Test
	public void shouldTestTerminalNotNullAndKioskLocationNotNull() {

		checkIn.getFlightSegments().get(0).getFlightLegs().get(0).getOrigin().setTerminal(null);
		checkIn.setKioskLocation(null);
		Mockito.when(validationServiceExceptionGenerator.createValidationError(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.FLIGHT_SEGMENTS_PATH,
				DEVELOPER_MESSAGE_OPERATIONAL))
				.thenReturn(createValidationServiceException(CheckInErrorCode.MANDATORY_DATA_MISSING.name(),
						CheckInValidationConstants.FLIGHT_SEGMENTS_PATH, DEVELOPER_MESSAGE_OPERATIONAL));

		Mockito.when(validationServiceExceptionGenerator.createValidationError(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.KIOSK_LOCATION_PATH,
				DEVELOPER_MESSAGE_OPERATIONAL))
				.thenReturn(createValidationServiceException(CheckInErrorCode.MANDATORY_DATA_MISSING.name(),
						CheckInValidationConstants.KIOSK_LOCATION_PATH, DEVELOPER_MESSAGE_OPERATIONAL));
		validationServiceExceptionList = operationalCheckValidation.validate(checkIn);

		Assert.assertEquals(2, validationServiceExceptionList.size());
		validationServiceException = validationServiceExceptionList.get(0);

		Assert.assertEquals(CheckInErrorCode.MANDATORY_DATA_MISSING.name(), validationServiceException.getCode());
		Assert.assertEquals(DEVELOPER_MESSAGE_OPERATIONAL, validationServiceException.getDeveloperMessage());
		Assert.assertEquals(CheckInValidationConstants.FLIGHT_SEGMENTS_PATH, validationServiceException.getPath());

		validationServiceException = validationServiceExceptionList.get(1);
		validationServiceExceptionList = operationalCheckValidation.validate(checkIn);
		Assert.assertEquals(CheckInErrorCode.MANDATORY_DATA_MISSING.name(), validationServiceException.getCode());
		Assert.assertEquals(DEVELOPER_MESSAGE_OPERATIONAL, validationServiceException.getDeveloperMessage());
		Assert.assertEquals(CheckInValidationConstants.KIOSK_LOCATION_PATH, validationServiceException.getPath());

	}

	private ValidationServiceException createValidationServiceException(final String serviceErrorCode,
			final String path, final String developerMessage) {
		ValidationServiceException validationServiceException = new ValidationServiceException(serviceErrorCode);
		validationServiceException.setPath(path);
		validationServiceException.setDeveloperMessage(developerMessage);

		return validationServiceException;
	}

	/**
	 * Used for returning JSON string from specified file name
	 * 
	 * @param fileName
	 * @return
	 */
	public String getJSONStringFromFile(String fileName) {
		JSONParser parser = new JSONParser();
		JSONObject jsonObject;
		try {
			ClassLoader classLoader = getClass().getClassLoader();
			File jsonFile = new File(classLoader.getResource(fileName).getFile());
			jsonObject = (JSONObject) parser.parse(new FileReader(jsonFile));
		} catch (Exception e) {
			ApplicationServiceException appExp = new ApplicationServiceException(
					CheckInErrorCode.REQUEST_INVALID.name());
			appExp.setDeveloperMessage(CheckInErrorCode.REQUEST_INVALID.name());
			throw appExp;
		}
		return jsonObject.toString();
	}

}
