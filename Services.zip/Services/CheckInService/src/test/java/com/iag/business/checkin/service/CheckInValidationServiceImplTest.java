package com.iag.business.checkin.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.bind.JAXBException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iag.business.checkin.domain.response.CheckInValidation;
import com.iag.business.checkin.mapper.CheckInValidationResponseMapper;
import com.iag.business.checkin.repository.CheckInValidationRepository;
import com.iag.business.checkin.session.AmadeusSession;
import com.iag.domain.model.CheckIn;

public class CheckInValidationServiceImplTest {
	private final static String BOOKING_ID = "CHK001PAX1S";
	private final static String REQUEST_FILENAME = "static/Json/sampleRequest_1.json";
	public static final String VALIDATION_TYPE = "ELIGIBILITY";
	public static final String SUCCESS_MSG = "SUCCESS";
	public static final String FAILED_MSG = "FAILURE";

	private static final String AMADEUS_PAX2S_JSON = "mock_response/amadeus_PAX2S.json";
	private static final String AMADEUS_PAX1F_JSON = "mock_response/amadeus_PAX1F.json";
	private final static String SAMPLE_REQUEST_PAX2S = "static/Json/amadeus_sample_request_PAX2S.json";
	private final static String SAMPLE_REQUEST_PAX1F = "static/Json/amadeus_sample_request_PAX1F.json";

	@InjectMocks
	CheckInValidationServiceImpl checkInValidationServiceImpl;

	@Mock
	private AmadeusSession session;

	@Mock
	CheckInValidationResponseMapper checkInValidationResponseMapper;

	CheckIn checkIn;

	CheckIn checkInPAX2S;

	CheckIn checkInPAX1F;

	@Mock
	private WebServiceTemplate amadeusWebServiceTemplate;

	@Mock
	private CheckInValidationRepository checkInRepository;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		session = new AmadeusSession();
		checkIn = new ObjectMapper().readValue(getJSONStringFromFile(REQUEST_FILENAME), CheckIn.class);
		checkInPAX2S = new ObjectMapper().readValue(getJSONStringFromFile(SAMPLE_REQUEST_PAX2S), CheckIn.class);
		checkInPAX1F = new ObjectMapper().readValue(getJSONStringFromFile(SAMPLE_REQUEST_PAX1F), CheckIn.class);
	}

	@Test
	public void shouldReturnCheckInValidationSuccessoOutcome() throws Exception {
		Mockito.when(checkInRepository.checkInValidation(BOOKING_ID, session, checkInPAX2S))
				.thenReturn(getMappedResponse(AMADEUS_PAX2S_JSON));
		CheckInValidation checkInValidation = checkInValidationServiceImpl.checkInValidation(BOOKING_ID, session,
				checkInPAX2S);
		assertNotNull(checkInValidation);
		assertNotNull(checkInValidation.getValidationOutcomes());
	}

	/**
	 * Test success response for single passengers
	 * 
	 * @throws IOException
	 * @throws JAXBException
	 */
	@Test
	public void shouldTestCheckInValidationSuccessResponseWithSinglePassenger() throws JAXBException, IOException {
		Mockito.when(checkInRepository.checkInValidation(BOOKING_ID, session, checkInPAX2S))
				.thenReturn(getMappedResponse(AMADEUS_PAX2S_JSON));
		CheckInValidation checkInValidation = checkInValidationServiceImpl.checkInValidation(BOOKING_ID, session,
				checkInPAX2S);
		assertTrue(checkInValidation.getTotalRecords() != 0);
		assertTrue(checkInValidation.getTotalRecords() == checkInValidation.getValidationOutcomes().size());
		assertNotNull(checkInValidation.getValidationOutcomes().iterator().next().getPassenger());
		assertNotNull(
				checkInValidation.getValidationOutcomes().iterator().next().getPassenger().getPassengerIdentifier());
		assertNotNull(checkInValidation.getValidationOutcomes().iterator().next().getCode());
		assertNotNull(checkInValidation.getValidationOutcomes().iterator().next().getResult());
		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().iterator().next().getValidationType());
		assertEquals(SUCCESS_MSG, checkInValidation.getValidationOutcomes().iterator().next().getResult());
		assertEquals(checkInPAX2S.getPassengers().iterator().next().getIdentifier(),
				checkInValidation.getValidationOutcomes().iterator().next().getPassenger().getPassengerIdentifier());

	}

	/**
	 * Test failed response with single passenger in outcome and request
	 * 
	 * @throws IOException
	 * @throws JAXBException
	 */
	@Test
	public void shouldTestCheckInValidationOutcomesFailedResponseWithSinglePassenger()
			throws JAXBException, IOException {
		Mockito.when(checkInRepository.checkInValidation(BOOKING_ID, session, checkInPAX1F))
				.thenReturn(getMappedResponse(AMADEUS_PAX1F_JSON));
		CheckInValidation checkInValidation = checkInValidationServiceImpl.checkInValidation(BOOKING_ID, session,
				checkInPAX1F);
		assertTrue(checkInValidation.getTotalRecords() != 0);
		assertTrue(checkInValidation.getTotalRecords() == checkInValidation.getValidationOutcomes().size());
		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().iterator().next().getValidationType());
		assertEquals(FAILED_MSG, checkInValidation.getValidationOutcomes().iterator().next().getResult());
		assertNotNull(checkInValidation.getValidationOutcomes().iterator().next().getCode());
	}

	/**
	 * Test success response for multiple passengers
	 * 
	 * @throws IOException
	 * @throws JAXBException
	 */
	@Test
	public void shouldTestCheckInValidationSuccessResponseWithMultiplePassengers() throws JAXBException, IOException {
		Mockito.when(checkInRepository.checkInValidation(BOOKING_ID, session, checkInPAX2S))
				.thenReturn(getMappedResponse(AMADEUS_PAX2S_JSON));
		CheckInValidation checkInValidation = checkInValidationServiceImpl.checkInValidation(BOOKING_ID, session,
				checkInPAX2S);
		assertTrue(checkInValidation.getTotalRecords() != 0);
		assertTrue(checkInValidation.getTotalRecords() == checkInValidation.getValidationOutcomes().size());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getPassenger());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getPassenger().getPassengerIdentifier());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getCode());
		assertNotNull(checkInValidation.getValidationOutcomes().get(0).getResult());
		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().get(0).getValidationType());
		assertEquals(SUCCESS_MSG, checkInValidation.getValidationOutcomes().get(0).getResult());

		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getPassenger());
		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getPassenger().getPassengerIdentifier());
		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getCode());
		assertNotNull(checkInValidation.getValidationOutcomes().get(1).getResult());
		assertEquals(VALIDATION_TYPE, checkInValidation.getValidationOutcomes().get(1).getValidationType());
		assertEquals(SUCCESS_MSG, checkInValidation.getValidationOutcomes().get(1).getResult());

		assertEquals(checkInPAX2S.getPassengers().get(0).getIdentifier(),
				checkInValidation.getValidationOutcomes().get(0).getPassenger().getPassengerIdentifier());
		assertEquals(checkInPAX2S.getPassengers().get(1).getIdentifier(),
				checkInValidation.getValidationOutcomes().get(1).getPassenger().getPassengerIdentifier());
	}

	private CheckInValidation getMappedResponse(String fileName) throws IOException {
		InputStream inputstream = new ClassPathResource(fileName).getInputStream();
		CheckInValidation checkInValidation = new ObjectMapper().readValue(inputstream, CheckInValidation.class);
		return checkInValidation;
	}

	/**
	 * Used for returning JSON string from specified file name
	 * 
	 * @param fileName
	 * @return
	 */
	public String getJSONStringFromFile(String fileName) throws Exception {
		JSONParser parser = new JSONParser();
		JSONObject jsonObject;
		ClassLoader classLoader = getClass().getClassLoader();
		File jsonFile = new File(classLoader.getResource(fileName).getFile());
		jsonObject = (JSONObject) parser.parse(new FileReader(jsonFile));
		return jsonObject.toString();
	}

}
