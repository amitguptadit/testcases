package com.iag.business.checkin.validation;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iag.business.checkin.application.exception.ApplicationServiceException;
import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.exception.ValidationServiceExceptionGenerator;
import com.iag.domain.model.CheckIn;
import com.iag.domain.model.party.role.Passenger;

public class PassengerValidationTest {

	@InjectMocks
	private PassengerValidation passengerValidation;

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@Mock
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	ValidationServiceException validationServiceException;

	CheckIn checkin;

	private final static String FILENAME = "static/Json/sampleRequest_1.json";

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		checkin = new ObjectMapper().readValue(getJSONStringFromFile(FILENAME), CheckIn.class);

	}

	@Test
	public void shouldTestCheckInObjectIsNotNull() {
		Mockito.when(validationServiceExceptionGenerator.createValidationError(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.PASSENGER_PATH,
				CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING))
				.thenReturn(createValidationServiceException(CheckInErrorCode.MANDATORY_DATA_MISSING.name(),
						CheckInValidationConstants.PASSENGER_PATH,
						CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING));
		validationServiceException = passengerValidation.validate(null);
		Assert.assertEquals(validationServiceException.getCode(), CheckInErrorCode.MANDATORY_DATA_MISSING.name());
		Assert.assertEquals(CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING,
				validationServiceException.getDeveloperMessage());
		Assert.assertEquals(CheckInValidationConstants.PASSENGER_PATH, validationServiceException.getPath());
	}

	@Test
	public void shouldTestSuccessfulPassengerValidation() throws Exception {
		Mockito.when(validationServiceExceptionGenerator.createValidationError(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.PASSENGER_PATH,
				CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING))
				.thenReturn(createValidationServiceException(CheckInErrorCode.MANDATORY_DATA_MISSING.name(),
						CheckInValidationConstants.PASSENGER_PATH,
						CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING));
		passengerValidation.validate(checkin);

	}

	@Test
	public void shouldTestPassengersListIsNotNull() throws Exception {
		CheckIn checkin = new ObjectMapper().readValue(getJSONStringFromFile(FILENAME), CheckIn.class);
		checkin.setPassengers(null);
		Mockito.when(validationServiceExceptionGenerator.createValidationError(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.PASSENGER_PATH,
				CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING))
				.thenReturn(createValidationServiceException(CheckInErrorCode.MANDATORY_DATA_MISSING.name(),
						CheckInValidationConstants.PASSENGER_PATH,
						CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING));
		validationServiceException = passengerValidation.validate(checkin);
		Assert.assertEquals(validationServiceException.getCode(), CheckInErrorCode.MANDATORY_DATA_MISSING.name());
		Assert.assertEquals(CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING,
				validationServiceException.getDeveloperMessage());
		Assert.assertEquals(CheckInValidationConstants.PASSENGER_PATH, validationServiceException.getPath());

	}

	@Test
	public void shouldTestPassengersListSizeNotEmpty() throws Exception {
		CheckIn checkin = new ObjectMapper().readValue(getJSONStringFromFile(FILENAME), CheckIn.class);
		checkin.setPassengers(new ArrayList<Passenger>());
		Mockito.when(validationServiceExceptionGenerator.createValidationError(
				CheckInErrorCode.MANDATORY_DATA_MISSING.name(), CheckInValidationConstants.PASSENGER_PATH,
				CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING))
				.thenReturn(createValidationServiceException(CheckInErrorCode.MANDATORY_DATA_MISSING.name(),
						CheckInValidationConstants.PASSENGER_PATH,
						CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING));
		validationServiceException = passengerValidation.validate(checkin);
		Assert.assertEquals(validationServiceException.getCode(), CheckInErrorCode.MANDATORY_DATA_MISSING.name());
		Assert.assertEquals(CheckInValidationConstants.DEVELOPER_MESSAGE_MANDATORY_DATA_MISSING,
				validationServiceException.getDeveloperMessage());
		Assert.assertEquals(CheckInValidationConstants.PASSENGER_PATH, validationServiceException.getPath());

	}

	private ValidationServiceException createValidationServiceException(final String serviceErrorCode,
			final String path, final String developerMessage) {
		ValidationServiceException validationServiceException = new ValidationServiceException(serviceErrorCode);
		validationServiceException.setPath(path);
		validationServiceException.setDeveloperMessage(developerMessage);

		return validationServiceException;
	}

	/**
	 * Used for returning JSON string from specified file name
	 * 
	 * @param fileName
	 * @return
	 */
	public String getJSONStringFromFile(String fileName) {
		JSONParser parser = new JSONParser();
		JSONObject jsonObject;
		try {
			ClassLoader classLoader = getClass().getClassLoader();
			File jsonFile = new File(classLoader.getResource(fileName).getFile());
			jsonObject = (JSONObject) parser.parse(new FileReader(jsonFile));
		} catch (Exception e) {
			ApplicationServiceException appExp = new ApplicationServiceException(
					CheckInErrorCode.REQUEST_INVALID.name());
			appExp.setDeveloperMessage(CheckInErrorCode.REQUEST_INVALID.name());
			throw appExp;
		}
		return jsonObject.toString();
	}

}
