package com.iag.business.checkin.mapper;

import javax.xml.transform.dom.DOMResult;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.iag.business.checkin.session.AmadeusSession;

public class CheckInValidationRequestHeaderMapperTest {

	private static final String KIOSK = "KIOSK";
	private static final String GB = "GB";
	private static final String BOOKINGS = "BOOKINGS";

	CheckInValidationRequestHeaderMapper checkInValidationHeaderMapper;
	@Mock
	Element element;
	@Mock
	Document document;

	@Before
	public void setUp() {
		document = Mockito.mock(Document.class);
		element = Mockito.mock(Element.class);
		checkInValidationHeaderMapper = new CheckInValidationRequestHeaderMapper();
	}

	@Test
	public void shouldAddSessionDetailsToSoapHeaderforAllValue() {
		SoapMessage message = Mockito.mock(SoapMessage.class);
		SoapHeader soapHeader = Mockito.mock(SoapHeader.class);
		Mockito.when(message.getSoapHeader()).thenReturn(soapHeader);
		DOMResult xmlHeader = Mockito.mock(DOMResult.class);
		Mockito.when(soapHeader.getResult()).thenReturn(xmlHeader);
		Node headerNode = Mockito.mock(Node.class);
		Mockito.when(xmlHeader.getNode()).thenReturn(headerNode);
		Mockito.when(headerNode.getOwnerDocument()).thenReturn(document);
		Mockito.when(document.createElementNS(Mockito.anyString(), Mockito.anyString())).thenReturn(element);
		checkInValidationHeaderMapper.mapHeaders(message, getSessionRequest());
	}

	@Test
	public void shouldReturnNotWhenSessionIdentifierValueIsNuLL() {
		SoapMessage message = Mockito.mock(SoapMessage.class);
		SoapHeader soapHeader = Mockito.mock(SoapHeader.class);
		Mockito.when(message.getSoapHeader()).thenReturn(soapHeader);
		DOMResult xmlHeader = Mockito.mock(DOMResult.class);
		Mockito.when(soapHeader.getResult()).thenReturn(xmlHeader);
		Node headerNode = Mockito.mock(Node.class);
		Mockito.when(xmlHeader.getNode()).thenReturn(headerNode);
		Mockito.when(headerNode.getOwnerDocument()).thenReturn(document);
		Mockito.when(document.createElementNS(Mockito.anyString(), Mockito.anyString())).thenReturn(element);

		checkInValidationHeaderMapper.mapHeaders(message, getSessionRequestForEmptyIdentifier());

	}

	@Test
	public void shouldReturnNotWhenTokenValueIsNuLL() {
		SoapMessage message = Mockito.mock(SoapMessage.class);
		SoapHeader soapHeader = Mockito.mock(SoapHeader.class);
		Mockito.when(message.getSoapHeader()).thenReturn(soapHeader);
		DOMResult xmlHeader = Mockito.mock(DOMResult.class);
		Mockito.when(soapHeader.getResult()).thenReturn(xmlHeader);
		Node headerNode = Mockito.mock(Node.class);
		Mockito.when(xmlHeader.getNode()).thenReturn(headerNode);
		Mockito.when(headerNode.getOwnerDocument()).thenReturn(document);
		Mockito.when(document.createElementNS(Mockito.anyString(), Mockito.anyString())).thenReturn(element);
		checkInValidationHeaderMapper.mapHeaders(message, getSessionRequestForEmptyToken());

	}

	public AmadeusSession getSessionRequest() {
		AmadeusSession sessionRequest = new AmadeusSession();
		sessionRequest.setChannel(KIOSK);
		sessionRequest.setLocation(GB);
		sessionRequest.setScope(BOOKINGS);
		sessionRequest.setSecurityToken("1S3WS869ESHF43PWZW7EF6H5Y9");
		sessionRequest.setSequenceNumber("1");
		sessionRequest.setSessionId("010A4WCDNO");
		return sessionRequest;
	}

	public AmadeusSession getSessionRequestForEmptyIdentifier() {
		AmadeusSession sessionRequest = new AmadeusSession();
		sessionRequest.setChannel(KIOSK);
		sessionRequest.setLocation(GB);
		sessionRequest.setScope(BOOKINGS);
		sessionRequest.setSecurityToken("1S3WS869ESHF43PWZW7EF6H5Y9");
		sessionRequest.setSequenceNumber("1");
		sessionRequest.setSessionId("");
		return sessionRequest;
	}

	public AmadeusSession getSessionRequestForEmptyToken() {
		AmadeusSession sessionRequest = new AmadeusSession();
		sessionRequest.setChannel(KIOSK);
		sessionRequest.setLocation(GB);
		sessionRequest.setScope(BOOKINGS);
		sessionRequest.setSecurityToken("");
		sessionRequest.setSequenceNumber("1");
		sessionRequest.setSessionId("010A4WCDNO");
		return sessionRequest;
	}
}
