package com.iag.business.checkin;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class ApplicationHealthIndicatorTest {
  @Test
  public void indicatesUp() throws Exception {
    ApplicationHealthIndicator healthIndicator = new ApplicationHealthIndicator();
    assertNotNull(healthIndicator.health());
    assertNotNull(healthIndicator.health().getStatus());
  }
}
