package com.iag.business.checkin.mapper;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.amadeus.xml.cregrr_16_2_1a.ApplicationErrorDetailType;
import com.amadeus.xml.cregrr_16_2_1a.ApplicationErrorInformationType;
import com.amadeus.xml.cregrr_16_2_1a.DCSACCCheckRegulatoryRqtsReply;
import com.amadeus.xml.cregrr_16_2_1a.DCSACCCheckRegulatoryRqtsReply.CustomerLevel;
import com.amadeus.xml.cregrr_16_2_1a.DCSACCCheckRegulatoryRqtsReply.CustomerLevel.ProductLevel;
import com.amadeus.xml.cregrr_16_2_1a.ErrorGroupType;
import com.amadeus.xml.cregrr_16_2_1a.FreeTextInformationType;
import com.amadeus.xml.cregrr_16_2_1a.ItemReferencesAndVersionsType;
import com.amadeus.xml.cregrr_16_2_1a.ItemReferencesAndVersionsType181303S;
import com.amadeus.xml.cregrr_16_2_1a.UniqueIdDescriptionType;
import com.amadeus.xml.cregrr_16_2_1a.UniqueIdDescriptionType254614C;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.domain.response.CheckInValidation;
import com.iag.business.checkin.domain.response.ValidationOutcome;
import com.iag.business.checkin.proxy.config.ServiceProxy;

/**
 * 
 * 
 * Check-in validation response mapper class to map response from Amadeus
 * DCSCPR_EditCPR_16.6 Response
 */
public class CheckInValidationResponseMapperTest {

	public static final String PRIME_ID_1 = "PRIME_ID_1";
	public static final String ITINERARY_IDENTIFIER_1 = "ITINERARY_IDENTIFIER_1";
	public static final String ITINERARY_IDENTIFIER_2 = "ITINERARY_IDENTIFIER_2";
	public static final String ITINERARY_IDENTIFIER_3 = "ITINERARY_IDENTIFIER_3";

	public static final String FREE_TEXT_1 = "FREE_TEXT_1";
	public static final String ERROR_CODE_1 = "123456";
	public static final String ERROR_CODE_1_PREFIX = "VAL123456";
	public static final String DESCRIPTION_1 = "FREE_TEXT_1 ";

	public static final String PRIME_ID_2 = "PRIME_ID_2";
	public static final String FREE_TEXT_2 = "FREE_TEXT_2";
	public static final String ERROR_CODE_2 = "876543";
	public static final String ERROR_CODE_2_PREFIX = "VAL876543";
	public static final String DESCRIPTION_2 = "FREE_TEXT_2 ";

	public static final String PRIME_ID_3 = "PRIME_ID_3";
	public static final String FREE_TEXT_3 = "FREE_TEXT_3";
	public static final String ERROR_CODE_3 = "878788";
	public static final String ERROR_CODE_3_PREFIX = "VAL878788";
	public static final String DESCRIPTION_3 = "FREE_TEXT_3 ";
	public static final String VALIDATION_OUTCOME_DESCRIPTION = "DESCRIPTION";

	public static final String CODE = "VAL003";
	public static final String VALIDATION_OUTCOME_CODE_SUCCESS = "VAL003";

	@InjectMocks
	CheckInValidationResponseMapper CheckInValidationResponseMapper;

	@Mock
	private ServiceProxy configurationInfrastructureServiceProxy;

	private DCSACCCheckRegulatoryRqtsReply amadeusReply;

	private ValidationOutcome validationOutcome;
	private CheckInValidation checkInValidation;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

	}

	@Test
	public void shouldReturnValidationOutcomeWithWarningMessage() {
		checkInValidation = CheckInValidationResponseMapper.map(getAmadeusReplyWithWarningMessage());
		validationOutcome = checkInValidation.getValidationOutcomes().get(0);
		assertEquals(ERROR_CODE_1_PREFIX, validationOutcome.getCode());
		assertEquals(DESCRIPTION_1, validationOutcome.getDescription());
		assertEquals(PRIME_ID_1, validationOutcome.getPassenger().getPassengerIdentifier());
		assertEquals(ITINERARY_IDENTIFIER_1,
				validationOutcome.getPassenger().getItinerary().getItineraryItems().get(0).getIdentifier());
		assertEquals(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_WARNING, validationOutcome.getResult());
		assertEquals(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY, validationOutcome.getValidationType());

	}

	@Test
	public void shouldReturnValidationOutcomeWithFailureMessage() {
		checkInValidation = CheckInValidationResponseMapper.map(getAmadeusReplyWithErrorMessageFailure());
		validationOutcome = checkInValidation.getValidationOutcomes().get(0);
		assertEquals(ERROR_CODE_1_PREFIX, validationOutcome.getCode());
		assertEquals(DESCRIPTION_1, validationOutcome.getDescription());
		assertEquals(PRIME_ID_1, validationOutcome.getPassenger().getPassengerIdentifier());
		assertEquals(ITINERARY_IDENTIFIER_1,
				validationOutcome.getPassenger().getItinerary().getItineraryItems().get(0).getIdentifier());
		assertEquals(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_FAILURE, validationOutcome.getResult());
		assertEquals(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY, validationOutcome.getValidationType());

	}

	@Test
	public void shouldReturnValidationOutcomeWithSuccessMessage() {

		Mockito.when(
				configurationInfrastructureServiceProxy
						.retrieveConfiguration(CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
								CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
										+ CheckInValidationConstants.VALIDATION_OUTCOME_SUCCESS_CODE_KEY))
				.thenReturn(CODE);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_SUCCESS_DESCRIPTION_KEY))
				.thenReturn(VALIDATION_OUTCOME_DESCRIPTION);

		checkInValidation = CheckInValidationResponseMapper.map(getAmadeusReplySinglePassengerSuccessValidation());
		validationOutcome = checkInValidation.getValidationOutcomes().get(0);
		assertEquals(VALIDATION_OUTCOME_CODE_SUCCESS, validationOutcome.getCode());
		assertEquals(VALIDATION_OUTCOME_DESCRIPTION, validationOutcome.getDescription());
		assertEquals(PRIME_ID_1, validationOutcome.getPassenger().getPassengerIdentifier());
		assertEquals(ITINERARY_IDENTIFIER_1,
				validationOutcome.getPassenger().getItinerary().getItineraryItems().get(0).getIdentifier());
		assertEquals(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_SUCCESS, validationOutcome.getResult());
		assertEquals(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY, validationOutcome.getValidationType());

	}

	@Test
	public void shouldReturnValidationOutcomeWithSuccessAndFailureMessage() {

		Mockito.when(
				configurationInfrastructureServiceProxy
						.retrieveConfiguration(CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
								CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
										+ CheckInValidationConstants.VALIDATION_OUTCOME_SUCCESS_CODE_KEY))
				.thenReturn(CODE);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_SUCCESS_DESCRIPTION_KEY))
				.thenReturn(VALIDATION_OUTCOME_DESCRIPTION);

		checkInValidation = CheckInValidationResponseMapper.map(getAmadeusReplySuccessFailValidation());

		validationOutcome = checkInValidation.getValidationOutcomes().get(0);
		assertEquals(ERROR_CODE_1_PREFIX, validationOutcome.getCode());
		assertEquals(DESCRIPTION_1, validationOutcome.getDescription());
		assertEquals(PRIME_ID_1, validationOutcome.getPassenger().getPassengerIdentifier());
		assertEquals(ITINERARY_IDENTIFIER_1,
				validationOutcome.getPassenger().getItinerary().getItineraryItems().get(0).getIdentifier());
		assertEquals(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_FAILURE, validationOutcome.getResult());
		assertEquals(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY, validationOutcome.getValidationType());

		validationOutcome = checkInValidation.getValidationOutcomes().get(1);

		assertEquals(VALIDATION_OUTCOME_CODE_SUCCESS, validationOutcome.getCode());
		assertEquals(VALIDATION_OUTCOME_DESCRIPTION, validationOutcome.getDescription());
		assertEquals(PRIME_ID_2, validationOutcome.getPassenger().getPassengerIdentifier());
		assertEquals(ITINERARY_IDENTIFIER_2,
				validationOutcome.getPassenger().getItinerary().getItineraryItems().get(0).getIdentifier());
		assertEquals(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_SUCCESS, validationOutcome.getResult());
		assertEquals(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY, validationOutcome.getValidationType());

	}

	@Test
	public void shouldReturnMultipleValidationOutcomeWithFailureMessage() {

		Mockito.when(
				configurationInfrastructureServiceProxy
						.retrieveConfiguration(CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
								CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
										+ CheckInValidationConstants.VALIDATION_OUTCOME_SUCCESS_CODE_KEY))
				.thenReturn(CODE);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_SUCCESS_DESCRIPTION_KEY))
				.thenReturn(VALIDATION_OUTCOME_DESCRIPTION);

		checkInValidation = CheckInValidationResponseMapper.map(getAmadeusReplyMultiplePassengerFailValidation());

		validationOutcome = checkInValidation.getValidationOutcomes().get(0);
		assertEquals(ERROR_CODE_1_PREFIX, validationOutcome.getCode());
		assertEquals(DESCRIPTION_1, validationOutcome.getDescription());
		assertEquals(PRIME_ID_1, validationOutcome.getPassenger().getPassengerIdentifier());
		assertEquals(ITINERARY_IDENTIFIER_1,
				validationOutcome.getPassenger().getItinerary().getItineraryItems().get(0).getIdentifier());
		assertEquals(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_FAILURE, validationOutcome.getResult());
		assertEquals(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY, validationOutcome.getValidationType());

		validationOutcome = checkInValidation.getValidationOutcomes().get(1);
		assertEquals(ERROR_CODE_2_PREFIX, validationOutcome.getCode());
		assertEquals(DESCRIPTION_2, validationOutcome.getDescription());
		assertEquals(PRIME_ID_2, validationOutcome.getPassenger().getPassengerIdentifier());
		assertEquals(ITINERARY_IDENTIFIER_2,
				validationOutcome.getPassenger().getItinerary().getItineraryItems().get(0).getIdentifier());
		assertEquals(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_FAILURE, validationOutcome.getResult());
		assertEquals(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY, validationOutcome.getValidationType());

	}

	@Test
	public void shouldReturnMultipleValidationOutcomeWithSuccessMessage() {

		Mockito.when(
				configurationInfrastructureServiceProxy
						.retrieveConfiguration(CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
								CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
										+ CheckInValidationConstants.VALIDATION_OUTCOME_SUCCESS_CODE_KEY))
				.thenReturn(CODE);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_SUCCESS_DESCRIPTION_KEY))
				.thenReturn(VALIDATION_OUTCOME_DESCRIPTION);

		checkInValidation = CheckInValidationResponseMapper.map(getAmadeusReplyMultiplePassengerSuccessValidation());

		validationOutcome = checkInValidation.getValidationOutcomes().get(0);
		assertEquals(VALIDATION_OUTCOME_CODE_SUCCESS, validationOutcome.getCode());
		assertEquals(VALIDATION_OUTCOME_DESCRIPTION, validationOutcome.getDescription());
		assertEquals(PRIME_ID_1, validationOutcome.getPassenger().getPassengerIdentifier());
		assertEquals(ITINERARY_IDENTIFIER_1,
				validationOutcome.getPassenger().getItinerary().getItineraryItems().get(0).getIdentifier());
		assertEquals(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_SUCCESS, validationOutcome.getResult());
		assertEquals(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY, validationOutcome.getValidationType());

		validationOutcome = checkInValidation.getValidationOutcomes().get(1);

		assertEquals(VALIDATION_OUTCOME_CODE_SUCCESS, validationOutcome.getCode());
		assertEquals(VALIDATION_OUTCOME_DESCRIPTION, validationOutcome.getDescription());
		assertEquals(PRIME_ID_2, validationOutcome.getPassenger().getPassengerIdentifier());
		assertEquals(ITINERARY_IDENTIFIER_2,
				validationOutcome.getPassenger().getItinerary().getItineraryItems().get(0).getIdentifier());
		assertEquals(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_SUCCESS, validationOutcome.getResult());
		assertEquals(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY, validationOutcome.getValidationType());

	}

	@Test
	public void shouldReturnMultipleValidationOutcomeWithSuccessAndFailureMessage() {

		Mockito.when(
				configurationInfrastructureServiceProxy
						.retrieveConfiguration(CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
								CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
										+ CheckInValidationConstants.VALIDATION_OUTCOME_SUCCESS_CODE_KEY))
				.thenReturn(CODE);

		Mockito.when(configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.VALIDATION_OUTCOME_NAMESPACE,
				CheckInValidationConstants.VALIDATION_OUTCOME_PREFIX
						+ CheckInValidationConstants.VALIDATION_OUTCOME_SUCCESS_DESCRIPTION_KEY))
				.thenReturn(VALIDATION_OUTCOME_DESCRIPTION);

		checkInValidation = CheckInValidationResponseMapper
				.map(getAmadeusReplyMultiplePassengerSuccessFailValidation());

		validationOutcome = checkInValidation.getValidationOutcomes().get(0);
		assertEquals(VALIDATION_OUTCOME_CODE_SUCCESS, validationOutcome.getCode());
		assertEquals(VALIDATION_OUTCOME_DESCRIPTION, validationOutcome.getDescription());
		assertEquals(PRIME_ID_1, validationOutcome.getPassenger().getPassengerIdentifier());
		assertEquals(ITINERARY_IDENTIFIER_1,
				validationOutcome.getPassenger().getItinerary().getItineraryItems().get(0).getIdentifier());
		assertEquals(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_SUCCESS, validationOutcome.getResult());
		assertEquals(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY, validationOutcome.getValidationType());

		validationOutcome = checkInValidation.getValidationOutcomes().get(1);

		assertEquals(VALIDATION_OUTCOME_CODE_SUCCESS, validationOutcome.getCode());
		assertEquals(VALIDATION_OUTCOME_DESCRIPTION, validationOutcome.getDescription());
		assertEquals(PRIME_ID_2, validationOutcome.getPassenger().getPassengerIdentifier());
		assertEquals(ITINERARY_IDENTIFIER_2,
				validationOutcome.getPassenger().getItinerary().getItineraryItems().get(0).getIdentifier());
		assertEquals(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_SUCCESS, validationOutcome.getResult());
		assertEquals(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY, validationOutcome.getValidationType());

		validationOutcome = checkInValidation.getValidationOutcomes().get(2);
		assertEquals(ERROR_CODE_3_PREFIX, validationOutcome.getCode());
		assertEquals(DESCRIPTION_3, validationOutcome.getDescription());
		assertEquals(PRIME_ID_3, validationOutcome.getPassenger().getPassengerIdentifier());
		assertEquals(ITINERARY_IDENTIFIER_3,
				validationOutcome.getPassenger().getItinerary().getItineraryItems().get(0).getIdentifier());
		assertEquals(CheckInValidationConstants.VALIDATION_OUTCOME_RESULT_FAILURE, validationOutcome.getResult());
		assertEquals(CheckInValidationConstants.VALIDATION_TYPE_ELIGIBILITY, validationOutcome.getValidationType());

	}

	public DCSACCCheckRegulatoryRqtsReply getAmadeusReplySinglePassengerfailValidation() {
		amadeusReply = new DCSACCCheckRegulatoryRqtsReply();
		List<CustomerLevel> customerLevelList = new ArrayList<CustomerLevel>();
		CustomerLevel customerLevel = new CustomerLevel();
		ErrorGroupType errorGroupType = new ErrorGroupType();
		ApplicationErrorInformationType infoType = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel, PRIME_ID_1);
		setFreeText(errorGroupType, infoType, FREE_TEXT_1);
		setErrorcode(errorGroupType, infoType, ERROR_CODE_1);
		setProductLevel(errorGroupType, customerLevel, ITINERARY_IDENTIFIER_1);
		errorGroupType.getErrorOrWarningCodeDetails().getErrorDetails()
				.setErrorCategory(CheckInValidationConstants.ERROR_CATEGORY_FAILURE);
		customerLevelList.add(customerLevel);
		amadeusReply.setCustomerLevel(customerLevelList);
		return amadeusReply;
	}

	public DCSACCCheckRegulatoryRqtsReply getAmadeusReplyWithWarningMessage() {
		amadeusReply = new DCSACCCheckRegulatoryRqtsReply();
		List<CustomerLevel> customerLevelList = new ArrayList<CustomerLevel>();
		CustomerLevel customerLevel = new CustomerLevel();
		ErrorGroupType errorGroupType = new ErrorGroupType();
		ApplicationErrorInformationType infoType = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel, PRIME_ID_1);
		setFreeText(errorGroupType, infoType, FREE_TEXT_1);
		setErrorcode(errorGroupType, infoType, ERROR_CODE_1);
		errorGroupType.getErrorOrWarningCodeDetails().getErrorDetails()
				.setErrorCategory(CheckInValidationConstants.ERROR_CATEGORY_WARNING);
		setProductLevel(errorGroupType, customerLevel, ITINERARY_IDENTIFIER_1);
		customerLevelList.add(customerLevel);
		amadeusReply.setCustomerLevel(customerLevelList);
		return amadeusReply;
	}

	public DCSACCCheckRegulatoryRqtsReply getAmadeusReplyWithErrorMessageFailure() {
		amadeusReply = new DCSACCCheckRegulatoryRqtsReply();
		List<CustomerLevel> customerLevelList = new ArrayList<CustomerLevel>();
		CustomerLevel customerLevel = new CustomerLevel();
		ErrorGroupType errorGroupType = new ErrorGroupType();
		ApplicationErrorInformationType infoType = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel, PRIME_ID_1);
		setFreeText(errorGroupType, infoType, FREE_TEXT_1);
		setErrorcode(errorGroupType, infoType, ERROR_CODE_1);
		errorGroupType.getErrorOrWarningCodeDetails().getErrorDetails()
				.setErrorCategory(CheckInValidationConstants.ERROR_CATEGORY_FAILURE);
		setProductLevel(errorGroupType, customerLevel, ITINERARY_IDENTIFIER_1);
		customerLevelList.add(customerLevel);
		amadeusReply.setCustomerLevel(customerLevelList);
		return amadeusReply;
	}

	public DCSACCCheckRegulatoryRqtsReply getAmadeusReplySinglePassengerSuccessValidation() {
		amadeusReply = new DCSACCCheckRegulatoryRqtsReply();
		List<CustomerLevel> customerLevelList = new ArrayList<CustomerLevel>();
		CustomerLevel customerLevel = new CustomerLevel();
		ErrorGroupType errorGroupType = new ErrorGroupType();
		ApplicationErrorInformationType infoType = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel, PRIME_ID_1);
		setFreeText(errorGroupType, infoType, FREE_TEXT_1);
		setProductLevelWithoutErrors(customerLevel, ITINERARY_IDENTIFIER_1);
		customerLevelList.add(customerLevel);
		amadeusReply.setCustomerLevel(customerLevelList);
		return amadeusReply;
	}

	public DCSACCCheckRegulatoryRqtsReply getAmadeusReplyMultiplePassengerFailValidation() {
		amadeusReply = new DCSACCCheckRegulatoryRqtsReply();
		List<CustomerLevel> customerLevelList = new ArrayList<CustomerLevel>();

		CustomerLevel customerLevel = new CustomerLevel();
		ErrorGroupType errorGroupType = new ErrorGroupType();
		ApplicationErrorInformationType infoType = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel, PRIME_ID_1);
		setFreeText(errorGroupType, infoType, FREE_TEXT_1);
		setErrorcode(errorGroupType, infoType, ERROR_CODE_1);
		errorGroupType.getErrorOrWarningCodeDetails().getErrorDetails()
				.setErrorCategory(CheckInValidationConstants.ERROR_CATEGORY_FAILURE);
		setProductLevel(errorGroupType, customerLevel, ITINERARY_IDENTIFIER_1);
		customerLevelList.add(customerLevel);

		CustomerLevel customerLevel2 = new CustomerLevel();
		ErrorGroupType errorGroupType2 = new ErrorGroupType();
		ApplicationErrorInformationType infoType2 = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel2, PRIME_ID_2);
		setFreeText(errorGroupType2, infoType2, FREE_TEXT_2);
		setErrorcode(errorGroupType2, infoType2, ERROR_CODE_2);
		errorGroupType2.getErrorOrWarningCodeDetails().getErrorDetails()
				.setErrorCategory(CheckInValidationConstants.ERROR_CATEGORY_FAILURE);
		setProductLevel(errorGroupType2, customerLevel2, ITINERARY_IDENTIFIER_2);
		customerLevelList.add(customerLevel2);
		amadeusReply.setCustomerLevel(customerLevelList);

		return amadeusReply;
	}

	public DCSACCCheckRegulatoryRqtsReply getAmadeusReplyMultiplePassengerSuccessValidation() {
		amadeusReply = new DCSACCCheckRegulatoryRqtsReply();
		List<CustomerLevel> customerLevelList = new ArrayList<CustomerLevel>();

		CustomerLevel customerLevel = new CustomerLevel();
		ErrorGroupType errorGroupType = new ErrorGroupType();
		ApplicationErrorInformationType infoType = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel, PRIME_ID_1);
		setFreeText(errorGroupType, infoType, FREE_TEXT_1);
		setProductLevelWithoutErrors(customerLevel, ITINERARY_IDENTIFIER_1);
		customerLevelList.add(customerLevel);

		CustomerLevel customerLevel2 = new CustomerLevel();
		ErrorGroupType errorGroupType2 = new ErrorGroupType();
		ApplicationErrorInformationType infoType2 = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel2, PRIME_ID_2);
		setFreeText(errorGroupType2, infoType2, FREE_TEXT_2);
		setProductLevelWithoutErrors(customerLevel2, ITINERARY_IDENTIFIER_2);
		customerLevelList.add(customerLevel2);
		amadeusReply.setCustomerLevel(customerLevelList);

		return amadeusReply;
	}

	public DCSACCCheckRegulatoryRqtsReply getAmadeusReplyMultiplePassengerSuccessFailValidation() {
		amadeusReply = new DCSACCCheckRegulatoryRqtsReply();
		List<CustomerLevel> customerLevelList = new ArrayList<CustomerLevel>();

		CustomerLevel customerLevel = new CustomerLevel();
		ErrorGroupType errorGroupType = new ErrorGroupType();
		ApplicationErrorInformationType infoType = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel, PRIME_ID_1);
		setFreeText(errorGroupType, infoType, FREE_TEXT_1);
		setProductLevelWithoutErrors(customerLevel, ITINERARY_IDENTIFIER_1);
		customerLevelList.add(customerLevel);

		CustomerLevel customerLevel2 = new CustomerLevel();
		ErrorGroupType errorGroupType2 = new ErrorGroupType();
		ApplicationErrorInformationType infoType2 = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel2, PRIME_ID_2);
		setFreeText(errorGroupType2, infoType2, FREE_TEXT_2);
		setProductLevelWithoutErrors(customerLevel2, ITINERARY_IDENTIFIER_2);
		customerLevelList.add(customerLevel2);

		CustomerLevel customerLevel3 = new CustomerLevel();
		ErrorGroupType errorGroupType3 = new ErrorGroupType();
		ApplicationErrorInformationType infoType3 = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel3, PRIME_ID_3);
		setFreeText(errorGroupType3, infoType3, FREE_TEXT_3);
		setErrorcode(errorGroupType3, infoType3, ERROR_CODE_3);
		errorGroupType3.getErrorOrWarningCodeDetails().getErrorDetails()
				.setErrorCategory(CheckInValidationConstants.ERROR_CATEGORY_FAILURE);
		setProductLevel(errorGroupType3, customerLevel3, ITINERARY_IDENTIFIER_3);
		customerLevelList.add(customerLevel3);

		amadeusReply.setCustomerLevel(customerLevelList);

		return amadeusReply;
	}

	public DCSACCCheckRegulatoryRqtsReply getAmadeusReplySuccessFailValidation() {
		amadeusReply = new DCSACCCheckRegulatoryRqtsReply();
		List<CustomerLevel> customerLevelList = new ArrayList<CustomerLevel>();

		CustomerLevel customerLevel = new CustomerLevel();
		ErrorGroupType errorGroupType = new ErrorGroupType();
		ApplicationErrorInformationType infoType = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel, PRIME_ID_1);
		setFreeText(errorGroupType, infoType, FREE_TEXT_1);
		setErrorcode(errorGroupType, infoType, ERROR_CODE_1);
		errorGroupType.getErrorOrWarningCodeDetails().getErrorDetails()
				.setErrorCategory(CheckInValidationConstants.ERROR_CATEGORY_FAILURE);
		setProductLevel(errorGroupType, customerLevel, ITINERARY_IDENTIFIER_1);
		customerLevelList.add(customerLevel);

		CustomerLevel customerLevel2 = new CustomerLevel();

		ErrorGroupType errorGroupType2 = new ErrorGroupType();
		ApplicationErrorInformationType infoType2 = new ApplicationErrorInformationType();
		setPassengerIdentifier(customerLevel2, PRIME_ID_2);
		setFreeText(errorGroupType2, infoType2, FREE_TEXT_2);
		setProductLevelWithoutErrors(customerLevel2, ITINERARY_IDENTIFIER_2);
		customerLevelList.add(customerLevel2);
		amadeusReply.setCustomerLevel(customerLevelList);

		return amadeusReply;
	}

	public void setPassengerIdentifier(CustomerLevel customerLevel, String primeId) {

		ItemReferencesAndVersionsType itemReferencesAndVersionsType = new ItemReferencesAndVersionsType();

		UniqueIdDescriptionType uniqueIdDescriptionType = new UniqueIdDescriptionType();
		uniqueIdDescriptionType.setPrimeId(primeId);
		itemReferencesAndVersionsType.setIdSection(uniqueIdDescriptionType);
		customerLevel.setCustomerIdentifier(itemReferencesAndVersionsType);

	}

	public void setFreeText(ErrorGroupType errorGroupType, ApplicationErrorInformationType infoType, String freeText) {
		FreeTextInformationType freeTextInformationType = new FreeTextInformationType();
		List<String> freeTextList = new ArrayList<String>();
		freeTextList.add(freeText);
		freeTextInformationType.setFreeText(freeTextList);
		errorGroupType.setErrorWarningDescription(freeTextInformationType);
	}

	public void setErrorcode(ErrorGroupType errorGroupType, ApplicationErrorInformationType infoType,
			String errorCode) {

		ApplicationErrorDetailType detailType = new ApplicationErrorDetailType();
		detailType.setErrorCode(errorCode);
		infoType.setErrorDetails(detailType);
		errorGroupType.setErrorOrWarningCodeDetails(infoType);
	}

	public void setProductLevel(ErrorGroupType errorGroupType, CustomerLevel customerLevel,
			String itineraryIdentifier) {
		ProductLevel productLevel = new ProductLevel();
		List<ErrorGroupType> errorGroupTypeList = new ArrayList<ErrorGroupType>();
		List<ProductLevel> productLevelList = new ArrayList<ProductLevel>();

		errorGroupTypeList.add(errorGroupType);
		productLevel.setErrors(errorGroupTypeList);
		setItineraryIdentifier(productLevel, itineraryIdentifier);
		productLevelList.add(productLevel);
		customerLevel.setProductLevel(productLevelList);
	}

	public void setProductLevelWithoutErrors(CustomerLevel customerLevel, String itineraryIdentifier) {
		ProductLevel productLevel = new ProductLevel();
		List<ErrorGroupType> errorGroupTypeList = new ArrayList<ErrorGroupType>();
		List<ProductLevel> productLevelList = new ArrayList<ProductLevel>();
		productLevel.setErrors(errorGroupTypeList);
		setItineraryIdentifier(productLevel, itineraryIdentifier);
		productLevelList.add(productLevel);
		customerLevel.setProductLevel(productLevelList);
	}

	public void setItineraryIdentifier(ProductLevel productLevel, String itineraryIdentifier) {
		ItemReferencesAndVersionsType181303S itemReferencesAndVersionsType = new ItemReferencesAndVersionsType181303S();
		UniqueIdDescriptionType254614C uniqueIdDescriptionType = new UniqueIdDescriptionType254614C();
		uniqueIdDescriptionType.setPrimeId(itineraryIdentifier);
		itemReferencesAndVersionsType.setIdSection(uniqueIdDescriptionType);
		productLevel.setProductIdentifier(itemReferencesAndVersionsType);

	}

}
