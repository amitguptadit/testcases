package com.iag.business.checkin.application.error;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ValidationErrorTest {
  
  private ValidationError validationError;
  
  private static final String ERROR_CODE = "REQUEST_INVALID";
  
  @Before
  public void setUp(){
    validationError = new ValidationError(ERROR_CODE);
  }
  
  @Test
  public void shouldAddValidationError(){    
    validationError.addValidationError(new ValidationError(ERROR_CODE));
    Assert.assertEquals(ERROR_CODE, validationError.getCode());
    
    validationError.addValidationError(new ValidationError(ERROR_CODE));
  }
  
  @Test
  public void shouldRunWhenValidationErrorInstanceIsSerializable() throws JsonProcessingException{
    ValidationError childValidationError = new ValidationError(ERROR_CODE);
    childValidationError.setBusinessMessage("Request Invalid");
    childValidationError.setDeveloperLink("www.iag.com");
    childValidationError.setPath("serive-path");
    validationError.addValidationError(childValidationError);
    Assert.assertEquals(ERROR_CODE, validationError.getCode());
    ObjectMapper mapper = new ObjectMapper();
    Assert.assertTrue(mapper.canSerialize(validationError.getClass()));
    String errorAsJsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(validationError);
    System.out.println(errorAsJsonString);    
   
  }
}
