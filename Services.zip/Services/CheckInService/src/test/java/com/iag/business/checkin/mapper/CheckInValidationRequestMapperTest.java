package com.iag.business.checkin.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Before;
import org.junit.Test;

import com.amadeus.xml.cregrq_16_2_1a.DCSACCCheckRegulatoryRqts;
import com.amadeus.xml.cregrq_16_2_1a.DCSACCCheckRegulatoryRqts.CustomerLevel;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.domain.model.CarrierType;
import com.iag.domain.model.CheckIn;
import com.iag.domain.model.party.role.Passenger;

public class CheckInValidationRequestMapperTest {

	CheckInValidationRequestMapper checkInValidationRequestMapper;

	private final static String SAMPLE_REQUEST_PAX1F = "static/Json/amadeus_sample_request_PAX1F.json";
	private final static String SAMPLE_REQUEST_PAX2S = "static/Json/amadeus_sample_request_PAX2S.json";
	private final static String SAMPLE_REQUEST_NON_MARKETING = "static/Json/sample_request_non_marketing.json";
	private final static String SAMPLE_REQUEST_MULTIPLE_PRODUCT_LEVEL = "static/Json/amadeus_sample_multiple_leg.json";


	@Before
	public void setUp() {
		checkInValidationRequestMapper = new CheckInValidationRequestMapper();
	}

	@Test
	public void shouldCreateRequestForSinglePassenger() throws IOException, ParseException {
		CheckIn checkIn = getDummyCheckInObject(SAMPLE_REQUEST_PAX1F);
		DCSACCCheckRegulatoryRqts dcsaccCheckRegulatoryRqts = checkInValidationRequestMapper.map(checkIn);
		assertNotEquals(null, dcsaccCheckRegulatoryRqts);
		assertNotNull(dcsaccCheckRegulatoryRqts.getCustomerLevel());
		assertTrue(dcsaccCheckRegulatoryRqts.getCustomerLevel().size() == checkIn.getPassengers().size());
		doCustomerLevelValidation(dcsaccCheckRegulatoryRqts.getCustomerLevel().iterator().next());
		doProductLevelValidation(dcsaccCheckRegulatoryRqts.getCustomerLevel().iterator().next(),
				checkIn.getPassengers().iterator().next());
	}

	@Test
	public void shouldTestNonMarketingCarrier() throws IOException, ParseException {
		CheckIn checkIn = getDummyCheckInObject(SAMPLE_REQUEST_NON_MARKETING);
		DCSACCCheckRegulatoryRqts dcsaccCheckRegulatoryRqts = checkInValidationRequestMapper.map(checkIn);
		assertNotEquals(null, dcsaccCheckRegulatoryRqts);
		assertNotNull(dcsaccCheckRegulatoryRqts.getCustomerLevel());
		assertTrue(dcsaccCheckRegulatoryRqts.getCustomerLevel().size() == checkIn.getPassengers().size());
	}

	@Test
	public void shouldTestMultipleProduct() throws IOException, ParseException {
		CheckIn checkIn = getDummyCheckInObject(SAMPLE_REQUEST_MULTIPLE_PRODUCT_LEVEL);
		DCSACCCheckRegulatoryRqts dcsaccCheckRegulatoryRqts = checkInValidationRequestMapper.map(checkIn);
		assertNotEquals(null, dcsaccCheckRegulatoryRqts);
		assertNotNull(dcsaccCheckRegulatoryRqts.getCustomerLevel());
		assertTrue(dcsaccCheckRegulatoryRqts.getCustomerLevel().size() == checkIn.getPassengers().size());
		assertTrue(dcsaccCheckRegulatoryRqts.getCustomerLevel().get(0).getProductLevel().get(0).getProductIdentifier()
				.getIdSection().getPrimeId() == checkIn.getPassengers().iterator().next().getItinerary()
						.getItineraryItems().get(0).getIdentifier());
		assertTrue(dcsaccCheckRegulatoryRqts.getCustomerLevel().get(0).getProductLevel().get(1).getProductIdentifier()
				.getIdSection().getPrimeId() == checkIn.getPassengers().iterator().next().getItinerary()
						.getItineraryItems().get(1).getIdentifier());
		assertEquals(
				checkIn.getPassengers().iterator().next().getItinerary().getItineraryItems().get(0).getCarriers().get(0)
						.getCode(),
				dcsaccCheckRegulatoryRqts.getCustomerLevel().get(0).getProductLevel().get(0).getOperatingFlightDetails()
						.getCarrierDetails().getMarketingCarrier());
		assertEquals(
				checkIn.getPassengers().iterator().next().getItinerary().getItineraryItems().get(1).getCarriers().get(0)
						.getCode(),
				dcsaccCheckRegulatoryRqts.getCustomerLevel().get(0).getProductLevel().get(1).getOperatingFlightDetails()
						.getCarrierDetails().getMarketingCarrier());
		assertEquals(
				checkIn.getPassengers().iterator().next().getItinerary().getItineraryItems().get(0).getOrigin()
						.getIdentifier(),
				dcsaccCheckRegulatoryRqts.getCustomerLevel().get(0).getProductLevel().get(0).getOperatingFlightDetails()
						.getBoardPoint());
		assertEquals(
				checkIn.getPassengers().iterator().next().getItinerary().getItineraryItems().get(1).getOrigin()
						.getIdentifier(),
				dcsaccCheckRegulatoryRqts.getCustomerLevel().get(0).getProductLevel().get(1).getOperatingFlightDetails()
						.getBoardPoint());
		assertEquals(
				checkIn.getPassengers().iterator().next().getItinerary().getItineraryItems().get(0).getDestination()
						.getIdentifier(),
				dcsaccCheckRegulatoryRqts.getCustomerLevel().get(0).getProductLevel().get(0).getOperatingFlightDetails()
						.getOffPoint());
		assertEquals(
				checkIn.getPassengers().iterator().next().getItinerary().getItineraryItems().get(1).getDestination()
						.getIdentifier(),
				dcsaccCheckRegulatoryRqts.getCustomerLevel().get(0).getProductLevel().get(1).getOperatingFlightDetails()
						.getOffPoint());

	}

	@Test
	public void shouldCreateRequestForMultiplePassenger() throws IOException, ParseException {
		CheckIn checkIn = getDummyCheckInObject(SAMPLE_REQUEST_PAX2S);
		DCSACCCheckRegulatoryRqts dcsaccCheckRegulatoryRqts = checkInValidationRequestMapper.map(checkIn);
		assertNotEquals(null, dcsaccCheckRegulatoryRqts);
		assertNotNull(dcsaccCheckRegulatoryRqts.getCustomerLevel());
		assertTrue(dcsaccCheckRegulatoryRqts.getCustomerLevel().size() == checkIn.getPassengers().size());
		// customer level validation for first passenger
		doCustomerLevelValidation(dcsaccCheckRegulatoryRqts.getCustomerLevel().get(0));
		// customer level validation for second passenger
		doCustomerLevelValidation(dcsaccCheckRegulatoryRqts.getCustomerLevel().get(1));

		// product level validation for first passenger
		doProductLevelValidation(dcsaccCheckRegulatoryRqts.getCustomerLevel().get(0), checkIn.getPassengers().get(0));
		// product level validation for second passenger
		doProductLevelValidation(dcsaccCheckRegulatoryRqts.getCustomerLevel().get(1), checkIn.getPassengers().get(1));
	}

	private void doProductLevelValidation(CustomerLevel customerLevel, Passenger<?> passenger) {

		// validating marketing carrier code
		String marketingCarrierInRequest = customerLevel.getProductLevel().iterator().next().getOperatingFlightDetails()
				.getCarrierDetails().getMarketingCarrier();
		String marketingCarrierInCheckInObject = passenger.getItinerary().getItineraryItems().iterator().next()
				.getCarriers().iterator().next().getCode();
		assertNotNull(marketingCarrierInRequest);
		assertEquals(marketingCarrierInRequest, marketingCarrierInCheckInObject);
		assertEquals(CarrierType.MARKETING.name(), passenger.getItinerary().getItineraryItems().iterator().next()
				.getCarriers().iterator().next().getType().name());

		// validating flight details
		assertNotNull(customerLevel.getProductLevel().iterator().next().getOperatingFlightDetails().getFlightDetails());
		BigInteger flightDetailsInRequest = customerLevel.getProductLevel().iterator().next()
				.getOperatingFlightDetails().getFlightDetails().getFlightNumber();
		String flightDetailsInCheckInObject = passenger.getItinerary().getItineraryItems().iterator().next()
				.getCarriers().iterator().next().getFlightNumber();
		assertNotNull(flightDetailsInRequest);
		assertEquals(flightDetailsInRequest, new BigInteger(flightDetailsInCheckInObject));

		// validation borading point
		String boardingPointInMappedRequest = customerLevel.getProductLevel().iterator().next()
				.getOperatingFlightDetails().getBoardPoint();
		String boardingPointInCheckInObject = passenger.getItinerary().getItineraryItems().iterator().next().getOrigin()
				.getIdentifier();
		assertNotNull(boardingPointInMappedRequest);
		assertEquals(boardingPointInMappedRequest, boardingPointInCheckInObject);

		// validation off point
		String offPointInMappedRequest = customerLevel.getProductLevel().iterator().next().getOperatingFlightDetails()
				.getOffPoint();
		String offPointInCheckInObject = passenger.getItinerary().getItineraryItems().iterator().next().getDestination()
				.getIdentifier();
		assertNotNull(offPointInMappedRequest);
		assertEquals(offPointInMappedRequest, offPointInCheckInObject);

		// validating prime Id for under Id section
		assertNotNull(customerLevel.getProductLevel().iterator().next().getProductIdentifier().getIdSection());
		String primeIdInMappedRequest = customerLevel.getProductLevel().iterator().next().getProductIdentifier()
				.getIdSection().getPrimeId();
		String primeIdInCheckInObject = passenger.getItinerary().getItineraryItems().iterator().next().getIdentifier();
		assertNotNull(primeIdInMappedRequest);
		assertNotNull(primeIdInMappedRequest, primeIdInCheckInObject);

		// validating arrival and departure dates
		assertNotNull(customerLevel.getProductLevel().iterator().next().getOperatingFlightDetails().getArrivalDate());
		assertNotNull(customerLevel.getProductLevel().iterator().next().getOperatingFlightDetails().getDepartureDate());

		assertEquals(CheckInValidationConstants.REFERENCE_QUALIFIER_PRODUCT_LEVEL, customerLevel.getProductLevel()
				.iterator().next().getProductIdentifier().getIdSection().getReferenceQualifier());

	}

	private void doCustomerLevelValidation(CustomerLevel customerLevel) {
		assertEquals(CheckInValidationConstants.REFERENCE_QUALIFIER,
				customerLevel.getCustomerIdentifier().getIdSection().getReferenceQualifier());
		assertNotNull(customerLevel.getCustomerIdentifier().getIdSection().getPrimeId());
		assertNotNull(customerLevel.getProductLevel());
		assertNotNull(customerLevel.getProductLevel().iterator().next().getOperatingFlightDetails());
		assertNotNull(
				customerLevel.getProductLevel().iterator().next().getOperatingFlightDetails().getCarrierDetails());
	}

	/**
	 * Return Sample CheckIn object
	 * 
	 * @param fileName
	 * @return
	 * @throws IOException
	 * @throws ParseException
	 */
	private CheckIn getDummyCheckInObject(String fileName) throws IOException, ParseException {
		CheckIn checkIn = new ObjectMapper().readValue(getJSONStringFromFile(fileName), CheckIn.class);
		return checkIn;
	}

	/**
	 * Used for returning JSON string from specified file name
	 * 
	 * @param fileName
	 * @return
	 * @throws ParseException
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public String getJSONStringFromFile(String fileName) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONObject jsonObject;
		ClassLoader classLoader = getClass().getClassLoader();
		File jsonFile = new File(classLoader.getResource(fileName).getFile());
		jsonObject = (JSONObject) parser.parse(new FileReader(jsonFile));
		return jsonObject.toString();
	}

}
