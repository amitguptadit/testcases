package com.iag.business.checkin.validation;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.exception.ValidationServiceExceptionGenerator;

public class BookingIdentifierValidationTest {

	@InjectMocks
	private BookingIdentifierValidation bookingIdentifierValidation;

	@Mock
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	ValidationServiceException validationServiceException;

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	private static final String BOOKING_IDENTIFIER_VALID_CHARACTER = "TK001213";

	private static final String BOOKING_IDENTIFIER_ABOVERANGE_CHARACTER = "ETYTIRTPIRTPIWTPIWPITTWTYTIW6722725722929";

	private static final String INVALID_BOOKING_IDENTIFIER = "TK@#$$$$";

	@Before
	public void setUp() {
		validationServiceExceptionGenerator = mock(ValidationServiceExceptionGenerator.class);
		MockitoAnnotations.initMocks(this);

	}

	@Test
	public void shouldValidateValidBookingIdentifier() {
		validationServiceException = bookingIdentifierValidation.validate(BOOKING_IDENTIFIER_VALID_CHARACTER);
		assertEquals(null, validationServiceException);

	}

	@Test
	public void shouldValidateInValidBookingIdentifier() {
		Mockito.when(validationServiceExceptionGenerator.createValidationError(CheckInErrorCode.DATA_INVALID.name(),
				CheckInValidationConstants.BOOKING_IDENTIFIER_PATH, CheckInValidationConstants.DEVELOPER_MESSAGE_BOOKING_IDENTIFIER))
				.thenReturn(createValidationServiceException(CheckInErrorCode.DATA_INVALID.name(),
						CheckInValidationConstants.BOOKING_IDENTIFIER_PATH,
						CheckInValidationConstants.DEVELOPER_MESSAGE_BOOKING_IDENTIFIER));

		validationServiceException = bookingIdentifierValidation.validate(INVALID_BOOKING_IDENTIFIER);
		Assert.assertEquals(validationServiceException.getCode(), CheckInErrorCode.DATA_INVALID.name());
		Assert.assertEquals(CheckInValidationConstants.DEVELOPER_MESSAGE_BOOKING_IDENTIFIER,
				validationServiceException.getDeveloperMessage());
		Assert.assertEquals(CheckInValidationConstants.BOOKING_IDENTIFIER_PATH, validationServiceException.getPath());
	}

	@Test
	public void shouldValidateEmptydBookingIdentifier() {
		Mockito.when(validationServiceExceptionGenerator.createValidationError(CheckInErrorCode.DATA_INVALID.name(),
				CheckInValidationConstants.BOOKING_IDENTIFIER_PATH, CheckInValidationConstants.DEVELOPER_MESSAGE_BOOKING_IDENTIFIER))
				.thenReturn(createValidationServiceException(CheckInErrorCode.DATA_INVALID.name(),
						CheckInValidationConstants.BOOKING_IDENTIFIER_PATH,
						CheckInValidationConstants.DEVELOPER_MESSAGE_BOOKING_IDENTIFIER));
		validationServiceException = bookingIdentifierValidation.validate("");
		Assert.assertEquals(validationServiceException.getCode(), CheckInErrorCode.DATA_INVALID.name());
		Assert.assertEquals(CheckInValidationConstants.DEVELOPER_MESSAGE_BOOKING_IDENTIFIER,
				validationServiceException.getDeveloperMessage());
		Assert.assertEquals(CheckInValidationConstants.BOOKING_IDENTIFIER_PATH, validationServiceException.getPath());
	}

	@Test
	public void shouldValidateInvalidRangeBookingIdentifier() {
		Mockito.when(validationServiceExceptionGenerator.createValidationError(CheckInErrorCode.DATA_INVALID.name(),
				CheckInValidationConstants.BOOKING_IDENTIFIER_PATH, CheckInValidationConstants.DEVELOPER_MESSAGE_BOOKING_IDENTIFIER))
				.thenReturn(createValidationServiceException(CheckInErrorCode.DATA_INVALID.name(),
						CheckInValidationConstants.BOOKING_IDENTIFIER_PATH,
						CheckInValidationConstants.DEVELOPER_MESSAGE_BOOKING_IDENTIFIER));
		validationServiceException = bookingIdentifierValidation.validate(BOOKING_IDENTIFIER_ABOVERANGE_CHARACTER);
		Assert.assertEquals(validationServiceException.getCode(), CheckInErrorCode.DATA_INVALID.name());
		Assert.assertEquals(CheckInValidationConstants.DEVELOPER_MESSAGE_BOOKING_IDENTIFIER,
				validationServiceException.getDeveloperMessage());
		Assert.assertEquals(CheckInValidationConstants.BOOKING_IDENTIFIER_PATH, validationServiceException.getPath());
	}

	private ValidationServiceException createValidationServiceException(final String serviceErrorCode,
			final String path, final String developerMessage) {
		ValidationServiceException validationServiceException = new ValidationServiceException(serviceErrorCode);
		validationServiceException.setPath(path);
		validationServiceException.setDeveloperMessage(developerMessage);

		return validationServiceException;
	}
}
