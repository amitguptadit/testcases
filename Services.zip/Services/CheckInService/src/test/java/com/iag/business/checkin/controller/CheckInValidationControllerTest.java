package com.iag.business.checkin.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iag.business.checkin.application.exception.ValidationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.domain.response.CheckInValidation;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.error.matcher.CustomValidationServiceExceptionMatcher;
import com.iag.business.checkin.exception.ValidationServiceExceptionGenerator;
import com.iag.business.checkin.service.CheckInValidationService;
import com.iag.business.checkin.session.AmadeusSession;
import com.iag.business.checkin.validation.CheckInValidator;
import com.iag.domain.model.CheckIn;

/**
 * 
 *
 * Test class for check-in validation controller
 *
 */
public class CheckInValidationControllerTest {

	private final static String URI = "/bookings/CHK001/check-ins/validations";

	private final static String INVALID_URI = "/bookings/CHK001/checkins/";
	private final static String INVALID_BOOKING_IDENTIFIER = "KLDFDF08KLDF,.,{";
	private final static String SAMPLE_RESPONSE_FILENAME = "mock_response/amadeus_PAX2S.json";
	private final static String REQUEST_FILENAME = "static/Json/sampleRequest_1.json";
	private static final String DEVELOPER_MSG = "BOOKING_NOT_FOUND";
	private final static String FILENAME = "static/Json/sampleRequest_1.json";
	private final static String POST_REQUEST = "POST";

	private static final String BOOKING_IDENTIFIER = "CHK001";

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@InjectMocks
	private CheckInValidationController checkInValidationController;

	@Mock
	private ValidationServiceExceptionGenerator validationServiceExceptionGenerator;

	ValidationServiceException validationServiceException;

	private MockMvc mockMvc;

	Map<String, String> headerValueMap;

	CheckIn checkIn;

	@Mock
	AmadeusSession session;

	@Mock
	CheckInValidationService checkInValidationService;

	@Mock
	CheckInValidator checkInValidator;

	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		headerValueMap = new HashMap<String, String>();
		headerValueMap.put("tokennumber", "sec123");
		headerValueMap.put("sessionidentifier", "session123");
		headerValueMap.put("location", "GB");
		headerValueMap.put("channel", "KISOK");
		headerValueMap.put("scope", "BOOKINGS");
		mockMvc = MockMvcBuilders.standaloneSetup(checkInValidationController).build();
		session = new AmadeusSession();
		checkIn = new ObjectMapper().readValue(getJSONStringFromFile(FILENAME), CheckIn.class);
		HttpServletRequest httpServletRequestMock = new MockHttpServletRequest();
		ServletRequestAttributes servletRequestAttributes = new ServletRequestAttributes(httpServletRequestMock);
		RequestContextHolder.setRequestAttributes(servletRequestAttributes);
		validationServiceExceptionGenerator = mock(ValidationServiceExceptionGenerator.class);
	}

	@After
	public void teardown() {
		RequestContextHolder.resetRequestAttributes();
	}

	@Test
	public void shouldReturnHttpStatusAsNotAllowedWhenHttpMethodIsNotPost() throws Exception {
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(URI).accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON);
		ResultActions result = mockMvc.perform(request);
		result.andExpect(status().is4xxClientError()).andReturn();
		Assert.assertNotNull(result.andReturn().getRequest().getMethod());
		Assert.assertNotEquals(POST_REQUEST, result.andReturn().getRequest().getMethod());
		Assert.assertEquals(405, result.andReturn().getResponse().getStatus());
	}

	@Test
	public void shouldReturnHttpStatusAsNotAllowedWhenContentTypeIsNotJSON() throws Exception {
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post(URI).accept(MediaType.APPLICATION_ATOM_XML)
				.contentType(MediaType.APPLICATION_ATOM_XML);
		ResultActions result = mockMvc.perform(request);
		result.andExpect(status().isUnsupportedMediaType()).andReturn();
		Assert.assertNotNull(result.andReturn().getRequest().getMethod());
		Assert.assertEquals(415, result.andReturn().getResponse().getStatus());
	}

	@Test
	public void shouldTestCheckInvalidationSuccessResponse() throws Exception {
		CheckInValidation checkInValidation = getMappedResponse(SAMPLE_RESPONSE_FILENAME);
		Mockito.when(checkInValidationService.checkInValidation(Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenReturn(checkInValidation);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(URI).accept(MediaType.APPLICATION_JSON)
				.content(getJSONStringFromFile(REQUEST_FILENAME)).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.CREATED.value(), response.getStatus());
	}

	@Test
	public void shouldThrowValidationServiceExceptionWhenBookingIdentifierNotValid() {
		ValidationServiceException validationRequestInvalidDataException = createValidationServiceException(
				CheckInErrorCode.DATA_INVALID.name(), CheckInValidationConstants.BOOKING_IDENTIFIER_PATH,
				CheckInValidationConstants.DEVELOPER_MESSAGE_BOOKING_IDENTIFIER);
		Mockito.doThrow(validationRequestInvalidDataException).when(checkInValidator)
				.validate(INVALID_BOOKING_IDENTIFIER, checkIn, headerValueMap);
		exceptionRule.expect(ValidationServiceException.class);
		exceptionRule
				.expect(CustomValidationServiceExceptionMatcher.hasException(validationRequestInvalidDataException));
		checkInValidationController.checkInValidation(INVALID_BOOKING_IDENTIFIER, headerValueMap, checkIn).getBody();
	}

	@Test
	public void shouldReturnHttpStatusAsNotAllowedWhenRequestUrlIsNotValid() throws Exception {
		CheckInValidation checkInValidation = getMappedResponse(SAMPLE_RESPONSE_FILENAME);
		Mockito.when(checkInValidationService.checkInValidation(Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenReturn(checkInValidation);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(INVALID_URI).accept(MediaType.APPLICATION_JSON)
				.content(getJSONStringFromFile(REQUEST_FILENAME)).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().is4xxClientError()).andReturn();
		assertNotNull(result.getRequest());
		assertEquals(POST_REQUEST, result.getRequest().getMethod());
		assertEquals(404, result.getResponse().getStatus());
	}

	@Test
	public void shouldThrowValidationServiceExceptionWhenCheckInIsNull() throws Exception {
		ValidationServiceException validationRequestInvalidDataException = createValidationServiceException(
				CheckInErrorCode.REQUEST_INVALID.name(), CheckInErrorCode.DATA_INVALID.name(),
				CheckInValidationConstants.PASSENGER_PATH);
		Mockito.doThrow(validationRequestInvalidDataException).when(checkInValidator).validate(BOOKING_IDENTIFIER, null,
				headerValueMap);
		exceptionRule.expect(ValidationServiceException.class);
		exceptionRule
				.expect(CustomValidationServiceExceptionMatcher.hasException(validationRequestInvalidDataException));
		checkInValidationController.checkInValidation(BOOKING_IDENTIFIER, headerValueMap, null).getBody();
	}

	private ValidationServiceException createValidationServiceException(String parentErrorCode, String childErrorCode,
			String path) {
		ValidationServiceException validationServiceException = new ValidationServiceException(parentErrorCode);
		validationServiceException.addValidationException(createValidationServiceException(childErrorCode, path));
		return validationServiceException;
	}

	private ValidationServiceException createValidationServiceException(String errorCode, String path) {
		ValidationServiceException childValidationServiceException = new ValidationServiceException(errorCode);
		childValidationServiceException.setDeveloperMessage(DEVELOPER_MSG);
		childValidationServiceException.setPath(path);
		return childValidationServiceException;
	}

	@Test
	public void shouldTestSuccessResponse() throws IOException {
		CheckInValidation checkInValidation = getMappedResponse(SAMPLE_RESPONSE_FILENAME);
		Mockito.when(checkInValidationService.checkInValidation(Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenReturn(checkInValidation);
		CheckInValidation CheckInValidationObj = (CheckInValidation) checkInValidationService
				.checkInValidation(BOOKING_IDENTIFIER, session, checkIn);
		assertTrue(CheckInValidationObj.getTotalRecords() != 0);
		assertTrue(CheckInValidationObj.getTotalRecords() == CheckInValidationObj.getValidationOutcomes().size());
	}

	private CheckInValidation getMappedResponse(String fileName) throws IOException {
		InputStream inputstream = new ClassPathResource(fileName).getInputStream();
		CheckInValidation checkInValidation = new ObjectMapper().readValue(inputstream, CheckInValidation.class);
		return checkInValidation;
	}

	/**
	 * Used for returning JSON string from specified file name
	 * 
	 * @param fileName
	 * @return
	 */
	public String getJSONStringFromFile(String fileName) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONObject jsonObject;
		ClassLoader classLoader = getClass().getClassLoader();
		File jsonFile = new File(classLoader.getResource(fileName).getFile());
		jsonObject = (JSONObject) parser.parse(new FileReader(jsonFile));
		return jsonObject.toString();
	}

}
