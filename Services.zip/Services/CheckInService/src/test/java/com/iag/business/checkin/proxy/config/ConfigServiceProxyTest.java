package com.iag.business.checkin.proxy.config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iag.business.checkin.application.exception.ApplicationServiceException;
import com.iag.business.checkin.constant.CheckInValidationConstants;
import com.iag.business.checkin.error.CheckInErrorCode;
import com.iag.business.checkin.error.matcher.CustomApplicationServiceExceptionMatcher;
import com.iag.business.checkin.proxy.config.domain.Configuration;
import com.iag.business.checkin.proxy.config.domain.ConfigurationNamespaces;

public class ConfigServiceProxyTest {

	@InjectMocks
	ConfigServiceProxy configurationInfrastructureServiceProxy;

	private static final String BOOKING_IDENTIFIER_INVALID_MSG = "Booking identifier is invalid";
	private static final String REQUEST_INVALID_KEY = "checkinvalidation.error.REQUEST_INVALID.code";
	private static final String REQUEST_INVALID_DEVLINK_KEY = "checkinvalidation.error.REQUEST_INVALID.developer_link";
	private static final String REQUEST_INVALID_BUSINESS_MSG_KEY = "checkinvalidation.error.REQUEST_INVALID.business_message";
	private static final String INVALID_BOOKINGIDENTIFIER_DEV_MSG_KEY = "checkinvalidation.error.DATA_INVALID.developer_message_bookingidentifier";
	private static final String DATA_INVALID_KEY = "checkinvalidation.error.DATA_INVALID.code";
	private static final Map<String, String> serviceConfigMap = new HashMap<>();
	private final Map<String, Map<String, String>> configNamespacesMap = new ConcurrentHashMap<>();

	private final static String FILENAME = "static/Json/Error-checkinvalidation.json";
	private static final String DEVELOPER_LINK = "https://developer.iag.com";
	private static final String REQUEST_INVALID = "REQUEST_INVALID";
	private static final String CONFIG_SERVICE_URI = "config.service.uri";
	private static final String DATA_INVALID = "DATA_INVALID";
	private static final String REQUEST_INVALID_MESSAGE = "Request Invalid";

	private static final String SERVICENAME = "CONFIGURATION";

	private static final String CONFIGURATIONSERVICEURLMETADATA = "http://CONFIGURATIONISV1/configuration/{key}";

	@Mock
	RestTemplate restTemplate;

	@Mock
	private Environment environment;

	@Rule
	public ExpectedException thrown = ExpectedException.none();
	Configuration config;

	@Mock
	private RestTemplateBuilder restTemplateBuilder;

	@Mock
	private ServiceUrlGenerator serviceUrlGenerator;
	
	
	private final String configurationResourceIdentifierKey = "checkinvalidation";
	private final String configurationIdentifierKey = "checkinvalidationV1";


	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		config = setDummyConfigMap();
		when(restTemplateBuilder.build()).thenReturn(restTemplate);
		configurationInfrastructureServiceProxy = new ConfigServiceProxy(SERVICENAME, restTemplate,
				serviceUrlGenerator,configurationResourceIdentifierKey, configurationIdentifierKey);
	}

	@Test
	public void shouldThrowServiceExceptionWhenNoConfigurationFound() {
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(config,
				HttpStatus.NOT_FOUND);
		Mockito.when(serviceUrlGenerator.generateUrl(SERVICENAME)).thenReturn(CONFIGURATIONSERVICEURLMETADATA);
		Mockito.when(restTemplate.exchange(environment.getProperty(CONFIG_SERVICE_URI), HttpMethod.GET, null,
				Configuration.class)).thenReturn(configurationResponse);
		thrown.expect(ApplicationServiceException.class);
		thrown.expect(CustomApplicationServiceExceptionMatcher
				.hasException(new ApplicationServiceException(CheckInErrorCode.CONFIGURATION_NOT_FOUND.name())));
		configurationInfrastructureServiceProxy.retrieveConfiguration();
	}

	@SuppressWarnings({ "deprecation", "unchecked" })
	@Test
	public void shouldRetrieveConfigurationItemForSuccessResponse() {
		
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(config, HttpStatus.OK);
		Mockito.when(serviceUrlGenerator.generateUrl(SERVICENAME)).thenReturn(CONFIGURATIONSERVICEURLMETADATA);
		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class))).thenReturn(configurationResponse);
		configurationInfrastructureServiceProxy.retrieveConfiguration(CheckInValidationConstants.ERROR_NAMESPACE,
				REQUEST_INVALID_KEY);
		assertEquals(REQUEST_INVALID, configurationInfrastructureServiceProxy
				.retrieveConfiguration(CheckInValidationConstants.ERROR_NAMESPACE, REQUEST_INVALID_KEY));
		assertEquals(DATA_INVALID, configurationInfrastructureServiceProxy
				.retrieveConfiguration(CheckInValidationConstants.ERROR_NAMESPACE, DATA_INVALID_KEY));
		assertEquals(DEVELOPER_LINK, configurationInfrastructureServiceProxy
				.retrieveConfiguration(CheckInValidationConstants.ERROR_NAMESPACE, REQUEST_INVALID_DEVLINK_KEY));
		assertEquals(REQUEST_INVALID_MESSAGE, configurationInfrastructureServiceProxy
				.retrieveConfiguration(CheckInValidationConstants.ERROR_NAMESPACE, REQUEST_INVALID_BUSINESS_MSG_KEY));
		assertEquals(BOOKING_IDENTIFIER_INVALID_MSG, configurationInfrastructureServiceProxy.retrieveConfiguration(
				CheckInValidationConstants.ERROR_NAMESPACE, INVALID_BOOKINGIDENTIFIER_DEV_MSG_KEY));
	}

	@Test
	public void shouldThrowResourceAccessExceptionForInvalidURL() {
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(config,
				HttpStatus.NOT_FOUND);
		Mockito.when(serviceUrlGenerator.generateUrl(SERVICENAME)).thenReturn(CONFIGURATIONSERVICEURLMETADATA);
		Mockito.when(restTemplate.exchange(null, HttpMethod.GET, null, Configuration.class))
				.thenReturn(configurationResponse);
		thrown.expect(ApplicationServiceException.class);
		thrown.expect(CustomApplicationServiceExceptionMatcher
				.hasException(new ApplicationServiceException(CheckInErrorCode.CONFIGURATION_NOT_FOUND.name())));
		configurationInfrastructureServiceProxy.retrieveConfiguration();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldThrowExceptionOnBadRequest() {
		ResponseEntity<Configuration> configurationResponse = new ResponseEntity<Configuration>(config,
				HttpStatus.NOT_FOUND);
		Mockito.when(serviceUrlGenerator.generateUrl(SERVICENAME)).thenReturn(CONFIGURATIONSERVICEURLMETADATA);
		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class),
				Matchers.<HttpEntity<?>>any(), Mockito.any(Class.class))).thenReturn(configurationResponse);
		thrown.expect(ApplicationServiceException.class);
		thrown.expect(CustomApplicationServiceExceptionMatcher
				.hasException(new ApplicationServiceException(CheckInErrorCode.CONFIGURATION_NOT_FOUND.name())));
		configurationInfrastructureServiceProxy.retrieveConfiguration();
	}

	public Configuration setDummyConfigMap() throws IOException, ParseException {
		Configuration configuration = null;
		configuration = new ObjectMapper().readValue(getJSONStringFromFile(FILENAME), Configuration.class);
		List<ConfigurationNamespaces> configurationList = ((Configuration) configuration).getConfigurationNamespaces();
		for (ConfigurationNamespaces configurationNamespaces : configurationList) {
			configurationNamespaces.getConfigurationItems().forEach(configurationItem -> {
				serviceConfigMap.put(configurationItem.getIdentifier(), configurationItem.getValue());
			});
			configNamespacesMap.put(configurationNamespaces.getName(), serviceConfigMap);
		}
		return configuration;
	}

	@Test
	public void shouldThrowExceptionOnInavlidUrlGeneration() {
		Mockito.when(serviceUrlGenerator.generateUrl(SERVICENAME)).thenReturn(null);
		thrown.expect(ApplicationServiceException.class);
		thrown.expect(CustomApplicationServiceExceptionMatcher
				.hasException(new ApplicationServiceException(CheckInErrorCode.SYSTEM_UNAVAILABLE.name())));
		configurationInfrastructureServiceProxy.retrieveConfiguration(CheckInValidationConstants.ERROR_NAMESPACE,
				REQUEST_INVALID_KEY);
	}

	/**
	 * Used for returning JSON string from specified file name
	 * 
	 * @param fileName
	 * @return
	 */
	public String getJSONStringFromFile(String fileName) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONObject jsonObject;
		ClassLoader classLoader = getClass().getClassLoader();
		File jsonFile = new File(classLoader.getResource(fileName).getFile());
		jsonObject = (JSONObject) parser.parse(new FileReader(jsonFile));
		return jsonObject.toString();
	}
}
